import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: {
    target: 'es2020',
    emptyOutDir: true,
    // Three.js and OrbitControls intentionally stay in one offline-capable chunk.
    chunkSizeWarningLimit: 600,
  },
});
