import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const MASS = 1;
const HORIZON_U = 0.5;
const CRITICAL_IMPACT_PARAMETER = Math.sqrt(27);

function acceleration(u) {
  return 3 * MASS * u * u - u;
}

function rk4(u, du, h) {
  const k1u = du;
  const k1d = acceleration(u);
  const k2u = du + 0.5 * h * k1d;
  const k2d = acceleration(u + 0.5 * h * k1u);
  const k3u = du + 0.5 * h * k2d;
  const k3d = acceleration(u + 0.5 * h * k2u);
  const k4u = du + h * k3d;
  const k4d = acceleration(u + h * k3u);

  return [
    u + h * (k1u + 2 * k2u + 2 * k3u + k4u) / 6,
    du + h * (k1d + 2 * k2d + 2 * k3d + k4d) / 6,
  ];
}

function smoothstep(a, b, x) {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

function initialStateForImpactParameter(b, observerRadius = 32) {
  const u = 1 / observerRadius;
  const A = 1 - 2 / observerRadius;
  const tangential = b * Math.sqrt(A) / observerRadius;
  const radial = -Math.sqrt(1 - tangential * tangential);
  const du = -u * Math.sqrt(A) * radial / tangential;
  return [u, du];
}

function trace(b, limit = 1200) {
  let [u, du] = initialStateForImpactParameter(b);
  for (let step = 0; step < limit; step += 1) {
    const h = 0.028 + (0.009 - 0.028) * smoothstep(0.07, 0.28, u);
    [u, du] = rk4(u, du, h);
    if (u >= HORIZON_U) return 'captured';
    if (u <= 0) return 'escaped';
  }
  return 'critical';
}

function invariant(u, du) {
  return du * du + u * u - 2 * MASS * u * u * u;
}

// u = 1/(3M), u' = 0 is the unstable circular photon orbit.
let circularU = 1 / 3;
let circularDu = 0;
for (let i = 0; i < 1000; i += 1) {
  [circularU, circularDu] = rk4(circularU, circularDu, 0.01);
}
assert.equal(circularU, 1 / 3);
assert.equal(circularDu, 0);

// The first integral must remain 1/b² along a null geodesic.
let [u, du] = initialStateForImpactParameter(6);
const initialInvariant = invariant(u, du);
for (let i = 0; i < 250; i += 1) {
  [u, du] = rk4(u, du, 0.01);
}
assert.ok(Math.abs(invariant(u, du) - initialInvariant) < 1e-10);
assert.ok(Math.abs(initialInvariant - 1 / 36) < 1e-12);

// The exact Schwarzschild shadow boundary is b_crit = sqrt(27) M.
assert.equal(trace(CRITICAL_IMPACT_PARAMETER * 0.999), 'captured');
assert.equal(trace(CRITICAL_IMPACT_PARAMETER * 1.001), 'escaped');

const shader = await readFile(new URL('../src/black-hole.frag.glsl', import.meta.url), 'utf8');
assert.match(shader, /3\.0 \* MASS \* u \* u - u/);
assert.match(shader, /const float HORIZON_RADIUS = 2\.0/);
assert.match(shader, /const float DISK_INNER_RADIUS = 6\.0/);

console.log('Geodesic checks passed: photon sphere, invariant, and critical impact parameter.');
