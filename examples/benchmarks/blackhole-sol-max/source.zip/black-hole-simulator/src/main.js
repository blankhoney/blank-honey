import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import fragmentShader from './black-hole.frag.glsl?raw';
import './style.css';

const app = document.querySelector('#app');
const status = document.querySelector('#status');
const distanceLabel = document.querySelector('#observer-distance');
const orbitButton = document.querySelector('#orbit-toggle');
const resetButton = document.querySelector('#reset-view');

const MAX_RENDER_PIXELS = 1_800_000;
const INITIAL_POSITION = new THREE.Vector3(0, 13, 42);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

let renderer;

try {
  renderer = new THREE.WebGLRenderer({
    antialias: false,
    alpha: false,
    powerPreference: 'high-performance',
  });
} catch (error) {
  status.textContent = `无法启动 WebGL：${error.message}`;
  status.classList.add('status--error');
  throw error;
}

renderer.setClearColor(0x000005, 1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.append(renderer.domElement);
renderer.domElement.setAttribute('aria-label', '可交互的 Schwarzschild 黑洞模拟画布');

const viewCamera = new THREE.PerspectiveCamera(46, 1, 0.1, 500);
viewCamera.position.copy(INITIAL_POSITION);

const controls = new OrbitControls(viewCamera, renderer.domElement);
controls.target.set(0, 0, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.045;
controls.enablePan = false;
controls.minDistance = 26;
controls.maxDistance = 72;
controls.minPolarAngle = 0.12;
controls.maxPolarAngle = Math.PI - 0.12;
controls.autoRotate = !reducedMotion;
controls.autoRotateSpeed = 0.34;
controls.update();
controls.saveState();

const uniforms = {
  uResolution: { value: new THREE.Vector2(1, 1) },
  uTime: { value: 0 },
  uCameraPosition: { value: new THREE.Vector3() },
  uCameraRight: { value: new THREE.Vector3() },
  uCameraUp: { value: new THREE.Vector3() },
  uCameraForward: { value: new THREE.Vector3() },
  uTanHalfFov: { value: Math.tan(THREE.MathUtils.degToRad(viewCamera.fov * 0.5)) },
  uIntegrationSteps: { value: 1200 },
};

const scene = new THREE.Scene();
const screenCamera = new THREE.Camera();
const material = new THREE.RawShaderMaterial({
  glslVersion: THREE.GLSL3,
  uniforms,
  vertexShader: /* glsl */ `
    precision highp float;
    in vec3 position;
    void main() {
      gl_Position = vec4(position, 1.0);
    }
  `,
  fragmentShader,
  depthTest: false,
  depthWrite: false,
  toneMapped: false,
});
scene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material));

const basis = {
  right: new THREE.Vector3(),
  up: new THREE.Vector3(),
  back: new THREE.Vector3(),
};
const clock = new THREE.Clock();
let frame = 0;

function updateOrbitButton() {
  orbitButton.textContent = controls.autoRotate ? '暂停自动环绕' : '继续自动环绕';
  orbitButton.setAttribute('aria-pressed', String(controls.autoRotate));
}

function resize() {
  const width = Math.max(innerWidth, 1);
  const height = Math.max(innerHeight, 1);
  const nativeRatio = Math.max(devicePixelRatio || 1, 1);
  const budgetRatio = Math.sqrt(MAX_RENDER_PIXELS / (width * height));
  renderer.setPixelRatio(Math.min(nativeRatio, Math.max(0.5, budgetRatio)));
  renderer.setSize(width, height, false);
  renderer.getDrawingBufferSize(uniforms.uResolution.value);
  viewCamera.aspect = width / height;
  viewCamera.updateProjectionMatrix();
}

function updateCameraUniforms() {
  viewCamera.updateMatrixWorld();
  viewCamera.matrixWorld.extractBasis(basis.right, basis.up, basis.back);
  uniforms.uCameraPosition.value.copy(viewCamera.position);
  uniforms.uCameraRight.value.copy(basis.right).normalize();
  uniforms.uCameraUp.value.copy(basis.up).normalize();
  uniforms.uCameraForward.value.copy(basis.back).normalize().negate();
}

function render() {
  const delta = Math.min(clock.getDelta(), 0.05);
  controls.update(delta);
  updateCameraUniforms();
  uniforms.uTime.value += delta;
  renderer.render(scene, screenCamera);

  if (frame++ % 12 === 0) {
    distanceLabel.textContent = `${viewCamera.position.length().toFixed(1)} M`;
  }
  requestAnimationFrame(render);
}

orbitButton.addEventListener('click', () => {
  controls.autoRotate = !controls.autoRotate;
  updateOrbitButton();
});

resetButton.addEventListener('click', () => {
  controls.reset();
  controls.autoRotate = !reducedMotion;
  updateOrbitButton();
});

controls.addEventListener('start', () => {
  if (controls.autoRotate) {
    controls.autoRotate = false;
    updateOrbitButton();
  }
});

renderer.domElement.addEventListener('webglcontextlost', (event) => {
  event.preventDefault();
  status.textContent = 'WebGL 上下文已丢失，请刷新页面恢复。';
  status.classList.add('status--error');
});

addEventListener('resize', resize, { passive: true });
resize();
updateCameraUniforms();
updateOrbitButton();
status.textContent = '物理积分器运行中';
status.classList.add('status--ready');
render();
