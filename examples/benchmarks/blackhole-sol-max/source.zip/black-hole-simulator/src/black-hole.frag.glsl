precision highp float;
precision highp int;

uniform vec2 uResolution;
uniform float uTime;
uniform vec3 uCameraPosition;
uniform vec3 uCameraRight;
uniform vec3 uCameraUp;
uniform vec3 uCameraForward;
uniform float uTanHalfFov;
uniform int uIntegrationSteps;

out vec4 outColor;

const float PI = 3.14159265358979323846;
const float TAU = 6.28318530717958647692;
const float MASS = 1.0;
const float HORIZON_RADIUS = 2.0;
const float DISK_INNER_RADIUS = 6.0;
const float DISK_OUTER_RADIUS = 24.0;
const float DISK_HALF_THICKNESS = 0.035;
const float NT_PEAK_FLUX = 1.13674e-4;
const int MAX_STEPS = 1200;

float hash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p) {
  vec2 cell = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash12(cell), hash12(cell + vec2(1.0, 0.0)), f.x),
    mix(hash12(cell + vec2(0.0, 1.0)), hash12(cell + 1.0), f.x),
    f.y
  );
}

float fbm(vec2 p) {
  float sum = 0.0;
  float amplitude = 0.5;
  mat2 rotation = mat2(0.80, -0.60, 0.60, 0.80);
  for (int octave = 0; octave < 5; octave++) {
    sum += amplitude * valueNoise(p);
    p = rotation * p * 2.03 + 7.1;
    amplitude *= 0.5;
  }
  return sum;
}

vec2 skyUv(vec3 direction) {
  return vec2(
    atan(direction.z, direction.x) / TAU + 0.5,
    asin(clamp(direction.y, -1.0, 1.0)) / PI + 0.5
  );
}

vec3 starLayer(vec2 uv, float scale, float threshold) {
  vec2 grid = vec2(scale, scale * 0.5);
  vec2 cell = floor(uv * grid);
  vec2 local = fract(uv * grid) - 0.5;
  float seed = hash12(cell);
  float exists = smoothstep(threshold, 1.0, seed);
  float radius = mix(0.17, 0.055, fract(seed * 73.13));
  float distanceToStar = length(local);
  float core = 1.0 - smoothstep(radius * 0.18, radius, distanceToStar);
  float glow = exp(-55.0 * distanceToStar * distanceToStar) * 0.16;
  float temperature = fract(seed * 17.71);
  vec3 tint = mix(vec3(1.0, 0.66, 0.38), vec3(0.61, 0.76, 1.0), temperature);
  return tint * exists * (core * mix(2.0, 8.0, seed * seed) + glow);
}

vec3 sampleSky(vec3 direction) {
  direction = normalize(direction);
  vec2 uv = skyUv(direction);
  vec3 galacticNormal = normalize(vec3(-0.23, 0.91, 0.34));
  float latitude = abs(dot(direction, galacticNormal));
  float band = exp(-pow(latitude * 7.2, 1.35));
  float clouds = fbm(vec2(uv.x * 9.0, uv.y * 15.0) + vec2(2.3, -1.7));
  float detail = fbm(vec2(uv.x * 31.0, uv.y * 46.0));
  float dustLane = smoothstep(0.13, 0.0, latitude) * smoothstep(0.72, 0.27, clouds);

  vec3 sky = vec3(0.0018, 0.0035, 0.0090);
  sky += band * mix(vec3(0.012, 0.020, 0.047), vec3(0.22, 0.095, 0.040), clouds)
    * (0.24 + 0.95 * detail);
  sky *= 1.0 - 0.78 * dustLane;
  sky += starLayer(uv, 390.0, 0.9940);
  sky += starLayer(uv + vec2(0.173, 0.317), 790.0, 0.9974);
  return sky;
}

// Page-Thorne / Novikov-Thorne zero-torque flux for a Schwarzschild disk,
// with G = c = M = 1. The omitted constant only fixes the display exposure.
float novikovThorneFlux(float r) {
  if (r <= DISK_INNER_RADIUS) return 0.0;
  float rootR = sqrt(r);
  float root6 = sqrt(6.0);
  float root3 = sqrt(3.0);
  float ratio = ((rootR - root3) / (rootR + root3))
    / ((root6 - root3) / (root6 + root3));
  float integral = rootR - root6 - 0.5 * root3 * log(ratio);
  return max(integral, 0.0) / (pow(r, 2.5) * (r - 3.0));
}

vec3 blackbodyRgb(float kelvin) {
  float t = clamp(kelvin, 1000.0, 40000.0) / 100.0;
  float red;
  float green;
  float blue;

  if (t <= 66.0) {
    red = 1.0;
    green = 0.39008158 * log(t) - 0.63184144;
    blue = t <= 19.0 ? 0.0 : 0.54320679 * log(t - 10.0) - 1.19625409;
  } else {
    red = 1.29293619 * pow(t - 60.0, -0.13320476);
    green = 1.12989086 * pow(t - 60.0, -0.07551485);
    blue = 1.0;
  }
  return clamp(vec3(red, green, blue), 0.0, 1.0);
}

vec3 shadeDisk(vec3 hit, float observerA, float photonLambda) {
  float r = length(hit.xz);
  float flux = novikovThorneFlux(r);
  float normalizedFlux = flux / NT_PEAK_FLUX;

  // Exact frequency-shift factor for a circular Schwarzschild emitter:
  // g = sqrt(1 - 3M/r) / [sqrt(A_obs) (1 - Omega lambda)].
  float omega = pow(r, -1.5);
  float denominator = sqrt(observerA) * (1.0 - omega * photonLambda);
  float g = clamp(sqrt(max(1.0 - 3.0 / r, 0.0)) / denominator, 0.12, 3.5);

  float azimuth = atan(hit.z, hit.x);
  float advectedPhase = azimuth - omega * uTime * 4.0;
  float turbulence = fbm(vec2(advectedPhase * 4.2, log(r) * 12.0));
  float filaments = valueNoise(vec2(advectedPhase * 16.0, r * 2.4));
  float density = mix(0.74, 1.24, 0.72 * turbulence + 0.28 * filaments);

  float localTemperature = 9000.0 * pow(max(normalizedFlux, 1.0e-5), 0.25);
  vec3 spectralColor = blackbodyRgb(localTemperature * g);
  float bolometricRadiance = normalizedFlux * pow(g, 4.0) * density;
  float softEdges = smoothstep(DISK_INNER_RADIUS, DISK_INNER_RADIUS + 0.18, r)
    * (1.0 - smoothstep(DISK_OUTER_RADIUS - 1.5, DISK_OUTER_RADIUS, r));

  return spectralColor * bolometricRadiance * softEdges * 4.2;
}

// Exact Schwarzschild null-geodesic orbit equation in the ray's orbital plane:
// u''(phi) = 3 M u^2 - u, where u = 1/r and G = c = M = 1.
float orbitAcceleration(float u) {
  return 3.0 * MASS * u * u - u;
}

void rk4Orbit(inout float u, inout float du, float h) {
  float k1u = du;
  float k1d = orbitAcceleration(u);
  float k2u = du + 0.5 * h * k1d;
  float k2d = orbitAcceleration(u + 0.5 * h * k1u);
  float k3u = du + 0.5 * h * k2d;
  float k3d = orbitAcceleration(u + 0.5 * h * k2u);
  float k4u = du + h * k3d;
  float k4d = orbitAcceleration(u + h * k3u);
  u += h * (k1u + 2.0 * k2u + 2.0 * k3u + k4u) / 6.0;
  du += h * (k1d + 2.0 * k2d + 2.0 * k3d + k4d) / 6.0;
}

bool diskIntersection(vec3 previous, vec3 current, out vec3 hit) {
  bool crossesPlane = (previous.y > 0.0 && current.y <= 0.0)
    || (previous.y < 0.0 && current.y >= 0.0);

  if (crossesPlane) {
    float t = previous.y / (previous.y - current.y);
    hit = mix(previous, current, clamp(t, 0.0, 1.0));
  } else if (abs(previous.y) < DISK_HALF_THICKNESS
    && abs(current.y) < DISK_HALF_THICKNESS) {
    // A finite numerical photosphere keeps an exactly edge-on thin disk sampled.
    hit = current;
    hit.y = 0.0;
  } else {
    return false;
  }

  float diskRadius = length(hit.xz);
  return diskRadius >= DISK_INNER_RADIUS && diskRadius <= DISK_OUTER_RADIUS;
}

vec3 traceSchwarzschildRay(vec3 rayOrigin, vec3 rayDirection) {
  float observerRadius = length(rayOrigin);
  float observerA = max(1.0 - 2.0 * MASS / observerRadius, 1.0e-5);
  vec3 radialBasis = rayOrigin / observerRadius;
  float localRadialDirection = dot(rayDirection, radialBasis);
  vec3 tangent = rayDirection - localRadialDirection * radialBasis;
  float localTangentialDirection = length(tangent);

  if (localTangentialDirection < 1.0e-5) {
    return localRadialDirection < 0.0 ? vec3(0.0) : sampleSky(rayDirection);
  }

  vec3 tangentBasis = tangent / localTangentialDirection;
  float u = 1.0 / observerRadius;
  float du = -u * sqrt(observerA) * localRadialDirection / localTangentialDirection;
  float phi = 0.0;
  vec3 previous = rayOrigin;

  // The future-directed photon travels opposite our past-directed camera ray.
  float photonLambda = -cross(rayOrigin, rayDirection).y / sqrt(observerA);

  for (int iteration = 0; iteration < MAX_STEPS; iteration++) {
    if (iteration >= uIntegrationSteps) break;

    // Larger steps are safe asymptotically; resolve the photon sphere finely.
    float h = mix(0.028, 0.009, smoothstep(0.07, 0.28, u));
    rk4Orbit(u, du, h);
    phi += h;

    vec3 planeRadial = cos(phi) * radialBasis + sin(phi) * tangentBasis;
    if (u <= 0.0) return sampleSky(planeRadial);

    float radius = 1.0 / u;
    vec3 current = radius * planeRadial;
    vec3 diskHit;

    if (diskIntersection(previous, current, diskHit)) {
      return shadeDisk(diskHit, observerA, photonLambda);
    }
    if (radius <= HORIZON_RADIUS * 1.0005) return vec3(0.0);
    if (radius > 180.0 && du < 0.0) return sampleSky(planeRadial);

    previous = current;
  }

  // Rays remaining near r = 3M are the asymptotic critical curve.
  return vec3(0.0);
}

vec3 acesToneMap(vec3 color) {
  const float a = 2.51;
  const float b = 0.03;
  const float c = 2.43;
  const float d = 0.59;
  const float e = 0.14;
  return clamp((color * (a * color + b)) / (color * (c * color + d) + e), 0.0, 1.0);
}

void main() {
  vec2 ndc = gl_FragCoord.xy / uResolution * 2.0 - 1.0;
  ndc.x *= uResolution.x / uResolution.y;
  vec3 rayDirection = normalize(
    uCameraForward
    + ndc.x * uTanHalfFov * uCameraRight
    + ndc.y * uTanHalfFov * uCameraUp
  );

  vec3 hdr = traceSchwarzschildRay(uCameraPosition, rayDirection);
  vec3 mapped = acesToneMap(hdr);
  mapped = pow(mapped, vec3(1.0 / 2.2));

  float vignette = 1.0 - 0.10 * dot(ndc * vec2(0.58, 0.42), ndc * vec2(0.58, 0.42));
  outColor = vec4(mapped * vignette, 1.0);
}
