# Schwarzschild Black Hole Simulator

这是一个浏览器内实时运行的 Schwarzschild 黑洞模拟。它不是用二维扭曲或经验透镜公式伪造效果：GPU 会为每个像素积分广义相对论零测地线，再求射线与吸积盘或无穷远天球的交点。

## 直接观看

双击项目根目录的 `standalone.html`。它已经内联 Three.js、OrbitControls、着色器和样式，不需要安装依赖、不需要网络，也不需要启动服务器。

`dist/` 是可直接部署到任意静态托管的生产构建；本项目没有执行发布或上传。

## 安装与启动

```bash
npm ci
npm run dev
```

Vite 会打印本地地址，在浏览器中打开即可。生产构建与检查：

```bash
npm test
npm run build
```

若只查看普通生产构建：

```bash
python3 -m http.server 8080 -d dist
```

然后访问 `http://localhost:8080`。`npm run build` 还会同步生成根目录与 `dist/` 内的离线单文件版本。

## 操作

- 鼠标左键拖动或单指拖动：旋转观测者视角（Three.js `OrbitControls`）
- 滚轮或双指捏合：缩放观测距离
- 页面打开后会自动缓慢环绕；一旦手动拖动会停止自动环绕
- “暂停/继续自动环绕”和“重置视角”可恢复默认状态

## 物理模型

全部计算采用几何单位 `G = c = M = 1`。Schwarzschild 度规为：

```text
ds² = -(1 - 2M/r) dt² + (1 - 2M/r)⁻¹ dr² + r²(dθ² + sin²θ dφ²)
```

球对称性保证每条光线都位于一个通过原点的轨道平面。令 `u = 1/r`，片元着色器直接积分精确的 Schwarzschild 零测地线轨道方程：

```text
d²u/dφ² + u = 3Mu²
```

屏幕射线先从有限半径静止观测者的局域正交标架映射到坐标导数：

```text
b = rₒ nφ / √(1 - 2M/rₒ)
u′ₒ = -uₒ √(1 - 2M/rₒ) nr / nφ
```

随后使用靠近光子球时自动缩小步长的四阶 Runge–Kutta 积分。`r = 2M` 为事件视界，`r = 3M` 为不稳定光子球；无穷远观测者的精确临界碰撞参数是 `bcrit = √27 M`。数值测试会检查光子球定解、一阶积分守恒量及临界捕获/逃逸边界。

吸积盘采用非旋转黑洞的零力矩 Novikov–Thorne / Page–Thorne 薄盘通量，内缘严格位于 `ISCO = 6M`。对半径 `r` 的圆轨道发射体，代码使用有限距离静止观测者的精确频移因子：

```text
g = √(1 - 3M/r) / [√(1 - 2M/rₒ) (1 - Ωλ)]
Ω = r⁻³ᐟ²
```

观测到的盘面总辐亮度按 `g⁴` 变换，因此可同时看到引力红移、相对论多普勒偏色与迎向侧增亮。温度颜色、ACES 色调映射和小幅随轨道平流的密度涨落只负责把物理动态范围映射到普通显示器。

## 保真度边界

这是 `a = 0` 的 Schwarzschild 解，不是旋转 Kerr 黑洞；未模拟等离子体色散、磁流体、自引力、康普顿散射或完整频率相关辐射转移。星空是程序生成的无穷远纹理。为让完全侧视时仍能稳定采样，零厚度薄盘使用了 `0.035M` 的数值光球层；这不会替代测地线积分。渲染分辨率按约 180 万像素封顶，临界曲线最多积分 1200 步，以保持交互性。

## 项目结构

```text
black-hole-simulator/
├── index.html                       # 页面与可访问控件
├── src/
│   ├── main.js                      # Three.js、OrbitControls、相机与渲染循环
│   ├── black-hole.frag.glsl         # GR 测地线与吸积盘 GPU 光线追踪
│   └── style.css                    # 响应式 HUD
├── tests/geodesic.test.mjs          # 无测试框架的物理数值检查
├── scripts/make-standalone.mjs      # 生成离线单 HTML
├── dist/                            # 可发布静态构建
├── standalone.html                  # 双击即可运行的离线版本
├── package.json
├── package-lock.json
└── vite.config.js
```

## 本次构建结果

在 Node.js `v22.23.0`、npm `10.9.8` 下已执行 `npm test` 与 `npm run build`：数值检查通过，Vite 生产构建成功，并生成离线单 HTML。遵照交付约束，没有启动常驻服务，也没有打开浏览器，因此尚未做浏览器视觉验收或 GPU 帧率实测。

## 主要参考

- K. Schwarzschild, *Über das Gravitationsfeld eines Massenpunktes nach der Einsteinschen Theorie* (1916)
- D. N. Page & K. S. Thorne, *Disk-Accretion onto a Black Hole. Time-Averaged Structure of Accretion Disk* (1974), DOI: 10.1086/152990
- J.-P. Luminet, *Image of a Spherical Black Hole with Thin Accretion Disk* (1979), DOI: 10.1051/0004-6361/75/1/228
