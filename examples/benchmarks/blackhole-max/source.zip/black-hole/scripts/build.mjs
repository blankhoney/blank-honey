import { build, context } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const options = {
  absWorkingDir: root,
  entryPoints: ['src/main.js'], bundle: true, minify: true,
  format: 'iife', target: ['es2020'], write: false,
  legalComments: 'inline', loader: { '.glsl': 'text' },
  plugins: [{ name: 'standalone-html', setup(builder) {
    builder.onEnd(async result => {
      if (result.errors.length) return;
      const [template, css, notices] = await Promise.all([
        readFile(resolve(root, 'src/template.html'), 'utf8'),
        readFile(resolve(root, 'src/style.css'), 'utf8'),
        readFile(resolve(root, 'THIRD_PARTY_NOTICES.md'), 'utf8')
      ]);
      const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
      const html = template.replace('/* INLINE_STYLES */', () => css).replace('/* INLINE_SCRIPT */', () => js);
      await writeFile(resolve(root, 'index.html'), html + '\n<!--\n' + notices.replaceAll('-->', '-- >') + '\n-->\n');
      console.log(`Built offline index.html (${Math.round(Buffer.byteLength(js) / 1024)} KB JavaScript).`);
    });
  }}]
};
if (process.argv.includes('--watch')) {
  const ctx = await context(options);
  await ctx.watch();
  const { watch } = await import('node:fs');
  for (const name of ['template.html', 'style.css']) watch(resolve(root, 'src', name), () => ctx.rebuild());
  await import('./serve.mjs');
} else await build(options);
