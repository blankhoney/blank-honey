import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';
import vertexShader from './shaders/fullscreen.vert.glsl';
import geodesicShader from './shaders/geodesic.frag.glsl';
import radianceShader from './shaders/radiance.frag.glsl';
import { FLUX_PEAK, createBlackbodyTable } from './physics.js';

const $ = id => document.getElementById(id);
const viewport = $('viewport');
const qualityOptions = {
  balanced: { step: 0.045, scale: 0.90, maxPixels: 1150000 },
  high: { step: 0.025, scale: 1.50, maxPixels: 2400000 },
  ultra: { step: 0.012, scale: 1.80, maxPixels: 4200000 }
};
const state = {
  playing: true, time: 0, speed: 12, quality: 'high', mode: 0,
  dirty: true, refined: false, lastInteraction: 0, width: 1, height: 1,
  geometryCount: 0, frames: 0, fps: 0, ready: false, fatal: false,
  errors: [], traceWidth: 0, traceHeight: 0
};

function fail(message) {
  state.fatal = true;
  state.errors.push(message);
  $('loading').hidden = true;
  $('error').hidden = false;
  $('error').textContent = message;
  $('status').textContent = '渲染不可用';
}

function createSky() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048; canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  const pixels = ctx.createImageData(canvas.width, canvas.height);
  let seed = 73013;
  const random = () => ((seed = (1664525 * seed + 1013904223) >>> 0) / 4294967296);
  for (let y = 0; y < canvas.height; y++) {
    const latitude = (y / canvas.height - 0.5) * Math.PI;
    for (let x = 0; x < canvas.width; x++) {
      const longitude = (x / canvas.width - 0.5) * Math.PI * 2;
      const band = Math.sin(latitude) * 0.81 + Math.cos(latitude) * Math.sin(longitude + 0.9) * 0.58;
      const cloud = Math.exp(-band * band * 35) * (0.6 + 0.2 * Math.sin(longitude * 13 + latitude * 31) + 0.2 * random());
      const p = 4 * (y * canvas.width + x);
      pixels.data.set([3 + cloud * 15, 4 + cloud * 17, 7 + cloud * 22, 255], p);
    }
  }
  ctx.putImageData(pixels, 0, 0);
  for (let i = 0; i < 6100; i++) {
    const x = random() * canvas.width;
    const latitude = Math.asin(random() * 2 - 1);
    const y = (latitude / Math.PI + 0.5) * canvas.height;
    const radius = 0.22 + random() ** 7 * 1.7;
    const bright = 80 + Math.floor(random() * 175);
    const warm = random() > 0.72;
    ctx.save(); ctx.translate(x, y); ctx.scale(1 / Math.max(0.2, Math.cos(latitude)), 1);
    const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, radius * 2.8);
    gradient.addColorStop(0, `rgba(${warm ? bright : bright * 0.83},${bright * 0.9},${warm ? bright * 0.72 : bright},1)`);
    gradient.addColorStop(0.22, `rgba(${bright},${bright},${bright},0.55)`);
    gradient.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gradient; ctx.fillRect(-radius * 3, -radius * 3, radius * 6, radius * 6); ctx.restore();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  return texture;
}

function main() {
  const canvas = document.createElement('canvas');
  canvas.setAttribute('aria-label', 'Schwarzschild 黑洞光线追踪画面。拖动旋转，滚轮缩放。');
  canvas.setAttribute('role', 'img');
  const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance', preserveDrawingBuffer: true });
  if (!gl || !gl.getExtension('EXT_color_buffer_float')) {
    fail('此模拟需要 WebGL 2 和浮点颜色缓冲支持。请使用开启硬件加速的较新版本 Chrome、Edge、Firefox 或 Safari。');
    return;
  }
  const renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: false, alpha: false });
  renderer.setPixelRatio(1);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.debug.onShaderError = (context, program, vertex, fragment) => {
    const error = [context.getProgramInfoLog(program), context.getShaderInfoLog(vertex), context.getShaderInfoLog(fragment)].filter(Boolean).join('\n');
    console.error(error); fail(`着色器编译失败：${error}`);
  };
  viewport.prepend(canvas);
  const camera = new THREE.PerspectiveCamera(39, 1, 0.1, 1000);
  function preset(which) {
    const inclination = which === 'top' ? 5 : which === 'edge' ? 88.7 : 76;
    const radius = which === 'top' ? 62 : 56;
    camera.position.setFromSphericalCoords(radius, THREE.MathUtils.degToRad(inclination), 0);
    camera.lookAt(0, 0, 0);
  }
  preset('orbit');
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.085;
  controls.enablePan = false;
  controls.rotateSpeed = 0.65;
  controls.zoomSpeed = 0.7;
  controls.minDistance = 26;
  controls.maxDistance = 110;
  controls.minPolarAngle = 0.005;
  controls.maxPolarAngle = Math.PI - 0.005;
  controls.target.set(0, 0, 0);
  controls.update();
  controls.saveState();

  const quadGeometry = new THREE.PlaneGeometry(2, 2);
  const screenCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const rayTarget = new THREE.WebGLRenderTarget(1, 1, {
    count: 2, type: THREE.FloatType, format: THREE.RGBAFormat,
    minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter,
    depthBuffer: false, stencilBuffer: false
  });
  rayTarget.textures.forEach(texture => { texture.generateMipmaps = false; });
  const rayUniforms = {
    uCamera: { value: camera.position.clone() }, uBasis: { value: new THREE.Matrix3() },
    uAspect: { value: 1 }, uTanHalfFov: { value: Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) },
    uMaxStep: { value: 0.025 }, uOuterRadius: { value: 22 }, uDisk: { value: true },
    uProbeUV: { value: new THREE.Vector2(-1, -1) }
  };
  const rayMaterial = new THREE.RawShaderMaterial({
    vertexShader, fragmentShader: geodesicShader, glslVersion: THREE.GLSL3,
    uniforms: rayUniforms, depthTest: false, depthWrite: false, blending: THREE.NoBlending
  });
  const rayScene = new THREE.Scene();
  rayScene.add(new THREE.Mesh(quadGeometry, rayMaterial));
  const table = new THREE.DataTexture(createBlackbodyTable(), 1024, 1, THREE.RGBAFormat, THREE.FloatType);
  // Float linear sampling is optional in WebGL2. Fall back to nearest on such GPUs.
  table.minFilter = table.magFilter = gl.getExtension('OES_texture_float_linear') ? THREE.LinearFilter : THREE.NearestFilter;
  table.needsUpdate = true;
  const shadeUniforms = {
    uRayData: { value: rayTarget.textures[0] }, uRayMeta: { value: rayTarget.textures[1] },
    uSky: { value: createSky() }, uBlackbody: { value: table },
    uTime: { value: 0 }, uTemperature: { value: 8000 }, uFluxPeak: { value: FLUX_PEAK },
    uTextureStrength: { value: 0.75 }, uMode: { value: 0 },
    uStars: { value: true }, uObserverRadius: { value: camera.position.length() }
  };
  const shadeMaterial = new THREE.RawShaderMaterial({
    vertexShader, fragmentShader: radianceShader, glslVersion: THREE.GLSL3,
    uniforms: shadeUniforms, depthTest: false, depthWrite: false, blending: THREE.NoBlending
  });
  const shadeScene = new THREE.Scene();
  shadeScene.add(new THREE.Mesh(quadGeometry, shadeMaterial));
  const composer = new EffectComposer(renderer, new THREE.WebGLRenderTarget(1, 1, {
    type: THREE.HalfFloatType, depthBuffer: false, stencilBuffer: false
  }));
  composer.addPass(new RenderPass(shadeScene, screenCamera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.035, 0.15, 1.10);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());
  const fxaa = new ShaderPass(FXAAShader);
  composer.addPass(fxaa);

  function dirty() {
    state.dirty = true; state.refined = false; state.lastInteraction = performance.now();
  }
  function updateReadout() {
    const radius = camera.position.length();
    const inclination = THREE.MathUtils.radToDeg(Math.acos(camera.position.y / radius));
    $('inclination').innerHTML = `${inclination.toFixed(1)}<small>°</small>`;
    $('distance').innerHTML = `${radius.toFixed(1)}<small>r<sub>g</sub></small>`;
  }
  controls.addEventListener('change', () => { dirty(); updateReadout(); });
  controls.addEventListener('start', () => {
    document.querySelectorAll('[data-view]').forEach(button => { button.classList.remove('active'); button.setAttribute('aria-pressed', 'false'); });
  });
  new ResizeObserver(() => {
    state.width = Math.max(1, viewport.clientWidth);
    state.height = Math.max(1, viewport.clientHeight);
    camera.aspect = state.width / state.height;
    camera.fov = THREE.MathUtils.radToDeg(2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(39 / 2)) * Math.max(1, 1.4 / camera.aspect)));
    camera.updateProjectionMatrix();
    rayUniforms.uTanHalfFov.value = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const displayScale = Math.min(window.devicePixelRatio || 1, 1.5, Math.sqrt(2200000 / (state.width * state.height)));
    renderer.setSize(Math.floor(state.width * displayScale), Math.floor(state.height * displayScale), false);
    composer.setSize(Math.floor(state.width * displayScale), Math.floor(state.height * displayScale));
    fxaa.uniforms.resolution.value.set(1 / Math.floor(state.width * displayScale), 1 / Math.floor(state.height * displayScale));
    dirty();
  }).observe(viewport);

  function trace(refined) {
    const q = qualityOptions[state.quality];
    const scale = refined ? Math.min(q.scale, Math.sqrt(q.maxPixels / (state.width * state.height))) : Math.min(0.55, Math.sqrt(420000 / (state.width * state.height)));
    const width = Math.max(1, Math.round(state.width * scale)), height = Math.max(1, Math.round(state.height * scale));
    if (rayTarget.width !== width || rayTarget.height !== height) rayTarget.setSize(width, height);
    // Avoid the undefined perfectly coplanar observer/thin-disk configuration.
    if (Math.abs(camera.position.y) < 0.00005) {
      camera.position.y = Math.sign(camera.position.y || 1) * 0.00005;
      camera.lookAt(0, 0, 0);
    }
    camera.updateMatrixWorld();
    rayUniforms.uCamera.value.copy(camera.position);
    rayUniforms.uBasis.value.setFromMatrix4(camera.matrixWorld);
    rayUniforms.uAspect.value = camera.aspect;
    rayUniforms.uMaxStep.value = refined ? q.step : 0.065;
    shadeUniforms.uObserverRadius.value = camera.position.length();
    renderer.setRenderTarget(rayTarget);
    renderer.render(rayScene, screenCamera);
    renderer.setRenderTarget(null);
    state.dirty = false; state.refined = refined; state.geometryCount++;
    state.traceWidth = width; state.traceHeight = height;
    $('render-size').textContent = `${width} × ${height} · ${refined ? '已精化' : '交互预览'}`;
    $('status').textContent = refined ? '实时观测' : '追踪光线';
  }

  const descriptions = ['可见光 · 普朗克光谱', '总辐射强度 · 暖色为伪彩', '频率比 g = ν观测 / ν发射', '光路弯转角 · 直接像与高阶像'];
  $('mode').addEventListener('change', event => {
    state.mode = Number(event.target.value); shadeUniforms.uMode.value = state.mode;
    $('view-description').textContent = descriptions[state.mode];
    $('legend').hidden = state.mode < 2;
    $('legend').innerHTML = state.mode === 2 ? '<span><i style="background:#e96d45"></i>红移 g &lt; 1</span><span><i style="background:#627deb"></i>蓝移 g &gt; 1</span>' : '<span><i style="background:#e8ad6a"></i>φ &lt; π</span><span><i style="background:#54bfc9"></i>π–2π</span><span><i style="background:#c276b2"></i>φ &gt; 2π</span>';
    // Diagnostic colors are easiest to read without optical glare.
    bloom.enabled = $('bloom').checked && state.mode < 2;
  });
  for (const input of document.querySelectorAll('input[type="range"]')) {
    const update = () => input.style.setProperty('--range', `${100 * (input.value - input.min) / (input.max - input.min)}%`);
    input.addEventListener('input', update); update();
  }
  $('temperature').addEventListener('input', event => {
    const value = Number(event.target.value); shadeUniforms.uTemperature.value = value;
    $('temperature-value').textContent = `${value.toLocaleString('en-US')} K`;
  });
  $('exposure').addEventListener('input', event => {
    const value = Number(event.target.value); renderer.toneMappingExposure = value;
    $('exposure-value').textContent = value.toFixed(2);
  });
  $('speed').addEventListener('input', event => {
    state.speed = Number(event.target.value); $('speed-value').innerHTML = `${state.speed} t<sub>g</sub>/s`;
  });
  $('pause').addEventListener('click', () => {
    state.playing = !state.playing;
    $('pause').setAttribute('aria-pressed', String(!state.playing));
    $('pause').setAttribute('aria-label', state.playing ? '暂停吸积盘运动' : '继续吸积盘运动');
    $('pause-icon').textContent = state.playing ? 'Ⅱ' : '▷';
    $('playback-label').textContent = state.playing ? '时间正在流动' : '时间已暂停';
  });
  $('disk').addEventListener('change', event => { rayUniforms.uDisk.value = event.target.checked; dirty(); });
  $('stars').addEventListener('change', event => { shadeUniforms.uStars.value = event.target.checked; });
  $('bloom').addEventListener('change', event => { bloom.enabled = event.target.checked && state.mode < 2; });
  $('quality').addEventListener('change', event => { state.quality = event.target.value; dirty(); });
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => {
    const damping = controls.enableDamping;
    controls.enableDamping = false; controls.update();
    preset(button.dataset.view); controls.update(); controls.enableDamping = damping; dirty();
    document.querySelectorAll('[data-view]').forEach(other => { other.classList.toggle('active', other === button); other.setAttribute('aria-pressed', String(other === button)); });
    updateReadout();
  }));
  $('reset').addEventListener('click', () => { document.querySelector('[data-view="orbit"]').click(); });
  $('capture').addEventListener('click', () => {
    if (!state.refined) trace(true);
    composer.render();
    canvas.toBlob(blob => {
      if (!blob) return;
      const url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = `noctis-${new Date().toISOString().replaceAll(':', '-')}.png`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }, 'image/png');
  });
  $('model-open').addEventListener('click', () => $('model-dialog').showModal());
  $('model-close').addEventListener('click', () => $('model-dialog').close());
  $('model-dialog').addEventListener('click', event => { if (event.target === $('model-dialog')) {
    const rect = $('model-dialog').getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) $('model-dialog').close();
  }});
  document.querySelector('.wordmark').addEventListener('click', event => { event.preventDefault(); $('reset').click(); });
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); fail('图形上下文已丢失。请重新加载页面恢复观测。'); });
  updateReadout();

  // Read-only diagnostics plus isolated 1-pixel probes for reproducible GPU checks.
  const probeTarget = new THREE.WebGLRenderTarget(1, 1, { count: 2, type: THREE.FloatType, depthBuffer: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
  window.__NOCTIS = Object.freeze({
    getState: () => ({ ...state, camera: camera.position.toArray(), fov: camera.fov, aspect: camera.aspect, disk: rayUniforms.uDisk.value, temperature: shadeUniforms.uTemperature.value, glError: gl.getError() }),
    probe: (uv, disk = true) => {
      const oldDisk = rayUniforms.uDisk.value, oldStep = rayUniforms.uMaxStep.value;
      rayUniforms.uProbeUV.value.set(...uv); rayUniforms.uDisk.value = disk; rayUniforms.uMaxStep.value = 0.012;
      renderer.setRenderTarget(probeTarget); renderer.render(rayScene, screenCamera);
      const data = new Float32Array(4), meta = new Float32Array(4);
      renderer.readRenderTargetPixels(probeTarget, 0, 0, 1, 1, data, 0, 0);
      renderer.readRenderTargetPixels(probeTarget, 0, 0, 1, 1, meta, 0, 1);
      renderer.setRenderTarget(null);
      rayUniforms.uProbeUV.value.set(-1, -1); rayUniforms.uDisk.value = oldDisk; rayUniforms.uMaxStep.value = oldStep;
      return { data: Array.from(data), meta: Array.from(meta) };
    },
    captureStats: () => {
      const w = rayTarget.width, h = rayTarget.height, pixels = new Float32Array(w * h * 4);
      renderer.readRenderTargetPixels(rayTarget, 0, 0, w, h, pixels, 0, 1);
      const counts = { captured: 0, escaped: 0, disk: 0, unresolved: 0, invalid: 0 };
      let maxDiskInvariantError = 0;
      for (let i = 0; i < pixels.length; i += 4) {
        const status = Math.round(pixels[i + 3]);
        if (status === 0) counts.captured++;
        else if (status === 1) counts.escaped++;
        else if (status === 2) { counts.disk++; maxDiskInvariantError = Math.max(maxDiskInvariantError, pixels[i + 1]); }
        else if (status === 3) counts.unresolved++;
        else counts.invalid++;
      }
      return { width: w, height: h, counts, maxDiskInvariantError };
    }
  });

  let last = performance.now(), reportAt = last, reportFrames = 0;
  function frame(now) {
    if (state.fatal) return;
    requestAnimationFrame(frame);
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (document.hidden) return;
    controls.update();
    const refined = now - state.lastInteraction > 220;
    if (state.dirty || (!state.refined && refined)) trace(refined);
    if (state.playing) state.time += dt * state.speed;
    shadeUniforms.uTime.value = state.time;
    composer.render();
    state.frames++; reportFrames++;
    if (!state.ready && !state.fatal) {
      state.ready = true;
      $('loading').style.opacity = '0';
      setTimeout(() => { $('loading').hidden = true; }, 420);
    }
    if (now - reportAt >= 1000) {
      state.fps = Math.round(reportFrames * 1000 / (now - reportAt));
      $('performance').textContent = `${state.fps} FPS`;
      $('sim-time').innerHTML = `${Math.floor(state.time)} t<sub>g</sub>`;
      reportAt = now; reportFrames = 0;
    }
  }
  requestAnimationFrame(frame);
}

// Let the browser paint the opening UI before shader compilation and sky setup.
requestAnimationFrame(() => setTimeout(() => {
  try { main(); } catch (error) { console.error(error); fail(`无法启动模拟：${error.message}`); }
}, 30));
