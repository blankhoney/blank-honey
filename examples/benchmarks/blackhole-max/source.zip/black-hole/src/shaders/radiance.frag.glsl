precision highp float;
in vec2 vUv;
uniform sampler2D uRayData;
uniform sampler2D uRayMeta;
uniform sampler2D uSky;
uniform sampler2D uBlackbody;
uniform float uTime;
uniform float uTemperature;
uniform float uFluxPeak;
uniform float uTextureStrength;
uniform float uObserverRadius;
uniform int uMode;
uniform bool uStars;
out vec4 outColor;
const float PI = 3.141592653589793;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + 1.0), f.x), f.y);
}
float flux(float r) {
  float x = sqrt(r), a = sqrt(3.0), x0 = sqrt(6.0);
  float integral = x - x0 - a * 0.5 * log(((x-a)/(x+a))/((x0-a)/(x0+a)));
  return max(0.0, integral / (pow(r, 3.5) * (1.0 - 3.0 / r)));
}
vec3 spectrum(float temperature) {
  float t = clamp(log(max(temperature, 500.0) / 500.0) / log(160.0), 0.0, 1.0);
  return texture(uBlackbody, vec2((t * 1023.0 + 0.5) / 1024.0, 0.5)).rgb;
}
vec3 frequencyColor(float g) {
  vec3 neutral = vec3(0.82, 0.86, 0.82);
  if (g < 1.0) return mix(neutral, vec3(1.0, 0.065, 0.008), clamp((1.0 - g) / 0.5, 0.0, 1.0));
  return mix(neutral, vec3(0.04, 0.30, 1.0), clamp((g - 1.0) / 0.5, 0.0, 1.0));
}
void main() {
  vec4 meta = texture(uRayMeta, vUv);
  vec4 data = texture(uRayData, vUv);
  vec3 color = vec3(0.0);
  if (meta.w > 0.5 && meta.w < 1.5 && uStars) {
    vec3 d = normalize(meta.xyz);
    vec2 skyUV = vec2(atan(d.z, d.x) / (2.0 * PI) + 0.5, asin(clamp(d.y, -1.0, 1.0)) / PI + 0.5);
    // Remove longitude wrap discontinuity from mip selection.
    vec2 dx = dFdx(skyUV), dy = dFdy(skyUV);
    dx.x -= floor(dx.x + 0.5); dy.x -= floor(dy.x + 0.5);
    color = textureGrad(uSky, skyUV, dx, dy).rgb * 0.26;
    // Background is a bolometric synthetic sky at infinity. Static-observer shift.
    color *= pow(1.0 - 2.0 / uObserverRadius, -2.0);
  } else if (meta.w > 1.5 && meta.w < 2.5) {
    float r = data.x, angle = data.y, g = data.z;
    float emittedTime = uTime - data.w;
    float phase = angle - emittedTime * pow(r, -1.5);
    // Periodic, Kepler-advected emissivity structure, NOT a fluid simulation.
    vec2 flow = vec2(cos(phase), sin(phase));
    float structure = 0.46 * noise(flow * 5.0 + vec2(r * 2.7, r * 0.3));
    structure += 0.28 * noise(flow * 15.0 + vec2(r * 8.0, r));
    structure += 0.16 * noise(flow * 37.0 + vec2(r * 22.0, r * 3.0));
    structure += 0.10 * sin(r * 15.0 + 3.0 * sin(phase * 4.0));
    float modulation = mix(1.0, max(0.25, 0.55 + structure), uTextureStrength);
    float relativeFlux = flux(r) / uFluxPeak * modulation;
    float observedTemperature = uTemperature * pow(relativeFlux, 0.25) * g;
    if (uMode == 0) {
      // I_nu/nu³ is conserved, so g³ B_(nu/g)(T) = B_nu(gT).
      // The Planck LUT already includes the brightness change; no extra g⁴.
      color = spectrum(observedTemperature);
    } else if (uMode == 1) {
      float bolometric = relativeFlux * pow(g * uTemperature / 8000.0, 4.0);
      vec3 warm = mix(vec3(1.0, 0.095, 0.008), vec3(1.0, 0.76, 0.36), clamp(observedTemperature / 11000.0, 0.0, 1.0));
      color = warm * bolometric * 1.5;
    } else if (uMode == 2) {
      color = frequencyColor(g) * (0.4 + 0.6 * sqrt(relativeFlux));
    } else {
      color = meta.x > 2.0 * PI ? vec3(0.85, 0.2, 0.65) : meta.x > PI ? vec3(0.14, 0.8, 0.84) : vec3(0.95, 0.50, 0.14);
      color *= 0.35 + 0.65 * sqrt(relativeFlux);
    }
  } else if (meta.w > 2.5 && uMode == 3) color = vec3(1.0, 0.0, 1.0);
  outColor = vec4(color, 1.0);
}
