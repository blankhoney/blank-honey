precision highp float;
precision highp int;
in vec2 vUv;
uniform vec3 uCamera;
uniform mat3 uBasis;
uniform float uAspect;
uniform float uTanHalfFov;
uniform float uMaxStep;
uniform float uOuterRadius;
uniform bool uDisk;
uniform vec2 uProbeUV;
layout(location = 0) out vec4 rayData;
layout(location = 1) out vec4 rayMeta;
const float PI = 3.141592653589793;

// s = (u=1/r, du/dphi, positive Schwarzschild light travel time).
// Exact Schwarzschild null equations, in G=c=M=1.
vec3 derivative(vec3 s, float b) {
  float u = max(abs(s.x), 1e-7);
  return vec3(s.y, -s.x + 3.0 * s.x * s.x,
    1.0 / (b * u * u * max(1.0 - 2.0 * u, 1e-6)));
}
vec3 advance(vec3 s, float h, float b) {
  vec3 k1 = derivative(s, b);
  vec3 k2 = derivative(s + 0.5 * h * k1, b);
  vec3 k3 = derivative(s + 0.5 * h * k2, b);
  vec3 k4 = derivative(s + h * k3, b);
  return s + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4);
}
float errorOf(vec3 s, float b) {
  return abs((s.y * s.y + s.x * s.x - 2.0 * s.x * s.x * s.x) * b * b - 1.0);
}
void main() {
  vec2 uv = uProbeUV.x >= 0.0 ? uProbeUV : vUv;
  vec2 screen = (uv * 2.0 - 1.0) * vec2(uAspect, 1.0) * uTanHalfFov;
  vec3 d = normalize(uBasis * vec3(screen, -1.0));
  float R = length(uCamera);
  float fObserver = 1.0 - 2.0 / R;
  vec3 er = uCamera / R;
  float mu = dot(d, er);
  vec3 perpendicular = d - mu * er;
  float sine = length(perpendicular);
  rayData = vec4(0.0);
  rayMeta = vec4(0.0);
  if (sine < 1e-7) {
    if (mu > 0.0) rayMeta = vec4(d, 1.0);
    return;
  }
  vec3 et = perpendicular / sine;
  float b = R * sine / sqrt(fObserver);
  // Reversing the ray reverses the spatial angular momentum of the arriving photon.
  float lambda = -b * cross(er, et).y;
  vec3 s = vec3(1.0 / R, -mu / b, 0.0);
  float phi = 0.0;
  float nextPlane = atan(-er.y, et.y);
  if (nextPlane <= 1e-6) nextPlane += PI;
  // An exactly coplanar ray has an ill-defined thin-surface intersection.
  // OrbitControls avoids a camera exactly in the disk plane by a tiny epsilon.
  for (int i = 0; i < 1536; i++) {
    // Cap angular step, fractional inverse-radius change, and advance to disk
    // nodes exactly. No straight-segment disk intersection approximation.
    float h = min(uMaxStep, 0.085 * max(abs(s.x), 0.001) / max(abs(s.y), 0.001));
    h = min(h, nextPlane - phi);
    vec3 previous = s;
    s = advance(s, h, b);
    phi += h;
    if (s.x >= 0.49995) {
      rayMeta = vec4(phi, errorOf(s, b), b, 0.0);
      return;
    }
    if (s.x <= 0.0) {
      // Refine the u=0 escape event using RK4 from the previous accepted state.
      float lo = 0.0, hi = h;
      for (int k = 0; k < 12; k++) {
        float mid = 0.5 * (lo + hi);
        if (advance(previous, mid, b).x > 0.0) lo = mid; else hi = mid;
      }
      float escapedPhi = phi - h + 0.5 * (lo + hi);
      rayMeta = vec4(er * cos(escapedPhi) + et * sin(escapedPhi), 1.0);
      return;
    }
    if (phi >= nextPlane - 1e-6) {
      float r = 1.0 / s.x;
      if (uDisk && r > 6.0 && r < uOuterRadius) {
        vec3 point = er * cos(phi) + et * sin(phi);
        float g = sqrt(1.0 - 3.0 / r) / (sqrt(fObserver) * (1.0 - pow(r, -1.5) * lambda));
        rayData = vec4(r, atan(-point.z, point.x), g, s.z);
        rayMeta = vec4(phi, errorOf(s, b), b, 2.0);
        return; // Optically thick disk: first surface hit blocks all later hits.
      }
      nextPlane += PI;
    }
    if (phi > 8.0 * PI) break;
  }
  // Finite work budget: explicitly marked unresolved; never add a fake ring.
  rayMeta = vec4(phi, errorOf(s, b), b, 3.0);
}
