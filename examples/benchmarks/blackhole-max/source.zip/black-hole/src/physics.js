// Geometric units G = c = M = 1. All radii are in GM/c², times in GM/c³.
export const HORIZON = 2;
export const PHOTON_SPHERE = 3;
export const ISCO = 6;
export const CRITICAL_IMPACT = Math.sqrt(27);
export const omega = r => r ** -1.5;
export const lapse = r => 1 - 2 / r;
export const energyInvariant = (u, v) => v * v + u * u - 2 * u ** 3;

export function initialRay(radius, radialCosine) {
  const sine = Math.sqrt(Math.max(0, 1 - radialCosine ** 2));
  const b = radius * sine / Math.sqrt(lapse(radius));
  return { b, u: 1 / radius, v: -radialCosine / b };
}

export function rk4(u, v, h) {
  const acceleration = x => -x + 3 * x * x;
  const a = acceleration(u);
  const b = acceleration(u + h * v / 2);
  const c = acceleration(u + h * (v + h * a / 2) / 2);
  const d = acceleration(u + h * (v + h * b / 2));
  return [u + h * (v + 2 * (v + h * a / 2) + 2 * (v + h * b / 2) + v + h * c) / 6,
    v + h * (a + 2 * b + 2 * c + d) / 6];
}

// Independent double-precision reference solver used for numerical validation.
// Starting at u=0 is the asymptotic, incoming ray from infinity.
export function traceFromInfinity(b, step = 0.002, maxAngle = 30) {
  let u = 0, v = 1 / b, phi = 0, maxError = 0;
  const invariant = 1 / (b * b);
  for (let i = 0; phi < maxAngle; i++) {
    const oldU = u, oldV = v;
    [u, v] = rk4(u, v, step);
    maxError = Math.max(maxError, Math.abs(energyInvariant(u, v) - invariant) / invariant);
    if (u >= 0.5) return { status: 'captured', phi: phi + step, maxError, steps: i + 1 };
    if (u < 0) {
      let lo = 0, hi = step;
      for (let j = 0; j < 40; j++) {
        const mid = (lo + hi) / 2;
        if (rk4(oldU, oldV, mid)[0] > 0) lo = mid; else hi = mid;
      }
      const escape = phi + (lo + hi) / 2;
      return { status: 'escaped', phi: escape, deflection: escape - Math.PI, maxError, steps: i + 1 };
    }
    phi += step;
  }
  return { status: 'unresolved', phi, maxError };
}

// Page-Thorne zero-torque flux for Schwarzschild, with 3 Mdot/(8 pi) factored out.
// Integral [(E-Omega L) dL/dr] dr, with x=sqrt(r), evaluated analytically.
export function diskFlux(r) {
  if (r <= ISCO) return 0;
  const x = Math.sqrt(r), x0 = Math.sqrt(6), a = Math.sqrt(3);
  const integral = x - x0 - a / 2 * Math.log(((x - a) / (x + a)) / ((x0 - a) / (x0 + a)));
  return Math.max(0, integral / (r ** 3.5 * (1 - 3 / r)));
}
export const FLUX_PEAK = (() => {
  let peak = 0;
  for (let r = 6; r < 60; r += 0.002) peak = Math.max(peak, diskFlux(r));
  return peak;
})();

// lambda=L_y/E of the future-directed photon, not the reversed spatial ray.
export function frequencyShift(r, observerRadius, lambda) {
  return Math.sqrt(1 - 3 / r) / (Math.sqrt(lapse(observerRadius)) * (1 - omega(r) * lambda));
}

// CIE 1931 analytic fits: Wyman, Sloan & Shirley (2013).
// Integrate Planck B_lambda from 380 to 780 nm in 5 nm steps; linear sRGB output.
function cie(w) {
  const g = (center, left, right) => Math.exp(-0.5 * ((w - center) * (w < center ? left : right)) ** 2);
  return [0.362 * g(442, 0.0624, 0.0374) + 1.056 * g(599.8, 0.0264, 0.0323) - 0.065 * g(501.1, 0.049, 0.0382),
    0.821 * g(568.8, 0.0213, 0.0247) + 0.286 * g(530.9, 0.0613, 0.0322),
    1.217 * g(437, 0.0845, 0.0278) + 0.681 * g(459, 0.0385, 0.0725)];
}
export function blackbodyXYZ(temperature) {
  const xyz = [0, 0, 0];
  for (let w = 380; w <= 780; w += 5) {
    const b = (550 / w) ** 5 / Math.expm1(1.438776877e7 / (w * temperature));
    const matching = cie(w);
    for (let k = 0; k < 3; k++) xyz[k] += b * matching[k] * 5;
  }
  return xyz;
}
export function createBlackbodyTable(size = 1024) {
  const reference = blackbodyXYZ(8000)[1];
  const data = new Float32Array(size * 4);
  for (let i = 0; i < size; i++) {
    const temperature = 500 * Math.pow(160, i / (size - 1));
    const [x, y, z] = blackbodyXYZ(temperature).map(n => n / reference);
    data.set([Math.max(0, 3.2406 * x - 1.5372 * y - 0.4986 * z),
      Math.max(0, -0.9689 * x + 1.8758 * y + 0.0415 * z),
      Math.max(0, 0.0557 * x - 0.2040 * y + 1.057 * z), 1], 4 * i);
  }
  return data;
}
