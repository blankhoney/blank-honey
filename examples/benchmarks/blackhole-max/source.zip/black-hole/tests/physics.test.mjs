import test from 'node:test';
import assert from 'node:assert/strict';
import { CRITICAL_IMPACT, initialRay, energyInvariant, rk4, traceFromInfinity, diskFlux, FLUX_PEAK, frequencyShift, blackbodyXYZ } from '../src/physics.js';

test('static-observer tetrad initializes the null constraint', () => {
  for (const radius of [26, 46, 110]) for (const mu of [-0.999, -0.8, -0.2, 0.2, 0.8]) {
    const { b, u, v } = initialRay(radius, mu);
    assert.ok(Math.abs(energyInvariant(u, v) * b * b - 1) < 2e-14);
  }
});

test('capture boundary is b_c=3 sqrt(3), including strong lensing just outside', () => {
  const inside = traceFromInfinity(CRITICAL_IMPACT * 0.9999);
  const outside = traceFromInfinity(CRITICAL_IMPACT * 1.0001);
  assert.equal(inside.status, 'captured');
  assert.equal(outside.status, 'escaped');
  assert.ok(outside.deflection > 2 * Math.PI);
});

test('weak deflection agrees with 4/b + 15 pi/(4 b²) + 128/(3 b³)', () => {
  for (const b of [100, 200, 400]) {
    const actual = traceFromInfinity(b, 0.001).deflection;
    const expected = 4 / b + 15 * Math.PI / (4 * b * b) + 128 / (3 * b ** 3);
    assert.ok(Math.abs(actual / expected - 1) < 5e-5, `b=${b}: ${actual} vs ${expected}`);
  }
});

test('high-order weak-field numerical integration agrees with an independent quadrature', () => {
  // A change of variable at the closest approach removes the square-root singularity.
  // b² = r0³/(r0-2), u = u0 (1-t²), t in [0,1].
  for (const b of [5.3, 6, 10, 30]) {
    let lo = 3, hi = b;
    for (let i = 0; i < 100; i++) { const r = (lo + hi) / 2; if (r ** 3 / (r - 2) > b * b) hi = r; else lo = r; }
    const u0 = 1 / ((lo + hi) / 2);
    const integrand = t => 2 / Math.sqrt(2 - t * t - 2 * u0 * (3 - 3 * t * t + t ** 4));
    let sum = 0; const n = 40000;
    for (let i = 0; i <= n; i++) sum += integrand(i / n) * (i === 0 || i === n ? 1 : i % 2 ? 4 : 2);
    const deflection = 2 * sum / (3 * n) - Math.PI;
    const traced = traceFromInfinity(b, 0.002);
    assert.ok(Math.abs(traced.deflection - deflection) < 2e-9, `b=${b}`);
  }
});

test('photon sphere r=3 is a stationary null orbit', () => {
  let u = 1 / 3, v = 0;
  for (let i = 0; i < 200; i++) [u, v] = rk4(u, v, 0.01);
  assert.ok(Math.abs(u - 1 / 3) < 1e-13);
  assert.ok(Math.abs(v) < 1e-13);
});

test('RK4 conserves photon energy in strong lensing', () => {
  for (const b of [3, 5.18, 5.21, 5.3, 6, 10, 30]) {
    const result = traceFromInfinity(b, 0.025);
    assert.ok(result.maxError < 2e-6, `b=${b}: ${result.maxError}`);
  }
});

test('RK4 step halving has fourth-order convergence in strong deflection', () => {
  const reference = traceFromInfinity(5.3, 0.001).deflection;
  const coarse = Math.abs(traceFromInfinity(5.3, 0.08).deflection - reference);
  const fine = Math.abs(traceFromInfinity(5.3, 0.04).deflection - reference);
  assert.ok(coarse / fine > 12 && coarse / fine < 20, `${coarse / fine}`);
});

test('Page-Thorne flux has zero ISCO torque and matches the independent integral', () => {
  assert.equal(diskFlux(6), 0); assert.equal(diskFlux(5), 0);
  assert.ok(FLUX_PEAK > 0);
  for (const r of [6.1, 8, 12, 22, 100]) {
    const n = 10000, h = (r - 6) / n;
    const f = x => (x - 6) / (2 * Math.sqrt(x) * (x - 3));
    let integral = 0;
    for (let i = 0; i <= n; i++) integral += f(6 + h * i) * (i === 0 || i === n ? 1 : i % 2 ? 4 : 2);
    const reference = integral * h / 3 / (r ** 3.5 * (1 - 3 / r));
    assert.ok(Math.abs(diskFlux(r) / reference - 1) < 1e-9);
  }
});

test('frequency transfer includes gravitational, transverse, and longitudinal Doppler shifts', () => {
  assert.ok(Math.abs(frequencyShift(6, 1e15, 0) - Math.SQRT1_2) < 1e-14);
  assert.ok(Math.abs(frequencyShift(12, 46, 0) - Math.sqrt(0.75 / (1 - 2 / 46))) < 1e-14);
  const red = frequencyShift(10, 46, -8), blue = frequencyShift(10, 46, 8);
  assert.ok(blue > 1 && red < 1 && blue > red);
});

test('blackbody quadrature gives increasing luminance and a bluer hot spectrum', () => {
  const warm = blackbodyXYZ(4000), cool = blackbodyXYZ(12000);
  assert.ok(cool[1] > warm[1]);
  assert.ok(cool[2] / cool[0] > warm[2] / warm[0]);
  const neutral = blackbodyXYZ(6500), total = neutral.reduce((a, b) => a + b);
  assert.ok(Math.abs(neutral[0] / total - 0.3135) < 0.004);
  assert.ok(Math.abs(neutral[1] / total - 0.3237) < 0.004);
});
