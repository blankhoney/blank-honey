// Run this function in the browser console after the page is ready.
// Uses a separate double-precision CPU calculation to verify actual GPU outputs.
async function checkNoctis() {
  const api = window.__NOCTIS;
  if (!api?.getState().ready) throw new Error('Wait for the first rendered frame.');
  const assert = (value, message) => { if (!value) throw new Error(message); };
  const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
  const dot = (a, b) => a.reduce((sum, x, i) => sum+x*b[i], 0);
  const norm = a => a.map(x => x / Math.hypot(...a));
  const camera = api.getState();
  const R = Math.hypot(...camera.camera), er = norm(camera.camera);
  const right = norm(cross([0, 1, 0], er)), up = cross(er, right);
  const tanFov = Math.tan(camera.fov * Math.PI / 360);
  const fObserver = 1 - 2 / R;

  function oracle(uv, disk) {
    const x = (2*uv[0]-1)*camera.aspect*tanFov, y = (2*uv[1]-1)*tanFov;
    const d = norm(er.map((v, i) => -v+x*right[i]+y*up[i]));
    const mu = dot(d, er), perpendicular = d.map((v, i) => v-mu*er[i]);
    const sine = Math.hypot(...perpendicular);
    if (sine < 1e-7) return { status: 0 };
    const et = norm(perpendicular), b = R*sine/Math.sqrt(fObserver), lambda = -b*cross(er, et)[1];
    const derivative = ([u, v]) => [v, -u+3*u*u];
    const advance = (s, h) => {
      const add = (a, b, k) => a.map((x, i) => x+k*b[i]);
      const a = derivative(s), c = derivative(add(s, a, h/2)), e = derivative(add(s, c, h/2)), f = derivative(add(s, e, h));
      return s.map((v, i) => v+h/6*(a[i]+2*c[i]+2*e[i]+f[i]));
    };
    const timeRate = u => 1/(b*u*u*(1-2*u));
    let s = [1/R, -mu/b], phi = 0, delay = 0;
    let nextPlane = Math.atan2(-er[1], et[1]);
    if (nextPlane <= 1e-6) nextPlane += Math.PI;
    for (let i = 0; i < 100000; i++) {
      const h = Math.min(0.0005, nextPlane-phi), mid = advance(s,h/2), next = advance(s,h);
      if (next[0] >= 0.49995) return {status:0};
      if (next[0] <= 0) {
        let lo=0,hi=h;
        for(let k=0;k<35;k++){const m=(lo+hi)/2;if(advance(s,m)[0]>0)lo=m;else hi=m;}
        const angle=phi+(lo+hi)/2;
        return {status:1,direction:er.map((v,j)=>v*Math.cos(angle)+et[j]*Math.sin(angle))};
      }
      delay += h/6*(timeRate(s[0])+4*timeRate(mid[0])+timeRate(next[0]));
      phi += h; s = next;
      if(phi>=nextPlane-1e-10){
        const r=1/s[0];
        if(disk&&r>6&&r<22){
          const p=er.map((v,j)=>v*Math.cos(phi)+et[j]*Math.sin(phi));
          return {status:2,r,angle:Math.atan2(-p[2],p[0]),g:Math.sqrt(1-3/r)/(Math.sqrt(fObserver)*(1-r**-1.5*lambda)),delay};
        }
        nextPlane+=Math.PI;
      }
      if(phi>8*Math.PI) return {status:3};
    }
    throw new Error('CPU reference exceeded its iteration budget.');
  }

  const bCritical = Math.sqrt(27);
  const angle = Math.asin(bCritical*Math.sqrt(fObserver)/R);
  const uvOffset = Math.tan(angle)/(tanFov*camera.aspect)*0.5;
  const inside = api.probe([0.5+uvOffset*0.999,0.5],false);
  const outside = api.probe([0.5+uvOffset*1.001,0.5],false);
  assert(inside.meta[3]===0,'Ray inside critical impact parameter should be captured.');
  assert(outside.meta[3]===1,'Ray outside critical impact parameter should escape.');
  const results=[];
  let maxRadiusRelativeError=0,maxShiftError=0,maxDelayRelativeError=0,maxSkyDirectionError=0;
  for (const uv of [[.12,.46],[.25,.45],[.37,.46],[.43,.62],[.49,.64],[.60,.6],[.72,.45],[.86,.46],[.5,.82],[.85,.85],[.23,.75],[.5,.5],[.49,.66],[.5,.35],[.57,.51]]) {
    const cpu=oracle(uv,true), gpu=api.probe(uv,true);
    assert(cpu.status===gpu.meta[3],`Classification mismatch at ${uv}`);
    if(cpu.status===2){
      const radiusError=Math.abs(gpu.data[0]/cpu.r-1),gError=Math.abs(gpu.data[2]-cpu.g),delayError=Math.abs(gpu.data[3]/cpu.delay-1);
      assert(radiusError<0.0003,`Radius mismatch at ${uv}: ${radiusError}`);
      assert(gError<0.00002,`Frequency mismatch at ${uv}: ${gError}`);
      assert(delayError<0.0003,`Time delay mismatch at ${uv}: ${delayError}`);
      maxRadiusRelativeError=Math.max(maxRadiusRelativeError,radiusError);
      maxShiftError=Math.max(maxShiftError,gError);maxDelayRelativeError=Math.max(maxDelayRelativeError,delayError);
    } else if(cpu.status===1){
      const error=Math.hypot(...cpu.direction.map((v,i)=>v-gpu.meta[i]));
      assert(error<0.0001,`Escape direction mismatch at ${uv}: ${error}`);
      maxSkyDirectionError=Math.max(maxSkyDirectionError,error);
    }
    results.push({uv,status:cpu.status,gpu});
  }
  const stats=api.captureStats();
  assert(stats.counts.invalid===0,'Invalid pixels in geodesic buffers.');
  assert(stats.maxDiskInvariantError<0.00001,'Excessive GPU null-constraint drift.');
  return {passed:true,protocol:location.protocol,browser:navigator.userAgent,criticalBoundaryPassed:true,
    maxRadiusRelativeError,maxShiftError,maxDelayRelativeError,maxSkyDirectionError,
    camera:api.getState(),stats,probes:results};
}
checkNoctis();
