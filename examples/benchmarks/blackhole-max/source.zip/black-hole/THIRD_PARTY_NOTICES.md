# Third-party notices

The standalone HTML embeds Three.js 0.186.0, including OrbitControls and postprocessing helpers. Three.js is distributed under the MIT license reproduced below. esbuild 0.28.2 is an MIT-licensed build-time dependency and is not embedded as a runtime.

## Three.js — MIT License

Copyright © 2010-2026 three.js authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

## Scientific references

The CIE analytic fits are from Wyman, Sloan and Shirley (JCGT 2013); the
Schwarzschild geodesic and Page-Thorne disk equations are credited in README.md.
The implementation is written for this project and does not embed any of the
black-hole reference renderer's source code, external astronomical imagery,
or star catalogs.
