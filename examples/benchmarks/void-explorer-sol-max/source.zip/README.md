# VOID EXPLORER

A static browser vertical slice of a procedural universe. Pilot AURORA from orbit through atmosphere to generated terrain, land beside the river delta, lower the ramp, walk outside, reboard, and return to orbit. The chart's seven displayed stars are all selectable destinations; pulse-jump distance uses the same source value in the chart, HUD, marker, and transit countdown.

## Run

```sh
npm install
npm run dev
```

`npm run check` runs the deterministic simulation self-check and builds `dist/`. Vite is configured with `base: './'`, so the build works from a subdirectory. The app attempts WebGPU first and falls back to WebGL2.

## Controls

- `W` / `S`: thrust up / down
- `A` / `D`: yaw, arrow keys or pointer drag: pitch / steer
- `Space` / `C`: ascend / descend
- `Q` / `E`: roll, `Shift`: boost, `X`: brake
- `P`: assisted continuous descent and landing
- `M`: star chart, `T`: next target, `J`: pulse jump
- `G`: landing gear, `R`: ramp, `F`: disembark / board, `V`: camera
- On foot: `WASD` to walk, `Shift` to run, `F` near AURORA to board

## Visual references

Original geometry and code were created for this build. Visual direction and AURORA's silhouette follow the supplied public references:

- [Orbital flight](https://cdn.openai.com/devhub/showcase/void-explorer/concept-orbit-9ced0979a45d.webp)
- [Atmospheric descent](https://cdn.openai.com/devhub/showcase/void-explorer/concept-descent-da2bf1f314ee.webp)
- [AURORA top view](https://cdn.openai.com/devhub/showcase/void-explorer/aurora-concept-top-5887bd0cbcce.webp)
- [AURORA front support view](https://cdn.openai.com/devhub/showcase/void-explorer/aurora-concept-front-ca54e31f4a37.webp)

Blender was not available in the build environment, so the ship is authored as readable procedural Three.js geometry rather than an opaque `.blend`/GLB asset. It preserves the approved top silhouette: ivory and indigo hull, emerald canopy, twin cyan engines, four mirrored separate wings with open gaps, and pink tip lights.

No browser acceptance run was performed by this task; verification is command-line build and static inspection only.
