import * as THREE from 'three';
import './style.css';
import {
  DESTINATIONS,
  advanceJourney,
  clamp,
  formatDistance,
  headingLabel,
  lerp,
  mulberry32,
  terrainHeight,
  travelDistance
} from './sim.js';

const $ = (selector) => document.querySelector(selector);
const canvas = $('#viewport');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const ui = {
  app: $('#app'), intro: $('#intro'), launch: $('#launch-button'), renderer: $('#renderer-label'),
  targetName: $('#target-name'), targetDistance: $('#target-distance'), systemName: $('#system-name'),
  speed: $('#speed-value'), altitude: $('#altitude-value'), heading: $('#heading-value'), mode: $('#mode-value'),
  thrust: $('#thrust-bar'), thrustLabel: $('#thrust-label'), boost: $('#boost-bar'), boostLabel: $('#boost-label'),
  marker: $('#world-marker'), markerName: $('#marker-name'), markerDistance: $('#marker-distance'),
  chart: $('#chart-overlay'), chartMap: $('#chart-map'), chartClose: $('#chart-close'), chartButton: $('#chart-button'),
  chartDestination: $('#chart-destination'), chartDescription: $('#chart-description'), chartDistance: $('#chart-distance'),
  chartClass: $('#chart-class'), chartAtmosphere: $('#chart-atmosphere'), planetPreview: $('#planet-preview'),
  plotCourse: $('#plot-course'), targetButton: $('#target-button'), jumpButton: $('#jump-button'),
  gearButton: $('#gear-button'), rampButton: $('#ramp-button'), evaButton: $('#eva-button'),
  autopilotButton: $('#autopilot-button'), helpButton: $('#help-button'), controls: $('#controls-card'),
  journey: $('#journey-list'), journeyPercent: $('#journey-percent'), missionCopy: $('#mission-copy'),
  toast: $('#toast'), toastTitle: $('#toast-title'), toastMessage: $('#toast-message'),
  jumpOverlay: $('#jump-overlay'), jumpCountdown: $('#jump-countdown'), jumpDestination: $('#jump-destination')
};

const state = {
  started: false,
  current: DESTINATIONS[0],
  selected: DESTINATIONS[0],
  target: DESTINATIONS[0],
  mode: 'flight',
  phase: 'orbital',
  throttle: 0.34,
  speed: 8.4,
  boost: 1,
  boostHeld: false,
  brakeHeld: false,
  verticalVelocity: 0,
  yaw: 0,
  pitch: -0.08,
  roll: 0,
  gear: 0,
  gearTarget: 0,
  ramp: 0,
  rampTarget: 0,
  landed: false,
  wasLanded: false,
  evaComplete: false,
  returnedToShip: false,
  descentAssist: false,
  cameraMode: 0,
  chartOpen: false,
  jump: null,
  keys: new Set(),
  stepComplete: { orbit: false, atmosphere: false, land: false, eva: false, return: false },
  toastTimer: 0,
  lastTime: performance.now(),
  elapsed: 0
};

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x254c75, 0.00012);

const camera = new THREE.PerspectiveCamera(61, innerWidth / innerHeight, 0.08, 5000);
camera.position.set(0, 195, 96);

let renderer;
let rendererKind = 'WEBGL2';

async function createRenderer() {
  if ('gpu' in navigator) {
    try {
      const { WebGPURenderer } = await import('three/webgpu');
      const candidate = new WebGPURenderer({ canvas, antialias: true, alpha: true });
      await candidate.init();
      rendererKind = 'WEBGPU';
      return candidate;
    } catch (error) {
      console.info('WebGPU unavailable; continuing with WebGL2.', error);
    }
  }
  rendererKind = 'WEBGL2';
  return new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
}

renderer = await createRenderer();
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight, false);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.28;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
ui.renderer.textContent = `${rendererKind} // ONLINE`;

const hemiLight = new THREE.HemisphereLight(0x91ddff, 0x51305f, 2.1);
scene.add(hemiLight);
const sunLight = new THREE.DirectionalLight(0xffe3c4, 4.2);
sunLight.position.set(-180, 330, -260);
sunLight.castShadow = true;
sunLight.shadow.mapSize.set(1024, 1024);
sunLight.shadow.camera.left = -110;
sunLight.shadow.camera.right = 110;
sunLight.shadow.camera.top = 110;
sunLight.shadow.camera.bottom = -110;
sunLight.shadow.camera.far = 700;
scene.add(sunLight);
const rimLight = new THREE.DirectionalLight(0x44eaff, 2.8);
rimLight.position.set(180, 80, 220);
scene.add(rimLight);

function glowTexture() {
  const glowCanvas = document.createElement('canvas');
  glowCanvas.width = glowCanvas.height = 128;
  const context = glowCanvas.getContext('2d');
  const gradient = context.createRadialGradient(64, 64, 0, 64, 64, 62);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(.08, 'rgba(255,255,255,.95)');
  gradient.addColorStop(.25, 'rgba(255,255,255,.28)');
  gradient.addColorStop(1, 'rgba(255,255,255,0)');
  context.fillStyle = gradient;
  context.fillRect(0, 0, 128, 128);
  const texture = new THREE.CanvasTexture(glowCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

const glowMap = glowTexture();

function makeGlow(color, scale = 1, opacity = 1) {
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowMap,
    color,
    transparent: true,
    opacity,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  }));
  sprite.scale.setScalar(scale);
  return sprite;
}

function prism(points, depth, material, y = 0, edgeColor = 0x253052) {
  const shape = new THREE.Shape();
  shape.moveTo(points[0][0], points[0][1]);
  for (const [x, z] of points.slice(1)) shape.lineTo(x, z);
  shape.closePath();
  const geometry = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 1 });
  geometry.rotateX(Math.PI / 2);
  geometry.computeVertexNormals();
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.y = y + depth / 2;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  const edges = new THREE.LineSegments(
    new THREE.EdgesGeometry(geometry, 22),
    new THREE.LineBasicMaterial({ color: edgeColor, transparent: true, opacity: 0.48 })
  );
  edges.position.copy(mesh.position);
  const group = new THREE.Group();
  group.add(mesh, edges);
  return group;
}

function createAurora() {
  const ship = new THREE.Group();
  ship.name = 'AURORA';
  const ivory = new THREE.MeshStandardMaterial({ color: 0xe7ddc9, roughness: 0.54, metalness: 0.24, flatShading: true });
  const ivoryLight = new THREE.MeshStandardMaterial({ color: 0xfff5df, roughness: 0.45, metalness: 0.18, flatShading: true });
  const indigo = new THREE.MeshStandardMaterial({ color: 0x24224f, roughness: 0.38, metalness: 0.38, flatShading: true });
  const indigoLight = new THREE.MeshStandardMaterial({ color: 0x464078, roughness: 0.4, metalness: 0.3, flatShading: true });
  const canopy = new THREE.MeshStandardMaterial({ color: 0x087b78, emissive: 0x063f46, emissiveIntensity: 1.6, roughness: 0.16, metalness: 0.62, flatShading: true });
  const cyan = new THREE.MeshStandardMaterial({ color: 0x66ffff, emissive: 0x22dce8, emissiveIntensity: 5, roughness: 0.2 });
  const pink = new THREE.MeshStandardMaterial({ color: 0xff8ae8, emissive: 0xff23c8, emissiveIntensity: 5 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x11182e, metalness: 0.82, roughness: 0.24 });

  const body = prism([[0, -7.2], [1.35, -4.5], [2.15, -.8], [1.85, 3.8], [.72, 5.3], [0, 4.65], [-.72, 5.3], [-1.85, 3.8], [-2.15, -.8], [-1.35, -4.5]], 0.82, ivory, 0.2);
  ship.add(body);
  ship.add(prism([[0, -6.7], [.7, -4.6], [.86, 1.3], [0, 2.65], [-.86, 1.3], [-.7, -4.6]], 0.34, ivoryLight, 1.02));
  ship.add(prism([[0, -4.65], [.75, -3.5], [.82, -.65], [.52, .1], [-.52, .1], [-.82, -.65], [-.75, -3.5]], 0.28, canopy, 1.42, 0x70fff2));

  const frontWingLeft = [[-1.72, -3.35], [-2.65, -2.75], [-6.5, .25], [-6.05, .92], [-2.35, -.35]];
  const frontWingRight = frontWingLeft.map(([x, z]) => [-x, z]);
  const rearWingLeft = [[-2.05, .72], [-5.75, 2.4], [-6.28, 3.85], [-2.15, 3.25], [-1.72, 1.95]];
  const rearWingRight = rearWingLeft.map(([x, z]) => [-x, z]);
  ship.add(prism(frontWingLeft, .34, indigo, .12), prism(frontWingRight, .34, indigo, .12));
  ship.add(prism(rearWingLeft, .42, indigoLight, .05), prism(rearWingRight, .42, indigoLight, .05));

  // Separate ivory leading rails make the four-wing silhouette readable at speed.
  const railGeometry = new THREE.BoxGeometry(.17, .18, 4.85);
  for (const side of [-1, 1]) {
    const rail = new THREE.Mesh(railGeometry, ivoryLight);
    rail.position.set(side * 4.2, .67, -1.25);
    rail.rotation.y = side * .82;
    rail.castShadow = true;
    ship.add(rail);
  }

  const tipPositions = [[-6.38, .58, .47], [6.38, .58, .47], [-6.1, .55, 3.7], [6.1, .55, 3.7]];
  for (const [x, y, z] of tipPositions) {
    const tip = new THREE.Mesh(new THREE.OctahedronGeometry(.18, 0), pink);
    tip.position.set(x, y, z);
    const glow = makeGlow(0xff36d2, .95, .65);
    glow.position.copy(tip.position);
    ship.add(tip, glow);
  }

  const engineGroup = new THREE.Group();
  const trails = [];
  for (const side of [-1, 1]) {
    const engine = new THREE.Mesh(new THREE.CylinderGeometry(.7, .58, 1.55, 8), dark);
    engine.rotation.x = Math.PI / 2;
    engine.position.set(side * 1.08, .12, 4.52);
    engine.castShadow = true;
    const nozzle = new THREE.Mesh(new THREE.CircleGeometry(.48, 16), cyan);
    nozzle.position.set(side * 1.08, .12, 5.32);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(.58, .11, 8, 20), cyan);
    ring.position.copy(nozzle.position);
    const glow = makeGlow(0x42f6ff, 2.2, .62);
    glow.position.set(side * 1.08, .12, 5.5);
    const trail = new THREE.Mesh(
      new THREE.ConeGeometry(.42, 5.2, 8, 1, true),
      new THREE.MeshBasicMaterial({ color: 0x52eeff, transparent: true, opacity: .48, blending: THREE.AdditiveBlending, depthWrite: false })
    );
    trail.rotation.x = -Math.PI / 2;
    trail.position.set(side * 1.08, .12, 7.8);
    trails.push(trail);
    engineGroup.add(engine, nozzle, ring, glow, trail);
  }
  ship.add(engineGroup);

  const dorsal = prism([[-.28, .5], [.28, .5], [.18, 3.25], [-.18, 3.25]], .95, indigo, .78);
  ship.add(dorsal);

  const gear = new THREE.Group();
  const footMaterial = new THREE.MeshStandardMaterial({ color: 0x26334c, metalness: .72, roughness: .28 });
  for (const [x, z] of [[-1.5, 2.65], [1.5, 2.65], [0, -3.8]]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(.17, 1.8, .17), footMaterial);
    leg.position.set(x, -1.04, z);
    const foot = new THREE.Mesh(new THREE.BoxGeometry(.72, .12, .65), footMaterial);
    foot.position.set(x, -1.92, z + .18);
    gear.add(leg, foot);
  }
  gear.scale.y = .001;
  gear.visible = false;
  ship.add(gear);

  const rampPivot = new THREE.Group();
  rampPivot.position.set(0, -.32, 4.1);
  const ramp = new THREE.Mesh(new THREE.BoxGeometry(1.5, .12, 3.4), indigoLight);
  ramp.position.z = 1.6;
  ramp.castShadow = true;
  rampPivot.add(ramp);
  rampPivot.visible = false;
  ship.add(rampPivot);

  ship.scale.setScalar(.7);
  ship.userData = { gear, rampPivot, trails, materials: { ivory, indigo, canopy, cyan } };
  return ship;
}

const ship = createAurora();
ship.position.set(0, 182.4, 80);
scene.add(ship);

function createAstronaut() {
  const group = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: 0xe9dfcf, roughness: .72, metalness: .12 });
  const trim = new THREE.MeshStandardMaterial({ color: 0x343061, roughness: .45, metalness: .3 });
  const visor = new THREE.MeshStandardMaterial({ color: 0x0a7e7f, emissive: 0x07515a, emissiveIntensity: 1.5, metalness: .7, roughness: .16 });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(.72, .95, .4), suit);
  torso.position.y = 1.2;
  const head = new THREE.Mesh(new THREE.SphereGeometry(.34, 12, 8), visor);
  head.scale.z = .78;
  head.position.set(0, 1.92, -.02);
  const pack = new THREE.Mesh(new THREE.BoxGeometry(.62, .76, .28), trim);
  pack.position.set(0, 1.28, .35);
  group.add(torso, head, pack);
  for (const side of [-1, 1]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(.1, .65, 3, 6), suit);
    arm.position.set(side * .49, 1.2, 0);
    arm.rotation.z = side * -.08;
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(.13, .72, 3, 6), trim);
    leg.position.set(side * .21, .45, 0);
    group.add(arm, leg);
  }
  const lamp = makeGlow(0x62ffff, .55, .7);
  lamp.position.set(.32, 1.45, -.3);
  group.add(lamp);
  group.visible = false;
  group.scale.setScalar(.7);
  return group;
}

const astronaut = createAstronaut();
scene.add(astronaut);

let world = null;
let terrainMesh = null;
let waterMesh = null;
let planetMesh = null;
let atmosphereMesh = null;
let terrainObjects = null;
let landingBeacon = null;
const PLANET_RADIUS = 430;
const LANDING = new THREE.Vector3(145, 0, -115);

function disposeObject(root) {
  root.traverse((object) => {
    object.geometry?.dispose();
    if (Array.isArray(object.material)) object.material.forEach((material) => material.dispose());
    else object.material?.dispose();
  });
  root.removeFromParent();
}

function buildPlanet(destination) {
  if (world) disposeObject(world);
  world = new THREE.Group();
  world.name = `${destination.name} WORLD`;
  const random = mulberry32(destination.seed);
  const groundColor = new THREE.Color(destination.ground);
  const waterColor = new THREE.Color(destination.water);
  const accentColor = new THREE.Color(destination.accent);

  const planetGeometry = new THREE.IcosahedronGeometry(PLANET_RADIUS, 5);
  const planetColors = [];
  const position = planetGeometry.attributes.position;
  for (let index = 0; index < position.count; index += 1) {
    const vertex = new THREE.Vector3().fromBufferAttribute(position, index).normalize();
    const noise = Math.sin(vertex.x * 18 + destination.seed) + Math.cos(vertex.z * 25 - destination.seed * .3) + Math.sin(vertex.y * 31);
    const color = noise > .45 ? groundColor.clone().lerp(accentColor, clamp((noise - .4) * .18, 0, .28)) : waterColor.clone().multiplyScalar(.73 + Math.max(0, vertex.y) * .3);
    planetColors.push(color.r, color.g, color.b);
  }
  planetGeometry.setAttribute('color', new THREE.Float32BufferAttribute(planetColors, 3));
  const planetMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .79, metalness: .08, flatShading: true });
  planetMesh = new THREE.Mesh(planetGeometry, planetMaterial);
  planetMesh.position.y = -PLANET_RADIUS;
  planetMesh.receiveShadow = true;
  world.add(planetMesh);

  const atmosphereMaterial = new THREE.MeshBasicMaterial({ color: destination.sky, transparent: true, opacity: .2, side: THREE.BackSide, depthWrite: false, blending: THREE.AdditiveBlending });
  atmosphereMesh = new THREE.Mesh(new THREE.IcosahedronGeometry(PLANET_RADIUS + 12, 5), atmosphereMaterial);
  atmosphereMesh.position.copy(planetMesh.position);
  world.add(atmosphereMesh);

  const halo = new THREE.Mesh(
    new THREE.TorusGeometry(PLANET_RADIUS + 5, 3.2, 8, 160),
    new THREE.MeshBasicMaterial({ color: destination.accent, transparent: true, opacity: .45, blending: THREE.AdditiveBlending, depthWrite: false })
  );
  halo.rotation.x = Math.PI / 2;
  halo.position.copy(planetMesh.position);
  world.add(halo);

  if (destination.seed % 2 === 1) {
    const rings = new THREE.Mesh(
      new THREE.RingGeometry(PLANET_RADIUS * 1.15, PLANET_RADIUS * 1.42, 128),
      new THREE.MeshBasicMaterial({ color: destination.accent, transparent: true, opacity: .14, side: THREE.DoubleSide, depthWrite: false })
    );
    rings.rotation.x = Math.PI / 2;
    rings.position.copy(planetMesh.position);
    world.add(rings);
  }

  const terrainGeometry = new THREE.PlaneGeometry(1350, 1350, 108, 108);
  const terrainPosition = terrainGeometry.attributes.position;
  const terrainColors = [];
  for (let index = 0; index < terrainPosition.count; index += 1) {
    const x = terrainPosition.getX(index);
    const z = -terrainPosition.getY(index);
    const height = terrainHeight(x, z, destination.seed);
    terrainPosition.setZ(index, height);
    const aboveWater = clamp((height - 1.2) / 28, 0, 1);
    const color = height < 1.2
      ? waterColor.clone().multiplyScalar(.52)
      : groundColor.clone().lerp(accentColor, aboveWater * .2).offsetHSL((random() - .5) * .025, 0, (random() - .5) * .06);
    terrainColors.push(color.r, color.g, color.b);
  }
  terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(terrainColors, 3));
  terrainGeometry.computeVertexNormals();
  terrainGeometry.rotateX(-Math.PI / 2);
  const terrainMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .91, metalness: .03, flatShading: true, transparent: true, opacity: 0 });
  terrainMesh = new THREE.Mesh(terrainGeometry, terrainMaterial);
  terrainMesh.receiveShadow = true;
  terrainMesh.castShadow = true;
  terrainMesh.visible = false;
  world.add(terrainMesh);

  const waterGeometry = new THREE.PlaneGeometry(1350, 1350, 1, 1);
  const waterMaterial = new THREE.MeshStandardMaterial({ color: destination.water, emissive: destination.water, emissiveIntensity: .35, roughness: .18, metalness: .32, transparent: true, opacity: 0, depthWrite: false });
  waterMesh = new THREE.Mesh(waterGeometry, waterMaterial);
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.y = 1.2;
  waterMesh.visible = false;
  world.add(waterMesh);

  terrainObjects = new THREE.Group();
  const crystalGeometry = new THREE.ConeGeometry(.6, 4, 5);
  const crystalMaterial = new THREE.MeshStandardMaterial({ color: destination.ground, emissive: destination.accent, emissiveIntensity: .12, roughness: .68, flatShading: true });
  const crystals = new THREE.InstancedMesh(crystalGeometry, crystalMaterial, 180);
  const matrix = new THREE.Matrix4();
  for (let index = 0; index < 180; index += 1) {
    const x = (random() - .5) * 1050;
    const z = (random() - .5) * 1050;
    const y = terrainHeight(x, z, destination.seed);
    const scale = .6 + random() * 3.2;
    matrix.compose(
      new THREE.Vector3(x, y + scale * 1.9, z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(0, random() * Math.PI, (random() - .5) * .17)),
      new THREE.Vector3(scale, scale, scale)
    );
    crystals.setMatrixAt(index, matrix);
  }
  crystals.castShadow = true;
  crystals.receiveShadow = true;
  terrainObjects.add(crystals);
  terrainObjects.visible = false;
  world.add(terrainObjects);

  LANDING.y = terrainHeight(LANDING.x, LANDING.z, destination.seed);
  landingBeacon = new THREE.Group();
  const beaconRing = new THREE.Mesh(
    new THREE.RingGeometry(5.2, 5.55, 48),
    new THREE.MeshBasicMaterial({ color: destination.accent, transparent: true, opacity: .7, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })
  );
  beaconRing.rotation.x = -Math.PI / 2;
  const beaconStem = new THREE.Mesh(
    new THREE.CylinderGeometry(.06, .35, 10, 8, 1, true),
    new THREE.MeshBasicMaterial({ color: destination.accent, transparent: true, opacity: .32, blending: THREE.AdditiveBlending, depthWrite: false })
  );
  beaconStem.position.y = 5;
  const beaconGlow = makeGlow(destination.accent, 5, .45);
  beaconGlow.position.y = 10;
  landingBeacon.position.copy(LANDING);
  landingBeacon.position.y += .25;
  landingBeacon.add(beaconRing, beaconStem, beaconGlow);
  landingBeacon.visible = false;
  world.add(landingBeacon);

  const sun = makeGlow(destination.sun, 95, .8);
  sun.position.set(-390, 420, -800);
  world.add(sun);
  const sunCore = new THREE.Mesh(new THREE.IcosahedronGeometry(13, 2), new THREE.MeshBasicMaterial({ color: destination.sun }));
  sunCore.position.copy(sun.position);
  world.add(sunCore);

  scene.add(world);
  document.documentElement.style.setProperty('--planet', destination.ground);
  ui.systemName.textContent = `${destination.system} SYSTEM`;
}

buildPlanet(state.current);

scene.add(camera);

const skyRig = new THREE.Group();
const starDirections = [
  [-.72, .41, -.56], [-.35, .66, -.73], [.08, .48, -.88], [.48, .7, -.48], [.76, .2, -.61], [.58, -.18, -.79], [-.61, -.08, -.78]
];
const starBeacons = new Map();
DESTINATIONS.forEach((destination, index) => {
  const star = makeGlow(destination.sun, index === 0 ? 10 : 7 + (index % 3) * 1.2, .92);
  const direction = new THREE.Vector3(...starDirections[index]).normalize();
  star.position.copy(direction.multiplyScalar(720));
  star.userData.destination = destination;
  skyRig.add(star);
  starBeacons.set(destination.id, star);
});
scene.add(skyRig);

function createTravelStreaks() {
  const random = mulberry32(7321);
  const points = [];
  for (let index = 0; index < 240; index += 1) {
    const angle = random() * Math.PI * 2;
    const radius = 5 + random() * 92;
    const z = -20 - random() * 470;
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    points.push(x, y, z, x, y, z + 1.4 + random() * 4);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(points, 3));
  const material = new THREE.LineBasicMaterial({ color: 0x8df9ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, depthTest: false });
  const lines = new THREE.LineSegments(geometry, material);
  lines.frustumCulled = false;
  camera.add(lines);
  return lines;
}

const travelStreaks = createTravelStreaks();

function buildChart() {
  DESTINATIONS.forEach((destination) => {
    const button = document.createElement('button');
    button.className = 'star-node';
    button.type = 'button';
    button.dataset.id = destination.id;
    button.style.setProperty('--x', `${destination.map[0] / 10}%`);
    button.style.setProperty('--y', `${destination.map[1] / 6}%`);
    button.style.setProperty('--star', destination.sun);
    button.innerHTML = `<span>${destination.name}<small>${destination.system}</small></span>`;
    button.addEventListener('click', () => selectChartDestination(destination));
    ui.chartMap.append(button);
  });
  selectChartDestination(state.selected);
}

function selectChartDestination(destination) {
  state.selected = destination;
  document.querySelectorAll('.star-node').forEach((node) => {
    node.classList.toggle('selected', node.dataset.id === destination.id);
    node.classList.toggle('current', node.dataset.id === state.current.id);
  });
  ui.chartDestination.textContent = destination.name;
  ui.chartDescription.textContent = destination.description;
  ui.chartDistance.textContent = destination.id === state.current.id ? 'LOCAL ORBIT' : `${destination.distanceLy.toFixed(2)} LIGHT YEARS`;
  ui.chartClass.textContent = destination.className;
  ui.chartAtmosphere.textContent = destination.atmosphere;
  ui.planetPreview.style.setProperty('--planet', destination.ground);
  ui.plotCourse.textContent = destination.id === state.target.id ? 'WAYPOINT ACTIVE  ✓' : 'SET AS WAYPOINT  →';
}

buildChart();

function openChart() {
  if (!state.started || state.jump) return;
  state.chartOpen = true;
  ui.chart.classList.add('open');
  ui.chart.setAttribute('aria-hidden', 'false');
  selectChartDestination(state.target);
}

function closeChart() {
  state.chartOpen = false;
  ui.chart.classList.remove('open');
  ui.chart.setAttribute('aria-hidden', 'true');
}

function setTarget(destination, announce = true) {
  state.target = destination;
  state.selected = destination;
  ui.targetName.textContent = destination.id === state.current.id ? `${destination.name} // DELTA` : destination.name;
  ui.jumpButton.disabled = destination.id === state.current.id;
  selectChartDestination(destination);
  if (announce) toast('WAYPOINT LOCKED', destination.id === state.current.id ? 'River Delta approach plotted' : `${destination.name} synchronized`);
}

function cycleTarget() {
  const index = DESTINATIONS.findIndex((destination) => destination.id === state.target.id);
  setTarget(DESTINATIONS[(index + 1) % DESTINATIONS.length]);
}

function toast(title, message) {
  ui.toastTitle.textContent = title;
  ui.toastMessage.textContent = message;
  ui.toast.classList.add('show');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => ui.toast.classList.remove('show'), 2800);
}

function groundAt(x = ship.position.x, z = ship.position.z) {
  return terrainHeight(x, z, state.current.seed);
}

function shipAltitude() {
  return Math.max(0, ship.position.y - groundAt());
}

function toggleGear() {
  if (state.mode !== 'flight') return;
  if (!state.landed && shipAltitude() > 18) {
    toast('GEAR INTERLOCK', 'Descend below 18 km to deploy');
    return;
  }
  state.gearTarget = state.gearTarget > .5 ? 0 : 1;
  if (!state.gearTarget && state.landed) {
    state.gearTarget = 1;
    toast('GEAR LOCKED', 'Landing load detected');
    return;
  }
  toast('LANDING GEAR', state.gearTarget ? 'Deployment initiated' : 'Retracting');
}

function toggleRamp() {
  if (!state.landed || state.gear < .8 || state.mode !== 'flight') {
    toast('RAMP INTERLOCK', 'Land with gear deployed first');
    return;
  }
  state.rampTarget = state.rampTarget > .5 ? 0 : 1;
  toast('AFT RAMP', state.rampTarget ? 'Opening for surface egress' : 'Securing cabin');
}

function rampExitPosition() {
  const offset = new THREE.Vector3(0, 0, 6.4).applyAxisAngle(new THREE.Vector3(0, 1, 0), state.yaw);
  const result = ship.position.clone().add(offset);
  result.y = groundAt(result.x, result.z);
  return result;
}

function toggleEva() {
  if (state.mode === 'flight') {
    if (!state.landed || state.ramp < .8 || state.gear < .8) {
      toast('EVA INTERLOCK', 'Land and lower the ramp to disembark');
      return;
    }
    state.mode = 'foot';
    astronaut.position.copy(rampExitPosition());
    astronaut.visible = true;
    state.walkYaw = state.yaw;
    state.evaComplete = true;
    state.stepComplete.eva = true;
    toast('FIRST FOOTFALL', `${state.current.name} surface contact confirmed`);
    return;
  }
  const distance = new THREE.Vector2(astronaut.position.x - ship.position.x, astronaut.position.z - ship.position.z).length();
  if (distance > 10) {
    toast('AURORA', `${distance.toFixed(1)} km — move closer to the ramp`);
    return;
  }
  state.mode = 'flight';
  astronaut.visible = false;
  state.returnedToShip = true;
  toast('CABIN SECURE', 'Pilot link restored — close ramp and launch');
}

function takeOff() {
  if (!state.landed || state.mode !== 'flight') return false;
  if (state.ramp > .15) {
    toast('LAUNCH INTERLOCK', 'Close the aft ramp before lift-off');
    return true;
  }
  state.landed = false;
  state.verticalVelocity = 7.5;
  state.throttle = Math.max(.48, state.throttle);
  state.gearTarget = 0;
  state.descentAssist = false;
  toast('LIFT-OFF', 'AURORA is airborne');
  return true;
}

function toggleDescentAssist() {
  if (state.mode !== 'flight' || state.jump) return;
  if (state.landed) {
    toast('DESCENT ASSIST', 'Already on the surface');
    return;
  }
  if (state.target.id !== state.current.id) setTarget(state.current, false);
  state.descentAssist = !state.descentAssist;
  ui.autopilotButton.classList.toggle('active', state.descentAssist);
  toast('DESCENT ASSIST', state.descentAssist ? 'River Delta landing solution engaged' : 'Manual flight restored');
}

function startJump() {
  if (state.jump || state.mode !== 'flight') return;
  if (state.target.id === state.current.id) {
    toast('PULSE DRIVE', 'Select another star in the chart');
    return;
  }
  if (shipAltitude() < 85) {
    toast('PULSE DRIVE LOCKED', 'Climb above 85 km before interstellar travel');
    return;
  }
  const initialKm = state.target.distanceLy * 9.461e12;
  state.jump = { elapsed: 0, duration: reducedMotion ? 1.8 : 4.8, initialKm };
  state.descentAssist = false;
  ui.autopilotButton.classList.remove('active');
  ui.jumpDestination.textContent = state.target.name;
  ui.jumpOverlay.classList.add('active');
  ui.jumpOverlay.setAttribute('aria-hidden', 'false');
  toast('PULSE DRIVE', 'Space-time corridor acquired');
}

function finishJump() {
  const destination = state.target;
  state.current = destination;
  buildPlanet(destination);
  ship.position.set(0, 182.4, 80);
  state.yaw = 0;
  state.pitch = -.08;
  state.roll = 0;
  state.speed = 8.4;
  state.throttle = .34;
  state.verticalVelocity = 0;
  state.gear = state.gearTarget = 0;
  state.ramp = state.rampTarget = 0;
  state.landed = false;
  state.jump = null;
  ui.jumpOverlay.classList.remove('active');
  ui.jumpOverlay.setAttribute('aria-hidden', 'true');
  setTarget(destination, false);
  selectChartDestination(destination);
  toast('SYSTEM ARRIVAL', `${destination.system} orbit established`);
}

function updateJourney() {
  const altitude = shipAltitude();
  state.stepComplete = advanceJourney(state.stepComplete, {
    altitude,
    landed: state.landed,
    mode: state.mode,
    returnedToShip: state.returnedToShip
  });
  const order = ['orbit', 'atmosphere', 'land', 'eva', 'return'];
  const completed = order.filter((key) => state.stepComplete[key]).length;
  const active = order.find((key) => !state.stepComplete[key]);
  ui.journeyPercent.textContent = `${Math.round(14 + completed * 17.2)}%`;
  ui.journey.querySelectorAll('li').forEach((item) => {
    const key = item.dataset.step;
    item.classList.toggle('complete', state.stepComplete[key]);
    item.classList.toggle('active', key === active);
  });
  if (state.stepComplete.return) ui.missionCopy.textContent = 'Journey complete. The next charted light is waiting.';
  else if (state.mode === 'foot') ui.missionCopy.textContent = 'Explore the river delta, then return to AURORA through the aft ramp.';
  else if (state.landed) ui.missionCopy.textContent = 'Lower the aft ramp and step onto the generated terrain.';
  else if (altitude < 24) ui.missionCopy.textContent = 'Bleed speed, deploy landing gear, and follow the delta beacon.';
  else if (altitude < 95) ui.missionCopy.textContent = 'Atmosphere acquired. Hold the descent corridor.';
}

function openControls() {
  ui.controls.classList.toggle('open');
}

ui.launch.addEventListener('click', () => {
  state.started = true;
  ui.app.classList.add('started');
  ui.intro.classList.add('dismissed');
  setTimeout(() => toast('FLIGHT LINK', 'AURORA controls online — press P for descent assist'), 500);
});
ui.chartButton.addEventListener('click', openChart);
$('#target-chip').addEventListener('click', openChart);
ui.chartClose.addEventListener('click', closeChart);
ui.chart.querySelector('.chart-backdrop').addEventListener('click', closeChart);
ui.plotCourse.addEventListener('click', () => { setTarget(state.selected); closeChart(); });
ui.targetButton.addEventListener('click', cycleTarget);
ui.jumpButton.addEventListener('click', startJump);
ui.gearButton.addEventListener('click', toggleGear);
ui.rampButton.addEventListener('click', toggleRamp);
ui.evaButton.addEventListener('click', toggleEva);
ui.autopilotButton.addEventListener('click', toggleDescentAssist);
ui.helpButton.addEventListener('click', openControls);
ui.marker.addEventListener('click', () => state.target.id === state.current.id ? toggleDescentAssist() : startJump());

window.addEventListener('keydown', (event) => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
  state.keys.add(event.code);
  if (event.repeat) return;
  if (event.code === 'Escape' && state.chartOpen) return closeChart();
  if (event.code === 'KeyM') return state.chartOpen ? closeChart() : openChart();
  if (state.chartOpen || !state.started) return;
  if (event.code === 'KeyT') cycleTarget();
  if (event.code === 'KeyJ') startJump();
  if (event.code === 'KeyG') toggleGear();
  if (event.code === 'KeyR') toggleRamp();
  if (event.code === 'KeyF') toggleEva();
  if (event.code === 'KeyP') toggleDescentAssist();
  if (event.code === 'KeyV') {
    state.cameraMode = (state.cameraMode + 1) % 2;
    toast('CAMERA', state.cameraMode ? 'Close chase view' : 'Wide chase view');
  }
  if (event.code === 'Space' && state.landed) takeOff();
});
window.addEventListener('keyup', (event) => state.keys.delete(event.code));
window.addEventListener('blur', () => state.keys.clear());
window.addEventListener('wheel', (event) => {
  if (!state.started || state.chartOpen || state.mode !== 'flight') return;
  state.throttle = clamp(state.throttle - Math.sign(event.deltaY) * .06, 0, 1);
}, { passive: true });

let dragging = false;
let lastPointer = { x: 0, y: 0 };
canvas.addEventListener('pointerdown', (event) => {
  if (!state.started || state.chartOpen) return;
  dragging = true;
  lastPointer = { x: event.clientX, y: event.clientY };
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener('pointermove', (event) => {
  if (!dragging || state.mode !== 'flight' || state.descentAssist) return;
  const dx = event.clientX - lastPointer.x;
  const dy = event.clientY - lastPointer.y;
  state.yaw -= dx * .0025;
  state.pitch = clamp(state.pitch - dy * .002, -.48, .48);
  lastPointer = { x: event.clientX, y: event.clientY };
});
canvas.addEventListener('pointerup', () => { dragging = false; });

window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
});

const UP = new THREE.Vector3(0, 1, 0);
const FORWARD = new THREE.Vector3(0, 0, -1);
const tempVector = new THREE.Vector3();
const tempVectorB = new THREE.Vector3();
const cameraTarget = new THREE.Vector3();

function angleDelta(from, to) {
  return Math.atan2(Math.sin(to - from), Math.cos(to - from));
}

function damp(current, target, smoothing, dt) {
  return lerp(current, target, 1 - Math.exp(-smoothing * dt));
}

function settleOnSurface() {
  const ground = groundAt();
  ship.position.y = ground + 1.42;
  state.landed = true;
  state.wasLanded = true;
  state.speed = 0;
  state.verticalVelocity = 0;
  state.throttle = 0;
  state.pitch = 0;
  state.roll = 0;
  state.gearTarget = 1;
  state.descentAssist = false;
  ui.autopilotButton.classList.remove('active');
  state.stepComplete.land = true;
  toast('TOUCHDOWN', `${state.current.name} // River Delta`);
}

function updateDescentAssist(dt) {
  tempVector.set(LANDING.x - ship.position.x, 0, LANDING.z - ship.position.z);
  const horizontalDistance = tempVector.length();
  if (horizontalDistance > .001) tempVector.normalize();
  const targetYaw = Math.atan2(-tempVector.x, -tempVector.z);
  state.yaw += angleDelta(state.yaw, targetYaw) * Math.min(1, dt * 1.8);
  const approachSpeed = clamp(horizontalDistance * .14, 2.2, shipAltitude() > 70 ? 31 : 18);
  state.speed = damp(state.speed, approachSpeed, 2.2, dt);
  const movement = Math.min(horizontalDistance, state.speed * dt);
  ship.position.x += tempVector.x * movement;
  ship.position.z += tempVector.z * movement;

  const ground = groundAt();
  const desiredAltitude = 1.42 + clamp(horizontalDistance * .42, 0, 145);
  const currentAltitude = ship.position.y - ground;
  const descentRate = clamp(Math.abs(currentAltitude - desiredAltitude) * .36, .35, 15);
  ship.position.y += Math.sign(desiredAltitude - currentAltitude) * Math.min(Math.abs(desiredAltitude - currentAltitude), descentRate * dt);
  state.pitch = damp(state.pitch, clamp((desiredAltitude - currentAltitude) * .012, -.24, .12), 2.1, dt);
  state.roll = damp(state.roll, angleDelta(state.yaw, targetYaw) * -.6, 2.2, dt);
  state.throttle = clamp(state.speed / 31, .12, .74);
  if (shipAltitude() < 16) state.gearTarget = 1;
  if (horizontalDistance < 1.7 && shipAltitude() < 1.7 && state.gear > .78) settleOnSurface();
}

function updateManualFlight(dt) {
  const yawInput = (state.keys.has('KeyA') || state.keys.has('ArrowLeft') ? 1 : 0) - (state.keys.has('KeyD') || state.keys.has('ArrowRight') ? 1 : 0);
  const pitchInput = (state.keys.has('ArrowUp') ? 1 : 0) - (state.keys.has('ArrowDown') ? 1 : 0);
  const rollInput = (state.keys.has('KeyQ') ? 1 : 0) - (state.keys.has('KeyE') ? 1 : 0);
  if (state.keys.has('KeyW')) state.throttle = clamp(state.throttle + dt * .28, 0, 1);
  if (state.keys.has('KeyS')) state.throttle = clamp(state.throttle - dt * .32, 0, 1);
  state.yaw += yawInput * dt * (.62 + state.speed * .006);
  state.pitch = clamp(state.pitch + pitchInput * dt * .48, -.52, .52);
  const targetRoll = rollInput * .5 + yawInput * .25;
  state.roll = damp(state.roll, targetRoll, 3.2, dt);

  state.boostHeld = (state.keys.has('ShiftLeft') || state.keys.has('ShiftRight')) && state.boost > .015;
  state.brakeHeld = state.keys.has('KeyX');
  if (state.boostHeld) state.boost = clamp(state.boost - dt * .115, 0, 1);
  else state.boost = clamp(state.boost + dt * .055, 0, 1);

  const atmosphere = clamp(1 - shipAltitude() / 120, 0, 1);
  let targetSpeed = 3 + state.throttle * (29 - atmosphere * 8);
  if (state.boostHeld) targetSpeed += 58;
  if (state.brakeHeld) targetSpeed = Math.min(targetSpeed, 3.2);
  state.speed = damp(state.speed, targetSpeed, state.brakeHeld ? 4.7 : 1.7, dt);

  ship.rotation.order = 'YXZ';
  ship.rotation.set(state.pitch, state.yaw, state.roll);
  const forward = FORWARD.clone().applyQuaternion(ship.quaternion).normalize();
  ship.position.x += forward.x * state.speed * dt;
  ship.position.z += forward.z * state.speed * dt;

  const verticalInput = (state.keys.has('Space') ? 1 : 0) - (state.keys.has('KeyC') ? 1 : 0);
  state.verticalVelocity += verticalInput * dt * (8.5 + atmosphere * 5);
  state.verticalVelocity -= atmosphere * dt * .42;
  state.verticalVelocity *= Math.exp(-dt * (1.3 + atmosphere * .5));
  ship.position.y += (forward.y * state.speed * .63 + state.verticalVelocity) * dt;

  ship.position.x = clamp(ship.position.x, -610, 610);
  ship.position.z = clamp(ship.position.z, -610, 610);
  const clearance = ship.position.y - groundAt();
  if (clearance < 1.3) {
    if (state.gear > .72 && state.speed < 14 && Math.abs(state.verticalVelocity) < 5) settleOnSurface();
    else {
      ship.position.y = groundAt() + 2.1;
      state.verticalVelocity = Math.max(3, -state.verticalVelocity * .25);
      state.speed *= .52;
      toast('PROXIMITY ALERT', state.gear < .72 ? 'Deploy landing gear before contact' : 'Reduce approach speed');
    }
  }
}

function updateFlight(dt) {
  if (state.mode !== 'flight' || state.landed) return;
  if (state.descentAssist) updateDescentAssist(dt);
  else updateManualFlight(dt);
  ship.rotation.order = 'YXZ';
  ship.rotation.set(state.pitch, state.yaw, state.roll);
}

function updateFoot(dt) {
  if (state.mode !== 'foot') return;
  const turn = (state.keys.has('KeyA') || state.keys.has('ArrowLeft') ? 1 : 0) - (state.keys.has('KeyD') || state.keys.has('ArrowRight') ? 1 : 0);
  const walk = (state.keys.has('KeyW') || state.keys.has('ArrowUp') ? 1 : 0) - (state.keys.has('KeyS') || state.keys.has('ArrowDown') ? 1 : 0);
  state.walkYaw += turn * dt * 1.65;
  const walkSpeed = state.keys.has('ShiftLeft') || state.keys.has('ShiftRight') ? 7 : 3.8;
  astronaut.position.x -= Math.sin(state.walkYaw) * walk * walkSpeed * dt;
  astronaut.position.z -= Math.cos(state.walkYaw) * walk * walkSpeed * dt;
  astronaut.position.x = clamp(astronaut.position.x, -610, 610);
  astronaut.position.z = clamp(astronaut.position.z, -610, 610);
  astronaut.position.y = groundAt(astronaut.position.x, astronaut.position.z) + Math.abs(Math.sin(state.elapsed * 8)) * Math.abs(walk) * .06;
  astronaut.rotation.y = state.walkYaw;
}

function updateLandingHardware(dt) {
  state.gear = damp(state.gear, state.gearTarget, 4, dt);
  state.ramp = damp(state.ramp, state.rampTarget, 3, dt);
  const gear = ship.userData.gear;
  gear.visible = state.gear > .015;
  gear.scale.y = Math.max(.001, state.gear);
  const ramp = ship.userData.rampPivot;
  ramp.visible = state.ramp > .015;
  ramp.rotation.x = state.ramp * -.62;
}

function updateWorld(dt) {
  const altitude = shipAltitude();
  const atmosphere = clamp((125 - altitude) / 116, 0, 1);
  const terrainReveal = clamp((128 - altitude) / 62, 0, 1);
  document.documentElement.style.setProperty('--atmo', atmosphere.toFixed(3));
  scene.fog.color.set(state.current.sky).lerp(new THREE.Color(0x234469), 1 - atmosphere);
  scene.fog.density = lerp(.00012, .0041, atmosphere * atmosphere);
  hemiLight.intensity = lerp(2.1, 3.15, atmosphere);
  terrainMesh.visible = terrainReveal > .01;
  terrainMesh.material.opacity = terrainReveal;
  waterMesh.visible = terrainReveal > .02;
  waterMesh.material.opacity = terrainReveal * .68;
  waterMesh.position.y = 1.2 + Math.sin(state.elapsed * .62) * .06;
  terrainObjects.visible = altitude < 62;
  landingBeacon.visible = altitude < 145 && !state.landed;
  if (landingBeacon.visible) {
    landingBeacon.rotation.y += dt * .38;
    landingBeacon.children[1].material.opacity = .22 + Math.sin(state.elapsed * 2.5) * .08;
  }
  atmosphereMesh.material.opacity = .13 + atmosphere * .12;
  planetMesh.rotation.y += altitude > 130 ? dt * .002 : 0;
  skyRig.position.copy(camera.position);
  starBeacons.forEach((star, id) => {
    star.visible = altitude > 22 && id !== state.current.id;
    star.material.opacity = clamp((altitude - 18) / 55, .08, .92);
  });
}

function updateEffects(dt) {
  const jumpStrength = state.jump ? 1 : 0;
  const boostStrength = state.boostHeld ? .64 : 0;
  travelStreaks.material.opacity = damp(travelStreaks.material.opacity, jumpStrength * .78 + boostStrength * .3, 5, dt);
  travelStreaks.scale.z = damp(travelStreaks.scale.z, state.jump ? 13 : state.boostHeld ? 4.5 : 1, 4, dt);
  const positions = travelStreaks.geometry.attributes.position;
  const travel = dt * (state.jump ? 420 : state.boostHeld ? 95 : 10);
  for (let index = 0; index < positions.count; index += 2) {
    let z = positions.getZ(index) + travel;
    const length = positions.getZ(index + 1) - positions.getZ(index);
    if (z > 10) z = -490;
    positions.setZ(index, z);
    positions.setZ(index + 1, z + length);
  }
  positions.needsUpdate = true;
  ship.userData.trails.forEach((trail) => {
    trail.scale.y = damp(trail.scale.y, state.jump ? 3.5 : state.boostHeld ? 2.4 : .75 + state.throttle * .55, 6, dt);
    trail.material.opacity = state.mode === 'foot' || state.landed ? .06 : .25 + state.throttle * .25 + boostStrength * .45;
  });
  const targetFov = state.jump ? 84 : state.boostHeld ? 71 : state.cameraMode ? 67 : 61;
  camera.fov = damp(camera.fov, targetFov, 4, dt);
  camera.updateProjectionMatrix();
}

function updateCamera(dt) {
  if (state.jump) {
    const shake = reducedMotion ? 0 : .08 + Math.sin(state.elapsed * 29) * .06;
    camera.position.x += shake;
    return;
  }
  if (state.mode === 'foot') {
    const backward = new THREE.Vector3(Math.sin(state.walkYaw), 0, Math.cos(state.walkYaw));
    tempVector.copy(astronaut.position).addScaledVector(backward, 5.3).add(new THREE.Vector3(0, 2.8, 0));
    camera.position.lerp(tempVector, 1 - Math.exp(-dt * 5));
    cameraTarget.copy(astronaut.position).add(new THREE.Vector3(0, 1.25, 0)).addScaledVector(backward, -5);
    camera.lookAt(cameraTarget);
    return;
  }
  const offset = state.cameraMode ? new THREE.Vector3(0, 2.45, 8.7) : new THREE.Vector3(0, 5.2, 15.2);
  offset.applyQuaternion(ship.quaternion);
  tempVector.copy(ship.position).add(offset);
  camera.position.lerp(tempVector, 1 - Math.exp(-dt * (state.cameraMode ? 5.5 : 3.3)));
  const forward = FORWARD.clone().applyQuaternion(ship.quaternion);
  cameraTarget.copy(ship.position).addScaledVector(forward, state.cameraMode ? 18 : 11);
  cameraTarget.y -= state.cameraMode ? .2 : 2.15;
  camera.lookAt(cameraTarget);
}

function markerPosition() {
  if (state.mode === 'foot') {
    ui.markerName.textContent = 'AURORA';
    const distance = new THREE.Vector2(astronaut.position.x - ship.position.x, astronaut.position.z - ship.position.z).length();
    ui.markerDistance.textContent = formatDistance(distance);
    return ship.position.clone().add(new THREE.Vector3(0, 3.5, 0));
  }
  if (state.target.id === state.current.id) {
    const distance = ship.position.distanceTo(LANDING);
    ui.markerName.textContent = 'RIVER DELTA';
    ui.markerDistance.textContent = formatDistance(distance);
    return LANDING.clone().add(new THREE.Vector3(0, 9, 0));
  }
  const beacon = starBeacons.get(state.target.id);
  ui.markerName.textContent = state.target.name;
  ui.markerDistance.textContent = `${state.target.distanceLy.toFixed(2)} ly`;
  return beacon.getWorldPosition(new THREE.Vector3());
}

function updateMarker() {
  const point = markerPosition();
  const direction = camera.getWorldDirection(tempVectorB);
  const relative = tempVector.copy(point).sub(camera.position);
  const visible = direction.dot(relative.normalize()) > .05;
  point.project(camera);
  const inFrame = visible && Math.abs(point.x) < .93 && Math.abs(point.y) < .84;
  ui.marker.style.visibility = inFrame ? 'visible' : 'hidden';
  if (inFrame) {
    ui.marker.style.left = `${(point.x * .5 + .5) * innerWidth}px`;
    ui.marker.style.top = `${(-point.y * .5 + .5) * innerHeight}px`;
  }
}

function updateHud() {
  const altitude = shipAltitude();
  let targetKm;
  if (state.jump) targetKm = travelDistance(state.jump.initialKm, state.jump.elapsed / state.jump.duration);
  else if (state.target.id === state.current.id) targetKm = ship.position.distanceTo(LANDING);
  else targetKm = state.target.distanceLy * 9.461e12;
  ui.targetDistance.textContent = formatDistance(targetKm);
  ui.speed.textContent = (state.speed * .05).toFixed(2);
  ui.altitude.textContent = altitude < 10 ? altitude.toFixed(2) : altitude.toFixed(1);
  ui.heading.textContent = headingLabel(-state.yaw);
  state.phase = state.mode === 'foot' ? 'surface eva' : state.landed ? 'landed' : altitude > 95 ? 'orbital' : altitude > 12 ? 'atmospheric' : 'terrain flight';
  ui.mode.textContent = state.phase.toUpperCase();
  ui.thrust.style.width = `${state.throttle * 100}%`;
  ui.thrustLabel.textContent = `${Math.round(state.throttle * 100)}%`;
  ui.boost.style.width = `${state.boost * 100}%`;
  ui.boostLabel.textContent = `${Math.round(state.boost * 100)}%`;
  ui.gearButton.classList.toggle('active', state.gearTarget > .5);
  ui.rampButton.classList.toggle('active', state.rampTarget > .5);
  ui.evaButton.classList.toggle('active', state.mode === 'foot');
  ui.evaButton.querySelector('span').textContent = state.mode === 'foot' ? 'BOARD SHIP' : 'DISEMBARK';
  ui.jumpButton.disabled = state.target.id === state.current.id || state.mode === 'foot' || Boolean(state.jump);
  updateMarker();
  updateJourney();
}

function updateJump(dt) {
  if (!state.jump) return false;
  state.jump.elapsed += dt;
  const progress = clamp(state.jump.elapsed / state.jump.duration, 0, 1);
  if (progress < .18) ui.jumpCountdown.textContent = `CHARGING ${Math.round(progress / .18 * 100)}%`;
  else if (progress < .86) ui.jumpCountdown.textContent = `TRANSIT ${Math.round(progress * 100)}%`;
  else ui.jumpCountdown.textContent = 'REALSPACE LOCK';
  if (progress >= 1) finishJump();
  return true;
}

function animate(now) {
  const dt = Math.min(.05, Math.max(.001, (now - state.lastTime) / 1000));
  state.lastTime = now;
  state.elapsed += dt;

  const jumping = updateJump(dt);
  if (state.started && !state.chartOpen && !jumping) {
    updateFlight(dt);
    updateFoot(dt);
  }
  updateLandingHardware(dt);
  updateCamera(dt);
  updateWorld(dt);
  updateEffects(dt);
  updateHud();
  renderer.render(scene, camera);
}

setTarget(state.current, false);
updateHud();
renderer.setAnimationLoop(animate);
