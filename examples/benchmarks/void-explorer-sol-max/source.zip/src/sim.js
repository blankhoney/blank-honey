export const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
export const lerp = (a, b, amount) => a + (b - a) * amount;

export function mulberry32(seed) {
  return function random() {
    let value = (seed += 0x6d2b79f5);
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function terrainHeight(x, z, seed = 17) {
  const offset = seed * 0.731;
  const broad = Math.sin(x * 0.009 + offset) * 7 + Math.cos(z * 0.011 - offset) * 6;
  const ridges = Math.abs(Math.sin((x + z) * 0.021 + offset) * 12) - 4;
  const detail = Math.sin(x * 0.051) * Math.cos(z * 0.047) * 2.4;
  const riverCenter = Math.sin(z * 0.006 + offset) * 74 + Math.sin(z * 0.019) * 18;
  const riverCut = Math.max(0, 1 - Math.abs(x - riverCenter) / 32);
  return broad + ridges + detail + 8 - riverCut * riverCut * 27;
}

export function formatDistance(km) {
  if (!Number.isFinite(km)) return '—';
  if (km >= 9.461e12) return `${(km / 9.461e12).toFixed(2)} ly`;
  if (km >= 1e6) return `${(km / 1e6).toFixed(2)}m km`;
  if (km >= 1000) return `${(km / 1000).toFixed(1)}k km`;
  if (km < 10) return `${km.toFixed(2)} km`;
  return `${km.toFixed(1)} km`;
}

export function headingLabel(radians) {
  const degrees = ((radians * 180) / Math.PI + 360) % 360;
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return `${String(Math.round(degrees)).padStart(3, '0')}° ${directions[Math.round(degrees / 45) % 8]}`;
}

export function travelDistance(initialKm, progress) {
  const eased = 1 - Math.pow(1 - clamp(progress, 0, 1), 3);
  return initialKm * (1 - eased);
}

export function advanceJourney(previous, snapshot) {
  const next = { ...previous };
  if (snapshot.altitude < 95) next.orbit = true;
  if (snapshot.altitude < 24) next.atmosphere = true;
  if (snapshot.landed) next.land = true;
  if (snapshot.mode === 'foot') next.eva = true;
  if (snapshot.returnedToShip && !snapshot.landed && snapshot.altitude > 95) next.return = true;
  return next;
}

export const DESTINATIONS = [
  {
    id: 'luma', name: 'LUMA PRIME', system: 'HELIX-7', distanceLy: 0, map: [80, 410], seed: 17,
    className: 'PELAGIC', atmosphere: 'BREATHABLE',
    description: 'An ocean world cut by luminous river deltas and lavender highlands.',
    sky: '#4d8fc5', ground: '#4d3f8d', accent: '#46f4e3', water: '#0dc6d2', sun: '#ffd66e'
  },
  {
    id: 'vesper', name: 'VESPER REACH', system: 'VESPER-3', distanceLy: 3.84, map: [410, 350], seed: 31,
    className: 'TWILIGHT', atmosphere: 'THIN / ARGON',
    description: 'A permanent dusk world of copper mesas, glass plains, and long blue shadows.',
    sky: '#aa668d', ground: '#8c4c67', accent: '#ffab77', water: '#334b91', sun: '#ff9f68'
  },
  {
    id: 'eir', name: 'EIR SANCTUM', system: 'KITE-11', distanceLy: 6.21, map: [635, 110], seed: 49,
    className: 'GLACIAL', atmosphere: 'OXYGEN TRACE',
    description: 'Prismatic ice shelves orbit a quiet inland sea beneath twin cyan suns.',
    sky: '#79b7d5', ground: '#b4d2dc', accent: '#78fff2', water: '#3876ad', sun: '#c9ffff'
  },
  {
    id: 'morrow', name: 'MORROW DEEP', system: 'UMBRA-6', distanceLy: 8.76, map: [690, 205], seed: 64,
    className: 'SUPER-EARTH', atmosphere: 'DENSE / N₂',
    description: 'Vast indigo forests climb over warm plateaus beneath a broad silver ring.',
    sky: '#575a9f', ground: '#333b6d', accent: '#ff5ccf', water: '#173f71', sun: '#f7b3ff'
  },
  {
    id: 'caelum', name: 'CAELUM ARCHIVE', system: 'CAELUM-2', distanceLy: 12.43, map: [930, 120], seed: 83,
    className: 'RELIC', atmosphere: 'IONIZED',
    description: 'Geometric ruins and floating mineral reefs surround a brilliant white star.',
    sky: '#6e91ba', ground: '#8b7ba6', accent: '#fff38e', water: '#428fb0', sun: '#fff9d8'
  },
  {
    id: 'nyx', name: 'NYX CASCADE', system: 'NYX-14', distanceLy: 9.18, map: [865, 505], seed: 101,
    className: 'VOLCANIC', atmosphere: 'SULFUR VEIL',
    description: 'Black island chains rise through a warm magenta ocean threaded with lightning.',
    sky: '#9b5484', ground: '#493655', accent: '#ff6b9d', water: '#74377f', sun: '#ffb85d'
  },
  {
    id: 'solace', name: 'SOLACE DRIFT', system: 'DRIFT-8', distanceLy: 5.07, map: [510, 455], seed: 122,
    className: 'TEMPERATE', atmosphere: 'BREATHABLE',
    description: 'Wind-scoured grasslands and shallow mirror lakes cover a wandering rogue world.',
    sky: '#5f9da2', ground: '#557d68', accent: '#8dffd3', water: '#3c8ba0', sun: '#ffe2a0'
  }
];

function selfCheck() {
  console.assert(formatDistance(9461000000000) === '1.00 ly', 'light-year formatting');
  console.assert(formatDistance(182.44) === '182.4 km', 'kilometre formatting');
  console.assert(travelDistance(100, 0) === 100 && travelDistance(100, 1) === 0, 'travel endpoints');
  console.assert(terrainHeight(12, 34, 17) === terrainHeight(12, 34, 17), 'terrain determinism');
  console.assert(DESTINATIONS.every((destination) => destination.map.length === 2), 'chart coordinates');
  let journey = { orbit: false, atmosphere: false, land: false, eva: false, return: false };
  journey = advanceJourney(journey, { altitude: 90, landed: false, mode: 'flight', returnedToShip: false });
  journey = advanceJourney(journey, { altitude: 20, landed: false, mode: 'flight', returnedToShip: false });
  journey = advanceJourney(journey, { altitude: 1.4, landed: true, mode: 'flight', returnedToShip: false });
  journey = advanceJourney(journey, { altitude: 1.4, landed: true, mode: 'foot', returnedToShip: false });
  journey = advanceJourney(journey, { altitude: 110, landed: false, mode: 'flight', returnedToShip: true });
  console.assert(Object.values(journey).every(Boolean), 'complete orbit-to-surface-to-orbit journey');
  console.log('simulation self-check passed');
}

if (typeof process !== 'undefined' && process.argv[1]?.endsWith('/sim.js')) selfCheck();
