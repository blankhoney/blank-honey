import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createIcons, Sun, Sunset, Moon, RotateCcw, Maximize, Minimize, Plus, Minus, Camera, PanelsTopLeft, X, Play, Pause, MousePointer2 } from 'lucide';
import { buildArchitecture, BUILDINGS } from './architecture.js';
import { seededRandom } from './voxels.js';
import './style.css';

const ICONS = { Sun, Sunset, Moon, RotateCcw, Maximize, Minimize, Plus, Minus, Camera, PanelsTopLeft, X, Play, Pause, MousePointer2 };
const icon = name => `<i data-lucide="${name}" aria-hidden="true"></i>`;
const app = document.querySelector('#app');
app.innerHTML = `
  <canvas class="scene" tabindex="0" aria-label="云阙山院三维场景。拖动旋转，滚轮缩放；可使用全景、中轴、俯瞰按钮选择视角。"></canvas>
  <div class="vignette"></div>
  <div class="hotspots" hidden>${BUILDINGS.map(b => `<button class="hotspot" data-building="${b.id}" aria-label="查看${b.name}">${b.number}</button>`).join('')}</div>
  <div class="chrome">
    <header class="header">
      <div class="identity"><div class="seal" aria-hidden="true">云</div><div class="wordmark"><strong>云阙</strong><span>YUNQUE</span></div><div class="header-divider"></div><span class="edition">中式建筑 · 体素漫游</span></div>
      <div class="header-actions"><button class="guide-toggle" id="guide-toggle" aria-expanded="false" aria-controls="guide">${icon('panels-top-left')}<span>建筑导览</span></button><button class="icon-button" id="fullscreen" title="全屏观看" aria-label="全屏观看">${icon('maximize')}</button></div>
    </header>
    <section class="intro"><div class="eyebrow">一座院落，六重风景</div><h1>云阙山院</h1><p>叠檐藏山色，入院见天地。</p><div class="intro-line"></div><div class="caption"><span>东方营造</span><span>/</span><span>VOXEL NO. 001</span></div></section>
    <div class="scene-index" aria-hidden="true">方寸之间<i></i>山水有境</div>
    <nav class="view-picker" aria-label="选择观察视角"><button data-view="overview" aria-pressed="true">全景<span class="view-en">OVERVIEW</span></button><button data-view="axis" aria-pressed="false">中轴<span class="view-en">CENTRAL AXIS</span></button><button data-view="plan" aria-pressed="false">俯瞰<span class="view-en">BIRD’S EYE</span></button></nav>
    <div class="zoom-controls" aria-label="视角缩放"><button id="zoom-in" class="icon-button" title="放大" aria-label="放大">${icon('plus')}</button><span class="divider"></span><button id="zoom-out" class="icon-button" title="缩小" aria-label="缩小">${icon('minus')}</button></div>
    <div class="compass" aria-label="指北针"><span class="compass-label">N</span><div class="compass-needle"></div></div>
    <div class="dock-wrap"><div class="dock" aria-label="场景工具栏">
      <div class="lighting-switch" aria-label="光照时段"><button data-light="day" aria-pressed="true" title="日照 · 快捷键 1">${icon('sun')}<span>日照</span></button><button data-light="sunset" aria-pressed="false" title="暮色 · 快捷键 2">${icon('sunset')}<span>暮色</span></button><button data-light="night" aria-pressed="false" title="月夜 · 快捷键 3">${icon('moon')}<span>月夜</span></button></div>
      <span class="divider"></span><button id="orbit" aria-pressed="false" aria-label="开启自动环游" title="自动环游 · 空格">${icon('play')}<span class="orbit-label">环游</span></button><button class="square" id="reset" title="回到全景 · R" aria-label="回到全景">${icon('rotate-ccw')}</button><button class="square" id="capture" title="保存场景图片" aria-label="保存场景图片">${icon('camera')}</button>
    </div><div class="control-hint">${icon('mouse-pointer-2')}<span class="desktop-hint">拖动旋转<b>·</b>滚轮缩放<b>·</b>右键平移</span><span class="mobile-hint" hidden>单指旋转<b>·</b>双指缩放与平移</span></div></div>
    <aside class="guide" id="guide" aria-label="建筑导览" hidden>
      <div class="guide-head"><div><div class="guide-kicker">EXPLORE THE COURTYARD</div><h2>院落导览</h2></div><button class="icon-button" id="guide-close" title="关闭导览" aria-label="关闭导览">${icon('x')}</button></div>
      <div class="plan-map" aria-label="建筑布局示意图">${BUILDINGS.map(b => {
        const p = {main:[50,25,68,28],west:[24,54,27,41],east:[76,54,27,41],gate:[50,83,47,19],'west-tower':[21,20,22,22],'east-tower':[79,20,22,22]}[b.id];
        return `<button class="plan-node" data-building="${b.id}" aria-label="${b.name}" style="left:${p[0]}%;top:${p[1]}%;width:${p[2]}px;height:${p[3]}px">${b.number}</button>`;
      }).join('')}</div>
      <div class="guide-list">${BUILDINGS.map(b=>`<button class="building-row" data-building="${b.id}"><span class="building-number">${b.number}</span><span class="building-name">${b.name}</span><span class="building-roof">${b.type.split(' · ')[0]}</span></button>`).join('')}</div>
      <div class="building-detail" aria-live="polite"><div class="detail-en">SIX BUILDINGS. ONE HARMONIOUS WHOLE.</div><p>沿中轴穿过山门，走入庭院。选择一座建筑，靠近看看它的飞檐与木构。</p></div>
    </aside>
    <footer class="footer"><div class="footer-left"><span>AN EXPLORATION IN MINIATURE</span><span>以方为形 · 以境为意</span></div><span class="live" id="scene-status">实时三维场景</span></footer>
  </div>
  <div class="toast" role="status" aria-live="polite"></div>
  <div class="loading"><div class="seal">云</div><span>正在营造一方天地</span></div>
`;
createIcons({ icons: ICONS });

const canvas = document.querySelector('.scene');
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
} catch (error) {
  document.querySelector('.loading').innerHTML = `<div class="error-card"><h2>暂时无法开启三维场景</h2><p>请使用支持 WebGL 2 的现代浏览器，并在浏览器设置中开启图形加速后重试。</p><button onclick="location.reload()">重新加载</button></div>`;
  throw error;
}

renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = false;
renderer.shadowMap.needsUpdate = true;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.18;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#dce0d7');
scene.fog = new THREE.Fog('#dce0d7', 180, 460);
const camera = new THREE.OrthographicCamera(-100, 100, 70, -70, 1, 700);
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.dampingFactor = 0.07;
controls.minZoom = 0.6;
controls.maxZoom = 3.6;
controls.minPolarAngle = 0.08;
controls.maxPolarAngle = Math.PI * 0.46;
controls.maxTargetRadius = 60;
controls.autoRotateSpeed = 0.48;
controls.enablePan = true;
controls.screenSpacePanning = true;
controls.zoomSpeed = 0.78;

const sun = new THREE.DirectionalLight('#fff0d5', 3.4);
sun.position.set(-55, 85, 65);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -76, right: 76, top: 76, bottom: -76, near: 1, far: 240 });
sun.shadow.bias = -0.00025;
sun.shadow.normalBias = 0.15;
sun.shadow.radius = 2.2;
scene.add(sun);
const hemisphere = new THREE.HemisphereLight('#e9f0e5', '#64735d', 1.9);
scene.add(hemisphere);
const fill = new THREE.DirectionalLight('#cfdfeb', 0.55);
fill.position.set(70, 45, -30);
scene.add(fill);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshLambertMaterial({ color: '#d3d8cb' }));
ground.rotation.x = -Math.PI / 2;
ground.position.y = -7.5;
ground.receiveShadow = true;
scene.add(ground);

const architecture = buildArchitecture(scene);
const glowLights = [];
// Only four unshadowed local lights: lantern glow without per-lantern draw overhead.
for (const pos of [[0, 5, -7], [0, 4, 34], [-18, 4, 5], [18, 4, 5]]) {
  const light = new THREE.PointLight('#ffbb63', 0, 26, 1.6);
  light.position.set(...pos);
  scene.add(light);
  glowLights.push(light);
}

// Small cube petals and warm drifting motes. Animated as one instanced mesh.
const random = seededRandom(811);
const particleCount = 58;
const particleMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.14, 0.11, 0.16), new THREE.MeshBasicMaterial({ color: '#f1c3ac', transparent: true, opacity: 0.7 }), particleCount);
particleMesh.frustumCulled = false;
particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
scene.add(particleMesh);
const particles = Array.from({length: particleCount}, () => ({ x: (random() - 0.5) * 62, z: (random() - 0.5) * 60, y: 2 + random() * 14, speed: 0.13 + random() * 0.14, phase: random() * Math.PI * 2 }));
const matrix = new THREE.Matrix4();
const particleRotation = new THREE.Quaternion();
const particleScale = new THREE.Vector3(1, 1, 1);
const particlePosition = new THREE.Vector3();
const projected = new THREE.Vector3();
const hotspots = [...document.querySelectorAll('.hotspot')];
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
let currentLight = 'day';
let currentView = 'overview';
let selectedBuilding = null;
let transition = null;
let lightingTransition = null;
let toastTimeout;
let paused = document.hidden;
let elapsed = 0;
let lastTimestamp = 0;
let adaptiveSamples = [];
let adapted = false;
let startAt = performance.now();
const frameSamples = [];

const lightPresets = {
  day: { bg: '#dce0d7', ground: '#d3d8cb', sun: '#fff0d5', intensity: 3.4, hemi: 1.9, hemiColor: '#e9f0e5', hemiGround: '#64735d', fill: .55, pos: [-55,85,65], exposure: 1.18, glow: .35, point: 0 },
  sunset: { bg: '#d9bdac', ground: '#c5ab94', sun: '#ffb976', intensity: 3.6, hemi: 1.35, hemiColor: '#ddcdcf', hemiGround: '#645847', fill: .45, pos: [-75,38,35], exposure: 1.08, glow: 1.0, point: 11 },
  night: { bg: '#223645', ground: '#344c57', sun: '#c2dbed', intensity: 1.8, hemi: 1.7, hemiColor: '#a6bbd2', hemiGround: '#445766', fill: .4, pos: [-40,80,-45], exposure: 1.04, glow: 2.1, point: 50 },
};

function toast(message) {
  const node = document.querySelector('.toast');
  node.textContent = message;
  node.classList.add('visible');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => node.classList.remove('visible'), 2400);
}

function fitFrustum() {
  const aspect = innerWidth / innerHeight;
  // Fit the complete island on portrait screens, leaving space for the controls.
  const size = aspect < 1 ? 131 / aspect : aspect < 1.4 ? 126 : 111;
  camera.left = -size * aspect / 2;
  camera.right = size * aspect / 2;
  camera.top = size / 2;
  camera.bottom = -size / 2;
  camera.updateProjectionMatrix();
}

function setView(name, instant = false) {
  currentView = name;
  selectedBuilding = null;
  document.querySelectorAll('[data-building]').forEach(node=>node.classList.remove('active'));
  document.querySelectorAll('[data-view]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.view === name)));
  const views = {
    overview: { position: [104, 88, 116], target: [0, 3, 0], zoom: 1 },
    axis: { position: [0, 92, 147], target: [0, 3, -1], zoom: 1.05 },
    plan: { position: [0, 167, 0.6], target: [0, 0, 0], zoom: 1.07 },
  };
  moveCamera(views[name], instant);
}

function moveCamera(view, instant = false) {
  const toPosition = new THREE.Vector3(...view.position);
  const toTarget = new THREE.Vector3(...view.target);
  if (instant || reducedMotion) {
    transition = null;
    camera.position.copy(toPosition);
    controls.target.copy(toTarget);
    camera.zoom = view.zoom;
    camera.updateProjectionMatrix();
    controls.update();
  } else {
    transition = { start: performance.now(), fromPosition: camera.position.clone(), fromTarget: controls.target.clone(), fromZoom: camera.zoom, toPosition, toTarget, toZoom: view.zoom };
  }
}

function setOrbit(enabled) {
  controls.autoRotate = enabled;
  const button = document.querySelector('#orbit');
  button.setAttribute('aria-pressed', String(enabled));
  button.innerHTML = `${icon(enabled ? 'pause' : 'play')}<span class="orbit-label">${enabled ? '暂停' : '环游'}</span>`;
  button.title = enabled ? '暂停环游 · 空格' : '自动环游 · 空格';
  button.setAttribute('aria-label', enabled ? '暂停自动环游' : '开启自动环游');
  createIcons({icons:ICONS});
}

function setLight(name) {
  currentLight = name;
  document.body.dataset.theme = name;
  document.querySelectorAll('[data-light]').forEach(button=>button.setAttribute('aria-pressed', String(button.dataset.light === name)));
  const target = lightPresets[name];
  lightingTransition = {
    start: performance.now(), target,
    bg: scene.background.clone(), ground: ground.material.color.clone(), sun: sun.color.clone(), intensity: sun.intensity,
    hemi: hemisphere.intensity, hemiColor: hemisphere.color.clone(), hemiGround: hemisphere.groundColor.clone(), fill: fill.intensity,
    pos: sun.position.clone(), exposure: renderer.toneMappingExposure, glow: architecture.glowMaterial.emissiveIntensity, point: glowLights[0].intensity,
  };
}

function toggleGuide(force) {
  const panel = document.querySelector('#guide');
  const open = force === undefined ? panel.hidden : force;
  panel.hidden = !open;
  document.querySelector('.hotspots').hidden = !open;
  document.querySelector('#guide-toggle').setAttribute('aria-expanded', String(open));
  document.querySelector('.scene-index').hidden = open;
  if (!open) document.querySelector('#guide-toggle').focus({ preventScroll: true });
}

function focusBuilding(id) {
  const building = BUILDINGS.find(b=>b.id === id);
  if (!building) return;
  selectedBuilding = id;
  setOrbit(false);
  document.querySelectorAll('[data-building]').forEach(button=>button.classList.toggle('active', button.dataset.building === id));
  document.querySelectorAll('[data-view]').forEach(button=>button.setAttribute('aria-pressed', 'false'));
  document.querySelector('.building-detail').innerHTML = `<div class="detail-en">${building.en}</div><p>${building.description}</p>`;
  // A modest close-up preserves context and leaves room for the guide panel.
  const target = [...building.target];
  const position = [...building.camera];
  const aspect = innerWidth / innerHeight;
  moveCamera({position, target, zoom: aspect < 1 ? 1.6 : 1.7});
}

async function capture() {
  const button = document.querySelector('#capture');
  button.disabled = true;
  renderer.render(scene, camera);
  try {
    const blob = await new Promise(resolve => renderer.domElement.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('Could not export image');
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `云阙山院-${{day:'日照',sunset:'暮色',night:'月夜'}[currentLight]}.png`;
    link.click();
    setTimeout(()=>URL.revokeObjectURL(url), 10000);
    toast('已保存这一刻的云阙山院');
  } catch (error) {
    console.error(error);
    toast('图片保存失败，请重试');
  } finally { button.disabled = false; }
}

document.querySelectorAll('[data-light]').forEach(button=>button.addEventListener('click',()=>setLight(button.dataset.light)));
document.querySelectorAll('[data-view]').forEach(button=>button.addEventListener('click',()=>{setOrbit(false);setView(button.dataset.view);}));
document.querySelectorAll('[data-building]').forEach(button=>button.addEventListener('click',()=>focusBuilding(button.dataset.building)));
document.querySelector('#guide-toggle').addEventListener('click',()=>toggleGuide());
document.querySelector('#guide-close').addEventListener('click',()=>toggleGuide(false));
document.querySelector('#orbit').addEventListener('click',()=>setOrbit(!controls.autoRotate));
document.querySelector('#reset').addEventListener('click',()=>{setOrbit(false);setView('overview');});
document.querySelector('#capture').addEventListener('click',capture);
document.querySelector('#zoom-in').addEventListener('click',()=>{camera.zoom = Math.min(controls.maxZoom, camera.zoom * 1.18);camera.updateProjectionMatrix();});
document.querySelector('#zoom-out').addEventListener('click',()=>{camera.zoom = Math.max(controls.minZoom, camera.zoom / 1.18);camera.updateProjectionMatrix();});
document.querySelector('#fullscreen').addEventListener('click',async()=>{
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
    else toast('可使用浏览器菜单进入全屏');
  } catch { toast('可使用浏览器菜单进入全屏'); }
});
document.addEventListener('fullscreenchange',()=>{
  const button = document.querySelector('#fullscreen');
  const active = Boolean(document.fullscreenElement);
  button.innerHTML = icon(active ? 'minimize' : 'maximize');
  button.title = active ? '退出全屏' : '全屏观看';
  button.setAttribute('aria-label', button.title);
  createIcons({icons:ICONS});
});
document.addEventListener('keydown', event=>{
  if (event.altKey || event.ctrlKey || event.metaKey || ['INPUT','TEXTAREA','SELECT'].includes(event.target.tagName)) return;
  if (event.code === 'Space' && event.target.tagName !== 'BUTTON') {event.preventDefault();setOrbit(!controls.autoRotate);}
  if (event.key.toLowerCase() === 'r') {setOrbit(false);setView('overview');}
  if (['1','2','3'].includes(event.key)) setLight(['day','sunset','night'][Number(event.key)-1]);
  if (event.key === 'Escape' && !document.querySelector('#guide').hidden) toggleGuide(false);
});
controls.addEventListener('start',()=>{transition=null;});
window.addEventListener('resize',()=>{renderer.setSize(innerWidth,innerHeight);fitFrustum();});
document.addEventListener('visibilitychange',()=>{paused=document.hidden;lastTimestamp=0;});
canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();paused=true;toast('图形上下文暂时中断，恢复后将继续显示');});
canvas.addEventListener('webglcontextrestored',()=>{renderer.shadowMap.needsUpdate=true;paused=false;});

fitFrustum();
setView('overview', true);
const compassNeedle = document.querySelector('.compass-needle');
const lerpColor = (a,b,t) => a.clone().lerp(new THREE.Color(b),t);

function animate(timestamp) {
  requestAnimationFrame(animate);
  if (paused) return;
  const frameMs = lastTimestamp ? timestamp - lastTimestamp : null;
  const delta = frameMs === null ? 1/60 : Math.min(frameMs / 1000, 0.1);
  lastTimestamp = timestamp;
  elapsed += delta;
  if (frameMs !== null && frameMs > 0) {
    frameSamples.push(frameMs);
    if (frameSamples.length > 600) frameSamples.shift();
  }
  if (transition) {
    const t = Math.min(1, (timestamp - transition.start) / 1200);
    const eased = t < 0.5 ? 4*t*t*t : 1 - Math.pow(-2*t+2,3)/2;
    camera.position.lerpVectors(transition.fromPosition, transition.toPosition, eased);
    controls.target.lerpVectors(transition.fromTarget, transition.toTarget, eased);
    camera.zoom = THREE.MathUtils.lerp(transition.fromZoom, transition.toZoom, eased);
    camera.updateProjectionMatrix();
    if (t === 1) transition = null;
  }
  if (lightingTransition) {
    const l = lightingTransition;
    const t = reducedMotion ? 1 : Math.min(1, (timestamp - l.start)/850);
    const f = t*t*(3-2*t);
    const b = l.target;
    scene.background.copy(lerpColor(l.bg,b.bg,f));
    scene.fog.color.copy(scene.background);
    ground.material.color.copy(lerpColor(l.ground,b.ground,f));
    sun.color.copy(lerpColor(l.sun,b.sun,f));
    sun.intensity = THREE.MathUtils.lerp(l.intensity,b.intensity,f);
    sun.position.lerpVectors(l.pos,new THREE.Vector3(...b.pos),f);
    hemisphere.intensity = THREE.MathUtils.lerp(l.hemi,b.hemi,f);
    hemisphere.color.copy(lerpColor(l.hemiColor,b.hemiColor,f));
    hemisphere.groundColor.copy(lerpColor(l.hemiGround,b.hemiGround,f));
    fill.intensity = THREE.MathUtils.lerp(l.fill,b.fill,f);
    renderer.toneMappingExposure = THREE.MathUtils.lerp(l.exposure,b.exposure,f);
    architecture.glowMaterial.emissiveIntensity = THREE.MathUtils.lerp(l.glow,b.glow,f);
    glowLights.forEach(light=>light.intensity=THREE.MathUtils.lerp(l.point,b.point,f));
    renderer.shadowMap.needsUpdate = true;
    if (t === 1) lightingTransition = null;
  }
  if (!reducedMotion) {
    particles.forEach((p,i)=>{
      const cycle = (elapsed * p.speed + p.y) % 15;
      particlePosition.set(p.x + Math.sin(elapsed * .19 + p.phase) * 2.5, 15.5 - cycle, p.z + Math.cos(elapsed * .14 + p.phase));
      particleRotation.setFromEuler(new THREE.Euler(elapsed*.24+p.phase,elapsed*.3,0));
      matrix.compose(particlePosition,particleRotation,particleScale);
      particleMesh.setMatrixAt(i,matrix);
    });
    particleMesh.instanceMatrix.needsUpdate = true;
    architecture.water.forEach((surface,i)=>surface.material.opacity=.62+Math.sin(elapsed*.5+i)*.035);
  } else particleMesh.visible = false;
  controls.update(delta);
  compassNeedle.style.transform = `rotate(${-controls.getAzimuthalAngle() * 180 / Math.PI}deg)`;
  if (!document.querySelector('.hotspots').hidden) {
    hotspots.forEach((button,i)=>{
      const b = BUILDINGS[i];
      projected.set(b.position[0],b.size[1]+1,b.position[2]).project(camera);
      button.style.left = `${(projected.x*.5+.5)*innerWidth}px`;
      button.style.top = `${(-projected.y*.5+.5)*innerHeight}px`;
      button.style.visibility = Math.abs(projected.x) > 1 || Math.abs(projected.y) > 1 || projected.z > 1 ? 'hidden' : 'visible';
    });
  }
  renderer.render(scene,camera);
  // Downgrade pixel density once if sustained frame time needs it. Static shadows
  // are reused while orbiting, so voxel counts do not multiply shadow passes.
  if (!adapted && timestamp - startAt > 3000 && timestamp - startAt < 10000) {
    adaptiveSamples.push(frameMs === null ? 1/60 : frameMs / 1000);
    if (adaptiveSamples.length === 150) {
      const mean = adaptiveSamples.reduce((a,b)=>a+b,0)/adaptiveSamples.length;
      if (mean > 1/37 && renderer.getPixelRatio() > 1) renderer.setPixelRatio(1);
      adapted = true;
      adaptiveSamples = [];
    }
  }
}
requestAnimationFrame(animate);
requestAnimationFrame(()=>requestAnimationFrame(()=>{
  document.querySelector('.loading').classList.add('finished');
  setTimeout(()=>document.querySelector('.loading').remove(),650);
}));

// Read-only diagnostics let QA measure actual frames, scene size and camera state.
window.__YUNQUE__ = {
  get diagnostics() {
    const sorted = [...frameSamples].sort((a,b)=>a-b);
    const avg = frameSamples.reduce((a,b)=>a+b,0)/Math.max(frameSamples.length,1);
    return { buildings: BUILDINGS.length, voxelCount: architecture.count, drawCalls: renderer.info.render.calls, triangles: renderer.info.render.triangles, pixelRatio: renderer.getPixelRatio(), fps: avg ? Math.round(1000/avg) : 0, p95FrameMs: sorted[Math.floor(sorted.length*.95)] ?? 0, samples: frameSamples.length, light: currentLight, view: currentView, selectedBuilding, autoRotate: controls.autoRotate, zoom: camera.zoom, camera: camera.position.toArray(), target: controls.target.toArray(), size: [innerWidth,innerHeight], webgl: renderer.capabilities.isWebGL2 ? 2 : 1 };
  },
};
