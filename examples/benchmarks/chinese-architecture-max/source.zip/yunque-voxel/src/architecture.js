import * as THREE from 'three';
import { Voxels, seededRandom } from './voxels.js';

const P = {
  red: '#a7442f', redLight: '#c45c3d', redDark: '#732d27',
  wood: '#5b392d', woodLight: '#a97949', gold: '#d3a14e', goldLight: '#edc575',
  roof: '#326361', roofLight: '#498480', roofDark: '#204745',
  ochreRoof: '#b98936', ochreLight: '#d5ab53',
  stone: '#b9b8a5', stoneLight: '#dfddc7', stoneDark: '#848d81',
  plaster: '#ded7b9', window: '#422e28', grass: '#677b49', grassLight: '#7b8b54',
};

export const BUILDINGS = [
  { id: 'main', number: '01', name: '云阙殿', en: 'THE GRAND HALL', type: '重檐庑殿式',
    description: '院落的中轴主殿。双层琉璃瓦檐舒展，朱柱与层叠斗拱托起屋面，宽阔的石阶将庭院引向殿堂。',
    position: [0, 0, -20], target: [0, 7, -20], size: [37, 23, 25], camera: [47, 37, 40] },
  { id: 'west', number: '02', name: '听松斋', en: 'PINE WHISPER HALL', type: '歇山式 · 西配殿',
    description: '与东配殿相对而立，以回廊和庭院衔接主殿。青瓦、木格窗与朱红廊柱，在松影间构成安静的层次。',
    position: [-26, 0, 3], target: [-26, 4, 3], size: [17, 12, 26], camera: [10, 24, 38] },
  { id: 'east', number: '03', name: '观云斋', en: 'CLOUD GAZING HALL', type: '歇山式 · 东配殿',
    description: '与听松斋沿中轴对称。朝向庭院的开敞前廊、石台基和木格门窗，让建筑之间保持可步行的尺度。',
    position: [26, 0, 3], target: [26, 4, 3], size: [17, 12, 26], camera: [-10, 24, 38] },
  { id: 'gate', number: '04', name: '云阙山门', en: 'THE MOUNTAIN GATE', type: '歇山式 · 三间山门',
    description: '由南向北进入院落的起点。中央门洞贯通石铺甬道，两侧石狮守望，红灯笼悬在飞檐之下。',
    position: [0, 0, 32], target: [0, 4, 32], size: [24, 13, 15], camera: [28, 23, 70] },
  { id: 'west-tower', number: '05', name: '栖霞塔', en: 'SUNSET PAGODA', type: '三层方塔 · 攒尖式',
    description: '三重出檐逐层收分，层层栏杆围合塔身。方形攒尖屋顶以金色塔刹收束，与东塔共同平衡主殿轮廓。',
    position: [-29, 0, -25], target: [-29, 9, -25], size: [13, 25, 13], camera: [0, 27, 14] },
  { id: 'east-tower', number: '06', name: '凌云塔', en: 'CLOUD REACHING PAGODA', type: '三层方塔 · 攒尖式',
    description: '伫立于院落东北一角，与栖霞塔呼应。飞檐在每层转角处抬升，金色脊饰与青绿瓦面交织成清晰的剪影。',
    position: [29, 0, -25], target: [29, 9, -25], size: [13, 25, 13], camera: [58, 27, 14] },
];

export function buildArchitecture(scene) {
  const v = new Voxels();
  const random = seededRandom(90210);
  const extras = new THREE.Group();
  extras.name = 'signboards-and-water';
  scene.add(extras);
  const lanternPositions = [];
  const water = [];
  const box = (...args) => v.box(...args);

  function plaque(text, x, y, z, width = 4.2, angle = 0) {
    const canvas = document.createElement('canvas');
    canvas.width = 768;
    canvas.height = 192;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#263b34';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#c8a15a';
    ctx.lineWidth = 9;
    ctx.strokeRect(9, 9, 750, 174);
    ctx.fillStyle = '#edd6a0';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 118px "Songti SC", "STSong", serif';
    const spacing = 26;
    const tw = ctx.measureText(text).width + spacing * (text.length - 1);
    let start = 384 - tw / 2;
    for (const char of text) {
      const charWidth = ctx.measureText(char).width;
      ctx.fillText(char, start + charWidth / 2, 105);
      start += charWidth + spacing;
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, width / 4), new THREE.MeshLambertMaterial({ map: texture }));
    const t = v.transform;
    const c = Math.cos(t.angle), s = Math.sin(t.angle);
    mesh.position.set(t.x + x * c + z * s, t.y + y, t.z + z * c - x * s);
    mesh.rotation.y = t.angle + angle;
    extras.add(mesh);
  }

  function lantern(x, y, z, scale = 1) {
    box(x, y + 0.8 * scale, z, 0.09, 0.8 * scale, 0.09, P.wood);
    box(x, y, z, 0.68 * scale, 0.86 * scale, 0.68 * scale, '#e89751', 0.1, 'glow');
    box(x, y, z, 0.79 * scale, 0.46 * scale, 0.79 * scale, '#c75133', 0.1, 'glow');
    for (const dy of [-0.49, 0.49]) box(x, y + dy * scale, z, 0.62 * scale, 0.13 * scale, 0.62 * scale, P.gold);
    for (const dx of [-0.27, 0.27]) box(x + dx * scale, y, z + 0.35 * scale, 0.045, 0.82 * scale, 0.035, P.goldLight);
    box(x, y - 0.85 * scale, z, 0.1, 0.57 * scale, 0.1, P.redLight);
    const t = v.transform;
    lanternPositions.push(new THREE.Vector3(t.x + x * Math.cos(t.angle) + z * Math.sin(t.angle), t.y + y, t.z + z * Math.cos(t.angle) - x * Math.sin(t.angle)));
  }

  function railing(x, z, length, y, alongX = true) {
    const n = Math.max(1, Math.round(length / 2.2));
    for (let i = 0; i <= n; i++) {
      const a = -length / 2 + (i * length) / n;
      const px = x + (alongX ? a : 0), pz = z + (alongX ? 0 : a);
      box(px, y + 0.52, pz, 0.4, 1.04, 0.4, P.stoneLight, 0.08);
      box(px, y + 1.12, pz, 0.58, 0.2, 0.58, P.stoneLight);
      box(px, y + 1.28, pz, 0.29, 0.19, 0.29, P.stone);
    }
    for (const h of [0.3, 0.9]) box(x, y + h, z, alongX ? length : 0.18, 0.16, alongX ? 0.18 : length, P.stoneLight);
  }

  function platform(w, d, height, stairWidth = 6) {
    box(0, height / 2 - 0.03, 0, w, height, d, P.stone, 0.05);
    box(0, 0.15, 0, w + 0.5, 0.32, d + 0.5, P.stoneDark);
    box(0, height - 0.06, 0, w + 0.35, 0.22, d + 0.35, P.stoneLight);
    // Low-relief block joints, rather than a texture, preserve the voxel scale.
    for (let x = -w / 2 + 0.8; x < w / 2; x += 1.5) {
      box(x, height * 0.5, d / 2 + 0.015, 1.43, height * 0.55, 0.03, P.stone, 0.13);
    }
    const steps = Math.round(height / 0.28);
    for (let i = 0; i < steps; i++) {
      const h = height * (i + 1) / steps;
      const z = d / 2 + (steps - i) * 0.49;
      box(0, h / 2, z, stairWidth, h, 0.54, P.stoneLight, 0.055);
      for (const sign of [-1, 1]) box(sign * (stairWidth / 2 + 0.28), h / 2 + 0.17, z, 0.48, h + 0.34, 0.55, P.stone);
    }
  }

  function column(x, z, base, height, thick = 0.55) {
    box(x, base + 0.12, z, thick * 1.55, 0.24, thick * 1.55, P.stoneLight);
    box(x, base + 0.35, z, thick * 1.23, 0.22, thick * 1.23, P.stone);
    box(x, base + height / 2, z, thick, height - 0.5, thick, P.red, 0.09);
    box(x, base + height - 0.24, z, thick * 1.2, 0.42, thick * 1.2, P.redDark);
    for (let i = 0; i < 3; i++) {
      box(x, base + height + i * 0.22, z, thick + 0.6 + i * 0.24, 0.21, 0.35, i === 1 ? P.gold : P.redLight);
      box(x, base + height + i * 0.22, z, 0.35, 0.21, thick + 0.65 + i * 0.3, i === 1 ? P.roofDark : P.woodLight);
    }
    // Paired dougong arms and upper bearing blocks.
    for (const a of [-1, 1]) {
      box(x + a * 0.49, base + height + 0.34, z, 0.28, 0.32, 0.5, P.woodLight);
      box(x, base + height + 0.49, z + a * 0.58, 0.45, 0.25, 0.36, P.gold);
    }
  }

  function windowPanel(x, y, z, w = 2.4, h = 3.2) {
    box(x, y, z, w, h, 0.24, P.wood);
    box(x, y + 0.3, z + 0.14, w - 0.2, h - 0.85, 0.06, '#b0a477', 0.1);
    box(x, y - h / 2 + 0.4, z + 0.16, w - 0.16, 0.65, 0.09, P.redDark);
    for (let i = 0; i <= 4; i++) box(x - w / 2 + 0.13 + i * (w - 0.26) / 4, y + 0.3, z + 0.22, 0.09, h - 0.7, 0.07, P.wood);
    for (let i = 0; i <= 4; i++) box(x, y - h / 2 + 0.85 + i * (h - 0.95) / 4, z + 0.23, w - 0.18, 0.09, 0.08, P.wood);
    box(x, y + h / 2 + 0.13, z + 0.14, w + 0.27, 0.2, 0.4, P.gold);
  }

  /** A quantized, concave hip surface with raised corner tips, built tile by tile. */
  function roof(w, d, y, rise, { gold = false, type = 'hip', upturn = 1.3, cell = 0.62 } = {}) {
    const halfW = w / 2, halfD = d / 2;
    const ridgeHalf = type === 'pyramid' ? 0 : Math.max(0, halfW - halfD + (type === 'gable' ? 1.6 : 0));
    const nx = Math.round(w / cell), nz = Math.round(d / cell);
    const dx = w / nx, dz = d / nz;
    const tile = gold ? P.ochreRoof : P.roof;
    const light = gold ? P.ochreLight : P.roofLight;
    const trim = gold ? P.goldLight : '#81a096';
    for (let ix = 0; ix < nx; ix++) {
      const x = -halfW + dx * (ix + 0.5);
      for (let iz = 0; iz < nz; iz++) {
        const z = -halfD + dz * (iz + 0.5);
        const a = Math.abs(x) / halfW, b = Math.abs(z) / halfD;
        const tx = Math.max(0, (Math.abs(x) - ridgeHalf) / (halfW - ridgeHalf));
        const t = Math.min(1, Math.max(tx, b));
        const corner = Math.pow(a * b, 5);
        const curve = rise * Math.pow(1 - t, 1.6) + upturn * corner + 0.22 * Math.pow(t, 12);
        const h = y + Math.round(curve / 0.22) * 0.22;
        const border = ix === 0 || ix === nx - 1 || iz === 0 || iz === nz - 1;
        box(x, h, z, dx + 0.008, 0.38, dz + 0.008, border ? trim : (ix % 3 === 0 ? light : tile), border ? 0.06 : 0.17, 'roof');
        if (border) {
          box(x, h - 0.29, z, dx + 0.01, 0.2, dz + 0.01, P.redDark, 0.07);
          if ((ix + iz) % 2 === 0) box(x, h - 0.42, z, dx * 0.66, 0.15, dz * 0.66, P.woodLight);
        }
      }
    }
    if (type !== 'pyramid') {
      const len = ridgeHalf + 0.9;
      for (let x = -len; x <= len; x += 0.5) {
        box(x, y + rise + 0.15, 0, 0.52, 0.52, 0.61, P.gold, 0.1, 'roof');
        box(x, y + rise + 0.45, 0, 0.51, 0.14, 0.4, P.goldLight);
      }
      for (const sign of [-1, 1]) {
        for (let i = 0; i < 4; i++) {
          box(sign * (len + i * 0.24), y + rise + 0.33 + i * 0.3, 0, 0.38, 0.46, 0.46, P.gold);
        }
        box(sign * (len + 0.46), y + rise + 1.43, 0, 0.46, 0.29, 0.5, P.goldLight);
      }
    } else {
      for (let i = 0; i < 6; i++) {
        const a = 0.9 - i * 0.12;
        box(0, y + rise + 0.1 + i * 0.33, 0, a, 0.3, a, i % 2 === 0 ? P.gold : P.goldLight);
      }
      box(0, y + rise + 2.2, 0, 0.14, 0.8, 0.14, P.goldLight);
    }
    // Voxel ridge ornaments follow each hip toward the lifted corner.
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      for (let j = 0; j < 7; j++) {
        const t = 1 - j * 0.065;
        const x = sx * (ridgeHalf + (halfW - ridgeHalf) * t);
        const z = sz * halfD * t;
        const a = Math.abs(x) / halfW, b = Math.abs(z) / halfD;
        const h = y + rise * Math.pow(1 - t, 1.6) + upturn * Math.pow(a * b, 5) + 0.22 * Math.pow(t, 12);
        box(x, h + 0.3, z, 0.41, 0.3, 0.41, gold ? P.goldLight : P.gold, 0.08);
        if (j === 0) box(x + sx * 0.16, h + 0.63, z + sz * 0.16, 0.31, 0.45, 0.31, P.gold);
      }
    }
  }

  function hall({ x, z, angle = 0, main = false, gate = false, name }) {
    v.at(x, 0, z, angle, () => {
      const w = main ? 27 : gate ? 17 : 21;
      const d = main ? 15 : gate ? 8 : 10;
      const base = main ? 1.75 : 0.85;
      const h = main ? 6.1 : gate ? 4.5 : 4.7;
      const front = d / 2;
      platform(w + (main ? 7 : 3), d + (main ? 6 : 3.5), base, main ? 10 : 6);
      // Main body is recessed behind the column-lined veranda.
      if (!gate) {
        box(0, base + h * 0.43, -0.7, w - 0.9, h * 0.84, d - 2.4, P.red, 0.06);
        box(0, base + 0.65, -0.7, w - 0.7, 0.64, d - 2.25, P.redDark);
        for (const side of [-1, 1]) {
          box(side * (w / 2 - 0.4), base + h * 0.48, -0.5, 0.15, h * 0.62, d - 3.4, P.plaster);
          for (let zz = -d / 2 + 1.3; zz < d / 2 - 1.5; zz += 1.15) {
            box(side * (w / 2 - 0.3), base + h * 0.47, zz, 0.15, h * 0.66, 0.12, P.wood);
          }
        }
        const bays = main ? 7 : 5;
        for (let i = 0; i < bays; i++) {
          const xx = (i - (bays - 1) / 2) * ((w - 2) / bays);
          windowPanel(xx, base + 2.6, front - 1.85, main ? 2.7 : 2.9, main ? 3.7 : 3.15);
        }
        // A pair of taller central doors and small brass handles.
        for (const sign of [-1, 1]) {
          box(sign * 0.72, base + 2.08, front - 1.59, 1.36, 4.15, 0.15, P.redDark);
          for (let zz = 0; zz < 3; zz++) for (let yy = 0; yy < 4; yy++) {
            box(sign * 0.72 - 0.43 + zz * 0.43, base + 0.95 + yy * 0.68, front - 1.48, 0.07, 0.07, 0.08, P.gold);
          }
        }
      } else {
        for (const sign of [-1, 1]) {
          box(sign * 5.7, base + h / 2, -0.55, 4.1, h, d - 1.8, P.red);
          windowPanel(sign * 5.7, base + 2.2, front - 1.4, 2.3, 2.6);
          box(sign * 2.48, base + 2.1, -0.6, 0.28, 4.2, 4.4, P.redDark);
          for (let j = 0; j < 5; j++) box(sign * 2.64, base + 0.65 + j * 0.7, 0.8, 0.14, 0.14, 0.14, P.gold);
        }
      }
      const count = main ? 8 : gate ? 6 : 6;
      for (let i = 0; i < count; i++) {
        const xx = -w / 2 + 0.45 + i * (w - 0.9) / (count - 1);
        for (const sign of [-1, 1]) column(xx, sign * (front - 0.2), base, h, main ? 0.68 : 0.5);
      }
      for (const sign of [-1, 1]) {
        box(0, base + h - 0.04, sign * front, w + 0.8, 0.42, 0.45, P.redDark);
        box(0, base + h + 0.43, sign * front, w + 1.5, 0.27, 0.58, P.roofDark);
        box(sign * w / 2, base + h + 0.23, 0, 0.5, 0.45, d + 0.6, P.redDark);
        for (let xx = -w / 2 + 1; xx < w / 2; xx += 0.9) box(xx, base + h + 0.46, sign * front, 0.28, 0.48, 0.65, P.gold);
      }
      if (main) {
        roof(37, 24, base + h + 0.85, 3.9, { upturn: 1.55 });
        box(0, 12.35, -0.1, 23, 2.8, 11.3, P.red);
        for (const sign of [-1, 1]) {
          box(0, 12.2, sign * 5.63, 22.6, 0.65, 0.12, P.window);
          for (let xx = -10.6; xx <= 10.6; xx += 0.73) box(xx, 12.3, sign * 5.74, 0.13, 1.9, 0.15, P.woodLight);
          box(0, 13.44, sign * 5.84, 24.2, 0.28, 0.4, P.gold);
          for (let xx = -11; xx <= 11; xx += 3.65) column(xx, sign * 5.5, 11, 2.65, 0.45);
        }
        roof(30.5, 17.5, 14.24, 4.4, { gold: true, upturn: 1.15 });
        plaque(name, 0, 7.14, front + 0.29, 5.3);
        railing(0, -(d + 6) / 2 + 0.1, w + 6.5, base, true);
        for (const sign of [-1, 1]) {
          railing(sign * (w + 6.7) / 2, 0, d + 5.5, base, false);
          railing(sign * 11.1, (d + 6) / 2, 10.3, base, true);
        }
      } else {
        roof(w + 4.3, d + 4.7, base + h + 0.88, gate ? 3.55 : 3.5, { type: 'gable', upturn: 1.16 });
        // Exposed upper gables have cream panels framed by stepped red timbers.
        for (const sign of [-1, 1]) {
          for (let i = 0; i < 4; i++) box(sign * (w / 2 - 2.2), base + h + 1.12 + i * 0.45, 0, 0.3, 0.46, 5.6 - i * 1.15, P.plaster);
        }
        plaque(name, 0, base + h - 0.33, front + 0.27, gate ? 4.5 : 3.9);
      }
      const lightXs = main ? [-10, -6.3, 6.3, 10] : gate ? [-3.5, 3.5] : [-6.1, 6.1];
      for (const xx of lightXs) lantern(xx, base + h - 1.22, front + 0.3, main ? 1 : 0.87);
    });
  }

  function pagoda(x, z) {
    v.at(x, 0, z, 0, () => {
      platform(10.2, 10.2, 0.8, 4.2);
      for (let level = 0; level < 3; level++) {
        const y = 0.8 + level * 6.1;
        const size = 6.6 - level * 0.72;
        box(0, y + 2.0, 0, size - 0.45, 4.0, size - 0.45, P.red);
        for (const sign of [-1, 1]) {
          box(0, y + 2.2, sign * (size / 2 - 0.18), size - 1.2, 2.5, 0.16, P.window);
          box(sign * (size / 2 - 0.18), y + 2.2, 0, 0.16, 2.5, size - 1.2, P.window);
          for (let a = -1.6; a <= 1.6; a += 0.53) {
            box(a, y + 2.2, sign * size / 2, 0.1, 2.5, 0.15, P.woodLight);
            box(sign * size / 2, y + 2.2, a, 0.15, 2.5, 0.1, P.woodLight);
          }
          for (const other of [-1, 1]) column(sign * size / 2, other * size / 2, y, 4.05, 0.43);
          box(0, y + 0.1, sign * (size / 2 + 0.65), size + 2.2, 0.34, 0.5, P.woodLight);
          box(sign * (size / 2 + 0.65), y + 0.1, 0, 0.5, 0.34, size + 2.2, P.woodLight);
          for (const h of [0.55, 1.22]) {
            box(0, y + h, sign * (size / 2 + 0.64), size + 1.7, 0.14, 0.14, P.redLight);
            box(sign * (size / 2 + 0.64), y + h, 0, 0.14, 0.14, size + 1.7, P.redLight);
          }
          for (let a = -size / 2 - 0.4; a < size / 2 + 0.5; a += 0.8) {
            box(a, y + 0.68, sign * (size / 2 + 0.64), 0.16, 1.2, 0.16, P.redDark);
            box(sign * (size / 2 + 0.64), y + 0.68, a, 0.16, 1.2, 0.16, P.redDark);
          }
        }
        roof(size + 5.0, size + 5.0, y + 4.82, level === 2 ? 3.55 : 2.55, { type: 'pyramid', upturn: 1.15, cell: 0.57 });
      }
      lantern(-2.1, 3.5, 3.45, 0.78);
      lantern(2.1, 3.5, 3.45, 0.78);
    });
  }

  function lion(x, z, flip = false) {
    v.at(x, 0, z, flip ? Math.PI : 0, () => {
      box(0, 0.2, 0, 1.7, 0.4, 2.05, P.stoneDark);
      box(0, 0.52, 0, 1.52, 0.25, 1.84, P.stoneLight);
      box(0, 1.13, -0.15, 0.98, 1.08, 1.25, P.stone, 0.1);
      for (const sx of [-1, 1]) {
        box(sx * 0.38, 0.88, 0.58, 0.38, 0.47, 0.58, P.stoneLight);
        box(sx * 0.56, 1.85, 0.3, 0.31, 0.6, 0.59, P.stone);
        box(sx * 0.39, 2.4, 0.3, 0.35, 0.38, 0.36, P.stoneLight);
        box(sx * 0.28, 2.05, 0.84, 0.13, 0.13, 0.08, P.stoneDark);
      }
      box(0, 1.88, 0.31, 1.12, 0.95, 1.06, P.stoneLight);
      box(0, 1.74, 0.92, 0.69, 0.38, 0.46, P.stone);
      box(0, 1.85, 1.12, 0.24, 0.16, 0.12, P.stoneDark);
      box(0, 1.59, 1.02, 0.6, 0.09, 0.26, P.stoneDark);
      box(0, 1.39, -0.8, 0.39, 0.4, 0.39, P.stoneLight);
      box(0, 1.72, -0.98, 0.4, 0.36, 0.28, P.stone);
    });
  }

  function pine(x, z, height = 8, seed = 1) {
    const rand = seededRandom(seed);
    box(x, height * 0.36, z, 0.83, height * 0.72, 0.83, P.wood, 0.2);
    for (let level = 0; level < 4; level++) {
      const y = height * (0.43 + level * 0.17);
      const radius = height * (0.32 - level * 0.055);
      const offset = level % 2 ? 0.35 : -0.24;
      box(x + offset, y - 0.5, z, radius * 1.7, 0.43, 0.45, P.wood);
      for (let ix = -Math.ceil(radius); ix <= Math.ceil(radius); ix++) for (let iz = -Math.ceil(radius); iz <= Math.ceil(radius); iz++) {
        if (Math.abs(ix) + Math.abs(iz) > radius * 1.5 || Math.max(Math.abs(ix), Math.abs(iz)) > radius || rand() < 0.08) continue;
        box(x + ix * 0.85 + offset, y + (rand() > 0.65 ? 0.4 : 0), z + iz * 0.85, 0.91, 0.82, 0.91, ['#344c35', '#415d3d', '#536b45'][Math.floor(rand() * 3)], 0.17, 'leaves');
      }
    }
  }

  function blossom(x, z, seed) {
    const rand = seededRandom(seed);
    box(x, 0.22, z, 5.8, 0.4, 5.8, P.stoneLight);
    box(x, 0.46, z, 5.3, 0.12, 5.3, '#53613c');
    box(x, 2.3, z, 0.67, 4.0, 0.67, P.wood);
    box(x - 0.53, 3.78, z, 1.5, 0.5, 0.58, P.wood);
    box(x - 1.0, 4.38, z, 0.5, 1.3, 0.5, P.wood);
    box(x + 0.7, 4.2, z + 0.4, 1.6, 0.55, 0.65, P.wood);
    box(x + 1.3, 4.65, z + 0.4, 0.45, 1, 0.5, P.wood);
    const colors = ['#d98984', '#e8aaa0', '#f0bdb0', '#cd7379', '#edb6a4'];
    for (let ix = -4; ix <= 4; ix++) for (let iz = -4; iz <= 4; iz++) for (let iy = -1; iy <= 2; iy++) {
      const d = ix * ix / 17 + iz * iz / 13 + (iy - 0.25) ** 2 / 5;
      if (d > 1.25 || rand() < 0.16) continue;
      box(x + ix * 0.72, 5.1 + iy * 0.69, z + iz * 0.72, 0.83, 0.78, 0.83, colors[Math.floor(rand() * colors.length)], 0.11, 'leaves');
    }
    for (let i = 0; i < 22; i++) box(x + (rand() - 0.5) * 6.3, 0.56, z + (rand() - 0.5) * 6.3, 0.18, 0.035, 0.18, colors[i % colors.length]);
  }

  function path(cx, cz, w, d, cell = 1.35, raised = 0.065) {
    box(cx, 0.005, cz, w + 0.18, 0.08, d + 0.18, P.stoneDark, 0, 'ground');
    const nx = Math.round(w / cell), nz = Math.round(d / cell);
    for (let ix = 0; ix < nx; ix++) for (let iz = 0; iz < nz; iz++) {
      box(cx - w / 2 + (ix + 0.5) * w / nx, raised, cz - d / 2 + (iz + 0.5) * d / nz, w / nx - 0.045, 0.14, d / nz - 0.045, (ix + iz) % 7 === 0 ? '#c4c3ac' : '#d0cbb1', 0.09, 'ground');
    }
  }

  function pool(x, z) {
    box(x, 0.07, z, 8.1, 0.16, 6.9, P.stoneLight);
    box(x, 0.17, z, 7.4, 0.12, 6.2, '#285652');
    for (const s of [-1, 1]) {
      box(x + s * 4.05, 0.28, z, 0.42, 0.43, 7.25, P.stoneLight);
      box(x, 0.28, z + s * 3.46, 8.5, 0.43, 0.4, P.stoneLight);
    }
    const surface = new THREE.Mesh(new THREE.PlaneGeometry(7.65, 6.5), new THREE.MeshPhongMaterial({ color: '#6ca39a', transparent: true, opacity: 0.63, shininess: 90, specular: '#a9dfd3', depthWrite: false }));
    surface.rotation.x = -Math.PI / 2;
    surface.position.set(x, 0.26, z);
    extras.add(surface);
    water.push(surface);
    for (let i = 0; i < 18; i++) {
      const px = x + (random() - 0.5) * 6.6, pz = z + (random() - 0.5) * 5.5;
      if (i < 6) {
        box(px, 0.28, pz, 0.65, 0.05, 0.52, '#71834b', 0.15);
        if (i % 2 === 0) box(px, 0.39, pz, 0.22, 0.22, 0.22, '#e6b3a4');
      } else box(px, 0.2, pz, 0.12, 0.08, 0.55, i % 2 ? '#e4b47b' : '#b85937');
    }
  }

  function wall(cx, cz, length, angle = 0) {
    v.at(cx, 0, cz, angle, () => {
      box(0, 0.29, 0, length, 0.58, 1.15, P.stoneDark);
      box(0, 1.3, 0, length, 1.6, 0.75, '#ad604b', 0.03);
      box(0, 2.06, 0, length + 0.05, 0.17, 1.18, P.wood);
      for (let x = -length / 2; x < length / 2; x += 0.6) {
        for (let row = -1; row <= 1; row++) box(x + 0.28, 2.31 - Math.abs(row) * 0.14, row * 0.4, 0.58, 0.22, 0.47, P.roof, 0.2, 'roof');
      }
      for (let x = -length / 2; x <= length / 2 + 0.1; x += length / Math.ceil(length / 8)) {
        box(x, 1.28, 0, 1.08, 2.5, 1.12, P.redDark);
        box(x, 2.6, 0, 1.46, 0.26, 1.52, P.roofLight);
      }
    });
  }

  // Cutaway earth: a chunky floating foundation with independent stone strata.
  const terrainCell = 2;
  for (let x = -43; x <= 43; x += terrainCell) for (let z = -43; z <= 43; z += terrainCell) {
    if (Math.abs(x) + Math.abs(z) > 80) continue;
    const edge = Math.abs(x) > 40 || Math.abs(z) > 40 || Math.abs(x) + Math.abs(z) > 77;
    const h = edge ? 3.5 + Math.floor(random() * 3) * 0.7 : 5.9;
    box(x, -h / 2 - 0.25, z, 2, h, 2, '#747764', 0.13, 'earth');
    box(x, -0.33, z, 2, 0.65, 2, '#646b43', 0.15, 'ground');
    box(x, -0.035, z, 2, 0.19, 2, '#778357', 0.14, 'ground');
    if (edge) {
      box(x, -2.5 + Math.floor(random() * 2) * 0.65, z, 2.03, 0.56, 2.03, '#858775', 0.12, 'earth');
      if (random() > 0.6) box(x, -5.4, z, 1.95, 1.2, 1.95, '#626c5b', 0.2, 'earth');
    }
  }

  // A legible south-to-north route through the entrance, courts and main stairs.
  path(0, 17, 6.1, 52);
  path(0, 5.3, 34.6, 25.0, 1.55, 0.09);
  path(0, -10, 62, 4.5);
  path(-26, -12, 4.2, 24);
  path(26, -12, 4.2, 24);
  path(0, 23, 58, 4.2);
  // Central stone-carpet motif uses tiny blocks instead of a decal.
  for (let x = -3; x <= 3; x++) for (let z = -3; z <= 3; z++) {
    if (Math.abs(x) + Math.abs(z) === 3 || (x === 0 && z === 0)) box(x * 0.48, 0.185, 8 + z * 0.48, 0.46, 0.035, 0.46, '#9eab91', 0, 'ground');
  }
  for (const x of [-11.7, 11.7]) {
    pool(x, 22.2);
    blossom(x, 8.4, x > 0 ? 764 : 541);
    box(x, 0.15, -0.8, 5.8, 0.25, 4.0, P.stoneLight);
    box(x, 0.33, -0.8, 5.3, 0.16, 3.5, '#607248');
    for (let i = 0; i < 25; i++) box(x + (random() - 0.5) * 4.8, 0.55 + random() * 0.2, -0.8 + (random() - 0.5) * 2.8, 0.36, 0.37, 0.38, i % 4 ? '#839658' : '#ddbd77', 0.1, 'leaves');
  }

  hall({ x: 0, z: -20, main: true, name: '云阙殿' });
  hall({ x: -26, z: 3, angle: Math.PI / 2, name: '听松斋' });
  hall({ x: 26, z: 3, angle: -Math.PI / 2, name: '观云斋' });
  hall({ x: 0, z: 32, gate: true, name: '云阙山院' });
  pagoda(-29, -25);
  pagoda(29, -25);
  wall(0, -38, 76);
  wall(-38, -1, 74, Math.PI / 2);
  wall(38, -1, 74, Math.PI / 2);
  wall(-25, 36, 26);
  wall(25, 36, 26);
  for (const x of [-7.4, 7.4]) lion(x, -5.65);
  for (const x of [-5.0, 5.0]) lion(x, 40.1);

  // Bronze incense burner on the processional axis.
  box(0, 0.29, -0.5, 3.8, 0.48, 3.4, P.stoneLight);
  for (const x of [-0.76, 0.76]) for (const z of [-1.13, 0.13]) box(x, 0.97, z, 0.33, 1.12, 0.33, '#48685b');
  box(0, 1.44, -0.5, 2.2, 0.85, 1.84, '#5f8069');
  box(0, 1.86, -0.5, 2.5, 0.19, 2.1, P.gold);
  box(0, 1.97, -0.5, 1.9, 0.12, 1.6, '#3d5548');
  for (const x of [-1.4, 1.4]) {
    box(x, 1.75, -0.5, 0.27, 0.73, 0.36, '#5f8069');
    box(x * 0.9, 2.1, -0.5, 0.45, 0.18, 0.36, P.gold);
  }
  for (let i = 0; i < 5; i++) box(-0.56 + i * 0.28, 2.44, -0.5, 0.035, 0.9, 0.035, P.redLight);

  // Trees and rocks mirror in placement while their block clusters vary naturally.
  for (const sign of [-1, 1]) {
    [[32.2, 26.5, 9.5], [33, 16, 7], [35, -10, 8.2], [17.5, -35, 7.1], [8, -35.5, 6.2], [32.8, -34.4, 8.3], [24, 29.8, 6.4]].forEach(([x, z, h], i) => pine(x * sign, z, h, 120 + i + (sign + 1) * 34));
    for (const [x, z] of [[34, 31.7], [34.5, 20], [18.8, 29.5], [34, -15]]) {
      for (let i = 0; i < 5; i++) {
        const size = 0.6 + random() * 0.9;
        box(sign * x + (random() - 0.5) * 2.8, size * 0.4, z + (random() - 0.5) * 2.0, size * 1.2, size * 0.8, size, '#929b89', 0.22);
      }
    }
    // Stone lanterns mark the crossing and entrance.
    for (const z of [18, -3, 28]) {
      const x = sign * (z === 28 ? 6 : 16.7);
      box(x, 0.25, z, 1.2, 0.45, 1.2, P.stoneLight);
      box(x, 1.12, z, 0.4, 1.4, 0.4, P.stone);
      box(x, 1.89, z, 0.9, 0.2, 0.9, P.stoneLight);
      box(x, 2.25, z, 0.63, 0.57, 0.63, '#f6bc6f', 0, 'glow');
      box(x, 2.6, z, 1.14, 0.18, 1.14, P.stoneDark);
      box(x, 2.78, z, 0.84, 0.19, 0.84, P.stone);
      box(x, 2.94, z, 0.42, 0.19, 0.42, P.stoneLight);
      lanternPositions.push(new THREE.Vector3(x, 2.2, z));
    }
  }
  // Sparse grass tufts keep the garden grounded without filling walking routes.
  for (let i = 0; i < 360; i++) {
    const x = (random() - 0.5) * 82, z = (random() - 0.5) * 82;
    const inBorder = Math.abs(x) > 39 || z < -39 || (z > 38 && Math.abs(x) > 9);
    if (!inBorder || Math.abs(x) + Math.abs(z) > 78) continue;
    box(x, 0.24, z, 0.19, 0.42, 0.2, '#506842', 0.22, 'leaves');
    if (i % 3 === 0) box(x + 0.2, 0.18, z, 0.16, 0.29, 0.16, '#a2a06a');
  }

  const result = v.finish(scene);
  return { ...result, extras, water, lanternPositions, buildings: BUILDINGS };
}
