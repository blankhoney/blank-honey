import * as THREE from 'three';

export function seededRandom(seed = 1701) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let value = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    value = (value + Math.imul(value ^ (value >>> 7), 61 | value)) ^ value;
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

/** Static blocks share geometry, material and draw calls. No Object3D per voxel. */
export class Voxels {
  constructor() {
    this.batches = new Map();
    this.random = seededRandom();
    this.count = 0;
    this.transform = { x: 0, y: 0, z: 0, angle: 0 };
    this.color = new THREE.Color();
  }

  at(x, y, z, angle, build) {
    const previous = this.transform;
    this.transform = { x, y, z, angle };
    build();
    this.transform = previous;
  }

  box(x, y, z, w, h, d, color, variation = 0, kind = 'solid') {
    const t = this.transform;
    const c = Math.cos(t.angle);
    const s = Math.sin(t.angle);
    this.color.set(color);
    if (variation) this.color.multiplyScalar(1 + (this.random() - 0.5) * variation);
    if (!this.batches.has(kind)) this.batches.set(kind, []);
    this.batches.get(kind).push({
      x: t.x + x * c + z * s, y: t.y + y, z: t.z + z * c - x * s,
      w, h, d, angle: t.angle,
      r: this.color.r, g: this.color.g, b: this.color.b,
    });
    this.count++;
  }

  finish(scene) {
    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const matrix = new THREE.Matrix4();
    const position = new THREE.Vector3();
    const quaternion = new THREE.Quaternion();
    const scale = new THREE.Vector3();
    const axis = new THREE.Vector3(0, 1, 0);
    const meshes = [];
    let glowMaterial;
    for (const [kind, blocks] of this.batches) {
      const material = new THREE.MeshLambertMaterial({ color: 0xffffff });
      if (kind === 'glow') {
        material.emissive.set('#ffc36a');
        material.emissiveIntensity = 0.35;
        glowMaterial = material;
      }
      const mesh = new THREE.InstancedMesh(geometry, material, blocks.length);
      mesh.name = `voxel-${kind}`;
      for (let i = 0; i < blocks.length; i++) {
        const b = blocks[i];
        position.set(b.x, b.y, b.z);
        quaternion.setFromAxisAngle(axis, b.angle);
        scale.set(b.w, b.h, b.d);
        matrix.compose(position, quaternion, scale);
        mesh.setMatrixAt(i, matrix);
        this.color.setRGB(b.r, b.g, b.b);
        mesh.setColorAt(i, this.color);
      }
      mesh.castShadow = kind !== 'ground' && kind !== 'glow';
      mesh.receiveShadow = kind !== 'glow';
      mesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);
      mesh.computeBoundingBox();
      mesh.computeBoundingSphere();
      scene.add(mesh);
      meshes.push(mesh);
    }
    this.batches.clear();
    return { meshes, glowMaterial, count: this.count };
  }
}
