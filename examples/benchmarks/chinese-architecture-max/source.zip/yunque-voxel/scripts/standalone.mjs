import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

// This build has one entry and no lazy-loaded chunks or external assets. Inline
// the production bundle so the same project also opens directly under file://.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
let html = await readFile(path.join(dist, 'index.html'), 'utf8');
const jsMatch = html.match(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/);
const cssMatch = html.match(/<link\b[^>]*href="([^"]+\.css)"[^>]*>/);
if (!jsMatch || !cssMatch) throw new Error('Could not locate the production JS and CSS bundles.');
const resolveAsset = url => path.join(dist, url.replace(/^\.?\//, ''));
const js = await readFile(resolveAsset(jsMatch[1]), 'utf8');
const css = await readFile(resolveAsset(cssMatch[1]), 'utf8');
html = html.replace(jsMatch[0], () => `<script type="module">${js.replace(/<\/script/gi, '<\\/script')}</script>`);
html = html.replace(cssMatch[0], () => `<style>${css}</style>`);
const favicon = await readFile(path.join(root, 'public/favicon.svg'));
html = html.replace(/href="[^"]*favicon\.svg"/, `href="data:image/svg+xml;base64,${favicon.toString('base64')}"`);
await writeFile(path.join(dist, '云阙山院.html'), html);
console.log(`Standalone: dist/云阙山院.html (${(Buffer.byteLength(html)/1024).toFixed(0)} kB; no network required)`);
