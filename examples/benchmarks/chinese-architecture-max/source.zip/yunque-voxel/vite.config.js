import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: {
    // The deliberate single bundle also powers the offline HTML export.
    chunkSizeWarningLimit: 650,
  },
});
