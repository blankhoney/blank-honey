import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import {
  ISLANDS,
  createBoat,
  stepBoat,
  hullPose,
  waterHeight,
  celestial,
  canLight,
  clamp,
  damp,
  angleDelta,
} from './sea.js';
import { createWorld, loadVessel, createSeaEffects } from './world.js';
import { lensShader } from './shaders.js';
import './style.css';

const $ = (id) => document.getElementById(id);
const canvas = $('sea');
const storageKey = 'sunwake-voyage-v1';
let stored = {};
try {
  stored = JSON.parse(localStorage.getItem(storageKey) || '{}') || {};
} catch {
  /* A private tab can still sail. */
}
const restored =
  Number.isInteger(stored.lights) && stored.lights >= 0 && stored.lights <= 3
    ? stored.lights
    : 0;
const lit = Array.from({ length: restored }, (_, i) => i);
const boat = createBoat();
let natural = stored.water === 1 ? 1 : 0;
let vessel, renderer, composer, world, effects, bloom, lens;
let started = false,
  fatal = false,
  photo = false,
  cameraMode = 0;
let simulationTime = 0,
  cycleTime = 0,
  voyageTime = clamp(Number(stored.elapsed) || 0, 0, 100000);
let storm = 0.3,
  stormTarget = 0.3,
  wetness = 0.1,
  flash = 0;
let accumulator = 0,
  hudClock = 0,
  cameraHeading = 0;
let lastFrame = performance.now(),
  toastTimer;
let orbitAngle = 0,
  orbitHeight = 0,
  cameraDistance = 20.5;
let cameraReady = false,
  balanced = matchMedia('(pointer: coarse)').matches;
const pressed = new Set(),
  touch = new Set(),
  dialogs = [...document.querySelectorAll('dialog')];
const clockEnabled = $('cycle-enabled');
const camera = new THREE.PerspectiveCamera(
  55,
  innerWidth / innerHeight,
  0.15,
  3500,
);
const scene = new THREE.Scene();
const desiredCamera = new THREE.Vector3(),
  desiredLook = new THREE.Vector3(),
  smoothLook = new THREE.Vector3(),
  markerPoint = new THREE.Vector3();
const compassPoints = [...document.querySelectorAll('.compass-points span')];
const currentIsland = () => ISLANDS[lit.length];
const isPaused = () =>
  document.hidden || dialogs.some((dialog) => dialog.open) || fatal;

function notify(message) {
  $('toast').textContent = message;
  $('toast').classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('show'), 4600);
}

function showError(message) {
  fatal = true;
  $('error').replaceChildren();
  const title = document.createElement('strong');
  title.textContent = 'The sea could not be rendered.';
  const detail = document.createElement('p');
  detail.textContent = message;
  const retry = document.createElement('button');
  retry.className = 'secondary';
  retry.textContent = 'Reload voyage';
  retry.addEventListener('click', () => location.reload());
  $('error').append(title, detail, retry);
  $('error').hidden = false;
  $('start-label').textContent = 'Vessel unavailable';
}

function save() {
  try {
    localStorage.setItem(
      storageKey,
      JSON.stringify({
        lights: lit.length,
        water: natural,
        elapsed: voyageTime,
        distance: boat.distance,
      }),
    );
  } catch {
    /* Storage failure must never interrupt the voyage. */
  }
}

function resetBoat(toLastLight = false) {
  const distance = boat.distance;
  Object.assign(boat, createBoat());
  if (toLastLight && lit.length) {
    const last = ISLANDS[lit.length - 1];
    boat.x = last.dock.x;
    boat.z = last.dock.z + 38;
    boat.heading = currentIsland()
      ? Math.atan2(
          currentIsland().dock.x - boat.x,
          boat.z - currentIsland().dock.z,
        )
      : 0;
    boat.distance = distance;
  }
  const pose = hullPose(boat, simulationTime, storm);
  boat.y = pose.y;
  boat.pitch = pose.pitch;
  boat.roll = pose.roll;
  cameraHeading = boat.heading;
  cameraReady = false;
  effects?.clear();
  pressed.clear();
  touch.clear();
}

function updateObjective() {
  const target = currentIsland();
  $('objective-name').textContent = target?.name || 'The coast is awake';
  $('objective-description').textContent =
    target?.subtitle || 'Follow any horizon. The sea is yours.';
  $('progress-text').textContent =
    `${String(lit.length).padStart(2, '0')} / 03`;
  document.querySelectorAll('.route-progress i').forEach((node, i) => {
    node.classList.toggle('lit', lit.includes(i));
    node.classList.toggle('current', i === lit.length);
  });
  if (target) $('marker-label').textContent = target.name.toUpperCase();
  $('target-marker').hidden = !target;
}

function openDialog(dialog) {
  if (photo) setPhoto(false);
  if (!dialog.open) dialog.showModal();
  pressed.clear();
  touch.clear();
  document.body.classList.add('paused');
  if (dialog.id === 'chart-dialog') drawChart();
}

function closeDialogs() {
  dialogs.forEach((dialog) => dialog.close());
  document.body.classList.remove('paused');
  pressed.clear();
  touch.clear();
  lastFrame = performance.now();
  canvas.focus({ preventScroll: true });
}

function setWater(value, showToast = true) {
  natural = value === 1 ? 1 : 0;
  document.querySelectorAll('[data-water]').forEach((button) => {
    const active = Number(button.dataset.water) === natural;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  save();
  if (showToast)
    notify(
      natural
        ? 'Natural · deeper reflections, softer cedar. The same faceted sea.'
        : 'Illustrated · cobalt facets and honey-gold light.',
    );
}

function setPhoto(value) {
  photo = value;
  document.body.classList.toggle('photo-mode', photo);
  $('photo-exit').hidden = !photo;
  if (photo) $('photo-exit').focus({ preventScroll: true });
  else canvas.focus({ preventScroll: true });
}

function cycleCamera() {
  cameraMode = (cameraMode + 1) % 3;
  orbitAngle = 0;
  orbitHeight = 0;
  notify(
    [
      'Chase camera · a little room for the horizon',
      'Bow camera · glass between storms',
      'Orbit camera · drag to look around',
    ][cameraMode],
  );
}

function setPreset(preset) {
  if (preset === 'storm') {
    stormTarget = 0.98;
    cycleTime = 0;
    cameraMode = 1;
  } else if (preset === 'night') {
    stormTarget = 0.18;
    cycleTime = 211;
    cameraMode = 0;
  } else {
    stormTarget = 0.3;
    cycleTime = 0;
    cameraMode = 0;
  }
  $('weather-range').value = String(stormTarget);
  $('time-range').value = String(Math.floor(cycleTime));
  orbitAngle = 0;
  orbitHeight = 0;
  notify(
    preset === 'storm'
      ? 'A passing squall. The light is still there.'
      : preset === 'night'
        ? 'Look north. The sky has a tide of its own.'
        : 'A new dawn on the open water.',
  );
}

function beginVoyage() {
  if (!vessel || fatal) return;
  started = true;
  document.body.classList.add('started');
  $('instruments').hidden = false;
  boat.throttle = Math.max(0.42, boat.throttle);
  canvas.focus({ preventScroll: true });
  notify('W / S sets power · A / D steers · find the gold mooring ring.');
}

function newVoyage() {
  lit.length = 0;
  voyageTime = 0;
  cycleTime = 0;
  simulationTime = 0;
  storm = stormTarget = 0.3;
  $('weather-range').value = '0.3';
  cameraMode = 0;
  orbitAngle = orbitHeight = 0;
  resetBoat(false);
  updateObjective();
  save();
  closeDialogs();
  started = true;
  document.body.classList.add('started');
  $('instruments').hidden = false;
  boat.throttle = 0.5;
  notify('Three sleeping lanterns. One fresh start.');
}

function lightBeacon() {
  if (!started) return;
  const target = currentIsland();
  if (!target) {
    notify('Every lantern is alight. The open sea is yours.');
    return;
  }
  if (!canLight(boat, target)) {
    notify(
      Math.hypot(boat.x - target.dock.x, boat.z - target.dock.z) < 40
        ? 'Hold Space to ease below 8 knots, then press E.'
        : 'Find the gold mooring ring near the next lighthouse.',
    );
    return;
  }
  lit.push(lit.length);
  flash = 1;
  updateObjective();
  save();
  chime();
  notify(
    `${target.name} is awake. ${currentIsland() ? `Next, ${currentIsland().name}.` : 'The coast has its light again.'}`,
  );
  if (lit.length === 3) {
    $('voyage-stats').replaceChildren();
    for (const value of [
      `${(boat.distance / 1000).toFixed(2)} km travelled`,
      `${Math.floor(voyageTime / 60)}m ${Math.floor(voyageTime % 60)}s at sea`,
    ]) {
      const span = document.createElement('span');
      span.textContent = value;
      $('voyage-stats').append(span);
    }
    openDialog($('complete-dialog'));
  }
}

// Browser-native sound synthesis; no recordings, remote media, or autoplay.
let audioContext,
  audioMaster,
  oceanGain,
  oceanFilter,
  motorOscillator,
  soundEnabled = false;
async function toggleSound() {
  try {
    if (!audioContext) {
      const Audio = window.AudioContext || window.webkitAudioContext;
      if (!Audio) {
        notify('Ocean audio is unavailable on this device.');
        return;
      }
      audioContext = new Audio();
      audioMaster = audioContext.createGain();
      audioMaster.gain.value = 0;
      audioMaster.connect(audioContext.destination);
      const buffer = audioContext.createBuffer(
        1,
        audioContext.sampleRate * 4,
        audioContext.sampleRate,
      );
      const data = buffer.getChannelData(0);
      let brown = 0;
      for (let i = 0; i < data.length; i++) {
        brown = (brown + (Math.random() * 2 - 1) * 0.025) / 1.025;
        data[i] = brown * 3.3 + (Math.random() * 2 - 1) * 0.2;
      }
      const noise = audioContext.createBufferSource();
      noise.buffer = buffer;
      noise.loop = true;
      oceanFilter = audioContext.createBiquadFilter();
      oceanFilter.type = 'lowpass';
      oceanFilter.frequency.value = 1100;
      oceanGain = audioContext.createGain();
      oceanGain.gain.value = 0.11;
      noise.connect(oceanFilter);
      oceanFilter.connect(oceanGain);
      oceanGain.connect(audioMaster);
      noise.start();
      motorOscillator = audioContext.createOscillator();
      motorOscillator.type = 'sine';
      motorOscillator.frequency.value = 45;
      const motorGain = audioContext.createGain();
      motorGain.gain.value = 0.009;
      motorOscillator.connect(motorGain);
      motorGain.connect(audioMaster);
      motorOscillator.start();
    }
    await audioContext.resume();
    soundEnabled = !soundEnabled;
    audioMaster.gain.setTargetAtTime(
      soundEnabled ? 0.7 : 0,
      audioContext.currentTime,
      0.3,
    );
    $('sound-button').setAttribute('aria-pressed', String(soundEnabled));
    $('sound-button').setAttribute(
      'aria-label',
      soundEnabled ? 'Mute ocean audio' : 'Enable ocean audio',
    );
    $('sound-button').title = soundEnabled
      ? 'Mute ocean audio'
      : 'Enable ocean audio';
    $('sound-button').innerHTML =
      `<svg viewBox="0 0 24 24"><path d="M11 5 6 9H3v6h3l5 4V5Z${soundEnabled ? 'M15 8a6 6 0 0 1 0 8M18 5a10 10 0 0 1 0 14' : 'M16 9l5 6m0-6-5 6'}"/></svg>`;
  } catch {
    notify('Audio could not start. You can keep sailing.');
  }
}

function chime() {
  if (!audioContext || !soundEnabled) return;
  [440, 554.37, 659.25].forEach((frequency, i) => {
    const oscillator = audioContext.createOscillator(),
      gain = audioContext.createGain();
    const t = audioContext.currentTime + i * 0.14;
    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.1, t + 0.035);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.5);
    oscillator.connect(gain);
    gain.connect(audioMaster);
    oscillator.start(t);
    oscillator.stop(t + 1.6);
    oscillator.onended = () => {
      oscillator.disconnect();
      gain.disconnect();
    };
  });
}

function readInput() {
  const key = (...codes) => codes.some((code) => pressed.has(code));
  return {
    power:
      Number(key('KeyW', 'ArrowUp') || touch.has('up')) -
      Number(key('KeyS', 'ArrowDown') || touch.has('down')),
    turn:
      Number(key('KeyD', 'ArrowRight') || touch.has('right')) -
      Number(key('KeyA', 'ArrowLeft') || touch.has('left')),
    brake: key('Space') || touch.has('brake'),
    boost: key('ShiftLeft', 'ShiftRight'),
  };
}

function updateCamera(dt, light) {
  cameraHeading +=
    angleDelta(cameraHeading, boat.heading) * (1 - Math.exp(-1.8 * dt));
  const angle = cameraHeading + orbitAngle;
  const s = Math.sin(angle),
    c = Math.cos(angle);
  const portrait = innerHeight > innerWidth;
  if (cameraMode === 1) {
    desiredCamera.set(
      boat.x - Math.sin(boat.heading) * 1.2,
      boat.y + 2.1,
      boat.z + Math.cos(boat.heading) * 1.2,
    );
    desiredLook.set(
      boat.x + s * 32,
      boat.y + 2.35 + boat.pitch * 10 + orbitHeight * 10,
      boat.z - c * 32,
    );
  } else {
    const distance =
      cameraDistance +
      (portrait ? 4.5 : 0) +
      (cameraMode === 2 ? 4 : 0) +
      light.night * 3;
    desiredCamera.set(
      boat.x - s * distance + c * 0.7,
      boat.y * 0.23 + (cameraMode === 2 ? 11.8 : 8.6) + orbitHeight * 9,
      boat.z + c * distance + s * 0.7,
    );
    const localSea = waterHeight(
      desiredCamera.x,
      desiredCamera.z,
      simulationTime,
      storm,
    );
    desiredCamera.y = Math.max(desiredCamera.y, localSea + 3.1);
    desiredLook.set(
      boat.x + Math.sin(cameraHeading) * (cameraMode === 2 ? 0 : 11),
      2.3 + boat.y * 0.16 + light.night * 3.2,
      boat.z - Math.cos(cameraHeading) * (cameraMode === 2 ? 0 : 11),
    );
  }
  if (!cameraReady) {
    camera.position.copy(desiredCamera);
    smoothLook.copy(desiredLook);
    cameraReady = true;
  } else {
    camera.position.lerp(
      desiredCamera,
      1 - Math.exp(-dt * (cameraMode === 1 ? 5.5 : 2.6)),
    );
    smoothLook.lerp(desiredLook, 1 - Math.exp(-dt * 3.8));
  }
  camera.lookAt(smoothLook);
  camera.updateMatrixWorld();
}

function updateHUD(light) {
  const knots = boat.speed * 1.94384;
  $('speed').textContent = knots.toFixed(1);
  $('motion-label').textContent =
    knots < 0.7
      ? 'At rest'
      : readInput().brake
        ? 'Easing off'
        : knots > 17
          ? 'Riding the swell'
          : 'Under way';
  $('power-value').textContent = `${Math.round(boat.throttle * 100)}%`;
  $('power-fill').style.width = `${boat.throttle * 100}%`;
  $('wind-value').textContent = `SW  ${Math.round(11 + storm * 18)} kn`;
  $('swell-value').textContent = `${(1.5 + storm * 2.5).toFixed(1)} m swell`;
  const bearing = ((((boat.heading * 180) / Math.PI) % 360) + 360) % 360;
  $('heading').textContent =
    `${String(Math.round(bearing) % 360).padStart(3, '0')}°`;
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  compassPoints.forEach((node, i) => {
    node.textContent =
      directions[Math.round((bearing + [-90, -45, 45, 90][i] + 360) / 45) % 8];
  });
  $('phase-name').textContent = light.label;
  const weather =
    light.night > 0.5
      ? [
          'Under the northern sky',
          stormTarget > 0.6
            ? 'Rain passing under the stars'
            : 'Starlight · an aurora at sea',
          '☾',
        ]
      : stormTarget > 0.6
        ? ['Glass between storms', 'Passing rain · a break in the clouds', '☂']
        : light.warmth > 0.45
          ? [
              light.phase < 0.25
                ? 'First light voyage'
                : 'The last golden mile',
              'Golden skies · rolling swells',
              '☀',
            ]
          : ['The wide blue', 'Open skies · a steady sea wind', '☀'];
  $('weather-title').textContent = weather[0];
  $('weather-description').textContent = weather[1];
  document.querySelector('.weather-sun').textContent = weather[2];
  $('cycle-label').textContent =
    light.night > 0.5 ? 'NIGHT' : light.warmth > 0.55 ? 'GOLDEN' : 'DAY';
  $('cycle-progress').style.width = `${light.phase * 100}%`;
  $('time-value').textContent = light.label;
  $('sea-state-value').textContent =
    stormTarget < 0.25
      ? 'Gentle sea'
      : stormTarget < 0.6
        ? 'Rolling swell'
        : 'High seas';
  if (document.activeElement !== $('time-range'))
    $('time-range').value = String(Math.floor(cycleTime % 300));
  $('coordinates').textContent =
    `36° ${(42 - boat.z / 1852).toFixed(2)}′ N   024° ${(18 + boat.x / 1490).toFixed(2)}′ E`;
  const target = currentIsland();
  if (target) {
    const distance = Math.hypot(boat.x - target.dock.x, boat.z - target.dock.z);
    $('marker-distance').textContent =
      distance > 1000
        ? `${(distance / 1000).toFixed(2)} km`
        : `${Math.round(distance)} m`;
    markerPoint
      .set(target.beacon.x, target.height + 45, target.beacon.z)
      .project(camera);
    const visible =
      markerPoint.z < 1 && markerPoint.z > -1 && Math.abs(markerPoint.x) < 1.12;
    $('target-marker').hidden = !visible;
    if (visible) {
      $('target-marker').style.left =
        `${clamp((markerPoint.x * 0.5 + 0.5) * innerWidth, 65, innerWidth - 95)}px`;
      $('target-marker').style.top =
        `${clamp((-0.5 * markerPoint.y + 0.5) * innerHeight - 28, 142, innerHeight - 245)}px`;
    }
    const prompt = $('context-prompt');
    prompt.hidden = !started || distance >= 53;
    if (!prompt.hidden) {
      if (canLight(boat, target)) {
        if (!prompt.querySelector('button')) {
          const button = document.createElement('button');
          button.textContent = 'E  ·  Light the lighthouse';
          button.addEventListener('click', lightBeacon);
          prompt.replaceChildren(button);
        }
      } else
        prompt.textContent =
          distance >= 31
            ? 'Sail inside the golden ring'
            : 'Hold Space to slow below 8 knots';
    }
  } else $('context-prompt').hidden = true;
  if ($('chart-dialog').open) drawChart();
}

function drawChart() {
  const chart = $('chart'),
    ctx = chart.getContext('2d'),
    w = chart.width,
    h = chart.height;
  const minX = Math.min(-500, boat.x - 80),
    maxX = Math.max(500, boat.x + 80),
    minZ = Math.min(-1530, boat.z - 80),
    maxZ = Math.max(170, boat.z + 80);
  const map = (p) => ({
    x: 55 + ((p.x - minX) / (maxX - minX)) * (w - 110),
    y: 35 + ((p.z - minZ) / (maxZ - minZ)) * (h - 80),
  });
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#112c36';
  ctx.fillRect(0, 0, w, h);
  ctx.lineWidth = 1;
  ctx.strokeStyle = '#b5cab710';
  for (let x = 0; x < w; x += 47) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y < h; y += 47) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
  ctx.strokeStyle = '#a8c7b312';
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.ellipse(
      w * 0.48,
      h * 0.5,
      100 + i * 75,
      45 + i * 74,
      -0.6,
      0,
      Math.PI * 2,
    );
    ctx.stroke();
  }
  ctx.font = '10px Avenir, sans-serif';
  ctx.fillStyle = '#8ba9aa';
  ctx.fillText('THE SUNWAKE ARCHIPELAGO', 23, 27);
  ctx.textAlign = 'right';
  ctx.fillText('N', w - 28, 32);
  ctx.textAlign = 'left';
  ctx.strokeStyle = '#d9d2ac';
  ctx.beginPath();
  ctx.moveTo(w - 32, 43);
  ctx.lineTo(w - 32, 76);
  ctx.moveTo(w - 37, 50);
  ctx.lineTo(w - 32, 43);
  ctx.lineTo(w - 27, 50);
  ctx.stroke();
  const route = [{ x: 0, z: 35 }, ...ISLANDS.map((island) => island.dock)];
  ctx.setLineDash([4, 7]);
  ctx.strokeStyle = '#edc38977';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  route.forEach((point, i) => {
    const p = map(point);
    if (i) ctx.lineTo(p.x, p.y);
    else ctx.moveTo(p.x, p.y);
  });
  ctx.stroke();
  ctx.setLineDash([]);
  ISLANDS.forEach((island, i) => {
    const p = map(island),
      radiusX = (island.radius / (maxX - minX)) * (w - 110),
      radiusY = (island.radius / (maxZ - minZ)) * (h - 80);
    ctx.beginPath();
    for (let j = 0; j < 18; j++) {
      const a = (j / 18) * Math.PI * 2,
        r = 1 + Math.sin(j * 2.1 + island.seed) * 0.12;
      const x = p.x + Math.cos(a) * radiusX * r,
        y = p.y + Math.sin(a) * radiusY * r;
      if (j) ctx.lineTo(x, y);
      else ctx.moveTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = '#667c66';
    ctx.fill();
    ctx.strokeStyle = '#c2b58caa';
    ctx.stroke();
    ctx.fillStyle = '#91a080';
    ctx.beginPath();
    ctx.ellipse(p.x, p.y, radiusX * 0.5, radiusY * 0.4, -0.3, 0, Math.PI * 2);
    ctx.fill();
    const dock = map(island.dock),
      active = i === lit.length;
    ctx.strokeStyle = '#edc389';
    ctx.lineWidth = active ? 2 : 1;
    ctx.beginPath();
    ctx.arc(dock.x, dock.y, active ? 7 : 5, 0, Math.PI * 2);
    ctx.stroke();
    if (lit.includes(i)) {
      ctx.fillStyle = '#edc389';
      ctx.fill();
    }
    const left = p.x > w * 0.65;
    ctx.textAlign = left ? 'right' : 'left';
    ctx.fillStyle = i === lit.length ? '#efd2a6' : '#ced9ca';
    ctx.font = '12px Avenir, sans-serif';
    ctx.fillText(
      `${String(i + 1).padStart(2, '0')}  ${island.name.toUpperCase()}`,
      p.x + (left ? -radiusX - 15 : radiusX + 15),
      p.y - 3,
    );
    ctx.font = '10px Avenir, sans-serif';
    ctx.fillStyle = '#89a6a4';
    ctx.fillText(
      lit.includes(i)
        ? 'LIGHT RESTORED'
        : i === lit.length
          ? 'YOUR NEXT LIGHT'
          : 'SLEEPING BEACON',
      p.x + (left ? -radiusX - 15 : radiusX + 15),
      p.y + 14,
    );
    ctx.textAlign = 'left';
  });
  const p = map(boat);
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(boat.heading);
  ctx.beginPath();
  ctx.moveTo(0, -10);
  ctx.lineTo(5.7, 7);
  ctx.lineTo(0, 4);
  ctx.lineTo(-5.7, 7);
  ctx.closePath();
  ctx.fillStyle = '#f8edcc';
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = '#789a9a';
  ctx.font = '10px Avenir, sans-serif';
  ctx.fillText('Soundings unknown. Trust the light.', 23, h - 22);
  ctx.textAlign = 'right';
  ctx.fillText('NOT FOR NAVIGATION OUTSIDE THIS SEA', w - 22, h - 22);
  ctx.textAlign = 'left';
}

function resize() {
  if (!renderer) return;
  camera.aspect = innerWidth / innerHeight;
  camera.fov = innerWidth < 700 ? 62 : 55;
  camera.updateProjectionMatrix();
  const ratio = Math.min(devicePixelRatio || 1, balanced ? 1.15 : 1.7);
  renderer.setPixelRatio(ratio);
  renderer.setSize(innerWidth, innerHeight, false);
  composer.setPixelRatio(ratio);
  composer.setSize(innerWidth, innerHeight);
  lens.uniforms.uAspect.value = camera.aspect;
  bloom.enabled = !balanced;
}

function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min((now - lastFrame) / 1000, 0.05);
  lastFrame = now;
  if (fatal || !world) return;
  const paused = isPaused();
  if (!paused) {
    storm = damp(storm, stormTarget, 0.24, dt);
    if (clockEnabled.checked) cycleTime = (cycleTime + dt) % 300;
    if (started) voyageTime += dt;
    accumulator += dt;
    const input = started
      ? readInput()
      : { power: 0, turn: 0, brake: false, boost: false };
    if (!started) {
      const target = currentIsland();
      if (target) {
        const distance = Math.hypot(
          target.dock.x - boat.x,
          target.dock.z - boat.z,
        );
        const bearing = Math.atan2(
          target.dock.x - boat.x,
          boat.z - target.dock.z,
        );
        input.turn = clamp(
          angleDelta(boat.heading, bearing) * 1.6,
          -0.35,
          0.35,
        );
        boat.throttle = distance > 100 ? 0.32 : 0;
      } else boat.throttle = 0.18;
    }
    while (accumulator >= 1 / 120) {
      simulationTime += 1 / 120;
      stepBoat(boat, input, 1 / 120, simulationTime, storm);
      accumulator -= 1 / 120;
    }
    effects.update(boat, simulationTime, dt, storm, balanced);
    wetness = damp(
      wetness,
      clamp(boat.impact * 0.32 + boat.speed * 0.022 + storm * 0.22, 0, 1),
      1.4,
      dt,
    );
    flash = damp(flash, 0, 1.7, dt);
  }
  const light = celestial(cycleTime);
  world.update(
    boat,
    simulationTime,
    storm,
    light,
    natural,
    currentIsland(),
    lit,
  );
  vessel?.update(boat, simulationTime, natural);
  updateCamera(dt, light);
  bloom.strength = 0.36 + light.warmth * 0.16 + flash * 0.3;
  lens.uniforms.uTime.value = simulationTime;
  lens.uniforms.uWet.value = wetness;
  lens.uniforms.uStorm.value = storm;
  if (audioContext && soundEnabled) {
    audioMaster.gain.setTargetAtTime(
      paused ? 0.09 : 0.7,
      audioContext.currentTime,
      0.6,
    );
    oceanGain.gain.setTargetAtTime(
      0.13 +
        boat.speed * 0.012 +
        Math.sin(simulationTime * 0.7) * 0.025 +
        storm * 0.045,
      audioContext.currentTime,
      0.3,
    );
    oceanFilter.frequency.setTargetAtTime(
      650 + boat.speed * 95 + storm * 420,
      audioContext.currentTime,
      0.3,
    );
    motorOscillator.frequency.setTargetAtTime(
      34 + boat.speed * 4,
      audioContext.currentTime,
      0.2,
    );
  }
  hudClock += dt;
  if (hudClock >= 0.1) {
    updateHUD(light);
    hudClock = 0;
  }
  try {
    composer.render(dt);
  } catch (error) {
    console.error(error);
    showError(
      'WebGL stopped while drawing the ocean. Reload the voyage to try again.',
    );
  }
}

document.addEventListener('keydown', (event) => {
  if (
    event.target instanceof HTMLInputElement ||
    event.target instanceof HTMLSelectElement
  )
    return;
  if (
    event.target instanceof HTMLButtonElement &&
    (event.code === 'Space' || event.code === 'Enter')
  )
    return;
  if (event.code === 'Escape') {
    event.preventDefault();
    if (dialogs.some((dialog) => dialog.open)) closeDialogs();
    else if (photo) setPhoto(false);
    else openDialog($('pause-dialog'));
    return;
  }
  if (dialogs.some((dialog) => dialog.open)) return;
  if (
    ['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(
      event.code,
    )
  )
    event.preventDefault();
  pressed.add(event.code);
  if (event.repeat) return;
  if (event.code === 'KeyC') cycleCamera();
  if (event.code === 'KeyE') lightBeacon();
  if (event.code === 'KeyM') openDialog($('chart-dialog'));
  if (event.code === 'KeyH' || event.code === 'Slash')
    openDialog($('help-dialog'));
  if (event.code === 'KeyP') setPhoto(!photo);
  if (event.code === 'Digit1') setWater(0);
  if (event.code === 'Digit2') setWater(1);
  if (event.code === 'KeyR') {
    resetBoat(true);
    notify('Back in safe water. Raise power when you are ready.');
  }
  if (event.code === 'Enter' && !started && event.target === canvas)
    beginVoyage();
});
document.addEventListener('keyup', (event) => pressed.delete(event.code));
window.addEventListener('blur', () => {
  pressed.clear();
  touch.clear();
});
document.addEventListener('visibilitychange', () => {
  pressed.clear();
  touch.clear();
  lastFrame = performance.now();
  if (document.hidden) save();
});
window.addEventListener('pagehide', save);
window.addEventListener('resize', resize);
canvas.addEventListener('webglcontextlost', (event) => {
  event.preventDefault();
  showError(
    'The graphics context was lost. Reload to restore the sea; completed lights are saved.',
  );
});
let pointer = null;
canvas.addEventListener('pointerdown', (event) => {
  pointer = { x: event.clientX, y: event.clientY, id: event.pointerId };
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener('pointermove', (event) => {
  if (!pointer || pointer.id !== event.pointerId) return;
  orbitAngle -= (event.clientX - pointer.x) * 0.004;
  orbitHeight = clamp(
    orbitHeight + (event.clientY - pointer.y) * 0.003,
    -0.35,
    1.1,
  );
  pointer.x = event.clientX;
  pointer.y = event.clientY;
});
canvas.addEventListener('pointerup', () => {
  pointer = null;
});
canvas.addEventListener('pointercancel', () => {
  pointer = null;
});
canvas.addEventListener(
  'wheel',
  (event) => {
    event.preventDefault();
    cameraDistance = clamp(cameraDistance + event.deltaY * 0.015, 12, 37);
  },
  { passive: false },
);
document.querySelectorAll('[data-touch]').forEach((button) => {
  button.addEventListener('pointerdown', (event) => {
    event.preventDefault();
    button.setPointerCapture(event.pointerId);
    touch.add(button.dataset.touch);
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture'])
    button.addEventListener(type, () => touch.delete(button.dataset.touch));
});
dialogs.forEach((dialog) => {
  dialog.addEventListener('cancel', (event) => {
    event.preventDefault();
    closeDialogs();
  });
  dialog.addEventListener('close', () => {
    if (!dialogs.some((d) => d.open)) {
      document.body.classList.remove('paused');
      $('settings-button').setAttribute('aria-expanded', 'false');
    }
  });
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) {
      const rect = dialog.getBoundingClientRect();
      if (
        event.clientX < rect.left ||
        event.clientX > rect.right ||
        event.clientY < rect.top ||
        event.clientY > rect.bottom
      )
        closeDialogs();
    }
  });
});
document
  .querySelectorAll('[data-close]')
  .forEach((button) => button.addEventListener('click', closeDialogs));
document
  .querySelectorAll('[data-water]')
  .forEach((button) =>
    button.addEventListener('click', () =>
      setWater(Number(button.dataset.water)),
    ),
  );
document
  .querySelectorAll('[data-preset]')
  .forEach((button) =>
    button.addEventListener('click', () => setPreset(button.dataset.preset)),
  );
$('start-button').addEventListener('click', beginVoyage);
$('settings-button').addEventListener('click', () => {
  $('settings-button').setAttribute('aria-expanded', 'true');
  openDialog($('settings-dialog'));
});
$('chart-button').addEventListener('click', () =>
  openDialog($('chart-dialog')),
);
$('help-button').addEventListener('click', () => openDialog($('help-dialog')));
$('camera-button').addEventListener('click', cycleCamera);
$('brand').addEventListener('click', (event) => {
  event.preventDefault();
  openDialog($('help-dialog'));
});
$('sound-button').addEventListener('click', toggleSound);
$('photo-button').addEventListener('click', () => setPhoto(true));
$('photo-exit').addEventListener('click', () => setPhoto(false));
$('weather-cycle').addEventListener('click', () =>
  setPreset(stormTarget > 0.6 ? 'dawn' : 'storm'),
);
$('weather-range').addEventListener('input', (event) => {
  stormTarget = Number(event.target.value);
});
$('time-range').addEventListener('input', (event) => {
  cycleTime = Number(event.target.value);
});
$('quality').value = balanced ? 'balanced' : 'high';
$('quality').addEventListener('change', (event) => {
  balanced = event.target.value === 'balanced';
  resize();
});
$('recover-button').addEventListener('click', () => {
  resetBoat(true);
  closeDialogs();
  notify('Clear water beneath your keel.');
});
$('restart-button').addEventListener('click', newVoyage);
$('new-voyage-button').addEventListener('click', newVoyage);

try {
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
    powerPreference: 'high-performance',
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.debug.onShaderError = (gl, program, vertex, fragment) => {
    console.error(
      'Sunwake shader error:',
      gl.getProgramInfoLog(program),
      gl.getShaderInfoLog(vertex),
      gl.getShaderInfoLog(fragment),
    );
    showError(
      'This device could not compile the ocean shaders. Try an up-to-date browser with WebGL2 enabled.',
    );
  };
  world = createWorld(scene);
  effects = createSeaEffects(scene, world.uniforms);
  composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  bloom = new UnrealBloomPass(
    new THREE.Vector2(innerWidth, innerHeight),
    0.5,
    0.6,
    0.93,
  );
  composer.addPass(bloom);
  lens = new ShaderPass(lensShader);
  composer.addPass(lens);
  composer.addPass(new OutputPass());
  setWater(natural, false);
  resetBoat(lit.length > 0);
  boat.distance = clamp(Number(stored.distance) || 0, 0, 10000000);
  boat.speed = 3.6;
  boat.throttle = 0.32;
  updateObjective();
  resize();
  const params = new URLSearchParams(location.search);
  if (params.get('scene') === 'storm' || params.get('scene') === 'aurora')
    setPreset(params.get('scene') === 'aurora' ? 'night' : 'storm');
  if (params.get('water') === 'natural') setWater(1, false);
  if (params.get('view') === 'bow') cameraMode = 1;
  requestAnimationFrame(frame);
  vessel = await loadVessel(scene, world.uniforms);
  $('start-button').disabled = false;
  $('start-label').textContent = lit.length ? 'Continue voyage' : 'Set sail';
  $('start-arrow').textContent = '↗';
  if (lit.length)
    $('welcome').querySelector('p').textContent =
      `${lit.length} of 3 lanterns restored. Your horizon is waiting.`;
} catch (error) {
  console.error(error);
  showError(
    'Sunwake needs WebGL2 and its bundled vessel asset. Serve the dist folder with an HTTP static host; opening index.html as a file is not supported.',
  );
}
