// One wave definition drives the GPU surface, buoyancy, foam and spray contacts.
export const WAVES = [
  {
    amplitude: 1.02,
    length: 47,
    direction: [0.32, -0.948],
    speed: 0.94,
    phase: 0.3,
  },
  {
    amplitude: 0.56,
    length: 28,
    direction: [-0.68, -0.733],
    speed: 1.15,
    phase: 1.7,
  },
  {
    amplitude: 0.29,
    length: 16,
    direction: [0.87, 0.493],
    speed: 0.9,
    phase: 2.5,
  },
  {
    amplitude: 0.12,
    length: 8.4,
    direction: [-0.23, -0.973],
    speed: 1.05,
    phase: 0.9,
  },
  {
    amplitude: 0.065,
    length: 4.7,
    direction: [0.74, -0.673],
    speed: 0.88,
    phase: 4.1,
  },
].map((w) => ({
  ...w,
  k: (2 * Math.PI) / w.length,
  omega: Math.sqrt((9.81 * 2 * Math.PI) / w.length) * w.speed,
}));

export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const damp = (a, b, rate, dt) =>
  a + (b - a) * (1 - Math.exp(-rate * dt));
export const angleDelta = (a, b) =>
  Math.atan2(Math.sin(b - a), Math.cos(b - a));
export const waveScale = (storm) => 0.74 + storm * 1.32;

export function displacedPoint(x, z, t, storm = 0.3) {
  let px = x,
    pz = z,
    y = 0;
  const scale = waveScale(storm);
  for (const w of WAVES) {
    const a = w.amplitude * scale;
    const p =
      w.k * (w.direction[0] * x + w.direction[1] * z) - w.omega * t + w.phase;
    y += a * Math.sin(p);
    px += w.direction[0] * a * 0.28 * Math.cos(p);
    pz += w.direction[1] * a * 0.28 * Math.cos(p);
  }
  return { x: px, y, z: pz };
}

export function waterHeight(x, z, t, storm = 0.3) {
  // Invert Gerstner horizontal displacement: sampling parameter-space directly
  // would make a floating hull miss the rendered crests by several centimetres.
  let u = x,
    v = z;
  for (let i = 0; i < 4; i++) {
    const p = displacedPoint(u, v, t, storm);
    u += x - p.x;
    v += z - p.z;
  }
  return displacedPoint(u, v, t, storm).y;
}

export function hullDisplacement(x, z, boat, t) {
  const dx = x - boat.x,
    dz = z - boat.z;
  const side = dx * Math.cos(boat.heading) + dz * Math.sin(boat.heading);
  const fore = dx * Math.sin(boat.heading) - dz * Math.cos(boat.heading);
  const strength = Math.min(boat.speed / 10, 1.3);
  const bow =
    Math.exp(-((fore - 4.1) ** 2) * 1.4) *
    Math.exp(-((Math.abs(side) - 1.35) ** 2) * 1.8);
  const behind = Math.max(0, -fore - 2.8);
  const spread = 1.25 + behind * 0.29;
  const kelvin =
    Math.exp(-((Math.abs(side) - spread) ** 2) * 0.55) *
    Math.exp(-behind / 27) *
    (fore < -2.8 ? 1 : 0);
  return (
    strength * (bow * 0.3 + kelvin * Math.sin(behind * 0.85 - t * 3.4) * 0.16)
  );
}

export function surfaceHeight(x, z, t, storm, boat) {
  return waterHeight(x, z, t, storm) + hullDisplacement(x, z, boat, t);
}

export function hullPose(boat, t, storm) {
  const f = { x: Math.sin(boat.heading), z: -Math.cos(boat.heading) };
  const s = { x: Math.cos(boat.heading), z: Math.sin(boat.heading) };
  const sample = (fore, side) =>
    waterHeight(
      boat.x + f.x * fore + s.x * side,
      boat.z + f.z * fore + s.z * side,
      t,
      storm,
    );
  const bow = sample(3.5, 0),
    stern = sample(-2.8, 0);
  const port = sample(0, -1.12),
    starboard = sample(0, 1.12);
  const center = sample(0, 0);
  return {
    // Model datum = designed waterline; keel -0.68 m, gunwale +1.05 m.
    y: center * 0.42 + (bow + stern) * 0.19 + (port + starboard) * 0.1 + 0.04,
    pitch: clamp(Math.atan2(bow - stern, 6.3), -0.36, 0.36),
    roll: clamp(Math.atan2(starboard - port, 2.24), -0.34, 0.34),
  };
}

export const ISLANDS = [
  {
    name: 'Morrow Light',
    subtitle: 'The first ember',
    x: 168,
    z: -395,
    radius: 56,
    height: 31,
    seed: 2,
    dock: { x: 130, z: -312 },
    beacon: { x: 167, z: -392 },
  },
  {
    name: 'The Glass Isles',
    subtitle: 'A light through the rain',
    x: -265,
    z: -807,
    radius: 70,
    height: 44,
    seed: 7,
    dock: { x: -227, z: -707 },
    beacon: { x: -267, z: -803 },
  },
  {
    name: 'Northstar Reach',
    subtitle: 'Carry the dawn home',
    x: 215,
    z: -1300,
    radius: 84,
    height: 55,
    seed: 13,
    dock: { x: 166, z: -1190 },
    beacon: { x: 220, z: -1298 },
  },
];

export function createBoat() {
  return {
    x: 0,
    z: 35,
    y: 0,
    vy: 0,
    surfaceY: undefined,
    heading: 0,
    yaw: 0,
    speed: 0,
    throttle: 0,
    rudder: 0,
    pitch: 0,
    roll: 0,
    distance: 0,
    impact: 0,
  };
}

export function stepBoat(boat, input, dt, t, storm, islands = ISLANDS) {
  boat.throttle = clamp(boat.throttle + input.power * dt * 0.34, 0, 1);
  const reef = input.brake ? 0.13 : 1;
  const windDrive = 0.84 + 0.16 * Math.cos(boat.heading + 0.5);
  const targetSpeed =
    boat.throttle * (input.boost ? 15.5 : 12.4) * windDrive * reef;
  boat.speed = damp(boat.speed, targetSpeed, input.brake ? 1.45 : 0.27, dt);
  boat.rudder = damp(boat.rudder, input.turn, 3.4, dt);
  const targetYaw = boat.rudder * Math.min(boat.speed / 7, 1) * 0.43;
  boat.yaw = damp(boat.yaw, targetYaw, 2.5, dt);
  boat.heading += boat.yaw * dt;
  const priorX = boat.x,
    priorZ = boat.z;
  boat.x += Math.sin(boat.heading) * boat.speed * dt;
  boat.z -= Math.cos(boat.heading) * boat.speed * dt;
  for (const island of islands) {
    const dx = boat.x - island.x,
      dz = boat.z - island.z;
    const distance = Math.hypot(dx, dz),
      safe = island.radius * 1.17 + 5;
    if (distance < safe) {
      const inv = 1 / Math.max(distance, 0.001);
      boat.x = island.x + (distance < 0.001 ? 1 : dx * inv) * safe;
      boat.z = island.z + dz * inv * safe;
      boat.speed *= 0.45;
    }
  }
  // ponytail: the bounded archipelago keeps Float32 precision; rebase the world
  // only if voyages expand beyond this 5 km play area.
  boat.x = clamp(boat.x, -2400, 2400);
  boat.z = clamp(boat.z, -2700, 1300);
  boat.distance += Math.hypot(boat.x - priorX, boat.z - priorZ);
  const pose = hullPose(boat, t, storm);
  // Damping is relative to the moving water, not a stationary world frame.
  // This removes large-wave heave lag while keeping the designed waterline.
  const seaVelocity = (pose.y - (boat.surfaceY ?? pose.y)) / dt;
  boat.surfaceY = pose.y;
  const acceleration =
    64 * (pose.y - boat.y) - 16 * (boat.vy - seaVelocity * 0.85);
  boat.vy += acceleration * dt;
  boat.y += boat.vy * dt;
  boat.pitch = damp(boat.pitch, pose.pitch + boat.speed * 0.002, 6, dt);
  boat.roll = damp(boat.roll, pose.roll - boat.yaw * boat.speed * 0.034, 5, dt);
  boat.impact = damp(
    boat.impact,
    Math.max(0, acceleration - 3) * boat.speed * 0.025,
    5,
    dt,
  );
}

export function canLight(boat, island) {
  return (
    Boolean(island) &&
    Math.hypot(boat.x - island.dock.x, boat.z - island.dock.z) < 31 &&
    boat.speed < 8 / 1.94384
  );
}

export function celestial(cycleSeconds) {
  const phase = (((cycleSeconds / 300 + 0.018) % 1) + 1) % 1;
  const angle = phase * Math.PI * 2;
  const sun = {
    x: Math.sin(angle) * 0.8,
    y: Math.sin(angle) * 0.7,
    z: -Math.cos(angle),
  };
  const length = Math.hypot(sun.x, sun.y, sun.z);
  sun.x /= length;
  sun.y /= length;
  sun.z /= length;
  const daylight = clamp((sun.y + 0.12) / 0.32, 0, 1);
  const night = 1 - clamp((sun.y + 0.19) / 0.2, 0, 1);
  const warmth = Math.pow(1 - Math.abs(sun.y), 4) * (1 - night);
  const label =
    phase < 0.08
      ? 'First light'
      : phase < 0.4
        ? 'Open daylight'
        : phase < 0.54
          ? 'Golden hour'
          : phase < 0.91
            ? 'Northern night'
            : 'Before the dawn';
  return { phase, sun, daylight, night, warmth, label };
}

export function seededRandom(seed) {
  return () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

// Generated from the CPU constants above so tuning cannot desynchronise them.
const gl = (n) => Number(n).toFixed(8);
export const WAVE_GLSL = `
vec3 displaceSea(vec2 p, float time, float storm) {
  vec3 q = vec3(p.x, 0., p.y);
  float scale = .74 + storm * 1.32;
  ${WAVES.map(
    (w) => `{
    vec2 d = vec2(${w.direction.map(gl).join(',')});
    float a = ${gl(w.amplitude)} * scale;
    float phase = ${gl(w.k)} * dot(d, p) - ${gl(w.omega)} * time + ${gl(w.phase)};
    q.y += a * sin(phase);
    q.xz += d * a * .28 * cos(phase);
  }`,
  ).join('\n')}
  return q;
}
float boatPressure(vec2 p, vec4 boat, float speed, float time) {
  vec2 offset = p - boat.xy;
  float side = dot(offset, vec2(cos(boat.z), sin(boat.z)));
  float fore = dot(offset, vec2(sin(boat.z), -cos(boat.z)));
  float bow = exp(-pow(fore - 4.1, 2.) * 1.4) * exp(-pow(abs(side) - 1.35, 2.) * 1.8);
  float behind = max(0., -fore - 2.8);
  float kelvin = exp(-pow(abs(side) - 1.25 - behind * .29, 2.) * .55) * exp(-behind / 27.) * step(fore, -2.8);
  return min(speed / 10., 1.3) * (bow * .3 + kelvin * sin(behind * .85 - time * 3.4) * .16);
}`;
