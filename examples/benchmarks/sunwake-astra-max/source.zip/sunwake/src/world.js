import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
  ISLANDS,
  seededRandom,
  surfaceHeight,
  waterHeight,
  clamp,
} from './sea.js';
import {
  oceanVertex,
  oceanFragment,
  skyVertex,
  skyFragment,
  particleVertex,
  particleFragment,
  wakeVertex,
  wakeFragment,
} from './shaders.js';

export function createWorld(scene) {
  const uniforms = {
    uTime: { value: 0 },
    uStorm: { value: 0.3 },
    uSpeed: { value: 0 },
    uSurfaceOffset: { value: 0 },
    uBoat: { value: new THREE.Vector4() },
    uSun: { value: new THREE.Vector3(0.09, 0.08, -1) },
    uDay: { value: 1 },
    uNight: { value: 0 },
    uWarm: { value: 1 },
    uNatural: { value: 0 },
  };
  // A dense central grid with progressively larger outer facets: one seamless
  // surface, no tiled mesh seams or texture assets, ~157k triangles at full detail.
  const count = 281,
    half = (count - 1) / 2;
  const positions = [],
    indices = [];
  const spread = (n) =>
    Math.sign(n) *
    (Math.abs(n) * 1.65 + Math.max(0, Math.abs(n) - 58) ** 2 * 0.25);
  for (let z = 0; z < count; z++)
    for (let x = 0; x < count; x++)
      positions.push(spread(x - half), 0, spread(z - half));
  for (let z = 0; z < count - 1; z++)
    for (let x = 0; x < count - 1; x++) {
      const a = z * count + x;
      if ((x + z) % 2)
        indices.push(a, a + count, a + 1, a + 1, a + count, a + count + 1);
      else indices.push(a, a + count, a + count + 1, a, a + count + 1, a + 1);
    }
  const oceanGeometry = new THREE.BufferGeometry();
  oceanGeometry.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(positions, 3),
  );
  oceanGeometry.setIndex(indices);
  const ocean = new THREE.Mesh(
    oceanGeometry,
    new THREE.ShaderMaterial({
      uniforms,
      vertexShader: oceanVertex,
      fragmentShader: oceanFragment,
      side: THREE.DoubleSide,
    }),
  );
  ocean.frustumCulled = false;
  scene.add(ocean);
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(3000, 32, 18),
    new THREE.ShaderMaterial({
      uniforms,
      vertexShader: skyVertex,
      fragmentShader: skyFragment,
      side: THREE.BackSide,
      depthWrite: false,
    }),
  );
  sky.frustumCulled = false;
  sky.renderOrder = -10;
  scene.add(sky);

  const ambient = new THREE.HemisphereLight(0xc3dfeb, 0x77553a, 2.1);
  const sun = new THREE.DirectionalLight(0xffc181, 3.2);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, {
    left: -20,
    right: 20,
    top: 20,
    bottom: -20,
    near: 1,
    far: 160,
  });
  sun.shadow.bias = -0.0006;
  sun.shadow.normalBias = 0.025;
  sun.shadow.camera.updateProjectionMatrix();
  scene.add(ambient, sun, sun.target);
  scene.fog = new THREE.FogExp2(0xaf8070, 0.0007);

  const cloudGeo = new THREE.IcosahedronGeometry(1, 1);
  const fairMaterial = new THREE.MeshStandardMaterial({
    color: 0xc9b3b8,
    roughness: 1,
    flatShading: true,
  });
  const stormMaterial = new THREE.MeshStandardMaterial({
    color: 0x555361,
    roughness: 1,
    flatShading: true,
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  const fairClouds = new THREE.InstancedMesh(cloudGeo, fairMaterial, 144);
  const stormClouds = new THREE.InstancedMesh(cloudGeo, stormMaterial, 42);
  const random = seededRandom(129),
    dummy = new THREE.Object3D();
  for (let i = 0; i < 144; i++) {
    const cluster = Math.floor(i / 6),
      angle = (cluster / 24) * Math.PI * 2 + 0.34;
    const radius = 720 + random() * 520;
    const spread = (random() - 0.5) * 130;
    dummy.position.set(
      Math.sin(angle) * radius + spread,
      100 + random() * 100 + Math.sin(angle * 3) * 15,
      Math.cos(angle) * radius,
    );
    dummy.scale.set(
      90 + random() * 100,
      16 + random() * 29,
      35 + random() * 70,
    );
    dummy.rotation.set(random() * 0.14, random(), random() * 0.14);
    dummy.updateMatrix();
    fairClouds.setMatrixAt(i, dummy.matrix);
  }
  for (let i = 0; i < 42; i++) {
    const a = (i / 42) * Math.PI * 2;
    dummy.position.set(
      Math.sin(a) * (350 + random() * 500),
      130 + random() * 110,
      Math.cos(a) * (350 + random() * 500),
    );
    dummy.scale.set(
      160 + random() * 200,
      30 + random() * 60,
      150 + random() * 180,
    );
    dummy.rotation.set(0.05, random(), 0.06);
    dummy.updateMatrix();
    stormClouds.setMatrixAt(i, dummy.matrix);
  }
  fairClouds.frustumCulled = stormClouds.frustumCulled = false;
  scene.add(fairClouds, stormClouds);

  const islandObjects = ISLANDS.map((island) => buildIsland(scene, island));
  const markerMaterial = new THREE.ShaderMaterial({
    uniforms: {
      ...uniforms,
      uRingAlpha: { value: 0.5 },
      uSurfaceOffset: { value: 0.12 },
    },
    vertexShader: oceanVertex,
    fragmentShader:
      'uniform float uRingAlpha; void main() { gl_FragColor = vec4(1.15, .73, .29, uRingAlpha); }',
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  const mooringRing = new THREE.Mesh(
    new THREE.TorusGeometry(25, 0.085, 3, 96),
    markerMaterial,
  );
  mooringRing.rotation.x = Math.PI / 2;
  scene.add(mooringRing);

  const gulls = [];
  const gullMaterial = new THREE.MeshBasicMaterial({
    color: 0xeee4c6,
    side: THREE.DoubleSide,
  });
  for (let i = 0; i < 9; i++) {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute(
      'position',
      new THREE.Float32BufferAttribute(
        [
          -1.8, 0, 0, 0, 0, -0.25, 0, 0.06, 0.27, 0, 0, -0.25, 1.8, 0, 0, 0,
          0.06, 0.27,
        ],
        3,
      ),
    );
    const mesh = new THREE.Mesh(geometry, gullMaterial);
    scene.add(mesh);
    gulls.push(mesh);
  }
  const warmColor = new THREE.Color(),
    daySky = new THREE.Color(0xb8d6e5),
    dawnSky = new THREE.Color(0xe7b5a0),
    nightSky = new THREE.Color(0x6687b9);
  const update = (boat, time, storm, light, natural, target, lit) => {
    uniforms.uTime.value = time;
    uniforms.uStorm.value = storm;
    uniforms.uSpeed.value = boat.speed;
    uniforms.uBoat.value.set(boat.x, boat.z, boat.heading, boat.y);
    uniforms.uSun.value.set(light.sun.x, light.sun.y, light.sun.z);
    uniforms.uDay.value = light.daylight;
    uniforms.uNight.value = light.night;
    uniforms.uWarm.value = light.warmth;
    uniforms.uNatural.value = natural;
    ocean.position.set(
      Math.round(boat.x / 12) * 12,
      0,
      Math.round(boat.z / 12) * 12,
    );
    sky.position.set(boat.x, 0, boat.z);
    fairClouds.position.set(boat.x + Math.sin(time * 0.002) * 45, 0, boat.z);
    stormClouds.position.set(boat.x, 0, boat.z);
    stormMaterial.opacity = clamp((storm - 0.32) * 1.5, 0, 0.93);
    stormClouds.visible = stormMaterial.opacity > 0.005;
    fairMaterial.color
      .copy(dawnSky)
      .lerp(daySky, 1 - light.warmth)
      .lerp(nightSky, light.night * 0.7);
    ambient.color
      .copy(daySky)
      .lerp(dawnSky, light.warmth * 0.3)
      .lerp(nightSky, light.night);
    ambient.intensity = 0.35 + light.daylight * 1.5;
    sun.color
      .set(light.night > 0.6 ? 0x8dbedb : 0xffd7a1)
      .lerp(new THREE.Color(0xffae62), light.warmth * 0.65);
    sun.intensity = (0.25 + light.daylight * 3.1) * (1 - storm * 0.31);
    const lightDirection = uniforms.uSun.value
      .clone()
      .multiplyScalar(light.night > 0.6 ? -1 : 1);
    lightDirection.y = Math.max(0.16, lightDirection.y);
    sun.position.set(
      boat.x + lightDirection.x * 65,
      lightDirection.y * 65 + 12,
      boat.z + lightDirection.z * 65,
    );
    sun.target.position.set(boat.x, 0, boat.z);
    warmColor
      .set(0x879ca4)
      .lerp(new THREE.Color(0xbb8a75), light.warmth * 0.7)
      .lerp(new THREE.Color(0x112538), light.night);
    scene.fog.color.copy(warmColor);
    scene.fog.density = 0.00052 + storm * 0.00055;
    mooringRing.visible = Boolean(target);
    if (target) {
      mooringRing.position.set(target.dock.x, 0.12, target.dock.z);
      markerMaterial.uniforms.uRingAlpha.value =
        0.47 + Math.sin(time * 1.5) * 0.13;
    }
    islandObjects.forEach((object, i) => {
      const isLit = lit.includes(i);
      object.lampMaterial.emissiveIntensity = isLit ? 5.2 : 0.7;
      object.beam.rotation.y = time * 0.23 + i * 2.1;
      object.beamMaterial.opacity = isLit
        ? 0.045 + light.night * 0.075
        : light.night * 0.02;
      object.buoy.position.y =
        waterHeight(ISLANDS[i].dock.x, ISLANDS[i].dock.z, time, storm) + 0.05;
      object.buoy.rotation.z = Math.sin(time * 0.9 + i) * 0.08;
      object.buoyLight.color.set(isLit ? 0xbde0b3 : 0xf4bf71);
    });
    gulls.forEach((gull, i) => {
      const a = time * 0.06 + i * 0.7;
      gull.position.set(
        125 + Math.cos(a) * (110 + i * 3),
        42 + i * 4 + Math.sin(a * 2) * 3,
        -325 + Math.sin(a) * 100,
      );
      gull.rotation.y = -a;
      const attr = gull.geometry.attributes.position;
      attr.setY(0, Math.sin(time * 3.2 + i) * 0.65);
      attr.setY(4, Math.sin(time * 3.2 + i) * 0.65);
      attr.needsUpdate = true;
      gull.visible = light.night < 0.65;
    });
  };
  return { uniforms, update, ocean, islandObjects };
}

function buildIsland(scene, island) {
  const random = seededRandom(island.seed),
    vertices = [],
    colors = [],
    indices = [];
  const radial = 28;
  const rings = [
    [0, island.height],
    [0.26, island.height * 0.82],
    [0.52, island.height * 0.5],
    [0.74, island.height * 0.16],
    [0.91, 1.0],
    [1.14, -2.2],
  ];
  const coast = Array.from({ length: radial }, () => 0.9 + random() * 0.19);
  const rock = new THREE.Color(0x607275),
    grass = new THREE.Color(0x506e59),
    sand = new THREE.Color(0xc1b28e),
    shade = new THREE.Color();
  rings.forEach(([r, y], ring) => {
    for (let i = 0; i < radial; i++) {
      const a = (i / radial) * Math.PI * 2;
      const radius = r * island.radius * coast[i];
      vertices.push(
        island.x + Math.cos(a) * radius,
        y + (ring === 0 ? 0 : (random() - 0.5) * Math.min(y * 0.25, 6)),
        island.z + Math.sin(a) * radius,
      );
      shade
        .copy(ring >= 4 ? sand : ring <= 2 ? rock : grass)
        .multiplyScalar(0.8 + random() * 0.29);
      colors.push(shade.r, shade.g, shade.b);
      if (ring < rings.length - 1) {
        const a0 = ring * radial + i,
          b = ring * radial + ((i + 1) % radial);
        indices.push(a0, a0 + radial, b, b, a0 + radial, b + radial);
      }
    }
  });
  const terrainGeo = new THREE.BufferGeometry();
  terrainGeo.setAttribute(
    'position',
    new THREE.Float32BufferAttribute(vertices, 3),
  );
  terrainGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrainGeo.setIndex(indices);
  terrainGeo.computeVertexNormals();
  const terrain = new THREE.Mesh(
    terrainGeo,
    new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.96,
      flatShading: true,
      side: THREE.DoubleSide,
    }),
  );
  scene.add(terrain);
  const stone = new THREE.MeshStandardMaterial({
    color: 0x788383,
    flatShading: true,
    roughness: 1,
  });
  const evergreens = new THREE.MeshStandardMaterial({
    color: 0x284f48,
    flatShading: true,
    roughness: 1,
  });
  for (let i = 0; i < 14; i++) {
    const a = random() * Math.PI * 2,
      r = island.radius * (0.43 + random() * 0.2);
    const tree = new THREE.Mesh(
      new THREE.ConeGeometry(2 + random() * 1.3, 9 + random() * 7, 5),
      evergreens,
    );
    tree.position.set(
      island.x + Math.cos(a) * r,
      island.height * (0.74 - (r / island.radius) * 0.68) + 4.5,
      island.z + Math.sin(a) * r,
    );
    scene.add(tree);
  }
  for (let i = 0; i < 14; i++) {
    const a = random() * Math.PI * 2,
      r = island.radius * (1.04 + random() * 0.16);
    const boulder = new THREE.Mesh(
      new THREE.IcosahedronGeometry(2 + random() * 4, 0),
      stone,
    );
    boulder.position.set(
      island.x + Math.cos(a) * r,
      -0.3,
      island.z + Math.sin(a) * r,
    );
    boulder.scale.y = 0.8 + random();
    scene.add(boulder);
  }
  const tower = new THREE.Group();
  tower.position.set(island.beacon.x, island.height - 0.3, island.beacon.z);
  const ivory = new THREE.MeshStandardMaterial({
    color: 0xe7debf,
    roughness: 0.76,
    flatShading: true,
  });
  const navy = new THREE.MeshStandardMaterial({
    color: 0x193640,
    roughness: 0.6,
    flatShading: true,
  });
  const copper = new THREE.MeshStandardMaterial({
    color: 0x996547,
    roughness: 0.6,
    metalness: 0.3,
    flatShading: true,
  });
  for (let i = 0; i < 5; i++) {
    const tier = new THREE.Mesh(
      new THREE.CylinderGeometry(3.75 - i * 0.22, 4 - i * 0.22, 5, 12),
      i === 2 ? navy : ivory,
    );
    tier.position.y = i * 5 + 2.5;
    tower.add(tier);
  }
  const base = new THREE.Mesh(
    new THREE.CylinderGeometry(5.2, 5.7, 1.4, 12),
    stone,
  );
  base.position.y = 0.6;
  tower.add(base);
  const balcony = new THREE.Mesh(
    new THREE.CylinderGeometry(4.4, 4.4, 0.6, 12),
    navy,
  );
  balcony.position.y = 25;
  tower.add(balcony);
  const door = new THREE.Mesh(new THREE.BoxGeometry(1.45, 3.2, 0.17), navy);
  door.position.set(0, 1.8, 3.91);
  tower.add(door);
  for (let y = 7; y < 23; y += 7) {
    const window = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.4, 0.12), navy);
    window.position.set(0, y, 3.62 - y * 0.04);
    tower.add(window);
  }
  const lampMaterial = new THREE.MeshStandardMaterial({
    color: 0xffd293,
    emissive: 0xffa648,
    emissiveIntensity: 0.7,
    roughness: 0.3,
  });
  const lantern = new THREE.Mesh(
    new THREE.CylinderGeometry(2.4, 2.4, 3.4, 8),
    lampMaterial,
  );
  lantern.position.y = 27;
  tower.add(lantern);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    const bar = new THREE.Mesh(
      new THREE.CylinderGeometry(0.07, 0.07, 3.8, 5),
      navy,
    );
    bar.position.set(Math.cos(a) * 2.58, 27, Math.sin(a) * 2.58);
    tower.add(bar);
    const rail = new THREE.Mesh(
      new THREE.CylinderGeometry(0.07, 0.07, 1.5, 5),
      navy,
    );
    rail.position.set(Math.cos(a) * 4.06, 25.9, Math.sin(a) * 4.06);
    tower.add(rail);
  }
  const handrail = new THREE.Mesh(
    new THREE.TorusGeometry(4.06, 0.09, 4, 24),
    navy,
  );
  handrail.rotation.x = Math.PI / 2;
  handrail.position.y = 26.6;
  tower.add(handrail);
  const roof = new THREE.Mesh(new THREE.ConeGeometry(3.6, 3.6, 12), copper);
  roof.position.y = 30.5;
  tower.add(roof);
  const finial = new THREE.Mesh(
    new THREE.SphereGeometry(0.27, 8, 6),
    lampMaterial,
  );
  finial.position.y = 32.5;
  tower.add(finial);
  scene.add(tower);
  const beam = new THREE.Group();
  beam.position.copy(tower.position);
  beam.position.y += 27;
  const beamGeo = new THREE.ConeGeometry(24, 260, 24, 1, true);
  beamGeo.translate(0, -130, 0);
  beamGeo.rotateZ(Math.PI / 2);
  const beamMaterial = new THREE.MeshBasicMaterial({
    color: 0xffd6a0,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const lightBeam = new THREE.Mesh(beamGeo, beamMaterial),
    opposite = lightBeam.clone();
  opposite.rotation.y = Math.PI;
  beam.add(lightBeam, opposite);
  scene.add(beam);
  const buoy = new THREE.Group();
  buoy.position.set(island.dock.x, 0, island.dock.z);
  const buoyBody = new THREE.Mesh(
    new THREE.CylinderGeometry(0.35, 0.7, 1.4, 8),
    copper,
  );
  buoyBody.position.y = 0.4;
  buoy.add(buoyBody);
  const buoyCap = new THREE.Mesh(
    new THREE.CylinderGeometry(0.16, 0.28, 1.15, 8),
    ivory,
  );
  buoyCap.position.y = 1.55;
  buoy.add(buoyCap);
  const buoyLight = new THREE.MeshBasicMaterial({ color: 0xf4bf71 });
  const buoyLamp = new THREE.Mesh(
    new THREE.SphereGeometry(0.24, 8, 6),
    buoyLight,
  );
  buoyLamp.position.y = 2.2;
  buoy.add(buoyLamp);
  scene.add(buoy);
  return { terrain, tower, beam, beamMaterial, lampMaterial, buoy, buoyLight };
}

export async function loadVessel(scene, uniforms) {
  const gltf = await new GLTFLoader().loadAsync(
    `${import.meta.env.BASE_URL}assets/sunwake-vessel.glb`,
  );
  const vessel = new THREE.Group();
  vessel.name = 'Sunwake';
  vessel.rotation.order = 'YXZ';
  vessel.add(gltf.scene);
  scene.add(vessel);
  const materials = new Set();
  gltf.scene.traverse((object) => {
    if (!object.isMesh) return;
    object.castShadow = true;
    object.receiveShadow = true;
    const list = Array.isArray(object.material)
      ? object.material
      : [object.material];
    list.forEach((material) => {
      materials.add(material);
      material.userData.originalColor = material.color.clone();
      material.userData.originalRoughness = material.roughness;
      material.side = THREE.DoubleSide;
      material.flatShading = true;
      if (/canvas|Hemp/.test(material.name)) {
        // Wind deforms high canvas/ropes; deck-level mooring coils remain still.
        material.onBeforeCompile = (shader) => {
          shader.uniforms.uSeaTime = uniforms.uTime;
          shader.uniforms.uSeaSpeed = uniforms.uSpeed;
          shader.vertexShader =
            'uniform float uSeaTime, uSeaSpeed;\n' + shader.vertexShader;
          shader.vertexShader = shader.vertexShader.replace(
            '#include <begin_vertex>',
            `#include <begin_vertex>
            float clothWeight = smoothstep(1.5, 4.7, position.y) * smoothstep(.02, 1.5, abs(position.x));
            transformed.z += sin(position.y * 3.1 + uSeaTime * 3.5) * clothWeight * (.026 + uSeaSpeed * .003);
            transformed.z += sin(position.x * 4.8 - uSeaTime * 2.6) * clothWeight * .045;`,
          );
        };
        material.customProgramCacheKey = () => 'sunwake-cloth-v1';
      }
    });
  });
  const wheel = gltf.scene.getObjectByName('Wheel'),
    rudder = gltf.scene.getObjectByName('Rudder'),
    propeller = gltf.scene.getObjectByName('Propeller'),
    pennant = gltf.scene.getObjectByName('Pennant');
  const naturalColor = new THREE.Color();
  let lastNatural = -1;
  const update = (boat, time, natural) => {
    vessel.position.set(boat.x, boat.y, boat.z);
    // Local -Z is forward, hence positive heading is a negative Y rotation.
    vessel.rotation.set(boat.pitch, -boat.heading, boat.roll, 'YXZ');
    if (wheel) wheel.rotation.z = -boat.rudder * 1.7;
    if (rudder) rudder.rotation.y = -boat.rudder * 0.48;
    if (propeller) propeller.rotation.y = -time * boat.speed * 4;
    if (pennant)
      pennant.rotation.y =
        Math.sin(time * 3.8) * 0.08 + Math.sin(time * 2.1) * 0.04;
    if (natural !== lastNatural) {
      materials.forEach((material) => {
        naturalColor.copy(material.userData.originalColor);
        if (!natural && /Cedar|teak/.test(material.name))
          naturalColor.offsetHSL(0.008, 0.055, 0.015);
        material.color.copy(naturalColor);
        material.roughness = natural
          ? Math.max(0.22, material.userData.originalRoughness - 0.09)
          : Math.max(0.47, material.userData.originalRoughness);
      });
      lastNatural = natural;
    }
  };
  return { root: vessel, update };
}

export function createSeaEffects(scene, uniforms) {
  const capacity = 1800;
  const positions = new Float32Array(capacity * 3),
    life = new Float32Array(capacity),
    sizes = new Float32Array(capacity);
  const velocities = new Float32Array(capacity * 3),
    age = new Float32Array(capacity),
    lifespan = new Float32Array(capacity);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute(
    'position',
    new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage),
  );
  geometry.setAttribute(
    'aLife',
    new THREE.BufferAttribute(life, 1).setUsage(THREE.DynamicDrawUsage),
  );
  geometry.setAttribute(
    'aSize',
    new THREE.BufferAttribute(sizes, 1).setUsage(THREE.DynamicDrawUsage),
  );
  const particles = new THREE.Points(
    geometry,
    new THREE.ShaderMaterial({
      uniforms,
      vertexShader: particleVertex,
      fragmentShader: particleFragment,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    }),
  );
  particles.frustumCulled = false;
  scene.add(particles);
  const trail = [],
    maxTrail = 110,
    stripCount = 3;
  const wakePosition = new Float32Array(maxTrail * stripCount * 2 * 3),
    wakeAlpha = new Float32Array(maxTrail * stripCount * 2),
    indices = [];
  for (let strip = 0; strip < stripCount; strip++)
    for (let i = 0; i < maxTrail - 1; i++) {
      const a = (strip * maxTrail + i) * 2;
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
  const wakeGeometry = new THREE.BufferGeometry();
  wakeGeometry.setAttribute(
    'position',
    new THREE.BufferAttribute(wakePosition, 3).setUsage(THREE.DynamicDrawUsage),
  );
  wakeGeometry.setAttribute(
    'aAlpha',
    new THREE.BufferAttribute(wakeAlpha, 1).setUsage(THREE.DynamicDrawUsage),
  );
  wakeGeometry.setIndex(indices);
  const wake = new THREE.Mesh(
    wakeGeometry,
    new THREE.ShaderMaterial({
      uniforms,
      vertexShader: wakeVertex,
      fragmentShader: wakeFragment,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
  );
  wake.frustumCulled = false;
  wake.renderOrder = 1;
  scene.add(wake);
  let cursor = 0,
    emission = 0,
    trailClock = 0;
  const random = seededRandom(623);
  const rainCount = 520,
    rainPositions = new Float32Array(rainCount * 6);
  const rainSeeds = Array.from({ length: rainCount }, () => [
    random() * 110 - 55,
    random() * 40,
    random() * 110 - 55,
  ]);
  const rainGeometry = new THREE.BufferGeometry();
  rainGeometry.setAttribute(
    'position',
    new THREE.BufferAttribute(rainPositions, 3).setUsage(
      THREE.DynamicDrawUsage,
    ),
  );
  const rainMaterial = new THREE.LineBasicMaterial({
    color: 0x97c3cf,
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  const rain = new THREE.LineSegments(rainGeometry, rainMaterial);
  rain.frustumCulled = false;
  scene.add(rain);
  const emit = (boat, time, storm, sign) => {
    const i = cursor++ % capacity,
      k = i * 3;
    const fore = 2.6 + random() * 1.0,
      side = (1.0 + random() * 0.35) * sign;
    positions[k] =
      boat.x + Math.sin(boat.heading) * fore + Math.cos(boat.heading) * side;
    positions[k + 2] =
      boat.z - Math.cos(boat.heading) * fore + Math.sin(boat.heading) * side;
    positions[k + 1] =
      surfaceHeight(positions[k], positions[k + 2], time, storm, boat) + 0.08;
    const outward = (1.1 + random() * 2.4) * sign;
    velocities[k] =
      Math.sin(boat.heading) * boat.speed * 0.52 +
      Math.cos(boat.heading) * outward;
    velocities[k + 2] =
      -Math.cos(boat.heading) * boat.speed * 0.52 +
      Math.sin(boat.heading) * outward;
    velocities[k + 1] =
      1.1 + random() * (1.8 + boat.speed * 0.2) + Math.max(0, boat.vy) * 0.45;
    lifespan[i] = 0.7 + random() * 1.4;
    age[i] = 0;
    life[i] = 1;
    sizes[i] = 0.18 + random() * 0.43;
  };
  const update = (boat, time, dt, storm, balanced = false) => {
    const s = Math.sin(boat.heading),
      c = Math.cos(boat.heading);
    emission +=
      Math.max(0, boat.speed - 0.5) *
      (19 + boat.impact * 9) *
      dt *
      (balanced ? 0.45 : 1);
    while (emission >= 1) {
      emit(boat, time, storm, cursor % 2 ? 1 : -1);
      emission--;
    }
    for (let i = 0; i < capacity; i++) {
      if (life[i] <= 0) continue;
      const k = i * 3;
      age[i] += dt;
      life[i] = Math.max(0, 1 - age[i] / lifespan[i]);
      positions[k] += velocities[k] * dt;
      positions[k + 2] += velocities[k + 2] * dt;
      velocities[k + 1] -= 9.81 * dt;
      positions[k + 1] += velocities[k + 1] * dt;
      if (velocities[k + 1] < 0) {
        const water =
          surfaceHeight(positions[k], positions[k + 2], time, storm, boat) +
          0.04;
        if (positions[k + 1] < water) {
          positions[k + 1] = water;
          velocities[k] *= 0.97;
          velocities[k + 2] *= 0.97;
          velocities[k + 1] = 0;
          life[i] *= 0.6;
        }
      }
    }
    geometry.attributes.position.needsUpdate =
      geometry.attributes.aLife.needsUpdate =
      geometry.attributes.aSize.needsUpdate =
        true;
    trailClock += dt;
    if (trailClock > 0.09 && boat.speed > 0.6) {
      trailClock = 0;
      trail.unshift({
        x: boat.x - s * 3.65,
        z: boat.z + c * 3.65,
        heading: boat.heading,
        time,
        strength: Math.min(1, boat.speed / 7),
      });
      if (trail.length > maxTrail) trail.pop();
    }
    while (trail.length && time - trail.at(-1).time > 10) trail.pop();
    wakeAlpha.fill(0);
    for (let strip = 0; strip < stripCount; strip++)
      for (let i = 0; i < trail.length; i++) {
        const p = trail[i],
          age = time - p.time;
        const side = strip - 1;
        const center = side * (1.18 + age * 1.03);
        const width = side === 0 ? 0.45 + age * 0.37 : 0.24 + age * 0.21;
        for (let edge = 0; edge < 2; edge++) {
          const n = (strip * maxTrail + i) * 2 + edge,
            j = n * 3;
          const offset =
            center +
            (edge - 0.5) * width * 2 +
            Math.sin(age * 2 + i * 1.7) * 0.12;
          const x = p.x + Math.cos(p.heading) * offset,
            z = p.z + Math.sin(p.heading) * offset;
          wakePosition[j] = x;
          wakePosition[j + 2] = z;
          wakePosition[j + 1] = surfaceHeight(x, z, time, storm, boat) + 0.065;
          wakeAlpha[n] =
            Math.max(0, 1 - age / 10) ** 1.5 *
            p.strength *
            (side === 0 ? 0.32 : 0.73) *
            (i === trail.length - 1 ? 0 : 1);
        }
      }
    wakeGeometry.attributes.position.needsUpdate =
      wakeGeometry.attributes.aAlpha.needsUpdate = true;
    rainMaterial.opacity = Math.max(0, storm - 0.52) * 0.27;
    rain.visible = rainMaterial.opacity > 0.003;
    if (rain.visible) {
      for (let i = 0; i < rainCount; i++) {
        const seed = rainSeeds[i],
          j = i * 6;
        const y = (((seed[1] - time * 27) % 40) + 40) % 40;
        const x = boat.x + seed[0] + y * 0.16,
          z = boat.z + seed[2];
        rainPositions.set([x, y, z, x - 0.34, y - 1.65, z + 0.15], j);
      }
      rainGeometry.attributes.position.needsUpdate = true;
    }
  };
  const clear = () => {
    trail.length = 0;
    life.fill(0);
    wakeAlpha.fill(0);
    emission = 0;
  };
  return { update, clear };
}
