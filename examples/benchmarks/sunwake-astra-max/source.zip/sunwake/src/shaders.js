import { WAVE_GLSL } from './sea.js';

export const oceanVertex = `
uniform float uTime, uStorm, uSpeed, uSurfaceOffset;
uniform vec4 uBoat;
varying vec3 vWorld;
varying float vHeight;
${WAVE_GLSL}
void main() {
  vec3 anchor = (modelMatrix * vec4(position, 1.)).xyz;
  vec3 p = displaceSea(anchor.xz, uTime, uStorm);
  p.y += boatPressure(p.xz, uBoat, uSpeed, uTime) + uSurfaceOffset;
  vWorld = p;
  vHeight = p.y;
  gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.);
}`;

export const oceanFragment = `
uniform float uTime, uStorm, uDay, uNight, uWarm, uNatural;
uniform vec3 uSun;
varying vec3 vWorld;
varying float vHeight;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
  vec3 N = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  if (N.y < 0.) N = -N;
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 L = normalize(uSun);
  vec3 R = reflect(-V, N);
  float fresnel = .04 + .96 * pow(1. - max(dot(N, V), 0.), 4.);
  float faceLight = clamp(dot(N, normalize(vec3(-.45, .72, -.4))) * .5 + .5, 0., 1.);
  vec3 deep = mix(vec3(.006, .027, .105), vec3(.011, .074, .11), uNatural);
  vec3 shallow = mix(vec3(.008, .26, .45), vec3(.035, .28, .32), uNatural);
  float crest = smoothstep(-1.5, 2.8, vHeight) * .25;
  vec3 color = mix(deep, shallow, pow(faceLight, 2.9) * .83 + crest);
  color *= .20 + .88 * uDay;
  float rh = clamp(R.y * .85, 0., 1.);
  vec3 horizon = mix(vec3(.25, .42, .55), vec3(.95, .38, .13), uWarm * .78);
  vec3 skyReflect = mix(horizon, vec3(.08, .22, .38), pow(rh, .4));
  skyReflect = mix(skyReflect, vec3(.019, .038, .077), uNight);
  color = mix(color, skyReflect, fresnel * mix(.45, .70, uNatural));
  vec3 H = normalize(L + V);
  float specular = pow(max(dot(N, H), 0.), mix(82., 165., uNatural));
  float broad = pow(max(dot(N, H), 0.), 15.);
  float path = pow(max(dot(normalize(vWorld.xz - cameraPosition.xz), normalize(uSun.xz)), 0.), 28.);
  float sunVisible = smoothstep(-.07, .04, uSun.y);
  vec3 sunlight = mix(vec3(1.1, .93, .70), vec3(1.65, .52, .095), uWarm);
  color += sunlight * (specular * 3.7 + broad * .29 + path * fresnel * .27) * sunVisible * (1. - uStorm * .34);
  // Facet-sized glints ride the same crests, keeping the triangular silhouette.
  float slope = 1. - N.y;
  float cap = smoothstep(1.1, 2.3 + uStorm, vHeight) * smoothstep(.025, .15, slope);
  float flecks = smoothstep(.88, 1., sin(vWorld.x * 3.7 + uTime) * sin(vWorld.z * 4.2 - uTime * .6));
  vec3 foam = mix(vec3(.16, .63, .84), vec3(.66, .84, .85), uNatural);
  color += foam * cap * (.17 + flecks * .8) * (.2 + .8 * uDay);
  vec3 moon = -L;
  float moonshine = pow(max(dot(N, normalize(moon + V)), 0.), 110.);
  color += vec3(.25, .48, .69) * moonshine * 1.4 * uNight;
  float distance = length(vWorld.xz - cameraPosition.xz);
  float fog = 1. - exp(-distance * mix(.00056, .0011, uStorm));
  vec3 fogColor = mix(vec3(.18, .34, .46), vec3(.63, .36, .26), uWarm * .66);
  fogColor = mix(fogColor, vec3(.019, .035, .07), uNight);
  color = mix(color, fogColor, fog * .86);
  gl_FragColor = vec4(color, 1.);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

export const skyVertex = `
varying vec3 vWorld;
void main() {
  vWorld = (modelMatrix * vec4(position, 1.)).xyz;
  gl_Position = projectionMatrix * viewMatrix * vec4(vWorld, 1.);
}`;

export const skyFragment = `
uniform float uTime, uStorm, uDay, uNight, uWarm;
uniform vec3 uSun;
varying vec3 vWorld;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise2(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1., 0.)), f.x), mix(hash(i + vec2(0., 1.)), hash(i + vec2(1.)), f.x), f.y);
}
float fbm(vec2 p) { return noise2(p) * .57 + noise2(p * 2.03) * .28 + noise2(p * 4.07) * .15; }
void main() {
  vec3 ray = normalize(vWorld - cameraPosition);
  float h = max(ray.y, 0.);
  vec3 horizon = mix(vec3(.52, .71, .77), vec3(1.0, .48, .24), uWarm);
  vec3 zenith = mix(vec3(.13, .36, .56), vec3(.24, .22, .37), uWarm * .9);
  vec3 color = mix(horizon, zenith, pow(h, .48));
  color = mix(color, mix(vec3(.027, .048, .095), vec3(.004, .011, .034), pow(h, .5)), uNight);
  float dotSun = dot(ray, normalize(uSun));
  float halo = pow(max(dotSun, 0.), 23.);
  float glow = pow(max(dotSun, 0.), 150.);
  float disc = smoothstep(cos(.0215), cos(.018), dotSun);
  float sunVisible = smoothstep(-.045, .005, ray.y);
  color += (vec3(1.0, .31, .055) * halo * .65 + vec3(1., .53, .13) * glow * .9 + vec3(3.1, 2.3, 1.05) * disc) * sunVisible;
  // Distant haze bridges the geometric sea horizon without a hard seam.
  color = mix(color, mix(vec3(.15, .25, .35), vec3(.57, .32, .23), uWarm), (1. - smoothstep(-.10, .0, ray.y)) * uDay);
  vec2 cloudUV = ray.xz / max(.10, ray.y + .23) * 1.2 + vec2(uTime * .003, 0.);
  float cloud = smoothstep(.40, .66, fbm(cloudUV)) * smoothstep(-.015, .16, ray.y);
  vec3 cloudColor = mix(vec3(.13, .16, .24), vec3(.27, .22, .27), uWarm);
  cloudColor += vec3(.61, .27, .13) * pow(max(dotSun, 0.), 9.) * uWarm;
  color = mix(color, cloudColor * (.2 + .8 * uDay), cloud * max(0., uStorm - .23) * .94);
  vec2 starUV = vec2(atan(ray.z, ray.x) / 6.283185, asin(ray.y) / 3.14159) * vec2(580., 290.);
  vec2 cell = floor(starUV), f = fract(starUV) - .5;
  float seed = hash(cell);
  float star = (1. - smoothstep(.015, .13, length(f))) * step(.988, seed);
  star *= .6 + .4 * sin(uTime * 1.1 + seed * 100.);
  color += vec3(.73, .87, 1.) * star * uNight * smoothstep(.02, .21, h) * (1. - cloud * uStorm);
  float moonDisc = smoothstep(cos(.015), cos(.0125), dot(ray, -normalize(uSun)));
  color += vec3(.54, .72, .88) * moonDisc * uNight;
  // Procedural aurora curtains in angular sky coordinates.
  float azimuth = atan(ray.x, -ray.z);
  float curtain = h - .26 - sin(azimuth * 3.1 + uTime * .035) * .055 - sin(azimuth * 7.2 - uTime * .017) * .025;
  float ribbon = exp(-abs(curtain) * 22.) * smoothstep(.09, .18, h);
  float strands = .48 + .52 * pow(noise2(vec2(azimuth * 75. + uTime * .08, h * 3.)), 2.);
  vec3 aurora = mix(vec3(.09, .83, .55), vec3(.43, .14, .78), smoothstep(-.025, .10, curtain));
  color += aurora * ribbon * strands * uNight * .53 * (1. - cloud * uStorm * .8);
  gl_FragColor = vec4(color, 1.);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

export const particleVertex = `
attribute float aLife, aSize;
varying float vLife;
void main() {
  vLife = aLife;
  vec4 mv = modelViewMatrix * vec4(position, 1.);
  gl_PointSize = clamp(aSize * 180. / max(1., -mv.z), 1., 9.);
  gl_Position = projectionMatrix * mv;
}`;
export const particleFragment = `
uniform float uDay, uWarm;
varying float vLife;
void main() {
  float d = length(gl_PointCoord - .5) * 2.;
  if (d > 1. || vLife <= 0.) discard;
  vec3 color = mix(vec3(.11, .67, 1.1), vec3(1.35, .94, .46), uWarm * .32);
  color = mix(color, vec3(1.45), pow(1. - d, 4.));
  gl_FragColor = vec4(color * (.3 + uDay), (1. - d * d) * vLife);
}`;

export const wakeVertex = `
attribute float aAlpha;
varying float vAlpha;
varying vec3 vWorld;
void main() {
  vAlpha = aAlpha;
  vWorld = position;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.);
}`;
export const wakeFragment = `
uniform float uTime, uDay, uWarm;
varying float vAlpha;
varying vec3 vWorld;
void main() {
  float grain = sin(vWorld.x * 11. + sin(vWorld.z * 5. + uTime)) * sin(vWorld.z * 9. - uTime * 2.);
  float foam = .4 + smoothstep(-.4, .8, grain) * .6;
  vec3 color = mix(vec3(.29, .77, .98), vec3(1., .87, .62), uWarm * .45);
  gl_FragColor = vec4(color * (.3 + uDay * .9), vAlpha * foam);
}`;

export const lensShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uWet: { value: 0 },
    uStorm: { value: 0.3 },
    uAspect: { value: 1 },
    uGrain: { value: 0.003 },
  },
  vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }`,
  fragmentShader: `
  uniform sampler2D tDiffuse;
  uniform float uTime, uWet, uStorm, uAspect, uGrain;
  varying vec2 vUv;
  float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
  void main() {
    vec2 uv = vUv, distortion = vec2(0.);
    float rim = 0.;
    for (int i = 0; i < 3; i++) {
      float scale = 7. + float(i) * 5.;
      vec2 grid = uv * vec2(scale * uAspect, scale);
      vec2 cell = floor(grid), local = fract(grid);
      float seed = hash(cell + float(i) * 34.);
      float age = fract(uTime * (.035 + seed * .018) + seed);
      vec2 center = vec2(.2 + seed * .55, .25 + hash(cell + 17.) * .5 - age * age * .3);
      vec2 delta = local - center;
      delta.y *= 1.0 - age * .26;
      float radius = .055 + seed * .082;
      float d = length(delta) / radius;
      float edges = smoothstep(.14, .4, abs(uv.x - .5)) + smoothstep(.26, .45, abs(uv.y - .5));
      float enabled = step(seed, uWet * .26 + uStorm * .055) * min(1., edges + uStorm * .22);
      float mask = (1. - smoothstep(.75, 1., d)) * enabled * sin(age * 3.14159);
      distortion += delta * mask * .027;
      rim += exp(-pow((d - .85) * 12., 2.)) * enabled * .065 * max(0., delta.y / radius + .25);
    }
    vec3 color = texture2D(tDiffuse, clamp(uv + distortion, vec2(.001), vec2(.999))).rgb;
    color += rim * vec3(.56, .77, 1.);
    float vignette = 1. - .20 * pow(length((uv - .5) * vec2(1., .85)) * 1.25, 1.8);
    color *= vignette;
    color += (hash(uv * 2000. + fract(uTime)) - .5) * uGrain;
    gl_FragColor = vec4(color, 1.);
  }`,
};
