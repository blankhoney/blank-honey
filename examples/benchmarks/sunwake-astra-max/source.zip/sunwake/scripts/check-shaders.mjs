// Optional native GLSL check. No browser, graphics window or server is opened.
// Usage: node scripts/check-shaders.mjs /path/to/glslangValidator /scratch/path
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { ShaderChunk } from 'three';
import * as shaders from '../src/shaders.js';

const [validator, scratch] = process.argv.slice(2);
if (!validator || !scratch)
  throw new Error(
    'Provide a glslangValidator executable and a scratch directory.',
  );
fs.mkdirSync(scratch, { recursive: true });
const expand = (source) =>
  source.replace(/#include <([\w_]+)>/g, (_, name) => {
    if (!(name in ShaderChunk))
      throw new Error(`Unknown Three.js shader chunk: ${name}`);
    return expand(ShaderChunk[name]);
  });
const vertexPrefix = `#version 300 es
precision highp float;
precision highp int;
#define attribute in
#define varying out
uniform mat4 modelMatrix, modelViewMatrix, projectionMatrix, viewMatrix;
uniform vec3 cameraPosition;
in vec3 position;
in vec3 normal;
in vec2 uv;
`;
const fragmentPrefix = `#version 300 es
precision highp float;
precision highp int;
#define varying in
#define texture2D texture
out highp vec4 pc_fragColor;
#define gl_FragColor pc_fragColor
uniform vec3 cameraPosition;
vec4 linearToOutputTexel(vec4 value) { return value; }
`;
const pairs = [
  ['ocean', shaders.oceanVertex, shaders.oceanFragment],
  ['sky', shaders.skyVertex, shaders.skyFragment],
  ['spray', shaders.particleVertex, shaders.particleFragment],
  ['wake', shaders.wakeVertex, shaders.wakeFragment],
  ['lens', shaders.lensShader.vertexShader, shaders.lensShader.fragmentShader],
  [
    'mooring-ring',
    shaders.oceanVertex,
    'uniform float uRingAlpha; void main() { gl_FragColor = vec4(1.15, .73, .29, uRingAlpha); }',
  ],
];
for (const [name, vertex, fragment] of pairs) {
  const vert = path.join(scratch, `${name}.vert`),
    frag = path.join(scratch, `${name}.frag`);
  fs.writeFileSync(vert, vertexPrefix + expand(vertex));
  fs.writeFileSync(frag, fragmentPrefix + expand(fragment));
  try {
    execFileSync(validator, ['-l', vert, frag], { stdio: 'pipe' });
  } catch (error) {
    console.error(error.stdout?.toString(), error.stderr?.toString());
    throw new Error(`GLSL compilation/link failed: ${name}`);
  }
  console.log(`PASS GLSL ES 3.00 compile/link: ${name}`);
}
console.log(
  'Native shader validation passed. This is not browser or GPU acceptance.',
);
