import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
  WAVES,
  displacedPoint,
  waterHeight,
  surfaceHeight,
  hullPose,
  createBoat,
  stepBoat,
  canLight,
  celestial,
  ISLANDS,
  WAVE_GLSL,
} from '../src/sea.js';
import { createWorld, createSeaEffects } from '../src/world.js';

const root = fileURLToPath(new URL('..', import.meta.url));
process.chdir(root);
let checks = 0;
const check = (name, fn) => {
  fn();
  checks++;
  console.log(`PASS ${name}`);
};

check('Readable source JavaScript parses', () => {
  for (const name of fs
    .readdirSync('src')
    .filter((name) => name.endsWith('.js')))
    execFileSync(process.execPath, ['--check', `src/${name}`]);
  execFileSync(process.execPath, ['--check', 'vite.config.js']);
});

check('Every static UI binding points to a unique HTML element', () => {
  const html = fs.readFileSync('index.html', 'utf8'),
    js = fs.readFileSync('src/main.js', 'utf8');
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
  assert.equal(ids.length, new Set(ids).size, 'Duplicate HTML IDs');
  for (const match of js.matchAll(/\$\('([^']+)'\)/g))
    assert(ids.includes(match[1]), `Missing #${match[1]}`);
  assert(
    html.includes('data-water="0" class="active"'),
    'Illustrated must be the default',
  );
  assert(
    !html.includes('https://'),
    'Runtime HTML must not depend on remote resources',
  );
});

let worstInverse = 0;
check(
  'CPU buoyancy inverts the exact horizontally displaced GPU wave field',
  () => {
    for (const storm of [0, 0.3, 1])
      for (const t of [0, 17.4, 143.8, 301])
        for (let i = 0; i < 70; i++) {
          const p = displacedPoint(
            i * 7.135 - 240,
            Math.sin(i) * 250,
            t,
            storm,
          );
          const error = Math.abs(waterHeight(p.x, p.z, t, storm) - p.y);
          worstInverse = Math.max(worstInverse, error);
          assert(error < 0.002, `Wave mismatch ${error}m`);
        }
    for (const wave of WAVES)
      assert(
        WAVE_GLSL.includes(wave.amplitude.toFixed(8)),
        'Shader wave definitions must be generated from CPU constants',
      );
  },
);

const heaveStats = [];
check(
  'Five-minute resting buoyancy remains stable in both calm and high seas',
  () => {
    for (const storm of [0, 0.3, 1]) {
      const b = createBoat(),
        initial = hullPose(b, 0, storm);
      Object.assign(b, {
        y: initial.y,
        pitch: initial.pitch,
        roll: initial.roll,
      });
      let sum = 0,
        worst = 0,
        samples = 0,
        minFreeboard = Infinity;
      for (let tick = 1; tick <= 36000; tick++) {
        const time = tick / 120;
        stepBoat(
          b,
          { power: 0, turn: 0, brake: false, boost: false },
          1 / 120,
          time,
          storm,
        );
        const pose = hullPose(b, time, storm),
          error = Math.abs(b.y - pose.y);
        assert(
          Number.isFinite(b.y) &&
            Math.abs(b.roll) < 0.6 &&
            Math.abs(b.pitch) < 0.6,
        );
        if (tick > 240) {
          sum += error ** 2;
          worst = Math.max(worst, error);
          samples++;
        }
        // At the broad midship gunwale, even a lagging heave spring retains freeboard.
        const starboardHeight = b.y + 1.08 + Math.sin(b.roll) * 1.35;
        const sea = waterHeight(b.x + 1.35, b.z, time, storm);
        minFreeboard = Math.min(minFreeboard, starboardHeight - sea);
      }
      const rms = Math.sqrt(sum / samples);
      assert(
        rms < 0.5 && worst < 1.15,
        `Unstable heave: RMS ${rms}, max ${worst}`,
      );
      assert(
        minFreeboard > 0.05,
        `Midship deck awash at rest: ${minFreeboard}`,
      );
      assert.equal(b.speed, 0);
      assert.equal(b.distance, 0);
      heaveStats.push({
        storm,
        rmsMetres: Number(rms.toFixed(4)),
        maxErrorMetres: Number(worst.toFixed(4)),
        minFreeboardMetres: Number(minFreeboard.toFixed(4)),
      });
    }
  },
);

check(
  'Power, steering, braking, boundaries and recovery datum remain finite',
  () => {
    const b = createBoat();
    b.y = hullPose(b, 0, 0.5).y;
    for (let i = 0; i < 1800; i++)
      stepBoat(
        b,
        { power: 1, turn: 0, brake: false, boost: false },
        1 / 120,
        i / 120,
        0.5,
      );
    assert(b.speed > 8 && b.throttle === 1 && b.z < -50);
    const heading = b.heading;
    for (let i = 0; i < 1200; i++)
      stepBoat(
        b,
        { power: 0, turn: 1, brake: false, boost: true },
        1 / 120,
        15 + i / 120,
        1,
      );
    assert(b.heading > heading + 1 && b.speed > 10);
    for (let i = 0; i < 720; i++)
      stepBoat(
        b,
        { power: 0, turn: 0, brake: true, boost: false },
        1 / 120,
        25 + i / 120,
        1,
      );
    assert(b.speed < 2);
    const boundary = {
      ...createBoat(),
      x: 2399.9,
      heading: Math.PI / 2,
      speed: 15,
      throttle: 1,
    };
    stepBoat(
      boundary,
      { power: 0, turn: 0, brake: false, boost: true },
      1 / 120,
      0,
      0.3,
    );
    assert(boundary.x <= 2400);
    for (const value of Object.values(b)) assert(Number.isFinite(value));
  },
);

check(
  'Every objective is reachable outside land; fast or distant vessels cannot light it',
  () => {
    for (const island of ISLANDS) {
      const b = {
        ...createBoat(),
        x: island.dock.x,
        z: island.dock.z,
        speed: 3,
      };
      const before = { x: b.x, z: b.z };
      stepBoat(
        b,
        { power: 0, turn: 0, brake: true, boost: false },
        1 / 120,
        10,
        0.3,
      );
      assert(Math.hypot(b.x - before.x, b.z - before.z) < 0.1);
      assert(canLight(b, island));
      assert(
        !canLight({ ...b, speed: 8 / 1.94384 }, island),
        'Exactly 8 knots must still require slowing',
      );
      assert(!canLight({ ...b, x: b.x + 100 }, island));
      const collision = { ...createBoat(), x: island.x, z: island.z };
      stepBoat(
        collision,
        { power: 0, turn: 0, brake: false, boost: false },
        1 / 120,
        0,
        0.3,
      );
      assert(
        Math.hypot(collision.x - island.x, collision.z - island.z) >=
          island.radius * 1.17 + 4.99,
      );
    }
    assert(!canLight(createBoat(), undefined));
  },
);

check('Celestial states are periodic at exactly 300 simulated seconds', () => {
  for (const t of [0, 20, 110, 166, 230]) {
    const a = celestial(t),
      b = celestial(t + 300);
    assert(Math.abs(a.sun.y - b.sun.y) < 1e-10);
    assert(Math.abs(Math.hypot(a.sun.x, a.sun.y, a.sun.z) - 1) < 1e-12);
  }
  assert(celestial(0).warmth > 0.6);
  assert(celestial(60).daylight > 0.95);
  assert(celestial(211).night > 0.95);
});

check(
  'World construction and 120 frames of effects run without a browser or renderer',
  () => {
    const scene = new THREE.Scene(),
      world = createWorld(scene),
      effects = createSeaEffects(scene, world.uniforms);
    const b = { ...createBoat(), speed: 8, throttle: 0.65 };
    for (let i = 0; i < 120; i++) {
      const t = i / 60;
      stepBoat(
        b,
        { power: 0, turn: 0.15, brake: false, boost: false },
        1 / 60,
        t,
        0.98,
      );
      world.update(b, t, 0.98, celestial(211), i % 2, ISLANDS[1], [0]);
      effects.update(b, t, 1 / 60, 0.98, false);
    }
    world.update(b, 3, 0.1, celestial(0), 0, undefined, [0, 1, 2]);
    let triangles = 0;
    scene.traverse((object) => {
      const positions = object.geometry?.attributes.position?.array;
      if (positions) {
        for (const n of positions)
          assert(Number.isFinite(n), `${object.type} has invalid vertices`);
      }
      triangles += object.geometry?.index ? object.geometry.index.count / 3 : 0;
    });
    assert(triangles < 230000, `Geometry budget exceeded: ${triangles}`);
    const h = surfaceHeight(b.x, b.z - 4, 2, 0.98, b);
    assert(Number.isFinite(h));
    effects.clear();
  },
);

const bytes = fs.readFileSync('public/assets/sunwake-vessel.glb');
const gltf = await new GLTFLoader().parseAsync(
  bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),
  '',
);
check(
  'Actual Blender GLB parses with named animation parts and a correct waterline',
  () => {
    for (const name of [
      'Hull',
      'Rig',
      'Sail',
      'Pennant',
      'Wheel',
      'Rudder',
      'Propeller',
    ])
      assert(gltf.scene.getObjectByName(name), `Missing ${name}`);
    assert(
      gltf.scene
        .getObjectByName('Pennant')
        .position.distanceTo(new THREE.Vector3(0, 5.15, -1.88)) < 1e-5,
      'Pennant must rotate around its mast attachment',
    );
    const bounds = new THREE.Box3().setFromObject(gltf.scene),
      size = bounds.getSize(new THREE.Vector3());
    assert(size.x < 4 && size.z > 9 && size.z < 11 && size.y > 5);
    assert(bounds.min.y < -0.65 && bounds.min.y > -1.0);
    const blend = fs.readFileSync('art/sunwake-vessel.blend');
    assert.equal(blend.subarray(0, 7).toString(), 'BLENDER');
    const metadata = JSON.parse(
      fs.readFileSync('art/vessel-metadata.json', 'utf8'),
    );
    assert.equal(metadata.external_models, false);
    assert.equal(metadata.external_textures, false);
    assert(metadata.triangles < 12000);
  },
);

if (fs.existsSync('dist/index.html')) {
  check('Static build assets resolve under an arbitrary subdirectory', () => {
    const html = fs.readFileSync('dist/index.html', 'utf8');
    for (const match of html.matchAll(/(?:src|href)="([^"#]+)"/g)) {
      assert(match[1].startsWith('./'), `Non-relative build URL: ${match[1]}`);
      assert(
        fs.existsSync(path.join('dist', match[1])),
        `Missing build asset ${match[1]}`,
      );
      const url = new URL(
        match[1],
        'https://example.invalid/nested/sunwake/index.html',
      );
      assert(url.pathname.startsWith('/nested/sunwake/'));
    }
    assert(fs.existsSync('dist/assets/sunwake-vessel.glb'));
    for (const name of fs
      .readdirSync('dist/assets')
      .filter((name) => name.endsWith('.js')))
      execFileSync(process.execPath, ['--check', `dist/assets/${name}`]);
  });
}

console.log(
  JSON.stringify(
    {
      checks,
      maxWaveInverseErrorMetres: worstInverse,
      heaveStats,
      browserAcceptance: 'NOT PERFORMED',
      persistentServerStarted: false,
    },
    null,
    2,
  ),
);
