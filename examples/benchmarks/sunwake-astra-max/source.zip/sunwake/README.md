# SUNWAKE — A first-light voyage

一个以三角海面、晨光和木质小船为中心的静态 3D 航海游戏。默认 **Illustrated**，可即时比较 **Natural**；两者共用波场和航行物理。完整源码、依赖锁、原创 Blender 船模和静态构建都在本工程内。

**交付状态：命令行构建与自检通过。未做浏览器验收，未打开浏览器，未启动服务，未发布。**

## 运行与构建

需要 Node.js 22.12+（本次使用 22.23.0）。

```sh
npm ci
npm run build
npm run check
```

发布入口是 `dist/index.html`。将 **dist 的全部内容**放进任意 HTTP/HTTPS 静态目录即可，支持子目录部署；Vite 的 `base` 为 `./`。游戏不需要后端、API Key 或运行时 CDN。浏览器需要 WebGL2。不要以 `file://` 直接打开模块入口。

`npm run dev` 和 `npm run preview` 仅为后续主任务验收保留，本次没有执行。

## 航行

点击 **Set sail**，依次前往 **Morrow Light → The Glass Isles → Northstar Reach**。在金色泊位圈内减速至 **8 节以下**，按 **E** 点亮灯塔。完成后可以继续自由航行或重开航程。已点亮灯塔和累计航程保存在本机 localStorage 中。

| 操作                           | 键位                  |
| ------------------------------ | --------------------- |
| 增减帆力／动力，松手后保持设定 | W / S 或 ↑ / ↓        |
| 转舵                           | A / D 或 ← / →        |
| 收帆减速                       | 按住 Space            |
| 辅机加力                       | 按住 Shift            |
| 点亮附近灯塔                   | E                     |
| 追船／船首／环绕视角           | C，或底部 Camera 按钮 |
| 自由看向／调整镜头距离         | 拖动画面／滚轮        |
| Illustrated / Natural          | 1 / 2，或水面切换器   |
| 海图／帮助／暂停               | M / H 或 ? / Esc      |
| 回到最近安全水域               | R                     |
| 沉浸观景，隐藏界面             | P                     |

触屏设备显示转舵、加减动力、减速按钮；灯塔交互提示可直接点击。右上角可开启程序合成海浪音效。原生对话框支持键盘焦点与 Esc 关闭。

## 场景与制作内容

- **First light voyage**：追船视角，靛蓝与钴蓝浪面、橙金反光、白蓝船侧飞溅和镜头水滴。
- **Glass between storms**：船首视角、大浪、低云、雨丝与破云暖光。在右下卡片或 Sea & sky 内切换。
- **Northern night**：星空、月光和程序化极光。完整天空在 **300 个活动模拟秒**内循环；打开菜单／切到后台时暂停。Sea & sky 可调整时间、海况或停住昼夜循环。
- **共用海面**：五组 Gerstner 波的参数同时生成 GPU 波面和 CPU 逆位移采样。多点浮力使用水体相对速度阻尼，船首压力波、Kelvin 涟漪、历史航迹泡沫与喷溅落点共同追随波面。尾流保留转弯轨迹。
- **原创船只**：Blender 程序建模的叠板木船，包含船壳、肋骨、甲板、舷缘、座椅、舵轮、仪表、辅机、螺旋桨、帆、索具、系缆、锚和航行灯。舵轮、舵、螺旋桨、帆布和旗帜随运动／风变化，两种水面风格也切换船体材质表现。
- **群岛航线**：三座程序化岛屿与灯塔、泊位浮标、随波泊位圈、海图、指向标记、进度存档和完成画面。

快速验收入口参数（添加在部署后的页面 URL 后）：

```text
?scene=storm&view=bow
?scene=aurora
?water=natural
```

## 可读源文件

| 文件                                  | 内容                                                      |
| ------------------------------------- | --------------------------------------------------------- |
| `src/sea.js`                          | 共用波场、浮力、操船、岛屿坐标、目标条件与昼夜计算        |
| `src/shaders.js`                      | 三角水面、天空、星空／极光、泡沫、喷溅、镜头水滴          |
| `src/world.js`                        | 场景、岛屿、灯塔、原创船模接入、动态材质和水面特效        |
| `src/main.js`                         | 游戏循环、相机、操作、海图、状态与声音                    |
| `src/style.css`, `index.html`         | 响应式游戏界面                                            |
| `tools/build_vessel.py`               | 原创 Blender 船只的完整生成脚本                           |
| `art/sunwake-vessel.blend`            | 实际生成的可编辑 Blender 源文件                           |
| `art/vessel-preview.png`              | Blender 命令行渲染的船模预览，**不是游戏截图**            |
| `public/assets/sunwake-vessel.glb`    | 游戏使用的原创模型，8,188 个三角面、18 种材质、无纹理图片 |
| `package-lock.json`                   | 浏览器工程的完整依赖锁                                    |
| `tools/requirements-blender.lock.txt` | 本次 Blender Python 环境的版本锁                          |
| `scripts/check.mjs`                   | 不启动浏览器或服务器的可运行自检                          |
| `scripts/check-shaders.mjs`           | 可选原生 GLSL 编译检查                                    |
| `dist/`                               | 相对路径静态构建，含源映射                                |

可使用 Blender 5.2.1 重新生成船只：

船体与索具动画由游戏运行时驱动；GLB 保留独立节点，不含烘焙动画时间轴。

```sh
blender --background --python tools/build_vessel.py
```

也可在 Python 3.13 虚拟环境安装 `tools/requirements-blender.lock.txt` 后执行 `python tools/build_vessel.py`。建模脚本会生成 GLB、`.blend`、模型预览和元数据。

## 参考与边界

只查看了用户提供的 [First Light Voyage 概念图](https://cdn.openai.com/devhub/showcase/sunwake/concept-first-light-voyage-f0074c39cecd.webp) 与 [Glass Between Storms 概念图](https://cdn.openai.com/devhub/showcase/sunwake/concept-glass-between-storms-0085cc92f83d.webp)。未获取或复用官方游戏代码、成品船模或精灵素材；运行时所有场景几何及唯一 GLB 均为本任务原创。

这是单船街机航海物理：有限波列、多点浮力、水体相对阻尼与局部压力波。没有引入通用刚体／流体求解器。具体自检证据、数值与尚未执行的浏览器验收见 `VALIDATION.md`。没有生成可选的离线单 HTML。
