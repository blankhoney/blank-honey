"""Original Sunwake launch. Run with Blender -b -P or Python + bpy.

All components are authored here; there are no downloaded meshes or textures.
Game coordinates are X starboard, Y up, and negative Z forward. The hull's
designed waterline is Y=0, making its exported datum usable by buoyancy directly.
"""
from pathlib import Path
from math import sin, cos, pi
import json
import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "public" / "assets"
ART = ROOT / "art"
ASSETS.mkdir(parents=True, exist_ok=True)
ART.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)


def coord(p):
    return (p[0], -p[2], p[1])


def material(name, color, rough=0.6, metal=0.0, emission=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get("Principled BSDF")
    p.inputs["Base Color"].default_value = (*color, 1)
    p.inputs["Roughness"].default_value = rough
    p.inputs["Metallic"].default_value = metal
    if emission:
        p.inputs["Emission Color"].default_value = (*color, 1)
        p.inputs["Emission Strength"].default_value = emission
    return m


wood = [material(f"Cedar_{i}", (0.29 + i * 0.031, 0.094 + i * 0.013, 0.033 + i * 0.006), 0.46) for i in range(6)]
teak = material("Honey_teak", (0.57, 0.30, 0.105), 0.47)
seam = material("Tarred_seams", (0.052, 0.043, 0.03), 0.89)
cream = material("Ivory_hull", (0.8, 0.75, 0.59), 0.48)
blue = material("Midnight_enamel", (0.024, 0.08, 0.10), 0.3, 0.22)
brass = material("Aged_brass", (0.58, 0.37, 0.12), 0.28, 0.75)
steel = material("Iron_fittings", (0.085, 0.12, 0.14), 0.34, 0.66)
rope = material("Hemp_rope", (0.56, 0.48, 0.30), 0.94)
canvas = material("Flax_canvas", (0.88, 0.76, 0.52), 0.87)
seat = material("Linen_cushions", (0.71, 0.72, 0.60), 0.95)
red = material("Port_lamp", (0.85, 0.05, 0.018), 0.22, emission=2)
green = material("Starboard_lamp", (0.10, 0.82, 0.49), 0.22, emission=2)
amber = material("Lantern_glow", (1, 0.44, 0.09), 0.2, emission=2)
groups = {"Hull": [], "Rig": [], "Sail": [], "Pennant": [], "Propeller": [], "Rudder": [], "Wheel": []}


def mesh(name, vertices, faces, mat, group="Hull"):
    data = bpy.data.meshes.new(name)
    data.from_pydata([coord(v) for v in vertices], [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    groups[group].append(obj)
    return obj


def box(name, p, dimensions, mat, bevel=0.0, group="Hull"):
    bpy.ops.mesh.primitive_cube_add(size=1, location=coord(p))
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = (dimensions[0], dimensions[2], dimensions[1])
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    if bevel:
        modifier = obj.modifiers.new("Hand_planed_edges", "BEVEL")
        modifier.width = bevel
        modifier.segments = 1
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    groups[group].append(obj)
    return obj


def rod(name, a, b, radius, mat, group="Hull", vertices=8):
    va, vb = Vector(coord(a)), Vector(coord(b))
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=(vb - va).length, location=(va + vb) / 2)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_euler = (vb - va).to_track_quat("Z", "Y").to_euler()
    obj.data.materials.append(mat)
    groups[group].append(obj)
    return obj


def line(name, points, radius, mat, group="Hull", closed=False):
    data = bpy.data.curves.new(name, "CURVE")
    data.dimensions = "3D"
    data.bevel_depth = radius
    data.bevel_resolution = 0
    data.resolution_u = 1
    poly = data.splines.new("POLY")
    poly.points.add(len(points) - 1)
    for item, point in zip(poly.points, points):
        item.co = (*coord(point), 1)
    poly.use_cyclic_u = closed
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    groups[group].append(obj)
    return obj


stations = [(4.0, 1.03, 1.02), (3.5, 1.24, 1.02), (2.4, 1.42, 1.00), (1, 1.47, 1.01), (-1, 1.39, 1.10), (-2.8, 1.12, 1.22), (-4.2, 0.64, 1.42), (-5.05, 0.025, 1.55)]


def section(z, width, sheer, fraction, side, inset=0):
    x = width * sin(fraction * pi / 2) - inset * fraction
    y = -0.68 + (sheer + 0.68) * fraction ** 1.43 + inset
    return (side * x, y, z)


for side in [-1, 1]:
    for course in range(7):
        vertices = []
        for z, width, sheer in stations:
            vertices += [section(z, width, sheer, course / 7, side), section(z, width, sheer, (course + 1) / 7, side)]
        faces = []
        for j in range(len(stations) - 1):
            a = j * 2
            faces += [(a, a + 1, a + 3), (a, a + 3, a + 2)]
        mesh(f"Clinker_outer_{side}_{course}", vertices, faces, cream if course < 2 else wood[course % 6])
        inner = [section(z, width, sheer, f, side, 0.075) for z, width, sheer in stations for f in (course / 7, (course + 1) / 7)]
        mesh(f"Clinker_inner_{side}_{course}", inner, [tuple(reversed(f)) for f in faces], wood[(course + 2) % 6])
        if course > 1:
            line("Clinker_lap", [section(z, w + 0.018, sh, course / 7, side) for z, w, sh in stations], 0.017, seam)
    line("Rounded_gunwale", [(side * w, sh + 0.035, z) for z, w, sh in stations], 0.085, teak)
    line("Brass_rubbing_strip", [(side * (w + 0.043), sh - 0.09, z) for z, w, sh in stations], 0.025, brass)
    for z, width, sheer in stations[1:-1]:
        line("Bent_oak_frame", [section(z, width, sheer, j / 8, side, 0.105) for j in range(9)], 0.039, teak)

mesh("Transom", [(-1.03, 1.02, 4), (1.03, 1.02, 4), (.83, -.25, 4), (0, -.66, 4), (-.83, -.25, 4)], [(0, 1, 2), (0, 2, 4), (2, 3, 4)], wood[2])
line("Transom_cap", [(-1.03, 1.07, 4), (1.03, 1.07, 4)], .083, teak)
rod("Keel", (0, -.69, 3.8), (0, -.64, -4.4), .095, steel)
for i in range(12):
    x = (i - 5.5) * .19
    bow = -3.55 + abs(x) * 1.25
    length = 3.52 - bow
    box("Teak_sole_plank", (x, .15, (3.52 + bow) / 2), (.177, .10, length), wood[(i + 2) % 6], .012)
    for z in [3.15, 1.6, -.3, -1.7]:
        rod("Copper_floor_fastener", (x, .203, z), (x, .214, z), .022, brass, vertices=6)

for z in [2.8, -.28]:
    box("Thwart", (0, .73, z), (2.53, .17, .50), teak, .04)
    box("Linen_bench_pad", (0, .86, z), (2.2, .15, .40), seat, .055)
    for side in [-1, 1]:
        box("Thwart_knee", (side * .94, .43, z), (.14, .65, .27), wood[2], .02)

mesh("Foredeck", [(-.96, .98, -2.9), (.96, .98, -2.9), (.5, 1.24, -4.25), (0, 1.43, -4.91), (-.5, 1.24, -4.25)], [(0, 1, 2), (0, 2, 4), (2, 3, 4)], teak)
box("Forward_hatch", (0, 1.08, -3.38), (.77, .14, .72), wood[3], .06)
rod("Hatch_handle", (-.1, 1.20, -3.38), (.1, 1.20, -3.38), .03, brass)
box("Helm_console", (.69, 1.03, 1.20), (.59, .72, .65), wood[1], .06)
box("Helm_top", (.69, 1.41, 1.20), (.67, .08, .72), teak, .03)
rod("Wheel_shaft", (.69, 1.27, 1.47), (.69, 1.33, 1.77), .045, brass)
wheel_points = [(.69 + cos(j * pi / 24) * .30, 1.33 + sin(j * pi / 24) * .30, 1.8) for j in range(48)]
line("Wheel_rim", wheel_points, .033, teak, "Wheel", True)
for j in range(6):
    theta = j * pi / 3
    rod("Wheel_spoke", (.69, 1.33, 1.8), (.69 + cos(theta) * .37, 1.33 + sin(theta) * .37, 1.8), .017, brass, "Wheel")
for x in [.52, .83]:
    rod("Instrument_bezel", (x, 1.456, 1.1), (x, 1.477, 1.1), .102, brass, vertices=16)
    rod("Instrument_face", (x, 1.478, 1.1), (x, 1.482, 1.1), .085, blue, vertices=16)
    line("Instrument_needle", [(x - .045, 1.49, 1.13), (x + .035, 1.49, 1.06)], .007, cream)
rod("Throttle", (1, 1.42, 1.4), (1, 1.65, 1.32), .023, steel)
box("Throttle_grip", (1, 1.65, 1.32), (.09, .09, .17), blue, .035)

# A compact auxiliary engine keeps the open launch silhouette of the references.
box("Auxiliary_engine", (0, .82, 4.17), (.62, .79, .66), blue, .10)
box("Engine_cream_band", (0, .72, 4.18), (.64, .13, .68), cream, .02)
rod("Engine_leg", (0, .51, 4.26), (0, -.76, 4.35), .11, steel)
rod("Propeller_hub", (0, -.66, 4.29), (0, -.66, 4.61), .11, brass, "Propeller")
for j in range(3):
    a = j * 2 * pi / 3
    mesh("Propeller_blade", [(0, -.66, 4.55), (cos(a) * .35, -.66 + sin(a) * .35, 4.52), (cos(a + .46) * .32, -.66 + sin(a + .46) * .32, 4.63)], [(0, 1, 2)], brass, "Propeller")
box("Rudder_blade", (.70, -.28, 4.13), (.09, 1.15, .52), wood[1], .035, "Rudder")

# Standing rig, a small lugsail, stitched panels and an animated swallowtail.
rod("Mast", (0, .18, -1.88), (0, 5.18, -1.88), .081, teak, "Rig", 12)
rod("Mast_truck", (0, 5.15, -1.88), (0, 5.29, -1.88), .10, brass, "Rig")
rod("Lug_yard", (-.35, 4.65, -1.95), (2.23, 4.95, -1.85), .044, teak, "Rig")
rod("Boom", (0, 1.84, -1.88), (2.1, 2.04, -1.38), .04, teak, "Rig")
for side in [-1, 1]:
    line("Shroud", [(side * 1.19, 1.15, -.95), (side * .04, 4.72, -1.88)], .013, rope, "Rig")
line("Forestay", [(0, 1.44, -4.72), (0, 5.11, -1.88)], .016, rope, "Rig")
line("Main_sheet", [(1.13, .82, .15), (2.05, 2.04, -1.38)], .017, rope, "Rig")
line("Halyard", [(.08, 1.1, -1.8), (.08, 4.85, -1.8), (1.1, 4.8, -1.87)], .012, rope, "Rig")
vertices, faces = [], []
nx, ny = 10, 13
for j in range(ny + 1):
    v = j / ny
    for i in range(nx + 1):
        u = i / nx
        x = u * (2.05 + v * .1)
        y = 1.89 + v * 2.79 + u * .25
        z = -1.86 + u * .30 + sin(u * pi) * sin(v * pi) * .37
        vertices.append((x, y, z))
for j in range(ny):
    for i in range(nx):
        a = j * (nx + 1) + i
        faces += [(a, a + 1, a + nx + 2), (a, a + nx + 2, a + nx + 1)]
sail = mesh("Sail", vertices, faces, canvas, "Sail")
sail.data.materials[0].use_backface_culling = False
for u in [.2, .4, .6, .8]:
    line("Sail_seam", [(u * (2.05 + v * .1), 1.89 + v * 2.79 + u * .25, -1.87 + u * .30 + sin(u * pi) * sin(v * pi) * .37) for v in [i / 13 for i in range(14)]], .004, rope, "Sail")
mesh("Pennant", [(0, 5.15, -1.88), (0, 5.46, -1.88), (.89, 5.41, -1.87), (.62, 5.23, -1.87), (.89, 5.09, -1.87)], [(0, 1, 3), (1, 2, 3), (0, 3, 4)], blue, "Pennant")

for side in [-1, 1]:
    for z in [-2.5, 2.4]:
        x = side * 1.20
        rod("Cleat_base", (x, 1.10, z), (x, 1.18, z), .054, steel)
        rod("Cleat_horns", (x, 1.18, z - .15), (x, 1.18, z + .15), .037, steel)
    rod("Nav_lamp_base", (side * 1.11, 1.28, -2.75), (side * 1.11, 1.36, -2.75), .09, brass)
    rod("Nav_lamp_lens", (side * 1.11, 1.36, -2.75), (side * 1.11, 1.45, -2.75), .072, green if side > 0 else red)
    line("Grab_rail", [(side * 1.36, 1.07, .9), (side * 1.36, 1.30, .8), (side * 1.32, 1.36, -.1)], .025, brass)
for turn in range(5):
    r = .21 + turn * .038
    line("Mooring_rope_coil", [(-.64 + cos(j * pi / 20) * r, .22 + turn * .013, 1.13 + sin(j * pi / 20) * r) for j in range(41)], .019, rope)
rod("Anchor_shank", (-.65, .25, -1.8), (-.65, .26, -2.43), .035, steel)
line("Anchor_flukes", [(-.94, .26, -2.29), (-.65, .26, -2.45), (-.37, .26, -2.29)], .032, steel)
box("Voyage_locker", (-.72, .42, 2), (.56, .38, .63), blue, .035)
for z in [1.8, 2.19]:
    box("Locker_brass_strap", (-.72, .615, z), (.57, .018, .035), brass)
rod("Stern_lantern_hook", (-.88, 1.08, 3.57), (-.88, 1.83, 3.57), .028, brass)
rod("Stern_lantern", (-.88, 1.48, 3.57), (-.88, 1.70, 3.57), .095, amber)
for a in range(4):
    dx, dz = cos(a * pi / 2) * .095, sin(a * pi / 2) * .095
    rod("Lantern_cage", (-.88 + dx, 1.46, 3.57 + dz), (-.88 + dx, 1.73, 3.57 + dz), .012, brass)

# Join each animation group, retaining material slots and readable named nodes.
for name, objects in groups.items():
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    bpy.ops.object.convert(target="MESH")
    bpy.ops.object.join()
    obj = bpy.context.object
    obj.name = name
    pivots = {
        "Propeller": (0, -.66, 4.55),
        "Rudder": (.7, .3, 4.13),
        "Wheel": (.69, 1.33, 1.8),
        "Pennant": (0, 5.15, -1.88),
    }
    bpy.context.scene.cursor.location = coord(pivots.get(name, (0, 0, 0)))
    bpy.ops.object.origin_set(type="ORIGIN_CURSOR")
    # Consistent normals, including hull surfaces authored in either direction.
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode="OBJECT")
    if name in ["Sail", "Pennant"]:
        for mat in obj.data.materials:
            mat.use_backface_culling = False

scene = bpy.context.scene
scene["asset_origin"] = "Original procedural vessel authored for Sunwake, no external meshes or textures"
scene["waterline_game_y"] = 0.0
scene["keel_game_y"] = -0.68
scene["beam_m"] = 2.94
bpy.ops.object.select_all(action="SELECT")
bpy.ops.export_scene.gltf(filepath=str(ASSETS / "sunwake-vessel.glb"), export_format="GLB", use_selection=True, export_yup=True, export_animations=False, export_extras=True)

# A studio view is saved inside the editable .blend, separate from runtime assets.
world = scene.world or bpy.data.worlds.new("Studio")
scene.world = world
world.use_nodes = True
world.node_tree.nodes.get("Background").inputs[0].default_value = (.13, .18, .20, 1)
world.node_tree.nodes.get("Background").inputs[1].default_value = .6
for p, energy, size in [((4, 9, 3), 1700, 7), ((-5, 5, -3), 1200, 5)]:
    bpy.ops.object.light_add(type="AREA", location=coord(p))
    lamp = bpy.context.object
    lamp.data.energy = energy
    lamp.data.shape = "DISK"
    lamp.data.size = size
    lamp.rotation_euler = (Vector(coord((0, 1, 0))) - lamp.location).to_track_quat("-Z", "Y").to_euler()
bpy.ops.object.camera_add(location=coord((10, 8, 13)))
camera = bpy.context.object
camera.rotation_euler = (Vector(coord((0, 1.9, -.2))) - camera.location).to_track_quat("-Z", "Y").to_euler()
camera.data.type = "ORTHO"
camera.data.ortho_scale = 12.8
scene.camera = camera
scene.render.engine = "CYCLES"
scene.cycles.samples = 24
scene.render.resolution_x = 1200
scene.render.resolution_y = 1000
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = "PNG"
scene.render.film_transparent = True
scene.render.filepath = str(ART / "vessel-preview.png")
bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=str(ART / "sunwake-vessel.blend"), compress=False)
bpy.ops.render.render(write_still=True)
stats = {"generator": "Blender " + bpy.app.version_string, "objects": len(groups), "vertices": sum(len(o.data.vertices) for o in bpy.data.objects if o.type == "MESH"), "triangles": sum(sum(len(p.vertices) - 2 for p in o.data.polygons) for o in bpy.data.objects if o.type == "MESH"), "waterline": 0, "keel": -.68, "source": "tools/build_vessel.py", "external_models": False, "external_textures": False}
(ART / "vessel-metadata.json").write_text(json.dumps(stats, indent=2) + "\n")
print(json.dumps(stats))
