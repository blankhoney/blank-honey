# Void Explorer

明亮蓝紫星云中的复古 3D 宇宙探索游戏。原创 AURORA 飞船使用象牙色／靛蓝机身、翡翠座舱、双青色引擎和四片独立机翼。

## 运行与构建

```sh
npm ci
npm run verify
```

Node.js 22.12 或更新版本。`dist/` 是已完成的静态构建，可由主任务放到任意静态 HTTP(S) 站点的根目录或子目录。所有运行资源均包含在 `dist/`，资源路径为相对路径，不依赖外部 CDN。ES modules 和 Worker 需要 HTTP(S)，不保证双击 `file://` 可运行。WebGPU 需要受支持浏览器中的安全上下文；不具备 WebGPU 时自动使用 WebGL 2。

本任务没有启动开发服务器、没有打开浏览器、没有使用自动化 Chrome、没有发布。`npm run dev` 仅作为后续本地验收的可选入口提供，未执行。**未做浏览器验收，也未宣称验证过实际 WebGPU／WebGL 驱动渲染、帧率或移动设备表现。**

## 先完成一次旅行

1. 点击 **Begin exploration**。AURORA 自动寻找 Aethra 上的干燥平地，连续飞入大气并着陆。
2. 点击 **Leave the ship** 或按 **E**。等待后舷梯展开，然后按 **W** 沿舷梯走到地面。
3. 用 **WASD** 步行，拖动视角。可以绕过飞船、探索海岸、进入有真实深度的水域。
4. 回到船尾亮着青色引导灯的舷梯，按 **E** 沿舷梯回舱。按 **Space** 或点击 **Return to orbit** 连续起飞。
5. 按 **M** 打开星图；选择行星或 **Star field** 中的恒星，点击 **Set course**／按 **J** 进行脉冲航行。航线会避开已知天体。抵达后可选择新系统的行星继续着陆。

## 操作

| 操作                   | 按键                              |
| ---------------------- | --------------------------------- |
| 增加／减少油门         | W / S                             |
| 偏航                   | A / D                             |
| 抬头／低头             | ↑ / ↓                             |
| 横滚                   | Q / E（飞行中）                   |
| 垂直升降               | Space / Ctrl                      |
| 加速／制动             | Shift / X                         |
| 鼠标转向／环绕观察     | 左键拖动 / 右键拖动               |
| 星图／准星锁定目标     | M / T；也可直接点击星球或恒星     |
| 脉冲航行／取消自动航行 | J / Esc；输入手动飞行动作也会接管 |
| 辅助着陆／起飞         | L                                 |
| 起落架                 | G                                 |
| 下船／回舱             | E（着陆或步行中）                 |
| 步行／奔跑             | WASD / Shift                      |
| 扫描所选行星           | R（12 km 范围内）                 |
| 在当前位置放置导航点   | B                                 |
| 追尾／座舱视角         | C                                 |
| 拍照模式               | F                                 |
| 操作手册／暂停         | H / Esc（没有自动航线时）         |

触屏设备提供基本飞行按键；辅助旅程、星图、着陆和回舱也可以通过按钮完成。菜单支持原生对话框、键盘焦点和 Escape 关闭。音效默认为关闭，点击声音按钮后启用程序合成的引擎声。

## 工程内容

| 路径                                                   | 内容                                                                                 |
| ------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `src/world.js`                                         | 双精度全局坐标、确定性星系、飞行、导航避障、着陆、步行与回舱状态                     |
| `src/terrain.js`                                       | 共享球面地形场、海平面、河道、深度与网格生成                                         |
| `src/terrain-worker.js`                                | 异步近地表细节生成；旧地形保留，异常时降级本地计算                                   |
| `src/render.js`                                        | Three.js WebGPU 渲染与 WebGL 2 自动后备、浮动原点、光照、材质、bloom、大气与高速尘埃 |
| `src/chart.js`                                         | 按真实坐标绘制的可缩放星图、搜索、目标选择和导航点                                   |
| `src/main.js`, `src/style.css`, `index.html`           | 游戏交互、HUD、设置、探索日志、响应式界面                                            |
| `model/build_aurora.py`                                | 可重复运行的 Blender 原创建模脚本，保留 Mirror 修改器                                |
| `model/aurora.blend`                                   | 可编辑飞船模型                                                                       |
| `model/aurora-top.png`, `model/aurora-perspective.png` | Blender 命令行渲染的模型检查图；不是游戏截图                                         |
| `public/models/aurora.glb`                             | 集成进游戏的原创飞船模型                                                             |
| `checks/`                                              | 可重复运行的命令行自检与结果 JSON                                                    |
| `dist/`                                                | 可直接交给静态托管的构建产物                                                         |

重建模型需要 Blender 4.5 或兼容版本：

```sh
blender --background --factory-startup --python model/build_aurora.py
cp model/aurora-perspective.png public/models/aurora-preview.png
npm run verify
```

## 实现边界

- 星野按相邻 27 个空间区块生成，星图当前提供 379 个有真实 ID 和坐标的恒星目的地；继续旅行会生成后续区块。星云是环境气体，高速条纹是尘埃。可见的恒星和行星均来自同一目录。
- 所有长度使用同一米制坐标。距离到行星表面包括当地地形与水面，HUD 高度和星图距离使用相同计算。恒星脉冲导航的实际落点是该系统第一颗行星的安全轨道；恒星卡片始终显示到恒星表面的距离。行星导航停在轨道高度，地面导航点停在上空安全高度，随后可使用着陆辅助。
- 这是紧凑的街机探索切片：行星和恒星为缩比尺度，位置固定；没有天体引力积分、战斗、多人、复杂船舱或任务 NPC。地面碰撞包括球面地形、水域、舷梯与着陆支柱。可以从翼面下方穿行。
- 河流是球面海平面以下的程序化河槽，海水与河水共享水位和深度；未实现水文流体模拟。近景使用一个有裙边的高精度地形补片，基础整球网格始终保留。
- 默认背景亮度为 **1.35**，可在设置中调整至 **2.0**。亮度、图形偏好、种子、已访问系统、扫描记录与导航点保存在本地。重新载入从起始轨道开始；更换种子开启新的探索记录。
- 不提供离线单 HTML；保留完整可读源码和正常的静态模块构建。

## 验证

`npm run verify` 依次运行模拟旅程、生产构建和静态资源校验。已覆盖确定性星系、缓存回收后坐标一致、地形与水深、8 个种子的起始着陆点、飞行／加速／制动、轨道到地表、舷梯展开、步行、回舱、返回轨道、行星及跨星系旅行、40 条跨种子航线、脉冲冷却，以及 GLB 机翼镜像和资源完整性。

当前结果见 `checks/journey-report.json` 和 `checks/dist-report.json`。这些是命令行证据，不替代浏览器内实际渲染与输入验收。

## 视觉参考与来源

只查看并参照用户指定的公开概念图；未复用官方游戏代码、着色器、场景或成品模型。

- [Orbital flight reference](https://cdn.openai.com/devhub/showcase/void-explorer/concept-orbit-9ced0979a45d.webp)
- [Atmospheric descent reference](https://cdn.openai.com/devhub/showcase/void-explorer/concept-descent-da2bf1f314ee.webp)
- [AURORA top view — silhouette authority](https://cdn.openai.com/devhub/showcase/void-explorer/aurora-concept-top-5887bd0cbcce.webp)
- [AURORA supporting front view](https://cdn.openai.com/devhub/showcase/void-explorer/aurora-concept-front-ca54e31f4a37.webp)

Three.js 0.186.0、Vite 8.3.0 使用 MIT 许可。Space Grotesk 字体使用 SIL Open Font License，许可随字体放在 `public/fonts/OFL.txt`；运行时字体是本地资源。模型使用 Blender 4.5.3 的命令行建模及导出流程生成。
