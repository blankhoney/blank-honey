import './style.css';
import { Vector3 } from 'three';
import { Universe, Simulation, distanceTo, SECTOR } from './world.js';
import { clamp } from './terrain.js';
import { View } from './render.js';
import { StarChart, formatDistance } from './chart.js';

const $ = (selector) => document.querySelector(selector),
  $$ = (selector) => [...document.querySelectorAll(selector)];
const STORE = 'void-explorer-v1';
let stored = {};
try {
  stored = JSON.parse(localStorage.getItem(STORE) || '{}') ?? {};
} catch {}
const settings = {
  brightness: clamp(Number(stored.settings?.brightness) || 1.35, 0.9, 2),
  bloom: stored.settings?.bloom !== false,
  reducedMotion:
    stored.settings?.reducedMotion ?? matchMedia('(prefers-reduced-motion: reduce)').matches,
  quality: stored.settings?.quality === 'balanced' ? 'balanced' : 'high',
  renderer: stored.settings?.renderer === 'webgl' ? 'webgl' : 'auto',
};
let seed =
  typeof stored.seed === 'string' && stored.seed.trim() ? stored.seed.slice(0, 40) : 'AURORA-07';
let sim,
  view,
  ready = false,
  paused = false,
  started = false,
  frameHandle = 0,
  lastFrame = 0,
  uiTimer = 0,
  noticeTimer = 0,
  lastMessage = '',
  generation = 0;
let journey = { land: false, walk: false, return: false },
  photo = false,
  drag = null,
  mouse = { yaw: 0, pitch: 0 },
  lastSaved = 0;
const held = new Set();
let audioContext = null,
  hum = null,
  humGain = null,
  sound = false;
const chart = new StarChart(
  () => sim,
  (target) => {
    sim.select(target);
    save();
  },
);

function save() {
  if (!sim) return;
  try {
    localStorage.setItem(
      STORE,
      JSON.stringify({
        version: 1,
        seed,
        settings,
        visited: [...sim.visited],
        discovered: [...sim.discovered],
        waypoints: sim.waypoints.map((p) => ({ ...p, position: p.position.toArray() })),
        travelled: sim.travelled,
        journey,
      }),
    );
  } catch {
    /* A private window can play the complete journey without persistent storage. */
  }
}
function restoreProgress() {
  if (stored.seed !== seed) return;
  if (Array.isArray(stored.visited))
    for (const id of stored.visited.slice(0, 500))
      if (typeof id === 'string' && sim.universe.resolve(id)) sim.visited.add(id);
  if (Array.isArray(stored.discovered))
    for (const id of stored.discovered.slice(0, 500))
      if (typeof id === 'string' && sim.universe.resolve(id)?.kind === 'planet')
        sim.discovered.add(id);
  if (Array.isArray(stored.waypoints))
    sim.waypoints = stored.waypoints
      .slice(0, 100)
      .filter(
        (p) =>
          p &&
          typeof p.name === 'string' &&
          typeof p.id === 'string' &&
          Array.isArray(p.position) &&
          p.position.length === 3 &&
          p.position.every((v) => Number.isFinite(v) && Math.abs(v) < 1e12),
      )
      .map((p) => ({
        id: p.id,
        kind: 'waypoint',
        name: p.name.slice(0, 80),
        position: new Vector3(...p.position),
      }));
  sim.travelled = Number.isFinite(stored.travelled) ? Math.max(0, stored.travelled) : 0;
}
async function startGame() {
  const current = ++generation;
  cancelAnimationFrame(frameHandle);
  ready = false;
  held.clear();
  try {
    await view?.dispose();
  } catch (error) {
    console.warn('Previous graphics device cleanup failed; creating a fresh canvas.', error);
  }
  const old = $('#universe'),
    canvas = old.cloneNode();
  old.replaceWith(canvas);
  bindCanvas(canvas);
  sim = new Simulation(new Universe(seed));
  restoreProgress();
  journey = { land: false, walk: false, return: false };
  view = new View(canvas, sim, settings, (message) => sim.message(message));
  paused = false;
  started = false;
  photo = false;
  lastFrame = 0;
  lastMessage = '';
  lastSaved = 0;
  $('#interface').hidden = false;
  $('#restore-ui').hidden = true;
  $('#intro').hidden = false;
  $('#journey-panel').hidden = true;
  $('#paused').hidden = true;
  $('#fatal').hidden = true;
  document.body.classList.remove('started', 'cockpit', 'boost');
  $('#begin-button').disabled = $('#manual-button').disabled = true;
  $('#notice').classList.remove('quiet');
  $('#notice>span:last-child').textContent = 'Preparing AURORA and your procedural universe…';
  $('#seed-label').textContent = seed;
  $('#universe-seed').value = seed;
  try {
    await view.init();
    if (current !== generation) return;
    ready = true;
    $('#renderer-label').textContent = view.backend;
    $('#begin-button').disabled = $('#manual-button').disabled = false;
    sim.message('AURORA is ready · every light is a destination');
    save();
    requestAnimationFrame(frame);
  } catch (error) {
    console.error(error);
    showFatal(error);
  }
}
function showFatal(error) {
  ready = false;
  cancelAnimationFrame(frameHandle);
  $('#fatal').hidden = false;
  $('#fatal-detail').textContent =
    `Graphics initialization failed: ${error.message ?? error}. Try WebGL 2, or use a browser with hardware graphics enabled.`;
}
function begin(assist = false) {
  if (!ready) return;
  started = true;
  $('#intro').hidden = true;
  $('#journey-panel').hidden = false;
  document.body.classList.add('started');
  $('#universe').focus({ preventScroll: true });
  if (assist) sim.land();
  else {
    sim.cancel();
    sim.message('You have the controls · W to accelerate · H for flight manual');
  }
}
function selectPlanet() {
  const planets = sim.currentSystem.planets,
    index = planets.findIndex((p) => p.id === sim.target?.id);
  sim.select(planets[(index + 1) % planets.length]);
  chart.updateList();
}
function contextAction() {
  if (!ready) return;
  if (!started) begin();
  if (sim.mode === 'walking') sim.interact();
  else if (sim.mode === 'landed') journey.walk ? sim.takeoff() : sim.interact();
  else if (sim.route) sim.cancel();
  else sim.land();
  save();
}
function openDialog(id) {
  if (!ready) return;
  held.clear();
  mouse = { yaw: 0, pitch: 0 };
  const dialog = $(`#${id}`);
  dialog.showModal();
  if (id === 'chart-dialog') chart.open();
  if (id === 'log-dialog') updateLog();
  if (id === 'settings-dialog') syncSettings();
}
function closeDialog(dialog) {
  dialog.close();
  held.clear();
  lastFrame = 0;
  $('#universe').focus({ preventScroll: true });
}
function togglePause() {
  paused = !paused;
  held.clear();
  $('#paused').hidden = !paused;
  if (!paused) {
    lastFrame = 0;
    $('#universe').focus();
  }
}
function togglePhoto() {
  photo = !photo;
  $('#interface').hidden = photo;
  $('#restore-ui').hidden = !photo;
}
function toggleGear() {
  if (sim.mode !== 'flight') {
    sim.message('Landing gear stays deployed while on the surface');
    return;
  }
  sim.cancel();
  sim.gear = !sim.gear;
  sim.message(`Landing gear ${sim.gear ? 'deployed · speed limited to 55 m/s' : 'retracted'}`);
}
function landAction() {
  if (!ready) return;
  if (!started) begin();
  sim.mode === 'walking' ? sim.interact() : sim.land();
}
function pulseAction() {
  if (!ready) return;
  if (!started) begin();
  sim.travel();
}
function scan() {
  if (sim.scan()) save();
  if ($('#log-dialog').open) updateLog();
}
function waypoint() {
  sim.waypoint();
  save();
  chart.updateList();
}

$('#begin-button').onclick = () => begin(true);
$('#manual-button').onclick = () => begin(false);
$('#home-button').onclick = () => {
  if (!ready) return;
  $('#intro').hidden = !$('#intro').hidden;
  $('#journey-panel').hidden = !$('#intro').hidden;
};
$('#explore-nav').onclick = () => begin(false);
$('#context-button').onclick = contextAction;
$('#travel-button').onclick = pulseAction;
$('#land-button').onclick = landAction;
$('#cycle-target').onclick = () => ready && selectPlanet();
$('#marker-button').onclick = pulseAction;
$('#gear-button').onclick = () => ready && toggleGear();
$('#chart-travel').onclick = () => {
  closeDialog($('#chart-dialog'));
  pulseAction();
};
$('#add-waypoint').onclick = waypoint;
$('#survey-button').onclick = scan;
$('#touch-interact').onclick = () => ready && sim.interact();
$('#resume-button').onclick = togglePause;
$('#restore-ui').onclick = togglePhoto;
$('#retry-button').onclick = () => {
  settings.renderer = 'webgl';
  save();
  startGame();
};
$$('[data-dialog]').forEach((button) => (button.onclick = () => openDialog(button.dataset.dialog)));
$$('.close-dialog').forEach(
  (button) => (button.onclick = () => closeDialog(button.closest('dialog'))),
);
$$('dialog').forEach((dialog) => {
  dialog.addEventListener('cancel', () => {
    held.clear();
    lastFrame = 0;
  });
  dialog.addEventListener('click', (e) => {
    if (e.target !== dialog) return;
    const r = dialog.getBoundingClientRect();
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom)
      closeDialog(dialog);
  });
});

function syncSettings() {
  $('#brightness').value = settings.brightness;
  $('#brightness-value').value = settings.brightness.toFixed(2);
  $('#bloom').checked = settings.bloom;
  $('#reduced-motion').checked = settings.reducedMotion;
  $('#quality').value = settings.quality;
  $('#renderer').value = settings.renderer;
}
$('#brightness').oninput = (e) => {
  settings.brightness = Number(e.target.value);
  $('#brightness-value').value = settings.brightness.toFixed(2);
  save();
};
$('#bloom').onchange = (e) => {
  settings.bloom = e.target.checked;
  save();
};
$('#reduced-motion').onchange = (e) => {
  settings.reducedMotion = e.target.checked;
  save();
};
$('#quality').onchange = (e) => {
  settings.quality = e.target.value;
  save();
};
$('#renderer').onchange = (e) => {
  settings.renderer = e.target.value;
  save();
};
$('#settings-form').onsubmit = (e) => {
  e.preventDefault();
  seed = $('#universe-seed').value.trim().slice(0, 40) || 'AURORA-07';
  stored = {};
  closeDialog($('#settings-dialog'));
  startGame();
};

function bindCanvas(canvas) {
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  canvas.addEventListener('pointerdown', (e) => {
    if (!ready || paused) return;
    drag = {
      x: e.clientX,
      y: e.clientY,
      startX: e.clientX,
      startY: e.clientY,
      orbit: e.button === 2,
    };
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x,
      dy = e.clientY - drag.y;
    drag.x = e.clientX;
    drag.y = e.clientY;
    if (Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) > 5 && !started) begin();
    if (drag.orbit && sim.mode === 'flight') {
      view.look.x -= dx * 0.006;
      view.look.y = clamp(view.look.y + dy * 0.004, -0.7, 0.9);
    } else {
      mouse.yaw += dx * 0.033;
      if (sim.walker) view.look.y = clamp(view.look.y - dy * 0.004, -1.15, 1.15);
      else {
        mouse.pitch -= dy * 0.033;
        sim.cancel();
      }
    }
  });
  canvas.addEventListener('pointerup', (e) => {
    if (drag && Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) < 5) {
      const target = view.pick(e.clientX, e.clientY);
      if (target) {
        sim.select(target);
        chart.updateList();
      }
    }
    drag = null;
  });
  canvas.addEventListener('pointercancel', () => {
    drag = null;
    mouse = { yaw: 0, pitch: 0 };
  });
}
for (const button of $$('[data-hold]')) {
  button.onpointerdown = (e) => {
    e.preventDefault();
    if (!ready) return;
    if (!started) begin();
    held.add(button.dataset.hold);
    button.setPointerCapture(e.pointerId);
    sim.cancel();
  };
  button.onpointerup = button.onpointercancel = () => held.delete(button.dataset.hold);
}
window.addEventListener('keydown', (e) => {
  if (!ready || e.metaKey || e.altKey || e.target.matches('input,textarea,select')) return;
  if ($$('dialog').some((d) => d.open)) return;
  if (e.code === 'Escape') {
    e.preventDefault();
    if (photo) togglePhoto();
    else if (sim.route) sim.cancel();
    else togglePause();
    return;
  }
  if (e.code === 'Space' && e.target.closest('button')) return;
  if (
    [
      'Space',
      'ControlLeft',
      'ControlRight',
      'ArrowUp',
      'ArrowDown',
      'ArrowLeft',
      'ArrowRight',
      'Tab',
    ].includes(e.code) &&
    e.code !== 'Tab'
  )
    e.preventDefault();
  if (paused) return;
  held.add(e.code);
  if (e.repeat) return;
  const actions = {
    KeyM: () => openDialog('chart-dialog'),
    KeyH: () => openDialog('help-dialog'),
    KeyJ: pulseAction,
    KeyL: landAction,
    KeyG: toggleGear,
    KeyB: waypoint,
    KeyR: scan,
    KeyC: () => {
      view.cameraMode = view.cameraMode === 'chase' ? 'cockpit' : 'chase';
      view.look = { x: 0, y: 0 };
      sim.message(`${view.cameraMode === 'chase' ? 'Chase' : 'Cockpit'} camera`);
    },
    KeyF: togglePhoto,
    KeyT: () => {
      const target = view.pick(innerWidth / 2, innerHeight / 2);
      target
        ? sim.select(target)
        : sim.message('Center a planet or star in your crosshair, then press T');
    },
  };
  if (actions[e.code]) actions[e.code]();
  else if (e.code === 'KeyE' && sim.mode !== 'flight') sim.interact();
  else if (e.code === 'Space' && sim.mode === 'landed') sim.takeoff();
  else if (
    [
      'KeyW',
      'KeyS',
      'KeyA',
      'KeyD',
      'KeyQ',
      'KeyE',
      'KeyX',
      'ArrowUp',
      'ArrowDown',
      'ArrowLeft',
      'ArrowRight',
      'Space',
    ].includes(e.code)
  ) {
    if (!started) begin();
    if (sim.mode === 'flight') sim.cancel();
  }
});
window.addEventListener('keyup', (e) => held.delete(e.code));
window.addEventListener('blur', () => {
  held.clear();
  drag = null;
  mouse = { yaw: 0, pitch: 0 };
});
document.addEventListener('visibilitychange', () => {
  held.clear();
  lastFrame = 0;
  if (document.hidden) {
    save();
    if (audioContext) audioContext.suspend();
  } else if (sound) audioContext?.resume();
});
window.addEventListener('pagehide', save);
window.addEventListener('resize', () => {
  if (ready) view.resize();
  if ($('#chart-dialog').open) chart.draw();
});
function getInput(dt) {
  const yes = (code) => (held.has(code) ? 1 : 0),
    walk = !!sim.walker;
  if (walk)
    view.look.y = clamp(view.look.y + (yes('ArrowUp') - yes('ArrowDown')) * dt, -1.15, 1.15);
  const input = {
    throttle: yes('KeyW') - yes('KeyS'),
    yaw: clamp(
      (walk ? 0 : yes('KeyD') - yes('KeyA')) + yes('ArrowRight') - yes('ArrowLeft') + mouse.yaw,
      -1.8,
      1.8,
    ),
    pitch: clamp(yes('ArrowUp') - yes('ArrowDown') + mouse.pitch, -1.8, 1.8),
    roll: yes('KeyE') - yes('KeyQ'),
    lift: yes('Space') - Math.max(yes('ControlLeft'), yes('ControlRight')),
    boost: !!(yes('ShiftLeft') || yes('ShiftRight')),
    brake: !!yes('KeyX'),
    walkForward: yes('KeyW') - yes('KeyS'),
    walkSide: yes('KeyD') - yes('KeyA'),
  };
  mouse.yaw *= Math.exp(-dt * 14);
  mouse.pitch *= Math.exp(-dt * 14);
  return input;
}
function frame(time) {
  if (!ready) return;
  const dt = lastFrame ? Math.min((time - lastFrame) / 1000, 0.05) : 1 / 60;
  lastFrame = time;
  const modal = $$('dialog').some((d) => d.open),
    active = !paused && !modal && !document.hidden;
  try {
    if (active) {
      sim.step(dt, getInput(dt));
      if (sim.mode === 'landed') journey.land = true;
      if (sim.walker) journey.walk = true;
      if (sim.orbitCount > 0) journey.return = true;
    }
    view.update(active ? dt : 0);
    view.render();
    updateAudio(active);
    uiTimer += dt;
    if (uiTimer > 0.1) {
      updateUI();
      uiTimer = 0;
      if ($('#chart-dialog').open) chart.draw();
    }
    if (sim.time - lastSaved > 10) {
      lastSaved = sim.time;
      save();
    }
  } catch (error) {
    console.error(error);
    showFatal(error);
    return;
  }
  frameHandle = requestAnimationFrame(frame);
}
function splitDistance(n) {
  const text = formatDistance(n),
    cut = text.lastIndexOf(' ');
  return [text.slice(0, cut), text.slice(cut + 1)];
}
function updateUI() {
  const s = sim,
    t = s.target,
    g = s.ground,
    route = s.route?.type,
    walk = !!s.walker;
  $('#system-name').textContent = `${s.currentSystem.name.toUpperCase()} SYSTEM`;
  $('#sector-id').textContent = s.position
    .toArray()
    .map((v) => String(Math.floor(v / SECTOR)).padStart(2, '0'))
    .join(' · ');
  const seconds = Math.floor(s.time);
  $('#local-time').textContent =
    `T+ ${[Math.floor(seconds / 3600), Math.floor(seconds / 60) % 60, seconds % 60].map((x) => String(x).padStart(2, '0')).join(':')}`;
  const heading = ((Math.atan2(s.forward.x, -s.forward.z) * 180) / Math.PI + 360) % 360;
  $('#heading').textContent = `${String(Math.round(heading)).padStart(3, '0')}°`;
  const state =
    s.mode === 'walking'
      ? g.depth > 1.2
        ? 'SURFACE · SWIMMING'
        : g.depth > 0.1
          ? 'SURFACE · WADING'
          : 'ON FOOT'
      : s.mode === 'disembarking'
        ? 'DEPLOYING RAMP'
        : s.mode === 'boarding'
          ? 'BOARDING AURORA'
          : s.mode === 'landed'
            ? 'LANDED'
            : route === 'descend'
              ? 'FINAL DESCENT'
              : route === 'approach'
                ? 'LANDING APPROACH'
                : route === 'takeoff'
                  ? 'ASCENDING'
                  : s.boosting
                    ? 'PULSE FLIGHT'
                    : g.altitude < 750
                      ? 'ATMOSPHERIC FLIGHT'
                      : 'ORBITAL FLIGHT';
  $('#flight-state').textContent = state;
  $('#flight-assist').textContent = s.route
    ? 'NAVIGATION ASSIST ENGAGED'
    : walk
      ? 'SURFACE EXPLORATION'
      : s.gear
        ? 'LANDING GEAR DEPLOYED'
        : 'FLIGHT ASSIST ON';
  const velocity = walk
    ? held.has('KeyW') || held.has('KeyS') || held.has('KeyA') || held.has('KeyD')
      ? g.depth > 1.2
        ? 2.5
        : held.has('ShiftLeft')
          ? 11
          : 6
      : 0
    : s.speed;
  $('#speed').textContent =
    velocity < 1000 ? String(Math.round(velocity)).padStart(3, '0') : (velocity / 1000).toFixed(1);
  $('#speed-unit').textContent = velocity < 1000 ? 'm/s' : 'km/s';
  $('#energy-value').textContent = `${Math.round(s.energy)}%`;
  $('#energy-meter').style.width = `${s.energy}%`;
  $('#hull-value').innerHTML = `${Math.round(s.hull)}<span>%</span>`;
  $('#drive-state').textContent = s.driveCooling
    ? 'PULSE COOLING · CRUISE ACTIVE'
    : s.boosting
      ? 'PULSE DRIVE ACTIVE'
      : s.energy < 95
        ? 'CAPACITOR RECHARGING'
        : 'READY TO ENGAGE';
  $('#gear-button').innerHTML = `${s.gear ? 'DEPLOYED' : 'RETRACTED'} <kbd>G</kbd>`;
  const altitude = splitDistance(Math.max(0, g.clearance));
  $('#altitude').textContent = altitude[0];
  $('#altitude-unit').textContent = altitude[1].toUpperCase();
  $('#surface-label').textContent = g.depth > 0 ? `DEPTH ${g.depth.toFixed(1)} M` : 'SURFACE';
  if (t) {
    $('#target-name').textContent = t.name;
    $('#target-type').textContent = (
      t.type ?? (t.kind === 'waypoint' ? 'SAVED COORDINATES' : 'STELLAR DESTINATION')
    ).toUpperCase();
    const n = s.currentSystem.planets.findIndex((p) => p.id === t.id);
    $('#target-number').textContent =
      n >= 0
        ? `${String(n + 1).padStart(2, '0')} / ${String(s.currentSystem.planets.length).padStart(2, '0')}`
        : 'LOCKED';
    const d = splitDistance(distanceTo(s.viewpoint, t));
    $('#target-distance').innerHTML = `${d[0]} <small>${d[1]}</small>`;
    $('#distance-kind').textContent =
      t.kind === 'planet' ? 'SURFACE' : t.kind === 'waypoint' ? 'WAYPOINT' : 'STAR';
    const projected = view.project(t.position);
    $('#target-marker').hidden = !projected.visible || walk || s.mode === 'landed';
    $('#target-marker').style.left = `${projected.x}px`;
    $('#target-marker').style.top = `${projected.y}px`;
    $('.marker-name').textContent = t.name.toUpperCase();
    $('.marker-distance').textContent = formatDistance(distanceTo(s.viewpoint, t));
  }
  $('#ship-marker').hidden = !walk;
  if (walk) {
    const projected = view.project(s.position);
    $('#ship-marker').hidden = !projected.visible;
    $('#ship-marker').style.left = `${projected.x}px`;
    $('#ship-marker').style.top = `${projected.y - 32}px`;
    $('#ship-marker span').textContent = formatDistance(s.walker.position.distanceTo(s.position));
  }
  $('#land-button span').textContent = walk ? 'Reboard' : s.mode === 'landed' ? 'Launch' : 'Land';
  $('#touch-interact').textContent = walk ? 'E · BOARD' : 'E · EXIT';
  let action = 'Begin descent',
    icon = 'i-land',
    hint = 'AURORA will find a safe landing site.';
  if (walk) {
    action = 'Reboard AURORA';
    icon = 'i-ship';
    hint = 'Walk to the illuminated rear ramp. E to board.';
  } else if (s.mode === 'landed') {
    action = journey.walk ? 'Return to orbit' : 'Leave the ship';
    icon = journey.walk ? 'i-arrow' : 'i-ship';
    hint = journey.walk
      ? 'Ramp secured. Press Space to lift off.'
      : 'Press E, then walk forward down the ramp.';
  } else if (route) {
    action = 'Resume manual flight';
    icon = 'i-compass';
    hint =
      route === 'travel'
        ? 'Pulse drive is following your selected course.'
        : route === 'takeoff'
          ? 'Climbing continuously back into orbit.'
          : 'Landing assist is following a safe approach.';
  }
  if (s.mode === 'disembarking') {
    action = 'Opening rear ramp…';
    hint = 'Please wait for the ramp to finish deploying.';
  }
  $('#context-button').innerHTML = `${action}<svg><use href="#${icon}"/></svg>`;
  $('#context-button').disabled = s.mode === 'boarding' || s.mode === 'disembarking';
  $('#context-hint').textContent = hint;
  for (const [name, done] of Object.entries(journey)) {
    const li = $(`[data-step="${name}"]`);
    li.classList.toggle('complete', done);
    li.querySelector('i').textContent = done ? '✓' : '';
  }
  if (s.lastMessage !== lastMessage) {
    lastMessage = s.lastMessage;
    noticeTimer = s.time;
    $('#notice>span:last-child').textContent = lastMessage;
    $('#notice').classList.remove('quiet');
  }
  $('#notice').classList.toggle('quiet', s.time - noticeTimer > 7);
  document.body.classList.toggle('boost', s.boosting && !settings.reducedMotion);
  document.body.classList.toggle('cockpit', view.cameraMode === 'cockpit' && !walk);
  $('#log-dot').classList.toggle('live-dot', s.discovered.size > 0);
  if (walk !== $('#control-strip').classList.contains('walking')) {
    $('#control-strip').classList.toggle('walking', walk);
    $('#control-strip').innerHTML = walk
      ? '<span><kbd>W A S D</kbd> WALK</span><span><kbd>DRAG</kbd> LOOK</span><span><kbd>SHIFT</kbd> SPRINT</span><span><kbd>E</kbd> REBOARD</span><span><kbd>B</kbd> WAYPOINT</span><span><kbd>H</kbd> CONTROLS</span>'
      : '<span><kbd>W</kbd><kbd>S</kbd> THRUST</span><span><kbd>A</kbd><kbd>D</kbd> YAW</span><span><kbd>↑</kbd><kbd>↓</kbd> PITCH</span><span><kbd>SHIFT</kbd> BOOST</span><span><kbd>X</kbd> BRAKE</span><span><kbd>H</kbd> ALL CONTROLS</span>';
  }
}
function updateLog() {
  $('#log-systems').textContent = String(sim.visited.size).padStart(2, '0');
  $('#log-planets').textContent = String(sim.discovered.size).padStart(2, '0');
  $('#log-distance').textContent = (sim.travelled / 1000).toFixed(1);
  $('#empty-log').hidden = sim.discovered.size > 0;
  $('#discoveries').replaceChildren();
  for (const id of sim.discovered) {
    const p = sim.universe.resolve(id);
    if (!p) continue;
    const button = document.createElement('button'),
      name = document.createElement('b'),
      type = document.createElement('span');
    name.textContent = p.name;
    type.textContent = p.type;
    button.append(name, type);
    button.onclick = () => {
      sim.select(p);
      closeDialog($('#log-dialog'));
    };
    $('#discoveries').append(button);
  }
}
$('#sound-button').onclick = async () => {
  try {
    if (!audioContext) {
      audioContext = new AudioContext();
      hum = audioContext.createOscillator();
      hum.type = 'sine';
      humGain = audioContext.createGain();
      humGain.gain.value = 0;
      hum.connect(humGain);
      humGain.connect(audioContext.destination);
      hum.frequency.value = 58;
      hum.start();
      const shimmer = audioContext.createOscillator(),
        gain = audioContext.createGain();
      shimmer.type = 'sine';
      shimmer.frequency.value = 174;
      gain.gain.value = 0.07;
      shimmer.connect(gain);
      gain.connect(humGain);
      shimmer.start();
    }
    sound = !sound;
    await audioContext.resume();
    $('#sound-button').setAttribute('aria-pressed', String(sound));
    $('#sound-button').setAttribute(
      'aria-label',
      sound ? 'Mute ambient sound' : 'Enable ambient sound',
    );
    $('#sound-button use').setAttribute('href', sound ? '#i-sound' : '#i-mute');
  } catch (error) {
    sim?.message('Audio is unavailable in this browser');
    console.warn(error);
  }
};
function updateAudio(active) {
  if (!hum || !audioContext) return;
  hum.frequency.setTargetAtTime(
    52 + Math.min(sim.speed * 0.018, 200),
    audioContext.currentTime,
    0.3,
  );
  humGain.gain.setTargetAtTime(
    sound && active ? (sim.mode === 'flight' ? 0.035 : 0.013) : 0,
    audioContext.currentTime,
    0.25,
  );
}
syncSettings();
startGame();
