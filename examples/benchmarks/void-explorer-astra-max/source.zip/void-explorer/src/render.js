import * as THREE from 'three/webgpu';
import {
  pass,
  color,
  float,
  normalWorld,
  cameraPosition,
  positionWorld,
  abs,
  pow,
} from 'three/tsl';
import { bloom } from 'three/addons/tsl/display/BloomNode.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
  buildTerrain,
  random,
  hash,
  clamp,
  smooth,
  surface,
  tangentBasis,
  unit,
} from './terrain.js';
import { groundAt } from './world.js';

function geometry(data, water = false) {
  const g = new THREE.BufferGeometry();
  g.setAttribute(
    'position',
    new THREE.BufferAttribute(water ? data.waterPositions : data.positions, 3),
  );
  g.setAttribute('color', new THREE.BufferAttribute(water ? data.waterColors : data.colors, 3));
  g.setIndex(new THREE.BufferAttribute(data.indices, 1));
  g.computeVertexNormals();
  g.computeBoundingSphere();
  return g;
}
function glowTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const ctx = c.getContext('2d'),
    gradient = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(0.08, 'rgba(255,255,255,.9)');
  gradient.addColorStop(0.22, 'rgba(255,255,255,.28)');
  gradient.addColorStop(0.5, 'rgba(255,255,255,.08)');
  gradient.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}
function nebulaTexture() {
  const c = document.createElement('canvas');
  c.width = 2048;
  c.height = 1024;
  const ctx = c.getContext('2d'),
    rng = random(81519);
  ctx.fillStyle = '#1c2c4c';
  ctx.fillRect(0, 0, c.width, c.height);
  const clouds = [
    ['#5166ac', 0.8, 600, 490, 630],
    ['#5b397e', 0.9, 1210, 460, 550],
    ['#256c85', 0.7, 1700, 730, 530],
    ['#6373ad', 0.65, 250, 420, 460],
  ];
  for (const [col, alpha, x, y, r] of clouds) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, col);
    g.addColorStop(1, 'transparent');
    ctx.globalAlpha = alpha;
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 2048, 1024);
  }
  for (let i = 0; i < 170; i++) {
    const x = rng() * 2048,
      y = 490 + Math.sin(x * 0.0024) * 200 + (rng() - 0.5) * 235,
      r = 40 + rng() * 190;
    const g = ctx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, ['#9481bc', '#617eae', '#a176a9', '#3e8c98'][i % 4]);
    g.addColorStop(1, 'transparent');
    ctx.globalAlpha = 0.03 + rng() * 0.1;
    ctx.fillStyle = g;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  }
  ctx.globalAlpha = 1;
  const img = ctx.getImageData(0, 0, 2048, 1024);
  for (let i = 0; i < img.data.length; i += 4) {
    const grain = (rng() - 0.5) * 8;
    for (let j = 0; j < 3; j++) img.data[i + j] += grain;
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function reserveShip() {
  const ship = new THREE.Group(),
    hull = new THREE.MeshStandardMaterial({ color: '#e8dfc4', roughness: 0.4 }),
    wing = new THREE.MeshStandardMaterial({ color: '#37335c' });
  const core = new THREE.Mesh(new THREE.ConeGeometry(3.2, 25, 6), hull);
  core.rotation.x = -Math.PI / 2;
  ship.add(core);
  for (const side of [-1, 1])
    for (const z of [-1, 7]) {
      const g = new THREE.BufferGeometry();
      g.setAttribute(
        'position',
        new THREE.Float32BufferAttribute(
          [side * 2, 0, z - 4, side * 14, 0, z + 6, side * 4, 0, z + 3],
          3,
        ),
      );
      g.computeVertexNormals();
      const mat = wing.clone();
      mat.side = THREE.DoubleSide;
      ship.add(new THREE.Mesh(g, mat));
    }
  return ship;
}
export class View {
  constructor(canvas, simulation, settings, onNotice) {
    this.canvas = canvas;
    this.sim = simulation;
    this.settings = settings;
    this.onNotice = onNotice;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(61, 1, 0.18, 900000);
    this.origin = new THREE.Vector3();
    this.planets = new Map();
    this.cameraMode = 'chase';
    this.look = { x: 0, y: 0 };
    this.patch = null;
    this.pending = null;
    this.job = 0;
    this.clock = 0;
    this.lastCatalog = '';
    this.disposed = false;
    this.currentScale = 0;
  }
  async init() {
    this.renderer = new THREE.WebGPURenderer({
      canvas: this.canvas,
      antialias: true,
      forceWebGL: this.settings.renderer === 'webgl',
      logarithmicDepthBuffer: true,
      alpha: false,
    });
    this.renderer.setPixelRatio(
      Math.min(devicePixelRatio, this.settings.quality === 'high' ? 1.7 : 1.15),
    );
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.settings.brightness;
    await this.renderer.init();
    this.backend = this.renderer.backend.isWebGPUBackend ? 'WEBGPU' : 'WEBGL 2';
    this.pipeline = new THREE.RenderPipeline(this.renderer);
    this.scenePass = pass(this.scene, this.camera);
    const output = this.scenePass.getTextureNode('output');
    this.bloom = bloom(output, 0.32, 0.5, 1.05);
    this.pipeline.outputNode = output.add(this.bloom);
    this.glow = glowTexture();
    this.sky = new THREE.Mesh(
      new THREE.SphereGeometry(650000, 40, 24),
      new THREE.MeshBasicMaterial({
        map: nebulaTexture(),
        side: THREE.BackSide,
        depthWrite: false,
        fog: true,
      }),
    );
    this.sky.rotation.y = 0.45;
    this.sky.renderOrder = -10;
    this.scene.add(this.sky);
    this.fog = new THREE.FogExp2('#667a9e', 0);
    this.scene.fog = this.fog;
    this.scene.add(new THREE.HemisphereLight('#c3d8ff', '#6c5690', 2.3));
    this.sun = new THREE.DirectionalLight('#ffdec0', 3.1);
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    const rim = new THREE.DirectionalLight('#82cfff', 1.9);
    rim.position.set(80, 40, 55);
    this.scene.add(rim);
    const fill = new THREE.DirectionalLight('#cd89d2', 0.7);
    fill.position.set(-60, -20, 10);
    this.scene.add(fill);
    this.terrainMaterial = new THREE.MeshStandardMaterial({
      vertexColors: true,
      flatShading: true,
      roughness: 0.9,
      metalness: 0.08,
    });
    this.waterMaterial = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.3,
      metalness: 0.36,
      transparent: true,
      opacity: 0.86,
      emissive: '#174050',
      emissiveIntensity: 0.18,
    });
    this.ship = new THREE.Group();
    this.scene.add(this.ship);
    try {
      const gltf = await new GLTFLoader().loadAsync(`${import.meta.env.BASE_URL}models/aurora.glb`);
      this.ship.add(gltf.scene);
      this.model = gltf.scene;
      this.gear = this.model.getObjectByName('GearAssembly');
      this.ramp = this.model.getObjectByName('RampPivot');
    } catch (error) {
      this.model = reserveShip();
      this.ship.add(this.model);
      this.onNotice('AURORA asset unavailable · procedural reserve hull active');
      console.warn(error);
    }
    this.plumes = [];
    for (const x of [-4, 4]) {
      const g = new THREE.ConeGeometry(0.77, 1, 12);
      g.rotateX(Math.PI / 2);
      g.translate(0, 0, 0.5);
      const plume = new THREE.Mesh(
        g,
        new THREE.MeshBasicMaterial({
          color: new THREE.Color('#58efff').multiplyScalar(2.2),
          transparent: true,
          opacity: 0.65,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      plume.position.set(x, -0.15, 10.82);
      this.ship.add(plume);
      this.plumes.push(plume);
      const glow = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: this.glow,
          color: '#4eefff',
          transparent: true,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      glow.scale.set(6, 6, 1);
      glow.position.set(x, -0.15, 11);
      this.ship.add(glow);
    }
    this.starCore = new THREE.InstancedMesh(
      new THREE.IcosahedronGeometry(1, 1),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(2.2, 2.2, 2.2) }),
      420,
    );
    this.starGlow = new THREE.InstancedMesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({
        map: this.glow,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
      420,
    );
    this.starCore.frustumCulled = this.starGlow.frustumCulled = false;
    this.scene.add(this.starGlow, this.starCore);
    this.createDust();
    try {
      this.worker = new Worker(new URL('./terrain-worker.js', import.meta.url), { type: 'module' });
      this.worker.onmessage = ({ data }) => this.acceptPatch(data);
      this.worker.onerror = () => {
        this.onNotice('Terrain worker recovered with local generation');
        this.worker.terminate();
        this.worker = null;
        this.pending = null;
      };
    } catch {
      this.worker = null;
    }
    this.resize();
    this.update(0);
    return this;
  }
  resize() {
    const w = this.canvas.clientWidth,
      h = this.canvas.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }
  createPlanet(body) {
    const group = new THREE.Group();
    group.name = body.name;
    const data = buildTerrain(body, { resolution: body.id === this.sim.nearestBody.id ? 40 : 25 });
    const ground = new THREE.Mesh(geometry(data), this.terrainMaterial),
      water = new THREE.Mesh(geometry(data, true), this.waterMaterial);
    group.add(ground, water);
    const atmoMaterial = new THREE.MeshBasicNodeMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.FrontSide,
    });
    atmoMaterial.colorNode = color(body.biome === 1 ? '#aa7dff' : '#78d4ff').mul(1.5);
    const rim = float(1)
      .sub(abs(normalWorld.dot(cameraPosition.sub(positionWorld).normalize())))
      .clamp(0, 1);
    atmoMaterial.opacityNode = pow(rim, 3).mul(0.72);
    const atmo = new THREE.Mesh(new THREE.SphereGeometry(body.radius + 55, 72, 48), atmoMaterial);
    group.add(atmo);
    if (body.rings) {
      const rings = new THREE.Group();
      for (let i = 0; i < 15; i++) {
        const r = body.radius * (1.26 + i * 0.041),
          width = body.radius * (i % 4 === 0 ? 0.017 : 0.029);
        const mat = new THREE.MeshBasicMaterial({
          color: i % 3 === 0 ? '#c3b2d9' : i % 3 === 1 ? '#5bced0' : '#7584ba',
          transparent: true,
          opacity: i % 3 === 0 ? 0.35 : 0.23,
          side: THREE.DoubleSide,
          depthWrite: false,
        });
        const ring = new THREE.Mesh(new THREE.RingGeometry(r, r + width, 180), mat);
        rings.add(ring);
      }
      rings.rotation.set(1.14, 0.25, -0.43);
      group.add(rings);
    }
    this.scene.add(group);
    this.planets.set(body.id, { group, body, ground, water });
  }
  updateCatalog() {
    const ids = this.sim.bodies.map((b) => b.id).join(',');
    if (ids === this.lastCatalog) return;
    this.lastCatalog = ids;
    for (const body of this.sim.bodies) if (!this.planets.has(body.id)) this.createPlanet(body);
    for (const [id, item] of this.planets)
      if (!this.sim.bodies.some((b) => b.id === id)) {
        this.scene.remove(item.group);
        item.group.traverse((o) => {
          o.geometry?.dispose();
          if (
            o.material &&
            o.material !== this.terrainMaterial &&
            o.material !== this.waterMaterial
          )
            o.material.dispose();
        });
        this.planets.delete(id);
      }
  }
  createDust() {
    const rng = random(991);
    this.dustData = [];
    for (let i = 0; i < 190; i++)
      this.dustData.push([(rng() - 0.5) * 900, (rng() - 0.5) * 540, -rng() * 800]);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(190 * 6), 3));
    this.dust = new THREE.LineSegments(
      g,
      new THREE.LineBasicMaterial({
        color: '#b1e6f3',
        transparent: true,
        opacity: 0.25,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    this.dust.frustumCulled = false;
    this.scene.add(this.dust);
  }
  requestPatch() {
    const body = this.sim.nearestBody,
      g = groundAt(body, this.sim.viewpoint);
    if (g.altitude > 1050) {
      if (this.patch) this.patch.group.visible = false;
      return;
    }
    if (this.patch?.bodyId === body.id) this.patch.group.visible = true;
    if (this.pending) {
      if (this.clock - this.pending.started > 6) {
        this.worker?.terminate();
        this.worker = null;
        this.pending = null;
      } else return;
    }
    const size = clamp(400 + g.altitude * 0.5, 400, 950);
    if (
      this.patch?.bodyId === body.id &&
      g.normal.distanceTo(new THREE.Vector3(...this.patch.normal)) * body.radius < size * 0.22
    )
      return;
    const request = {
      id: ++this.job,
      body: { seed: body.seed, biome: body.biome, radius: body.radius, id: body.id },
      options: {
        normal: g.normal.toArray(),
        size,
        resolution: this.settings.quality === 'high' ? 80 : 56,
      },
    };
    this.pending = { ...request, started: this.clock };
    if (this.worker) this.worker.postMessage(request);
    else
      this.acceptPatch({
        id: request.id,
        bodyId: body.id,
        normal: request.options.normal,
        mesh: buildTerrain(request.body, request.options),
      });
  }
  acceptPatch(data) {
    if (this.disposed || data.id !== this.pending?.id) return;
    this.pending = null;
    if (data.error) {
      this.onNotice('Terrain detail retry · base terrain remains available');
      return;
    }
    if (data.bodyId !== this.sim.nearestBody.id) return;
    const group = new THREE.Group();
    group.add(
      new THREE.Mesh(geometry(data.mesh), this.terrainMaterial),
      new THREE.Mesh(geometry(data.mesh, true), this.waterMaterial),
    );
    if (this.patch) {
      this.scene.remove(this.patch.group);
      this.patch.group.traverse((o) => o.geometry?.dispose());
    }
    this.patch = { group, bodyId: data.bodyId, normal: data.normal };
    this.scene.add(group);
    this.createScatter(this.sim.nearestBody, data.normal);
  }
  createScatter(body, normal) {
    if (this.scatter) {
      this.scene.remove(this.scatter);
      this.scatter.traverse((o) => {
        o.geometry?.dispose();
        o.material?.dispose();
      });
    }
    const group = new THREE.Group(),
      rng = random(hash(`${body.id}:${normal.map((n) => n.toFixed(2))}`)),
      [u, v] = tangentBasis(normal);
    const rocks = new THREE.InstancedMesh(
      new THREE.IcosahedronGeometry(1, 0),
      new THREE.MeshStandardMaterial({ color: '#acb1c3', roughness: 0.92, flatShading: true }),
      180,
    );
    const plants = new THREE.InstancedMesh(
      new THREE.ConeGeometry(0.48, 3.5, 4),
      new THREE.MeshStandardMaterial({
        color: body.biome === 0 ? '#70a69c' : '#a5afe3',
        flatShading: true,
        roughness: 0.6,
        emissive: '#415768',
        emissiveIntensity: 0.1,
      }),
      180,
    );
    const object = new THREE.Object3D();
    let count = 0;
    for (let i = 0; i < 180; i++) {
      const a = ((rng() - 0.5) * 650) / body.radius,
        b = ((rng() - 0.5) * 650) / body.radius,
        n = unit(normal.map((x, j) => x + u[j] * a + v[j] * b)),
        s = surface(body, n);
      if (s.depth > 0) continue;
      const scale = 0.45 + rng() * 2.7;
      object.position.set(...n).multiplyScalar(body.radius + s.height + scale * 0.24);
      object.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(...n));
      object.scale.set(scale, scale * 0.5, scale * 0.75);
      object.updateMatrix();
      rocks.setMatrixAt(count, object.matrix);
      object.scale.setScalar(0.4 + rng() * 1.1);
      object.position.addScaledVector(new THREE.Vector3(...n), 1.5);
      object.updateMatrix();
      plants.setMatrixAt(count, object.matrix);
      count++;
    }
    rocks.count = plants.count = count;
    group.add(rocks, plants);
    this.scatter = group;
    this.scatterBody = body;
    this.scene.add(group);
  }
  update(dt) {
    this.clock += dt;
    const s = this.sim;
    this.origin.copy(s.viewpoint);
    this.updateCatalog();
    for (const { body, group } of this.planets.values())
      group.position.copy(body.position).sub(this.origin);
    if (this.patch) {
      const b = s.universe.resolve(this.patch.bodyId);
      if (b) this.patch.group.position.copy(b.position).sub(this.origin);
    }
    if (this.scatter) {
      this.scatter.position.copy(this.scatterBody.position).sub(this.origin);
      this.scatter.visible = s.nearestBody.id === this.scatterBody.id && s.ground.altitude < 700;
    }
    this.ship.position.copy(s.position).sub(this.origin);
    this.ship.quaternion.copy(s.orientation);
    this.ship.visible = this.cameraMode !== 'cockpit' || s.mode !== 'flight';
    if (this.gear) {
      this.gear.visible = s.gearAmount > 0.02;
      this.gear.scale.y = Math.max(0.02, s.gearAmount);
    }
    if (this.ramp) {
      this.ramp.visible = s.rampAmount > 0.01;
      this.ramp.rotation.x = s.rampAmount * 0.358;
    }
    for (const plume of this.plumes) {
      plume.visible = s.mode === 'flight';
      plume.scale.z =
        (s.boosting ? 52 : 6 + s.speed * 0.025) * (1 + Math.sin(this.clock * 43) * 0.055);
    }
    const f = s.forward,
      up = s.up;
    if (s.walker) {
      this.camera.position.set(0, 0, 0);
      const q = s.walker.orientation
        .clone()
        .multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), this.look.y));
      this.camera.quaternion.copy(q);
    } else if (this.cameraMode === 'cockpit') {
      this.camera.position
        .copy(this.ship.position)
        .add(new THREE.Vector3(0, 2.5, -6).applyQuaternion(s.orientation));
      this.camera.quaternion.copy(s.orientation);
    } else {
      const offset = new THREE.Vector3(0, 17, 54);
      offset
        .applyAxisAngle(new THREE.Vector3(0, 1, 0), this.look.x)
        .applyAxisAngle(new THREE.Vector3(1, 0, 0), this.look.y)
        .applyQuaternion(s.orientation);
      this.camera.position.copy(this.ship.position).add(offset);
      this.camera.up.copy(up);
      this.camera.lookAt(this.ship.position.clone().addScaledVector(f, 76).addScaledVector(up, 2));
    }
    this.camera.fov +=
      ((s.walker ? 73 : s.boosting ? 75 : 61) - this.camera.fov) * Math.min(1, dt * 3);
    this.camera.updateProjectionMatrix();
    this.camera.updateMatrixWorld();
    this.sky.position.copy(this.camera.position);
    const g = s.ground,
      atmo = (1 - smooth(70, 750, g.altitude)) * (s.nearestBody.biome === 3 ? 0.72 : 1);
    this.fog.density = atmo * 0.00034;
    this.fog.color.set(
      s.nearestBody.biome === 1 ? '#9c839e' : s.nearestBody.biome === 3 ? '#b4847c' : '#628aa6',
    );
    this.sun.position
      .copy(s.currentSystem.position)
      .sub(this.origin)
      .normalize()
      .multiplyScalar(30000);
    this.sun.target.position.copy(this.ship.position);
    this.renderer.toneMappingExposure = this.settings.brightness;
    this.bloom.strength.value = this.settings.bloom ? 0.34 : 0;
    const object = new THREE.Object3D(),
      stars = s.nearbySystems;
    for (let i = 0; i < stars.length; i++) {
      const star = stars[i];
      object.position.copy(star.position).sub(this.origin);
      const visibility = 1 - smooth(110000, 148000, object.position.length());
      object.scale.setScalar(Math.max(0.001, star.radius * visibility));
      object.quaternion.identity();
      object.updateMatrix();
      this.starCore.setMatrixAt(i, object.matrix);
      this.starCore.setColorAt(i, new THREE.Color(star.color));
      object.quaternion.copy(this.camera.quaternion);
      object.scale.setScalar(Math.max(0.001, star.radius * 8 * visibility));
      object.updateMatrix();
      this.starGlow.setMatrixAt(i, object.matrix);
      this.starGlow.setColorAt(i, new THREE.Color(star.color));
    }
    this.starCore.count = this.starGlow.count = stars.length;
    this.starCore.instanceMatrix.needsUpdate = this.starGlow.instanceMatrix.needsUpdate = true;
    if (this.starCore.instanceColor)
      this.starCore.instanceColor.needsUpdate = this.starGlow.instanceColor.needsUpdate = true;
    const dustPosition = this.dust.geometry.getAttribute('position');
    for (let i = 0; i < this.dustData.length; i++) {
      const p = this.dustData[i];
      p[2] += Math.min(s.speed, 28000) * dt * 0.45 + dt * 2;
      if (p[2] > 80) p[2] = -800;
      dustPosition.setXYZ(i * 2, p[0], p[1], p[2]);
      dustPosition.setXYZ(i * 2 + 1, p[0], p[1], p[2] - clamp(s.speed * 0.035, 1, 140));
    }
    dustPosition.needsUpdate = true;
    this.dust.quaternion.copy(s.orientation);
    this.dust.position.copy(this.ship.position);
    this.dust.visible = s.mode === 'flight' && !this.settings.reducedMotion;
    this.dust.material.opacity = s.boosting ? 0.5 : 0.18;
    this.requestPatch();
  }
  render() {
    this.pipeline.render();
  }
  project(position) {
    const v = position.clone().sub(this.origin).project(this.camera);
    return {
      x: (v.x * 0.5 + 0.5) * this.canvas.clientWidth,
      y: (-v.y * 0.5 + 0.5) * this.canvas.clientHeight,
      visible: v.z > -1 && v.z < 1 && Math.abs(v.x) < 1.15 && Math.abs(v.y) < 1.15,
    };
  }
  pick(x, y) {
    this.scene.updateMatrixWorld(true);
    const ray = new THREE.Raycaster();
    ray.setFromCamera(
      new THREE.Vector2(
        (x / this.canvas.clientWidth) * 2 - 1,
        1 - (y / this.canvas.clientHeight) * 2,
      ),
      this.camera,
    );
    const surfaces = [...this.planets.values()].map((item) => item.ground);
    const hit = ray.intersectObjects([...surfaces, this.starCore], false)[0];
    if (hit) {
      if (hit.object === this.starCore)
        return this.sim.universe.system(this.sim.nearbySystems[hit.instanceId]);
      return [...this.planets.values()].find((item) => item.ground === hit.object).body;
    }
    let target = null,
      best = 28;
    for (const item of this.sim.nearbySystems) {
      if (item.position.distanceTo(this.origin) > 148000) continue;
      const p = this.project(item.position),
        distance = Math.hypot(p.x - x, p.y - y);
      if (p.visible && distance < best) {
        best = distance;
        target = item;
      }
    }
    return target?.kind ? target : target ? this.sim.universe.system(target) : null;
  }
  async dispose() {
    this.disposed = true;
    this.worker?.terminate();
    this.bloom?.dispose();
    this.scenePass?.dispose();
    this.pipeline?.dispose();
    this.glow?.dispose();
    this.sky?.material.map?.dispose();
    this.scene.traverse((o) => {
      o.geometry?.dispose();
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) m?.dispose();
    });
    if (this.renderer?.initialized) await this.renderer.dispose();
  }
}
