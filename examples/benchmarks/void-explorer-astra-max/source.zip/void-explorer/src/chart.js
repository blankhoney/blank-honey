import { distanceTo } from './world.js';
import { clamp } from './terrain.js';
export const formatDistance = (n) =>
  n >= 1000
    ? `${(n / 1000).toLocaleString('en-US', { maximumFractionDigits: n < 100000 ? 2 : 0 })} km`
    : `${Math.round(n).toLocaleString('en-US')} m`;
export class StarChart {
  constructor(getSimulation, select) {
    this.getSimulation = getSimulation;
    this.select = select;
    this.mode = 'system';
    this.zoom = 1;
    this.pan = { x: 0, y: 0 };
    this.points = [];
    this.drag = null;
    this.canvas = document.querySelector('#star-chart');
    this.ctx = this.canvas.getContext('2d');
    this.search = document.querySelector('#chart-search');
    this.search.addEventListener('input', () => this.updateList());
    for (const mode of ['system', 'galaxy', 'waypoints'])
      document.querySelector(`#map-${mode}`).onclick = () => {
        this.mode = mode;
        this.search.value = '';
        this.recenter();
        this.updateList();
        for (const m of ['system', 'galaxy', 'waypoints'])
          document.querySelector(`#map-${m}`).classList.toggle('active', m === mode);
      };
    document.querySelector('#map-center').onclick = () => this.recenter();
    this.canvas.addEventListener(
      'wheel',
      (e) => {
        e.preventDefault();
        this.zoom = clamp(this.zoom * Math.exp(-e.deltaY * 0.0015), 0.3, 20);
        this.draw();
      },
      { passive: false },
    );
    this.canvas.addEventListener('pointerdown', (e) => {
      this.drag = { x: e.clientX, y: e.clientY, startX: e.clientX, startY: e.clientY };
      this.canvas.setPointerCapture(e.pointerId);
    });
    this.canvas.addEventListener('pointermove', (e) => {
      if (!this.drag) return;
      this.pan.x += e.clientX - this.drag.x;
      this.pan.y += e.clientY - this.drag.y;
      this.drag.x = e.clientX;
      this.drag.y = e.clientY;
      this.draw();
    });
    this.canvas.addEventListener('pointerup', (e) => {
      if (this.drag && Math.hypot(e.clientX - this.drag.startX, e.clientY - this.drag.startY) < 6) {
        const rect = this.canvas.getBoundingClientRect(),
          x = e.clientX - rect.left,
          y = e.clientY - rect.top;
        const point = this.points
          .filter((p) => Math.hypot(p.x - x, p.y - y) < 22)
          .sort((a, b) => Math.hypot(a.x - x, a.y - y) - Math.hypot(b.x - x, b.y - y))[0];
        if (point) {
          this.select(point.item);
          this.updateList();
        }
      }
      this.drag = null;
    });
    this.canvas.addEventListener('pointercancel', () => (this.drag = null));
  }
  items() {
    const s = this.getSimulation();
    return this.mode === 'system'
      ? s.currentSystem.planets
      : this.mode === 'galaxy'
        ? s.nearbySystems
        : s.waypoints;
  }
  recenter() {
    this.zoom = 1;
    this.pan = { x: 0, y: 0 };
    this.draw();
  }
  open() {
    this.updateList();
    this.recenter();
  }
  updateList() {
    const s = this.getSimulation(),
      query = this.search.value.toLowerCase().trim(),
      list = document.querySelector('#chart-list');
    list.replaceChildren();
    const items = this.items()
      .filter((i) => i.name.toLowerCase().includes(query))
      .sort((a, b) => distanceTo(s.viewpoint, a) - distanceTo(s.viewpoint, b));
    for (const item of items) {
      const button = document.createElement('button'),
        dot = document.createElement('i'),
        name = document.createElement('span'),
        distance = document.createElement('small');
      button.classList.toggle('selected', s.target?.id === item.id);
      button.setAttribute('aria-pressed', String(s.target?.id === item.id));
      button.style.setProperty(
        '--planet-color',
        item.color ?? ['#a8ddcb', '#bda0df', '#86d1ea', '#eba77e'][item.biome ?? 0],
      );
      name.textContent = item.name;
      distance.textContent = formatDistance(distanceTo(s.viewpoint, item));
      button.append(dot, name, distance);
      button.onclick = () => {
        this.select(item.kind ? item : s.universe.system(item));
        this.updateList();
        this.draw();
      };
      list.append(button);
    }
    if (!items.length) {
      const p = document.createElement('p');
      p.className = 'subtle';
      p.style.fontSize = '11px';
      p.textContent =
        this.mode === 'waypoints'
          ? 'Press B or mark your current position to save a waypoint.'
          : 'No destinations match your search.';
      list.append(p);
    }
    this.updateTarget();
    this.draw();
  }
  updateTarget() {
    const s = this.getSimulation(),
      t = s.target;
    if (!t) return;
    document.querySelector('#chart-target-name').textContent = t.name;
    document.querySelector('#chart-target-detail').textContent =
      `${t.type ?? (t.kind === 'waypoint' ? 'Saved coordinates' : 'Procedural star system')} · ${formatDistance(distanceTo(s.viewpoint, t))} away`;
  }
  draw() {
    const s = this.getSimulation();
    if (!s) return;
    const ctx = this.ctx,
      rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const ratio = Math.min(devicePixelRatio, 2),
      w = rect.width,
      h = rect.height;
    if (
      this.canvas.width !== Math.round(w * ratio) ||
      this.canvas.height !== Math.round(h * ratio)
    ) {
      this.canvas.width = Math.round(w * ratio);
      this.canvas.height = Math.round(h * ratio);
    }
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const items = this.items(),
      positions = [s.viewpoint, ...items.map((i) => i.position)];
    const minX = Math.min(...positions.map((p) => p.x)),
      maxX = Math.max(...positions.map((p) => p.x)),
      minZ = Math.min(...positions.map((p) => p.z)),
      maxZ = Math.max(...positions.map((p) => p.z));
    const cx = (minX + maxX) / 2,
      cz = (minZ + maxZ) / 2;
    const scale =
      Math.min((w - 110) / Math.max(2500, maxX - minX), (h - 120) / Math.max(2500, maxZ - minZ)) *
      this.zoom;
    const project = (p) => ({
      x: (p.x - cx) * scale + w / 2 + this.pan.x,
      y: (p.z - cz) * scale + h / 2 + this.pan.y,
    });
    const grid = 50 * this.zoom;
    ctx.strokeStyle = '#bdd6eb0d';
    ctx.lineWidth = 1;
    for (let x = (w / 2 + this.pan.x) % grid; x < w; x += grid) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = (h / 2 + this.pan.y) % grid; y < h; y += grid) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }
    if (this.mode === 'system') {
      const star = s.currentSystem,
        at = project(star.position);
      ctx.save();
      ctx.strokeStyle = '#bddde114';
      ctx.setLineDash([2, 5]);
      for (const p of items) {
        const r =
          Math.hypot(p.position.x - star.position.x, p.position.z - star.position.z) * scale;
        ctx.beginPath();
        ctx.arc(at.x, at.y, r, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
      const glow = ctx.createRadialGradient(at.x, at.y, 0, at.x, at.y, 25);
      glow.addColorStop(0, '#ffd6a575');
      glow.addColorStop(1, '#ffd6a500');
      ctx.fillStyle = glow;
      ctx.fillRect(at.x - 25, at.y - 25, 50, 50);
      ctx.fillStyle = '#ffe2b7';
      ctx.beginPath();
      ctx.arc(at.x, at.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    this.points = [];
    for (const item of items) {
      const p = project(item.position);
      this.points.push({ ...p, item });
      const selected = item.id === s.target?.id;
      const r =
        this.mode === 'galaxy' ? 2.1 : Math.max(4, Math.min(9, (item.radius ?? 350) * scale));
      const col = item.color ?? ['#a9dbbf', '#c1a0e2', '#8fd4ee', '#edb090'][item.biome ?? 0];
      if (this.mode !== 'galaxy') {
        ctx.fillStyle = `${col}12`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, r + 7, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
      if (selected) {
        ctx.strokeStyle = '#c2e8d7';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, r + 7, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([3, 4]);
        const player = project(s.viewpoint);
        ctx.beginPath();
        ctx.moveTo(player.x, player.y);
        if (s.route?.type === 'travel') {
          for (const waypoint of [s.route.end, ...s.route.points]) {
            const next = project(waypoint);
            ctx.lineTo(next.x, next.y);
          }
        }
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        ctx.setLineDash([]);
      }
      if (this.mode !== 'galaxy' || selected || this.zoom > 2) {
        ctx.fillStyle = selected ? '#dbf4e9' : '#b6cbd9';
        ctx.font = `${selected ? 11 : 9}px Space, sans-serif`;
        ctx.fillText(item.name, p.x + r + 10, p.y + 3);
      }
    }
    const player = project(s.viewpoint);
    ctx.save();
    ctx.translate(player.x, player.y);
    const f = s.forward;
    ctx.rotate(Math.atan2(f.x, -f.z));
    ctx.fillStyle = '#d2f9e4';
    ctx.shadowColor = '#aae9d0';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.moveTo(0, -7);
    ctx.lineTo(4.5, 5);
    ctx.lineTo(0, 2.5);
    ctx.lineTo(-4.5, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = '#c4e9de28';
    ctx.beginPath();
    ctx.arc(player.x, player.y, 16, 0, Math.PI * 2);
    ctx.stroke();
    document.querySelector('#chart-scale').textContent =
      `${this.mode === 'system' ? s.currentSystem.name.toUpperCase() : this.mode === 'galaxy' ? 'LOCAL STAR FIELD' : 'SAVED WAYPOINTS'} / ${formatDistance(100 / scale)} PER 100 PX`;
    this.updateTarget();
  }
}
