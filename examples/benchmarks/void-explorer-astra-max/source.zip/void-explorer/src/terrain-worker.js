import { buildTerrain } from './terrain.js';
self.onmessage = ({ data }) => {
  try {
    const mesh = buildTerrain(data.body, data.options);
    self.postMessage(
      { id: data.id, bodyId: data.body.id, mesh, normal: data.options.normal },
      Object.values(mesh).map((v) => v.buffer),
    );
  } catch (error) {
    self.postMessage({ id: data.id, error: String(error) });
  }
};
