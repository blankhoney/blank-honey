import { Vector3, Quaternion, Matrix4 } from 'three';
import { hash, random, surface, clamp, tangentBasis, unit } from './terrain.js';
export const UP = new Vector3(0, 1, 0),
  FORWARD = new Vector3(0, 0, -1);
export const SECTOR = 150000,
  GEAR_HEIGHT = 3.5;
const WORDS = [
  'Altair',
  'Lyra',
  'Caldera',
  'Oberon',
  'Solace',
  'Nacre',
  'Ione',
  'Orison',
  'Sable',
  'Mira',
  'Kepler',
  'Elara',
  'Aster',
  'Nivalis',
  'Eden',
  'Solis',
];
const TYPES = ['Temperate ocean', 'Amethyst highlands', 'Glacial archipelago', 'Volcanic frontier'];
export function facing(direction, up = UP) {
  const d = direction.clone();
  if (d.lengthSq() < 1e-12) d.set(0, 0, -1);
  d.normalize();
  const u = Math.abs(d.dot(up)) > 0.995 ? (Math.abs(d.y) > 0.9 ? new Vector3(1, 0, 0) : UP) : up;
  return new Quaternion().setFromRotationMatrix(new Matrix4().lookAt(new Vector3(), d, u));
}
export class Universe {
  constructor(seed = 'AURORA-07') {
    this.seed = String(seed);
    this.seedHash = hash(seed);
    this.cache = new Map();
    this.systemCache = new Map();
  }
  get home() {
    return this.system({
      id: 'eos',
      name: 'Eos',
      seed: this.seedHash,
      position: new Vector3(-12500, 6500, -27000),
      color: '#ffd8a4',
      radius: 1300,
    });
  }
  sector(x, y, z) {
    const key = `${x},${y},${z}`;
    if (this.cache.has(key)) return this.cache.get(key);
    const rng = random(hash(`${this.seed}:${key}`)),
      stars = [];
    for (let i = 0; i < 14; i++) {
      const seed = hash(`${key}:${i}:${this.seed}`);
      stars.push({
        id: `s:${key}:${i}`,
        kind: 'system',
        name: `${WORDS[seed % WORDS.length]} ${String((seed % 899) + 100)}`,
        seed,
        position: new Vector3((x + rng()) * SECTOR, (y + rng()) * SECTOR, (z + rng()) * SECTOR),
        color: ['#c0edff', '#ffd4a1', '#e8bcff', '#ffb6cd'][seed % 4],
        radius: 700 + rng() * 900,
      });
    }
    this.cache.set(key, stars);
    if (this.cache.size > 90) this.cache.delete(this.cache.keys().next().value);
    return stars;
  }
  nearby(position) {
    const cell = position.toArray().map((v) => Math.floor(v / SECTOR)),
      stars = [this.home];
    for (let x = -1; x <= 1; x++)
      for (let y = -1; y <= 1; y++)
        for (let z = -1; z <= 1; z++)
          stars.push(...this.sector(cell[0] + x, cell[1] + y, cell[2] + z));
    return stars;
  }
  system(star) {
    if (this.systemCache.has(star.id)) return this.systemCache.get(star.id);
    const rng = random(star.seed),
      sys = { ...star, kind: 'system', planets: [] };
    if (star.id === 'eos') {
      sys.planets = [
        {
          name: 'Aethra',
          position: new Vector3(1350, -1150, -1800),
          radius: 2350,
          biome: 0,
          rings: true,
        },
        {
          name: 'Vesper',
          position: new Vector3(-6700, 2450, -13700),
          radius: 1120,
          biome: 1,
          rings: false,
        },
        {
          name: 'Thalassa',
          position: new Vector3(14400, 6500, -20000),
          radius: 1540,
          biome: 2,
          rings: false,
        },
        {
          name: 'Cinder',
          position: new Vector3(-19100, -6000, -18200),
          radius: 960,
          biome: 3,
          rings: false,
        },
      ];
    } else {
      for (let i = 0; i < 3 + (star.seed % 3); i++) {
        const angle = rng() * Math.PI * 2,
          distance = 5500 + i * 5200 + rng() * 2200;
        sys.planets.push({
          name: `${star.name.split(' ')[0]} ${['b', 'c', 'd', 'e', 'f'][i]}`,
          position: star.position
            .clone()
            .add(
              new Vector3(
                Math.cos(angle) * distance,
                (rng() - 0.5) * 3000,
                Math.sin(angle) * distance,
              ),
            ),
          radius: 850 + rng() * 1700,
          biome: (star.seed + i) % 4,
          rings: i === 1 && star.seed % 2 === 0,
        });
      }
    }
    sys.planets.forEach((p, i) =>
      Object.assign(p, {
        id: `${star.id}/p${i}`,
        kind: 'planet',
        systemId: star.id,
        seed: hash(`${star.seed}:planet${i}`),
        type: TYPES[p.biome],
      }),
    );
    this.systemCache.set(star.id, sys);
    if (this.systemCache.size > 32)
      for (const key of this.systemCache.keys())
        if (key !== 'eos' && key !== star.id) {
          this.systemCache.delete(key);
          break;
        }
    return sys;
  }
  resolve(id) {
    if (typeof id !== 'string') return null;
    if (id === 'eos') return this.home;
    if (id.endsWith('/p0') || /\/p\d+$/.test(id)) {
      const [sid, pi] = id.split('/p');
      return this.resolve(sid)?.planets[Number(pi)];
    }
    const match = /^s:(-?\d+),(-?\d+),(-?\d+):(\d+)$/.exec(id);
    if (!match || +match[4] > 13 || [match[1], match[2], match[3]].some((n) => Math.abs(+n) > 1e7))
      return null;
    return this.system(this.sector(+match[1], +match[2], +match[3])[+match[4]]);
  }
}
export function distanceTo(position, target) {
  if (target.kind === 'planet') return Math.max(0, groundAt(target, position).clearance);
  return Math.max(
    0,
    position.distanceTo(target.position) - (target.kind === 'system' ? target.radius : 0),
  );
}
export function groundAt(body, position) {
  const normal = position.clone().sub(body.position).normalize();
  const s = surface(body, normal.toArray());
  return {
    ...s,
    normal,
    altitude: position.distanceTo(body.position) - body.radius - s.height,
    clearance: position.distanceTo(body.position) - body.radius - Math.max(s.height, s.water),
  };
}
export function landingSite(body, from) {
  const center = from.clone().sub(body.position).normalize().toArray(),
    [u, v] = tangentBasis(center);
  let best = null;
  for (let i = 0; i < 500; i++) {
    const angle = i * 2.399963,
      r = Math.sqrt(i / 499) * 0.72;
    const n = unit(center.map((k, j) => k + r * (u[j] * Math.cos(angle) + v[j] * Math.sin(angle))));
    const s = surface(body, n);
    if (s.depth > 0 || s.height < 6) continue;
    const [a, b] = tangentBasis(n);
    const heights = [a, b, a.map((x) => -x), b.map((x) => -x)].map(
      (t) => surface(body, unit(n.map((k, j) => k + (t[j] * 15) / body.radius))).height,
    );
    const slope = Math.max(...heights.map((h) => Math.abs(h - s.height))) / 15;
    const score = slope * 5 + r * 0.3;
    if (slope < 0.2 && (!best || score < best.score))
      best = { normal: new Vector3(...n), height: s.height, slope, score };
  }
  if (!best) return null;
  best.position = body.position
    .clone()
    .addScaledVector(best.normal, body.radius + best.height + GEAR_HEIGHT);
  return best;
}
export function safeCourse(start, end, obstacles) {
  const points = [start.clone(), end.clone()];
  for (const body of obstacles) {
    const offset = start.clone().sub(body.position),
      radius = body.radius + (body.kind === 'planet' ? 520 : 650);
    if (offset.length() < radius && offset.length() > 1) {
      points.splice(1, 0, body.position.clone().addScaledVector(offset.normalize(), radius * 1.15));
      break;
    }
  }
  // Bounded geometric detours: keep both legs outside each body's terrain envelope.
  for (let pass = 0; pass < 20; pass++) {
    let changed = false;
    for (let i = 0; i < points.length - 1 && !changed; i++) {
      const a = points[i],
        b = points[i + 1],
        ab = b.clone().sub(a),
        lengthSq = ab.lengthSq();
      if (lengthSq < 1) continue;
      for (const body of obstacles) {
        const radius = body.radius + (body.kind === 'planet' ? 520 : 650);
        const t = clamp(body.position.clone().sub(a).dot(ab) / lengthSq, 0, 1),
          closest = a.clone().addScaledVector(ab, t),
          offset = closest.clone().sub(body.position);
        if (offset.length() >= radius || t < 0.001 || t > 0.999) continue;
        if (offset.lengthSq() < 1) {
          offset.copy(a).sub(body.position).cross(ab).normalize();
          if (offset.lengthSq() < 0.1)
            offset.set(...tangentBasis(ab.clone().normalize().toArray())[0]);
        }
        const waypoint = body.position.clone().addScaledVector(offset.normalize(), radius * 1.7);
        points.splice(i + 1, 0, waypoint);
        changed = true;
        break;
      }
    }
    if (!changed) break;
  }
  return points.slice(1);
}
export class Simulation {
  constructor(universe) {
    this.universe = universe;
    this.position = new Vector3(0, 250, 2900);
    this.orientation = facing(new Vector3(0.05, -0.045, -1));
    this.velocity = new Vector3();
    this.speed = 0;
    this.throttle = 0;
    this.energy = 100;
    this.hull = 100;
    this.gear = false;
    this.gearAmount = 0;
    this.rampAmount = 0;
    this.mode = 'flight';
    this.route = null;
    this.target = universe.home.planets[0];
    this.currentSystem = universe.home;
    this.nearbySystems = universe.nearby(this.position);
    this.bodies = [...universe.home.planets];
    this.nearestBody = this.bodies[0];
    this.visited = new Set(['eos']);
    this.discovered = new Set();
    this.waypoints = [];
    this.walker = null;
    this.lastMessage = 'Flight systems ready';
    this.time = 0;
    this.travelled = 0;
    this.boosting = false;
    this.driveCooling = false;
    this.orbitCount = 0;
    this.refresh();
  }
  get viewpoint() {
    return this.walker?.position ?? this.position;
  }
  get ground() {
    return groundAt(this.nearestBody, this.viewpoint);
  }
  get forward() {
    return FORWARD.clone().applyQuaternion(this.orientation);
  }
  get up() {
    return UP.clone().applyQuaternion(this.orientation);
  }
  message(text) {
    this.lastMessage = text;
  }
  refresh() {
    this.nearbySystems = this.universe.nearby(this.position);
    const closest = [...this.nearbySystems]
      .sort(
        (a, b) =>
          a.position.distanceToSquared(this.position) - b.position.distanceToSquared(this.position),
      )
      .slice(0, 3);
    const systems = closest.map((s) => this.universe.system(s));
    if (!systems.some((s) => s.id === this.currentSystem.id)) systems.push(this.currentSystem);
    this.bodies = systems.flatMap((s) => s.planets);
    this.nearestBody = this.bodies.reduce((a, b) =>
      distanceTo(this.viewpoint, a) < distanceTo(this.viewpoint, b) ? a : b,
    );
    const containing = systems.find((s) =>
      s.planets.some((p) => distanceTo(this.position, p) < 6000),
    );
    this.currentSystem = containing ?? systems[0];
    if (this.position.distanceTo(this.currentSystem.position) < 43000)
      this.visited.add(this.currentSystem.id);
  }
  select(target) {
    if (!target) return;
    if (target.id !== this.target?.id) this.cancel();
    this.target = target.kind === 'system' ? this.universe.system(target) : target;
    this.message(`${target.name} selected`);
  }
  cancel() {
    if (this.route) {
      this.route = null;
      this.speed = Math.min(this.speed, 90);
      this.velocity.setLength(Math.min(this.velocity.length(), 90));
      this.throttle = 0;
      this.message('Manual flight');
    }
  }
  travel() {
    if (this.mode !== 'flight') {
      this.message('Take off before engaging the pulse drive');
      return false;
    }
    const t = this.target;
    if (!t) return false;
    let end = t.position.clone();
    if (t.kind === 'planet')
      end.addScaledVector(this.position.clone().sub(t.position).normalize(), t.radius + 950);
    if (t.kind === 'system') {
      const system = this.universe.system(t);
      this.target = system;
      end = system.planets[0].position
        .clone()
        .addScaledVector(
          this.position.clone().sub(system.planets[0].position).normalize(),
          system.planets[0].radius + 1800,
        );
    }
    if (t.kind === 'waypoint') {
      for (const body of this.bodies) {
        const g = groundAt(body, end);
        if (g.clearance < 420) {
          end = body.position
            .clone()
            .addScaledVector(g.normal, body.radius + Math.max(g.height, g.water) + 420);
          break;
        }
      }
    }
    const destinationBodies =
      t.kind === 'system'
        ? this.universe.system(t).planets
        : t.kind === 'planet'
          ? this.universe.resolve(t.systemId).planets
          : [];
    const obstacles = [
      ...new Map(
        [...this.bodies, ...destinationBodies, ...this.nearbySystems].map((body) => [
          body.id,
          body,
        ]),
      ).values(),
    ];
    const points = safeCourse(this.position, end, obstacles);
    this.route = { type: 'travel', end: points.shift(), points };
    this.gear = false;
    this.message(`Pulse course set · ${t.name}`);
    return true;
  }
  land() {
    if (this.mode === 'landed') return this.takeoff();
    if (this.mode !== 'flight') return false;
    const body = this.target?.kind === 'planet' ? this.target : this.nearestBody;
    const site = landingSite(body, this.position);
    if (!site) {
      this.message('No level dry site found. Approach a different hemisphere.');
      return false;
    }
    this.target = body;
    this.gear = true;
    this.route = {
      type: 'approach',
      body,
      site,
      end: site.position.clone().addScaledVector(site.normal, 420),
    };
    this.message(`Landing assist · ${body.name} · dry terrain acquired`);
    return true;
  }
  takeoff() {
    if (this.mode !== 'landed') {
      this.message('Return to AURORA to take off');
      return false;
    }
    const body = this.landedBody,
      normal = this.position.clone().sub(body.position).normalize();
    this.mode = 'flight';
    this.walker = null;
    this.gear = false;
    this.route = {
      type: 'takeoff',
      body,
      end: this.position.clone().addScaledVector(normal, 1100),
    };
    this.message('Ramp closing · ascent initiated');
    return true;
  }
  interact() {
    if (this.mode === 'landed') {
      this.mode = 'disembarking';
      this.message('Opening the rear ramp · stand by');
      return true;
    }
    if (this.mode === 'walking') {
      const local = this.walker.position
        .clone()
        .sub(this.position)
        .applyQuaternion(this.orientation.clone().invert());
      if (
        local.z < 7.5 ||
        (local.z < 10 && Math.abs(local.x) > 1.8) ||
        Math.hypot(local.x, local.z - 17) > 15
      ) {
        this.message('Approach the illuminated rear ramp to reboard');
        return false;
      }
      const onRamp = Math.abs(local.x) < 1.7 && local.z >= 7.5 && local.z < 17;
      this.boardingPath = (
        onRamp ? [new Vector3(0, 1.3, 8.8)] : [new Vector3(0, -1.7, 17), new Vector3(0, 1.3, 8.8)]
      ).map((p) => p.applyQuaternion(this.orientation).add(this.position));
      this.mode = 'boarding';
      this.message('Boarding AURORA · following the rear ramp');
      return true;
    }
    this.message('Land before opening the ramp');
    return false;
  }
  scan() {
    if (this.target?.kind !== 'planet') {
      this.message('Select a planet to survey');
      return false;
    }
    if (distanceTo(this.viewpoint, this.target) > 12000) {
      this.message('Survey range is 12 km. Approach the target.');
      return false;
    }
    this.discovered.add(this.target.id);
    this.message(`Survey complete · ${this.target.name} recorded in your expedition log`);
    return true;
  }
  waypoint() {
    const target = {
      id: `w:${Date.now()}`,
      kind: 'waypoint',
      name: `Waypoint ${String(this.waypoints.length + 1).padStart(2, '0')}`,
      position: this.viewpoint.clone(),
    };
    this.waypoints.push(target);
    this.target = target;
    this.message(`${target.name} placed`);
    return target;
  }
  step(dt, input = {}) {
    dt = clamp(dt, 0, 0.05);
    this.time += dt;
    if (Math.floor(this.time * 2) !== Math.floor((this.time - dt) * 2)) this.refresh();
    this.gearAmount += (Number(this.gear) - this.gearAmount) * Math.min(1, dt * 3);
    const rampOpen =
      this.mode === 'walking' || this.mode === 'boarding' || this.mode === 'disembarking';
    this.rampAmount += (Number(rampOpen) - this.rampAmount) * Math.min(1, dt * 3);
    const previous = this.position.clone();
    this.boosting = false;
    if (this.mode === 'disembarking' && this.rampAmount > 0.97) {
      this.mode = 'walking';
      this.walker = {
        position: this.position
          .clone()
          .add(new Vector3(0, 1.3, 8.8).applyQuaternion(this.orientation)),
        orientation: this.orientation
          .clone()
          .multiply(new Quaternion().setFromAxisAngle(UP, Math.PI)),
      };
      this.message('Ramp open · walk forward to the surface');
    } else if (this.mode === 'walking') this.walk(dt, input);
    else if (this.mode === 'boarding') {
      const entry = this.boardingPath[0].clone();
      const delta = entry.sub(this.walker.position),
        d = delta.length();
      this.walker.position.addScaledVector(delta.normalize(), Math.min(d, 10 * dt));
      if (d < 0.3) {
        this.boardingPath.shift();
        if (!this.boardingPath.length) {
          this.mode = 'landed';
          this.walker = null;
          this.message('Welcome aboard · press Space to lift off');
        }
      }
    } else if (this.mode === 'flight') {
      if (this.route) this.navigate(dt);
      else this.fly(dt, input);
      this.collide(dt);
    }
    this.travelled += previous.distanceTo(this.position);
    this.energy = clamp(this.energy + dt * (this.boosting ? -8 : 11), 0, 100);
    if (this.energy <= 2) this.driveCooling = true;
    if (this.energy >= 35) this.driveCooling = false;
    if (!this.boosting && this.mode !== 'flight') this.hull = clamp(this.hull + dt * 2, 0, 100);
  }
  fly(dt, input) {
    const ground = groundAt(this.nearestBody, this.position),
      alt = Math.max(0, ground.clearance);
    this.throttle = clamp(this.throttle + (input.throttle ?? 0) * dt * 0.48, 0, 1);
    if (input.brake) this.throttle = 0;
    const q = new Quaternion().setFromAxisAngle(UP, -(input.yaw ?? 0) * dt * 1.15);
    this.orientation
      .multiply(q)
      .multiply(
        new Quaternion().setFromAxisAngle(new Vector3(1, 0, 0), (input.pitch ?? 0) * dt * 0.9),
      )
      .multiply(
        new Quaternion().setFromAxisAngle(new Vector3(0, 0, 1), -(input.roll ?? 0) * dt * 1.25),
      )
      .normalize();
    this.boosting = !!input.boost && this.energy > 2 && !this.driveCooling && alt > 20;
    const cap = this.gear ? 55 : clamp(95 + alt * 1.4, 95, 1600);
    const desired = this.throttle * cap * (this.boosting ? clamp(alt / 300, 1, 18) : 1);
    this.speed += (desired - this.speed) * (1 - Math.exp(-dt * (input.brake ? 7 : 2)));
    const wanted = this.forward
      .multiplyScalar(this.speed)
      .addScaledVector(this.up, (input.lift ?? 0) * clamp(alt * 0.08 + 18, 18, 120));
    this.velocity.lerp(wanted, 1 - Math.exp(-dt * 4));
    this.position.addScaledVector(this.velocity, dt);
  }
  navigate(dt) {
    const route = this.route,
      delta = route.end.clone().sub(this.position),
      distance = delta.length();
    const near = route.type === 'descend',
      takingOff = route.type === 'takeoff';
    const max = near
      ? 140
      : takingOff
        ? 320
        : route.type === 'approach'
          ? 2000
          : this.driveCooling
            ? 1200
            : 28000;
    const acceleration = near ? 45 : takingOff ? 80 : 6000;
    const desired = Math.min(max, Math.sqrt(2 * acceleration * Math.max(0, distance - 0.5)));
    this.speed += (desired - this.speed) * Math.min(1, dt * (near ? 4 : 2.2));
    const movement = Math.min(distance, this.speed * dt);
    const direction = delta.normalize();
    this.position.addScaledVector(direction, movement);
    this.velocity.copy(direction).multiplyScalar(this.speed);
    this.boosting = this.speed > 1800 && !this.driveCooling;
    this.throttle = 0;
    const normal = (route.body ?? this.nearestBody).position
      .clone()
      .sub(this.position)
      .normalize()
      .negate();
    const level = this.forward.addScaledVector(normal, -this.forward.dot(normal));
    if (level.lengthSq() < 1e-8) level.set(...tangentBasis(normal.toArray())[1]);
    else level.normalize();
    const q = facing(near || takingOff ? level : direction, normal);
    this.orientation.slerp(q, 1 - Math.exp(-dt * 2));
    if (distance < 1 || movement >= distance) {
      this.speed = 0;
      this.velocity.set(0, 0, 0);
      if (route.type === 'travel' && route.points.length) {
        route.end = route.points.shift();
      } else if (route.type === 'approach') {
        route.type = 'descend';
        route.end = route.site.position.clone();
        this.message('Final descent · gear deployed');
      } else if (route.type === 'descend') this.touchdown(route.body, route.site.normal);
      else {
        this.route = null;
        this.orbitCount += takingOff ? 1 : 0;
        this.message(
          takingOff ? 'Orbit regained · the universe is yours' : 'Arrival · pulse drive disengaged',
        );
        this.refresh();
      }
    }
  }
  touchdown(body, normal) {
    this.mode = 'landed';
    this.route = null;
    this.speed = 0;
    this.velocity.set(0, 0, 0);
    this.throttle = 0;
    this.gear = true;
    this.landedBody = body;
    let tangent = this.forward.addScaledVector(normal, -this.forward.dot(normal));
    if (tangent.length() < 0.01) tangent = new Vector3(...tangentBasis(normal.toArray())[1]);
    this.orientation.copy(facing(tangent, normal));
    this.discovered.add(body.id);
    this.message('Touchdown confirmed · press E to explore on foot');
  }
  collide(dt) {
    for (const body of this.bodies) {
      if (distanceTo(this.position, body) > 260) continue;
      const g = groundAt(body, this.position),
        clearance = this.gear ? GEAR_HEIGHT : 2.6;
      if (g.clearance < clearance) {
        this.position
          .copy(body.position)
          .addScaledVector(g.normal, body.radius + Math.max(g.height, g.water) + clearance);
        if (this.gear && this.speed < 65 && g.depth === 0 && !this.route)
          this.touchdown(body, g.normal);
        else {
          const impact = this.velocity.dot(g.normal);
          if (impact < 0) this.velocity.addScaledVector(g.normal, -impact);
          this.hull = Math.max(15, this.hull - dt * Math.max(0, this.speed - 60) * 0.12);
          if (this.route && this.route.type !== 'descend' && this.route.type !== 'takeoff') {
            this.cancel();
            this.message('Terrain proximity · course interrupted');
          }
          this.speed *= 0.82;
          this.throttle = Math.min(this.throttle, 0.15);
        }
      }
    }
    for (const star of this.nearbySystems) {
      const delta = this.position.clone().sub(star.position),
        safe = star.radius + 400;
      if (delta.length() < safe) {
        this.position.copy(star.position).addScaledVector(delta.normalize(), safe);
        this.cancel();
        this.speed = 0;
        this.message('Stellar exclusion zone · turn away from the corona');
      }
    }
  }
  walk(dt, input) {
    const body = this.landedBody,
      w = this.walker,
      g = groundAt(body, w.position),
      up = g.normal;
    w.orientation.premultiply(new Quaternion().setFromAxisAngle(up, -(input.yaw ?? 0) * dt * 1.6));
    let forward = FORWARD.clone().applyQuaternion(w.orientation);
    forward.addScaledVector(up, -forward.dot(up)).normalize();
    const right = forward.clone().cross(up).normalize();
    const direction = forward
      .multiplyScalar(input.walkForward ?? 0)
      .addScaledVector(right, input.walkSide ?? 0);
    if (direction.length() > 1) direction.normalize();
    w.position.addScaledVector(direction, (g.depth > 1.2 ? 2.5 : input.boost ? 11 : 6) * dt);
    const next = groundAt(body, w.position);
    const eye = body.radius + Math.max(next.height, next.water - 0.8) + 1.75;
    w.position.copy(body.position).addScaledVector(next.normal, eye);
    const local = w.position
      .clone()
      .sub(this.position)
      .applyQuaternion(this.orientation.clone().invert());
    for (const [x, z] of [
      [0, -7],
      [-3.4, 5.5],
      [3.4, 5.5],
    ]) {
      const dx = local.x - x,
        dz = local.z - z,
        d = Math.hypot(dx, dz);
      if (local.y < 1.1 && d < 0.7) {
        local.x = x + (d ? dx / d : 1) * 0.7;
        local.z = z + (d ? dz / d : 0) * 0.7;
      }
    }
    if (Math.abs(local.x) < 1.7 && local.z > 7 && local.z < 18) {
      const ramp = -0.45 - clamp((local.z - 8.8) / 8.2, 0, 1) * 3.0 + 1.75;
      if (local.y < ramp) local.y = ramp;
    }
    w.position.copy(this.position).add(local.applyQuaternion(this.orientation));
    w.orientation.copy(facing(FORWARD.clone().applyQuaternion(w.orientation), next.normal));
  }
}
