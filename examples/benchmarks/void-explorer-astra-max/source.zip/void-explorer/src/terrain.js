// The renderer, collision system and navigation all sample this same planet.
export const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
export const mix = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, x) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
export function hash(text) {
  let h = 2166136261;
  for (const c of String(text)) h = Math.imul(h ^ c.charCodeAt(0), 16777619);
  return h >>> 0;
}
export function random(seed) {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function lattice(x, y, z, seed) {
  let h = Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(z, 2147483647) ^ seed;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
}
export function noise(x, y, z, seed) {
  const ix = Math.floor(x),
    iy = Math.floor(y),
    iz = Math.floor(z);
  const fx = smooth(0, 1, x - ix),
    fy = smooth(0, 1, y - iy),
    fz = smooth(0, 1, z - iz);
  const n = (a, b, c) => lattice(ix + a, iy + b, iz + c, seed);
  return mix(
    mix(mix(n(0, 0, 0), n(1, 0, 0), fx), mix(n(0, 1, 0), n(1, 1, 0), fx), fy),
    mix(mix(n(0, 0, 1), n(1, 0, 1), fx), mix(n(0, 1, 1), n(1, 1, 1), fx), fy),
    fz,
  );
}
function fbm(x, y, z, seed) {
  return (
    noise(x, y, z, seed) * 0.58 +
    noise(x * 2.07, y * 2.07, z * 2.07, seed + 1) * 0.28 +
    noise(x * 4.13, y * 4.13, z * 4.13, seed + 2) * 0.14
  );
}
export const PALETTES = [
  {
    low: [0.18, 0.55, 0.43],
    high: [0.58, 0.36, 0.66],
    snow: [0.91, 0.82, 0.9],
    water: [0.06, 0.55, 0.63],
    deep: [0.055, 0.2, 0.38],
  },
  {
    low: [0.6, 0.31, 0.45],
    high: [0.78, 0.49, 0.6],
    snow: [0.97, 0.79, 0.78],
    water: [0.28, 0.24, 0.6],
    deep: [0.13, 0.1, 0.31],
  },
  {
    low: [0.3, 0.58, 0.65],
    high: [0.57, 0.63, 0.82],
    snow: [0.86, 0.96, 0.96],
    water: [0.04, 0.52, 0.62],
    deep: [0.025, 0.16, 0.31],
  },
  {
    low: [0.5, 0.32, 0.3],
    high: [0.76, 0.45, 0.33],
    snow: [0.96, 0.78, 0.56],
    water: [0.86, 0.25, 0.14],
    deep: [0.29, 0.08, 0.1],
  },
];
export function surface(body, n) {
  const { seed, biome = 0 } = body,
    x = n[0],
    y = n[1],
    z = n[2];
  const continental = fbm(x * 2.7 + 7, y * 2.7 - 3, z * 2.7 + 5, seed);
  const ridges = Math.abs(noise(x * 11, y * 11, z * 11, seed + 41) - 0.5) * 2;
  let height = (continental - 0.465) * 700 + ridges * ridges * 55;
  const riverField = Math.abs(noise(x * 6.5 + 4, y * 6.5 + 9, z * 6.5, seed + 71) - 0.5);
  const river =
    (1 - smooth(0.012, 0.042, riverField)) *
    smooth(-12, 12, height) *
    (1 - smooth(120, 170, height));
  height = mix(height, -8 - ridges * 13, river);
  height += (noise(x * 150, y * 150, z * 150, seed + 91) - 0.5) * 1.6;
  const water = biome !== 3 ? 0 : -28;
  const depth = Math.max(0, water - height);
  const p = PALETTES[biome];
  let color = p.low.map((v, i) => mix(v, p.high[i], smooth(12, 115, height)));
  const snow = smooth(135, 185, height) + smooth(0.8, 0.96, Math.abs(y)) * 0.65;
  color = color.map((v, i) => mix(v, p.snow[i], clamp(snow, 0, 1)));
  if (height < 6)
    color = color.map((v, i) => mix(v, p.snow[i], (1 - smooth(0, 6, Math.max(0, height))) * 0.27));
  if (depth > 0) color = p.water.map((v, i) => mix(v, p.deep[i], smooth(0, 100, depth)));
  return { height, water, depth, river: river > 0.65 && depth > 0, color };
}
export function unit(v) {
  const l = Math.hypot(...v) || 1;
  return v.map((x) => x / l);
}
export function tangentBasis(n) {
  const a = Math.abs(n[1]) > 0.92 ? [1, 0, 0] : [0, 1, 0];
  const u = unit([a[1] * n[2] - a[2] * n[1], a[2] * n[0] - a[0] * n[2], a[0] * n[1] - a[1] * n[0]]);
  return [u, [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]]];
}
// A complete coarse sphere stays resident while a worker builds the local patch.
// ponytail: one patch with a skirt; use a cube-sphere quadtree for continent-sized ground travel.
export function buildTerrain(body, { normal = null, size = 700, resolution = 48 } = {}) {
  const positions = [],
    colors = [],
    waterPositions = [],
    waterColors = [],
    indices = [];
  const addVertex = (n, skirt = 0) => {
    const s = surface(body, n),
      r = body.radius + s.height - skirt;
    positions.push(n[0] * r, n[1] * r, n[2] * r);
    colors.push(...s.color);
    const wr = body.radius + s.water + 0.18;
    waterPositions.push(n[0] * wr, n[1] * wr, n[2] * wr);
    const p = PALETTES[body.biome];
    waterColors.push(...p.water.map((v, i) => mix(v, p.deep[i], smooth(0, 110, s.depth))));
  };
  const grids = normal
    ? [normal]
    : [
        [1, 0, 0],
        [-1, 0, 0],
        [0, 1, 0],
        [0, -1, 0],
        [0, 0, 1],
        [0, 0, -1],
      ];
  for (const face of grids) {
    const [u, v] = tangentBasis(face),
      offset = positions.length / 3;
    const extent = normal ? size / body.radius : 1;
    for (let y = 0; y <= resolution; y++)
      for (let x = 0; x <= resolution; x++) {
        const a = ((x / resolution) * 2 - 1) * extent,
          b = ((y / resolution) * 2 - 1) * extent;
        addVertex(unit(face.map((k, i) => k + u[i] * a + v[i] * b)));
      }
    for (let y = 0; y < resolution; y++)
      for (let x = 0; x < resolution; x++) {
        const a = offset + y * (resolution + 1) + x,
          b = a + 1,
          c = a + resolution + 1,
          d = c + 1;
        indices.push(a, b, c, b, d, c);
      }
    if (normal) {
      const edge = [];
      for (let i = 0; i < resolution; i++) edge.push(offset + i);
      for (let i = 0; i < resolution; i++) edge.push(offset + i * (resolution + 1) + resolution);
      for (let i = resolution; i > 0; i--) edge.push(offset + resolution * (resolution + 1) + i);
      for (let i = resolution; i > 0; i--) edge.push(offset + i * (resolution + 1));
      const skirtStart = positions.length / 3;
      for (const index of edge) addVertex(unit(positions.slice(index * 3, index * 3 + 3)), 30);
      for (let i = 0; i < edge.length; i++) {
        const j = (i + 1) % edge.length;
        indices.push(edge[i], skirtStart + i, edge[j], edge[j], skirtStart + i, skirtStart + j);
      }
    }
  }
  return {
    positions: new Float32Array(positions),
    colors: new Float32Array(colors),
    waterPositions: new Float32Array(waterPositions),
    waterColors: new Float32Array(waterColors),
    indices: new Uint32Array(indices),
  };
}
