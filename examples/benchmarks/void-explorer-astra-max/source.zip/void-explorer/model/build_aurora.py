"""Original AURORA model. Run with Blender --background --python model/build_aurora.py.
Top-view reference governs the planform. Blender +Y = nose, +Z = up.
No reference meshes or official game assets are used.
"""
import bpy, math, json
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

def material(name, color, metallic=0.0, roughness=0.5, emission=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    node = m.node_tree.nodes.get('Principled BSDF')
    node.inputs['Base Color'].default_value = (*color, 1)
    node.inputs['Metallic'].default_value = metallic
    node.inputs['Roughness'].default_value = roughness
    node.inputs['Emission Color'].default_value = (*color, 1)
    node.inputs['Emission Strength'].default_value = emission
    return m

ivory=material('Porcelain ivory · ceramic hull',(.83,.78,.64),.32,.36)
edge=material('Warm titanium · seams',(.41,.37,.34),.7,.42)
indigo=material('Deep indigo · wing carbon',(.065,.070,.17),.42,.40)
dark=material('Graphite · engine casing',(.04,.065,.095),.7,.32)
glass=material('Emerald · faceted canopy',(.015,.40,.32),.68,.17,.22)
cyan=material('Ion cyan · engine emission',(.06,.85,1),.1,.2,5)
pink=material('Rose · navigation lights',(1,.08,.43),.1,.2,5)

def mesh(name, verts, faces, mat, parent=None):
    data=bpy.data.meshes.new(name)
    data.from_pydata(verts,[],faces)
    data.update()
    obj=bpy.data.objects.new(name,data)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat)
    if parent: obj.parent=parent
    return obj

def slab(name, outline, z, thickness, mat, mirrored=False):
    count=len(outline)
    verts=[(x,y,z) for x,y in outline]+[(x,y,z-thickness) for x,y in outline]
    faces=[tuple(range(count)),tuple(reversed(range(count,count*2)))]
    faces += [(i,(i+1)%count,(i+1)%count+count,i+count) for i in range(count)]
    obj=mesh(name,verts,faces,mat)
    if mirrored:
        modifier=obj.modifiers.new('Bilateral symmetry · X','MIRROR')
        modifier.use_clip=True
    return obj

def box(name, loc, scale, mat, parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    obj=bpy.context.object;obj.name=name
    obj.scale=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    obj.data.materials.append(mat)
    if parent: obj.parent=parent
    return obj

def bar(name,a,b,width,mat,parent=None):
    a,b=Vector(a),Vector(b)
    obj=box(name,(a+b)*.5,(width,width,(a-b).length),mat,parent)
    obj.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    return obj

# A half-shell with a live Mirror modifier keeps the editable source symmetric.
stations=[(14.4,.04,.10,-.05),(11.8,.72,.55,-.3),(7.4,1.8,1.10,-.60),(2.6,2.8,1.36,-.85),
          (-2.8,3.25,1.15,-1.0),(-8.6,3.05,.65,-.85),(-10.4,2.0,.25,-.5),(-12.3,.08,.05,-.1)]
verts=[]
for y,width,top,bottom in stations:
    verts.extend([(0,y,top),(width*.72,y,top-.08),(width,y,(top+bottom)*.5),(width*.7,y,bottom),(0,y,bottom)])
faces=[]
for i in range(len(stations)-1):
    for j in range(4): faces.append((i*5+j,i*5+j+1,(i+1)*5+j+1,(i+1)*5+j))
faces.extend([(0,1,2,3,4),tuple(reversed(range((len(stations)-1)*5,len(stations)*5)))])
shell=mesh('AURORA · mirrored ivory fuselage',verts,faces,ivory)
shell.modifiers.new('Centerline symmetry','MIRROR').use_clip=True
slab('Indigo keel',[(0,14.1),(2.8,3),(3.7,-4),(2.1,-10.3),(0,-12.1)],-.48,.5,indigo,True)

# Four separate wing surfaces. The fore and aft outlines never bridge the open gap.
fore=[(2.3,6.1),(3.65,4.65),(14.1,-3.3),(13.8,-4.3),(5.4,1.4),(3.0,.15)]
aft=[(3.5,-1.5),(5.8,-3.2),(14.15,-6.3),(13.8,-7.2),(7.5,-9.0),(3.7,-6.4)]
slab('Fore wings · independent mirrored pair',fore,.0,.25,indigo,True)
slab('Aft wings · independent mirrored pair',aft,-.18,.30,indigo,True)
slab('Fore wing ivory leading edges',[(2.4,6.05),(3.65,4.65),(14.1,-3.3),(13.65,-3.5),(3.55,4.1)],.11,.15,ivory,True)
slab('Aft wing titanium spars',[(3.8,-2.4),(5.8,-3.65),(13.6,-6.2),(13.25,-6.4),(5.7,-4.05)],-.02,.12,edge,True)
for side in [-1,1]:
    for y in [-3.8,-6.7]:
        slab(f'Wing tip cap {side} {y}',[(side*13.5,y+.45),(side*14.15,y+.5),(side*14.35,y-.4),(side*13.55,y-.4)],.13,.4,ivory)
        bar(f'Pink tip beacon {side} {y}',(side*14.27,y-.36,.2),(side*14.3,y+.18,.2),.17,pink)
    bar(f'Fore wing seam {side}',(side*4.4,2.3,.05),(side*12.5,-3.2,.05),.035,edge)
    bar(f'Aft wing seam {side}',(side*5,-4.4,-.12),(side*10,-8.1,-.12),.045,edge)

# Canopy rings create a long emerald cockpit, with visible ivory structural frames.
canopy=[(10.3,.28,.73),(8.1,.72,1.33),(5.6,1.17,1.89),(3.2,1.44,2.12),(1.25,1.37,1.65)]
cv=[]
for y,width,z in canopy: cv.extend([(-width,y,z-.5),(0,y,z),(width,y,z-.5)])
cf=[]
for i in range(len(canopy)-1):
    for j in range(2): cf.append((i*3+j,i*3+j+1,(i+1)*3+j+1,(i+1)*3+j))
cf.extend([(0,1,2),(12,13,14)])
mesh('Emerald canopy',cv,cf,glass)
for i in range(len(canopy)):
    for j in range(2):bar(f'Canopy cross frame {i} {j}',cv[i*3+j],cv[i*3+j+1],.065,ivory)
for i in range(len(canopy)-1):
    for j in range(3):bar(f'Canopy longitudinal frame {i} {j}',cv[i*3+j],cv[(i+1)*3+j],.055,edge)

slab('Dorsal center armor',[(0,.8),(1.5,.5),(2.0,-2.8),(1.6,-5.8),(.8,-7),(0,-7.4)],1.4,.34,ivory,True)
slab('Dorsal indigo service hatch',[(0,-1.1),(.55,-1.6),(.55,-2.3),(0,-2.7)],1.43,.02,indigo,True)
for side in [-1,1]:
    slab(f'Engine shoulder armor {side}',[(side*2.3,2.4),(side*3.6,1.3),(side*4.4,-7.9),(side*3.2,-9.2),(side*2.8,-4.5)],.72,.6,ivory)
    bar(f'Cyan hull inlay {side}',(side*3.55,-3,.95),(side*3.8,-7,.88),.085,cyan)
    fin=mesh(f'Vertical stabilizer {side}',[(side*2.75,-6,.65),(side*3.1,-8.4,.65),(side*2.9,-8.2,3),(side*2.8,-7.7,3.3)],[(0,1,2,3)],ivory)
    fin.modifiers.new('Fin thickness','SOLIDIFY').thickness=.17
    bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=1.04,depth=2.75,location=(side*4,-9.45,-.15),rotation=(math.pi/2,0,0))
    bpy.context.object.name=f'Twin engine barrel {side}';bpy.context.object.data.materials.append(dark)
    for y in [-8.0,-9.1,-10.0]:
        bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=1.18,depth=.65,location=(side*4,-9.4+(y+9.1),-.15),rotation=(math.pi/2,0,0))
        o=bpy.context.object;o.name=f'Twin engine housing {side} {y}';o.data.materials.append(dark)
    bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=.80,depth=.14,location=(side*4,-10.8,-.15),rotation=(math.pi/2,0,0))
    o=bpy.context.object;o.name=f'Engine core {side}';o.data.materials.append(cyan)
    bpy.ops.mesh.primitive_torus_add(major_radius=.86,minor_radius=.055,major_segments=16,minor_segments=6,location=(side*4,-10.89,-.15),rotation=(math.pi/2,0,0))
    bpy.context.object.name=f'Ion ring {side}';bpy.context.object.data.materials.append(cyan)

gear=bpy.data.objects.new('GearAssembly',None);bpy.context.collection.objects.link(gear)
for x,y in [(0,7),(-3.4,-5.5),(3.4,-5.5)]:
    bar('Landing strut',(x,y,-.6),(x,y,-3.0),.23,dark,gear)
    bar('Landing piston',(x+.12,y,-1),(x+.12,y,-2.7),.11,ivory,gear)
    box('Landing foot',(x,y,-3.22),(1.8,2.3,.38),indigo,gear)
    box('Gear status cyan',(x,y+.8,-2.7),(.25,.15,.18),cyan,gear)
ramp=bpy.data.objects.new('RampPivot',None);bpy.context.collection.objects.link(ramp)
ramp.location=(0,-8.8,-.45)
mesh('Rear boarding ramp',[(-1.55,0,0),(1.55,0,0),(1.55,-8.2,0),(-1.55,-8.2,0)],[(0,1,2,3)],indigo,ramp).modifiers.new('Ramp thickness','SOLIDIFY').thickness=.14
for side in [-1,1]:bar('Ramp guidance strip',(side*1.37,0,.07),(side*1.37,-8.2,.07),.065,cyan,ramp)
for i in range(1,10):bar('Ramp tread',(-1.25,-i*.78,.06),(1.25,-i*.78,.06),.05,edge,ramp)

# Retain live modeling modifiers in the .blend; apply a copy during GLB export.
for obj in bpy.context.scene.objects:
    if obj.type=='MESH':
        bpy.context.view_layer.objects.active=obj
        obj.select_set(True)
        # Consistent outward normals, including the mirrored right side.
        bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
        obj.select_set(False)
ROOT.joinpath('public/models').mkdir(parents=True,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'model/aurora.blend'))
bpy.ops.export_scene.gltf(filepath=str(ROOT/'public/models/aurora.glb'),export_format='GLB',export_apply=True,export_yup=True,export_extras=True)

# Command-line model plates make the silhouette reviewable without a browser.
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=24
scene.render.film_transparent=True
scene.render.resolution_x=1100;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.world.color=(.19,.22,.30)
for loc,power,size in [((8,10,25),4200,16),((-12,-6,14),3400,12),((0,-18,10),2400,10)]:
    bpy.ops.object.light_add(type='AREA',location=loc)
    light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size
    light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=(25,30,31))
camera=bpy.context.object;camera.data.type='ORTHO';camera.data.ortho_scale=39
camera.rotation_euler=(-camera.location).to_track_quat('-Z','Y').to_euler();scene.camera=camera
gear.hide_render=True;ramp.hide_render=True
for child in list(gear.children)+list(ramp.children):child.hide_render=True
scene.render.filepath=str(ROOT/'model/aurora-perspective.png');bpy.ops.render.render(write_still=True)
camera.location=(0,0,45);camera.rotation_euler=(0,0,0)
scene.render.filepath=str(ROOT/'model/aurora-top.png');bpy.ops.render.render(write_still=True)
print(json.dumps({'blend':str(ROOT/'model/aurora.blend'),'model':str(ROOT/'public/models/aurora.glb'),'objects':len(bpy.data.objects)}))
