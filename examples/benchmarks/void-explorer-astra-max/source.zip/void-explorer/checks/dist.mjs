import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync, statSync, writeFileSync } from 'node:fs';
import { resolve, dirname, relative, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'),
  dist = resolve(root, 'dist');
assert.ok(existsSync(resolve(dist, 'index.html')), 'Run npm run build first.');
const html = readFileSync(resolve(dist, 'index.html'), 'utf8'),
  sourceHtml = readFileSync(resolve(root, 'index.html'), 'utf8');
function localAsset(url, from) {
  if (url.startsWith('#') || url.startsWith('data:')) return;
  assert.ok(
    !url.startsWith('/') && !/^https?:/.test(url),
    `Asset must be relative and local: ${url}`,
  );
  const path = resolve(dirname(from), decodeURIComponent(url.split('?')[0]));
  assert.ok(path.startsWith(dist + '/'), `Asset escapes dist: ${url}`);
  assert.ok(existsSync(path), `Missing asset ${path}`);
}
for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g))
  localAsset(match[1], resolve(dist, 'index.html'));
const ids = [...sourceHtml.matchAll(/\bid="([^"]+)"/g)].map((m) => m[1]);
assert.equal(new Set(ids).size, ids.length, 'HTML IDs must be unique');
for (const file of ['src/main.js', 'src/chart.js']) {
  const code = readFileSync(resolve(root, file), 'utf8');
  for (const match of code.matchAll(/(?:\$|querySelector)\(['"]#([a-zA-Z][\w-]*)/g))
    assert.ok(ids.includes(match[1]), `UI target ${match[1]} from ${file} is missing`);
}
const files = [];
function visit(dir) {
  for (const name of readdirSync(dir)) {
    const path = resolve(dir, name);
    if (statSync(path).isDirectory()) visit(path);
    else files.push(path);
  }
}
visit(dist);
for (const path of files) {
  if (extname(path) === '.js') execFileSync(process.execPath, ['--check', path]);
  if (extname(path) === '.css')
    for (const match of readFileSync(path, 'utf8').matchAll(/url\(["']?([^)'"\s]+)["']?\)/g))
      localAsset(match[1], path);
}
assert.ok(
  files.some((p) => /terrain-worker-.*\.js$/.test(p)),
  'Terrain worker must be emitted as a local asset',
);
assert.ok(files.some((p) => p.endsWith('models/aurora.glb')));
assert.ok(files.some((p) => p.endsWith('fonts/SpaceGrotesk.ttf')));
const lock = JSON.parse(readFileSync(resolve(root, 'package-lock.json'), 'utf8'));
assert.equal(lock.packages['node_modules/three'].version, '0.186.0');
assert.ok(!html.includes('src/main.js'), 'Production HTML should reference compiled modules');
const report = {
  checkedAt: new Date().toISOString(),
  status: 'passed',
  checks: [
    'Production JavaScript parses',
    'All HTML/CSS asset references are relative and present',
    'Worker, model and font are bundled',
    'UI selectors match unique HTML IDs',
    'Dependency lock exists',
  ],
  browserAcceptance: false,
  files: files.map((p) => ({ path: relative(dist, p), bytes: statSync(p).size })),
};
writeFileSync(resolve(root, 'checks/dist-report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(
  `PASS  Static dist · ${files.length} files · relative assets · JavaScript syntax · UI selectors · locked dependencies`,
);
