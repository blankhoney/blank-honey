import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { performance } from 'node:perf_hooks';
import { Vector3 } from 'three';
import { InstancedMesh, IcosahedronGeometry, MeshBasicMaterial } from 'three/webgpu';
import { View } from '../src/render.js';
import {
  Universe,
  Simulation,
  groundAt,
  distanceTo,
  landingSite,
  SECTOR,
  facing,
} from '../src/world.js';
import { surface, buildTerrain, unit } from '../src/terrain.js';

const results = [],
  start = performance.now();
function check(name, fn) {
  const t = performance.now();
  fn();
  results.push({ name, status: 'passed', milliseconds: Math.round(performance.now() - t) });
  console.log(`PASS  ${name}`);
}
const near = (a, b, epsilon = 1e-5) =>
  assert.ok(Math.abs(a - b) < epsilon, `${a} differs from ${b}`);
const finite = (s) => {
  for (const value of [
    ...s.position.toArray(),
    ...s.orientation.toArray(),
    s.speed,
    s.energy,
    s.hull,
  ])
    assert.ok(Number.isFinite(value));
};
function advance(s, seconds, input = {}) {
  for (let i = 0; i < seconds * 60; i++) {
    s.step(1 / 60, input);
    finite(s);
  }
}
function until(s, predicate, maxSeconds = 120) {
  let ticks = 0;
  while (!predicate() && ticks < maxSeconds * 60) {
    s.step(1 / 60);
    finite(s);
    ticks++;
  }
  assert.ok(predicate(), `Journey timed out: ${s.mode} / ${s.route?.type} / ${s.lastMessage}`);
  return ticks / 60;
}
const universe = new Universe(),
  simulation = new Simulation(universe);

check('Seeded stars and planets keep coordinates across reloads and cache eviction', () => {
  const twin = new Universe();
  const stars = universe.nearby(simulation.position);
  assert.equal(stars.length, 379);
  for (const star of stars) {
    const a = universe.resolve(star.id),
      b = twin.resolve(star.id);
    assert.equal(a.name, b.name);
    assert.deepEqual(a.position.toArray(), b.position.toArray());
    assert.ok(a.planets.length >= 3);
    near(distanceTo(simulation.position, star), distanceTo(simulation.position, a));
  }
  const a = universe.home.planets[0],
    position = a.position.toArray(),
    seed = a.seed;
  for (let x = 10; x < 120; x++) universe.nearby(new Vector3(x * SECTOR, 0, 0));
  assert.deepEqual(universe.resolve(a.id).position.toArray(), position);
  assert.equal(universe.resolve(a.id).seed, seed);
  assert.ok(universe.cache.size <= 90);
  assert.ok(universe.systemCache.size <= 32);
  assert.equal(universe.resolve('s:0,0,0:999'), null);
  assert.equal(universe.resolve('bad-id'), null);
  assert.equal(universe.resolve({}), null);
});

check(
  'Every visible stellar destination is selectable and reachable by the same catalog ID',
  () => {
    for (const star of simulation.nearbySystems) {
      simulation.select(star);
      assert.equal(simulation.target.id, star.id);
      assert.equal(simulation.target.kind, 'system');
      assert.ok(simulation.target.planets.length);
    }
    simulation.select(universe.home.planets[0]);
    const before = universe.sector(0, 0, 0)[4],
      after = universe.resolve(before.id);
    assert.deepEqual(before.position.toArray(), after.position.toArray());
  },
);

check('Real scene geometry supports direct targeting away from a planet center', () => {
  const s = new Simulation(new Universe());
  const view = new View(
    { clientWidth: 1440, clientHeight: 900 },
    s,
    { quality: 'balanced' },
    () => {},
  );
  view.origin.copy(s.position);
  view.createPlanet(s.target);
  view.planets.get(s.target.id).group.position.copy(s.target.position).sub(view.origin);
  view.starCore = new InstancedMesh(new IcosahedronGeometry(1, 0), new MeshBasicMaterial(), 0);
  view.camera.aspect = 1440 / 900;
  view.camera.position.copy(new Vector3(0, 17, 54).applyQuaternion(s.orientation));
  view.camera.up.copy(s.up);
  view.camera.lookAt(s.forward.multiplyScalar(76).addScaledVector(s.up, 2));
  view.camera.updateProjectionMatrix();
  view.camera.updateMatrixWorld();
  const projected = view.project(s.target.position);
  assert.ok(projected.visible);
  assert.equal(view.pick(projected.x + 100, projected.y).id, s.target.id);
  s.travel();
  assert.ok(s.route);
  s.select(s.universe.home.planets[1]);
  assert.equal(s.route, null);
  assert.equal(s.target.id, s.universe.home.planets[1].id);
});

check('Terrain, ocean depth, rivers and both geometry resolutions use one radial field', () => {
  const body = universe.home.planets[0];
  let wet = 0,
    dry = 0,
    rivers = 0;
  for (let i = 0; i < 5000; i++) {
    const y = 1 - (2 * (i + 0.5)) / 5000,
      a = i * 2.399963,
      n = [Math.sqrt(1 - y * y) * Math.cos(a), y, Math.sqrt(1 - y * y) * Math.sin(a)],
      g = surface(body, n);
    near(g.depth, Math.max(0, g.water - g.height));
    assert.deepEqual(g, surface({ ...body }, n));
    if (g.depth > 0) wet++;
    else dry++;
    if (g.river) {
      rivers++;
      assert.ok(g.depth > 0);
    }
    const p = body.position
      .clone()
      .add(new Vector3(...n).multiplyScalar(body.radius + Math.max(g.height, g.water) + 123));
    near(groundAt(body, p).clearance, 123, 0.001);
    near(distanceTo(p, body), 123, 0.001);
  }
  assert.ok(wet > 100 && dry > 100 && rivers > 10, `wet ${wet}, dry ${dry}, rivers ${rivers}`);
  for (const options of [{ resolution: 20 }, { normal: [0, 1, 0], size: 400, resolution: 56 }]) {
    const mesh = buildTerrain(body, options);
    assert.equal(mesh.positions.length, mesh.colors.length);
    assert.equal(mesh.waterPositions.length, mesh.positions.length);
    assert.equal(mesh.indices.length % 3, 0);
    assert.ok(Math.max(...mesh.indices) < mesh.positions.length / 3);
    const primaryVertices = options.normal
      ? (options.resolution + 1) ** 2
      : mesh.positions.length / 3;
    for (let i = 0; i < primaryVertices; i += 7) {
      const p = Array.from(mesh.positions.slice(i * 3, i * 3 + 3)),
        n = unit(p),
        g = surface(body, n);
      near(Math.hypot(...p), body.radius + g.height, 0.005);
      near(
        Math.hypot(...mesh.waterPositions.slice(i * 3, i * 3 + 3)),
        body.radius + g.water + 0.18,
        0.005,
      );
    }
    for (let i = 0; i < mesh.indices.length; i += 57) {
      if (i + 2 >= mesh.indices.length) break;
      const [a, b, c] = [0, 1, 2].map((k) =>
        new Vector3().fromArray(mesh.positions, mesh.indices[i + k] * 3),
      );
      if (!options.normal)
        assert.ok(
          b.clone().sub(a).cross(c.clone().sub(a)).dot(a) > 0,
          'Planet triangles must face outward',
        );
    }
  }
});

check('Dry landing sites remain valid across deterministic universe seeds', () => {
  for (const seed of [
    'AURORA-07',
    'hello',
    '2147',
    'NEON',
    'AURORA-08',
    'sunrise',
    'void',
    '山海',
  ]) {
    const s = new Simulation(new Universe(seed)),
      site = landingSite(s.target, s.position);
    assert.ok(site, `No starting landing site for ${seed}`);
    const g = groundAt(s.target, site.position);
    assert.equal(g.depth, 0);
    assert.ok(site.slope < 0.2);
    near(g.altitude, 3.5, 0.001);
  }
});

check('Manual acceleration, angular flight, boost, braking and gear speed limits', () => {
  const s = new Simulation(new Universe());
  s.position.set(0, 30000, 15000);
  s.refresh();
  advance(s, 4, { throttle: 1 });
  const base = s.speed;
  assert.ok(base > 900);
  const q = s.orientation.clone();
  advance(s, 0.7, { yaw: 1, pitch: 0.3, roll: 0.3 });
  assert.ok(q.angleTo(s.orientation) > 0.2);
  advance(s, 1.2, { boost: true });
  assert.ok(s.speed > base * 2);
  assert.ok(s.energy < 100);
  advance(s, 3, { brake: true });
  assert.ok(s.speed < 2);
  assert.equal(s.throttle, 0);
  s.gear = true;
  advance(s, 5, { throttle: 1 });
  assert.ok(s.speed <= 55.1);
  assert.ok(s.gearAmount > 0.99);
  const previous = s.position.clone();
  s.step(5, { throttle: 1 });
  assert.ok(previous.distanceTo(s.position) < 3, 'Large frame gaps must be clamped');
  finite(s);
  assert.ok(
    facing(new Vector3(), new Vector3(0, 0, -1))
      .toArray()
      .every(Number.isFinite),
  );
});

let landingSeconds = 0,
  ascentSeconds = 0,
  systemSeconds = 0;
check('Continuous orbital approach and atmospheric descent end on dry generated terrain', () => {
  assert.ok(simulation.land());
  let previous = simulation.position.clone(),
    enteredAtmosphere = false;
  landingSeconds = until(simulation, () => {
    const step = previous.distanceTo(simulation.position);
    assert.ok(step < 55, `Unexpected position discontinuity ${step}`);
    previous.copy(simulation.position);
    if (simulation.ground.altitude < 650) enteredAtmosphere = true;
    return simulation.mode === 'landed';
  });
  assert.ok(enteredAtmosphere);
  assert.ok(landingSeconds < 40);
  assert.equal(simulation.ground.depth, 0);
  assert.ok(simulation.ground.altitude >= 3.4 && simulation.ground.altitude < 5);
  assert.ok(simulation.gear);
  assert.ok(simulation.discovered.has(simulation.target.id));
});

check('Ramp opens before exit; walking crosses ramp and follows spherical ground', () => {
  const s = simulation;
  assert.ok(s.interact());
  assert.equal(s.mode, 'disembarking');
  assert.equal(s.walker, null);
  until(s, () => s.mode === 'walking', 4);
  assert.ok(s.rampAmount > 0.97);
  const before = s.walker.position.clone();
  advance(s, 3, { walkForward: 1 });
  assert.ok(s.walker.position.distanceTo(before) > 15);
  const g = groundAt(s.landedBody, s.walker.position);
  near(g.altitude, 1.75, 0.02);
  const ship = s.position.clone();
  advance(s, 1.5, { walkSide: 1 });
  assert.deepEqual(s.position.toArray(), ship.toArray());
  near(groundAt(s.landedBody, s.walker.position).altitude, 1.75, 0.02);
  const waypoint = s.waypoint();
  near(waypoint.position.distanceTo(s.walker.position), 0);
  assert.equal(s.waypoints.length, 1);
});

check('Physical return uses the rear ramp, then lift-off continues back to orbit', () => {
  const s = simulation;
  advance(s, 1.5, { walkSide: -1 });
  advance(s, 1.9, { walkForward: -1 });
  assert.ok(s.interact(), s.lastMessage);
  assert.equal(s.mode, 'boarding');
  assert.ok(s.boardingPath.length >= 1);
  for (const point of s.boardingPath) {
    const local = point.clone().sub(s.position).applyQuaternion(s.orientation.clone().invert());
    near(local.x, 0, 0.001);
    assert.ok(local.z >= 8.79 && local.z <= 17.01);
  }
  until(s, () => s.mode === 'landed', 10);
  assert.equal(s.walker, null);
  assert.ok(s.takeoff());
  ascentSeconds = until(s, () => !s.route, 40);
  assert.ok(s.ground.altitude > 1000);
  assert.equal(s.mode, 'flight');
  assert.ok(!s.gear);
  assert.equal(s.orbitCount, 1);
});

check('Navigation distances and pulse arrivals remain consistent between planets', () => {
  const s = simulation,
    planet = s.universe.home.planets[1];
  s.select(planet);
  const before = distanceTo(s.position, planet);
  assert.ok(s.travel());
  until(s, () => !s.route, 50);
  assert.ok(distanceTo(s.position, planet) < 1300);
  assert.ok(distanceTo(s.position, planet) < before);
  assert.equal(s.target.id, planet.id);
  assert.ok(s.scan());
  assert.ok(s.discovered.has(planet.id));
});

check('Interstellar pulse travel moves continuously into another generated system', () => {
  const s = simulation;
  const star = s.nearbySystems
    .filter((star) => star.id !== 'eos')
    .sort((a, b) => a.position.distanceTo(s.position) - b.position.distanceTo(s.position))[0];
  s.select(star);
  assert.ok(s.travel());
  const endpoint = (s.route.points.at(-1) ?? s.route.end).clone();
  let previous = s.position.clone();
  systemSeconds = until(
    s,
    () => {
      assert.ok(previous.distanceTo(s.position) < 475);
      previous.copy(s.position);
      return !s.route;
    },
    90,
  );
  assert.ok(s.position.distanceTo(endpoint) < 2, `Arrival mismatch ${s.lastMessage}`);
  assert.equal(s.currentSystem.id, star.id);
  assert.ok(s.visited.has(star.id));
  const body = s.currentSystem.planets[0];
  s.select(body);
  assert.ok(s.land());
  until(s, () => s.mode === 'landed', 80);
  assert.equal(s.landedBody.id, body.id);
  assert.equal(s.ground.depth, 0);
});

check('Water collision, manual touchdown and invalid reboarding preserve state', () => {
  const s = new Simulation(new Universe()),
    body = s.target;
  let wet = null;
  for (let i = 0; i < 1000; i++) {
    const n = unit([Math.sin(i * 1.3), Math.cos(i * 0.77), Math.sin(i * 0.51)]);
    if (surface(body, n).depth > 10) {
      wet = n;
      break;
    }
  }
  assert.ok(wet);
  s.position.copy(body.position).add(new Vector3(...wet).multiplyScalar(body.radius - 20));
  s.gear = true;
  s.step(1 / 60);
  assert.equal(s.mode, 'flight');
  assert.ok(s.ground.clearance >= 3.49);
  const site = landingSite(body, s.position);
  assert.ok(site);
  s.position.copy(site.position).addScaledVector(site.normal, -1);
  s.velocity.set(0, 0, 0);
  s.speed = 0;
  s.step(1 / 60);
  assert.equal(s.mode, 'landed');
  s.interact();
  until(s, () => s.mode === 'walking', 4);
  advance(s, 20, { walkForward: 1 });
  assert.equal(s.interact(), false);
  assert.equal(s.mode, 'walking');
  assert.equal(s.takeoff(), false);
});

check('Automatic courses avoid planets across 40 routes and four universe seeds', () => {
  for (const seed of ['AURORA-07', 'NEON', 'hello', '2147']) {
    const s = new Simulation(new Universe(seed));
    const targets = [
      ...s.universe.home.planets,
      ...s.nearbySystems
        .filter((p) => p.id !== 'eos')
        .sort((a, b) => a.position.distanceTo(s.position) - b.position.distanceTo(s.position))
        .slice(0, 6),
    ];
    for (const target of targets) {
      s.select(target);
      assert.ok(s.travel());
      const end = (s.route.points.at(-1) ?? s.route.end).clone();
      until(s, () => !s.route, 120);
      assert.ok(s.position.distanceTo(end) < 2, `${seed}: ${target.name}: ${s.lastMessage}`);
    }
  }
});

check('Pulse capacitor cools and recovers without rapid on-off flicker', () => {
  const s = new Simulation(new Universe());
  s.position.set(0, 30000, 20000);
  s.refresh();
  s.throttle = 1;
  let entered = 0,
    recovered = 0;
  for (let i = 0; i < 1800; i++) {
    s.step(1 / 60, { boost: true });
    if (s.driveCooling && !entered) entered = s.time;
    if (entered && !s.driveCooling) {
      recovered = s.time;
      break;
    }
    assert.ok(s.energy >= 0 && s.energy <= 100);
  }
  assert.ok(entered > 10);
  assert.ok(recovered - entered > 2.8);
  assert.ok(s.energy >= 35);
});

check(
  'Generated GLB is original, textured by materials and has separate mirrored wing pairs',
  () => {
    const raw = readFileSync(new URL('../public/models/aurora.glb', import.meta.url));
    assert.equal(raw.readUInt32LE(0), 0x46546c67);
    assert.equal(raw.readUInt32LE(4), 2);
    assert.equal(raw.readUInt32LE(8), raw.length);
    const gltf = JSON.parse(raw.subarray(20, 20 + raw.readUInt32LE(12)).toString());
    const wings = gltf.nodes.filter((n) => n.name?.includes('wings · independent mirrored pair'));
    assert.equal(wings.length, 2);
    assert.ok(gltf.nodes.some((n) => n.name === 'GearAssembly'));
    assert.ok(gltf.nodes.some((n) => n.name === 'RampPivot'));
    assert.ok(gltf.nodes.some((n) => n.name === 'Emerald canopy'));
    assert.equal(gltf.images, undefined);
    const chunkOffset = 20 + raw.readUInt32LE(12),
      bin = raw.subarray(chunkOffset + 8);
    for (const wing of wings) {
      for (const primitive of gltf.meshes[wing.mesh].primitives) {
        const accessor = gltf.accessors[primitive.attributes.POSITION],
          buffer = gltf.bufferViews[accessor.bufferView],
          offset = (buffer.byteOffset || 0) + (accessor.byteOffset || 0),
          stride = buffer.byteStride || 12;
        const vertices = [];
        for (let i = 0; i < accessor.count; i++)
          vertices.push([0, 1, 2].map((k) => bin.readFloatLE(offset + i * stride + k * 4)));
        assert.ok(vertices.some((v) => v[0] > 13) && vertices.some((v) => v[0] < -13));
        for (const v of vertices)
          assert.ok(
            vertices.some(
              (w) =>
                Math.abs(v[0] + w[0]) < 0.001 &&
                Math.abs(v[1] - w[1]) < 0.001 &&
                Math.abs(v[2] - w[2]) < 0.001,
            ),
            'Wing geometry must be mirrored',
          );
      }
    }
  },
);

const report = {
  checkedAt: new Date().toISOString(),
  scope:
    'Command-line simulation, procedural geometry and original GLB validation. No browser or graphics-driver acceptance was performed.',
  results,
  journeySeconds: { landing: landingSeconds, ascent: ascentSeconds, interstellar: systemSeconds },
  totalMilliseconds: Math.round(performance.now() - start),
};
writeFileSync(
  new URL('./journey-report.json', import.meta.url),
  JSON.stringify(report, null, 2) + '\n',
);
console.log(
  `\n${results.length} checks passed · landing ${landingSeconds.toFixed(1)} s · ascent ${ascentSeconds.toFixed(1)} s · stellar transit ${systemSeconds.toFixed(1)} s`,
);
