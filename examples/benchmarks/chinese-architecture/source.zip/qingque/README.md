# 青阙 QINGQUE

可运行的 Three.js 中国古典建筑体素场景。六座建筑构成对称院落，进入页面即显示全貌，可旋转、缩放、平移与切换晨昏光景。

## 直接观看

双击 `standalone/qingque.html` 即可用现代桌面浏览器打开。这个约 516 KB 的单文件已经内嵌脚本、样式与图标，无需安装、联网或启动服务器。浏览器须支持 WebGL 2 并启用硬件加速。

本次交付也已启动生产预览：<http://127.0.0.1:4174/>。这个地址仅在本机预览进程运行期间有效。

## 开发运行

需要 Node.js 22.12+。

```sh
cd /Users/blankhoney/Documents/Codex/2026-09-14/benchmark-chinese-architecture/outputs/qingque
npm ci
npm run dev
```

打开终端输出的地址，默认是 <http://127.0.0.1:5173/>。如果默认端口被占用，Vite 会显示另一个可用端口。

```sh
# 构建静态网站到 dist/
npm run build

# 本地查看构建产物
npm run preview -- --port 4174

# 修改源代码后重新生成可双击的单文件
npm run build:standalone
```

`dist/` 可部署到任何静态文件服务器。Vite 开发模式和生产预览只负责提供文件，无应用后端。双击观看请使用 `standalone/qingque.html`；模块化的 `dist/index.html` 应经 HTTP 服务打开。

## 场景与操作

- 六座主体建筑：中轴北端的最大体量重檐主殿、面向庭院的东西配殿、前端三开间山门，以及对称的三层钟楼、鼓楼。
- 68 × 70 场地，以山门—石板庭院—主殿台阶为主路，横向支路连接配殿，庭院保留足够的观赏与通行空间。
- 矩形庑殿式坡面、重檐与攒尖式塔顶，瓦片阶梯、翘角、屋脊饰件、斗拱、红柱、木格窗、栏杆、石狮和灯笼均由方块组合。
- 环境包括草地、院墙、松树、石景、对称莲池、石灯和香炉。晨光与暮色改变光源方向、色彩、强度及灯笼自发光。
- 鼠标左键拖动旋转，滚轮缩放，右键拖动平移；触屏单指旋转、双指缩放和平移。
- 下方工具栏提供全景／中轴／俯瞰、自动环绕、重置视角和 PNG 场景截图。截图保存三维画面，不包含页面工具栏。
- 右上角可切换光景与建筑标注；“营造手记”介绍场景。

这是中国古典建筑主题的艺术化体素作品，不是特定文物的测绘复原。

## 项目结构

```text
qingque/
├── index.html                  页面与交互界面
├── favicon.svg                 本地图标
├── src/
│   ├── main.js                 体素生成、实例化、光影、相机与交互
│   └── style.css               响应式页面样式
├── scripts/
│   └── build-standalone.mjs    内嵌脚本与样式的单文件生成器
├── standalone/qingque.html     可直接双击观看的交付文件
├── vite.config.js
├── package.json
├── package-lock.json
├── VALIDATION.md               本次实际运行记录
└── dist/                       已构建的静态网站
```

## 性能设计

11,391 块体素使用共享方块几何体，按实体、水面、灯笼三类材质合并到 `InstancedMesh`。配合静态阴影缓存、2048² 阴影贴图和最高 1.75 的渲染像素比，减少重复绘制。页面隐藏时暂停渲染，用户要求减少动态效果时关闭视角过渡动画。

本机 Chrome 的生产构建在 1440 × 900 视口持续环绕实测约 60 FPS，详见 `VALIDATION.md`。其他设备的实际帧率取决于 GPU、屏幕分辨率和浏览器配置。

使用的官方技术资料：[InstancedMesh](https://threejs.org/docs/pages/InstancedMesh.html)、[OrbitControls](https://threejs.org/docs/pages/OrbitControls.html)、[Three.js 阴影](https://threejs.org/manual/en/shadows.html)。项目未使用外部模型、图片、字体服务或运行时 CDN。
