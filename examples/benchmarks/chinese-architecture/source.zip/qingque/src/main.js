import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import './style.css';

const host = document.querySelector('#scene');
const scene = new THREE.Scene();
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.25;
host.appendChild(renderer.domElement);
renderer.domElement.setAttribute('aria-label', '青阙三维庭院：鼠标拖动旋转，滚轮缩放，右键平移');
renderer.domElement.setAttribute('tabindex', '0');
const camera = new THREE.OrthographicCamera(-60, 60, 45, -45, .1, 450);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = .065;
controls.minZoom = .65;
controls.maxZoom = 3.5;
controls.maxPolarAngle = Math.PI / 2.13;
controls.minPolarAngle = .12;
controls.autoRotateSpeed = .45;
controls.target.set(0, 2, 0);
controls.enablePan = true;
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const hemi = new THREE.HemisphereLight('#e9f0dc', '#77765b', 2.4);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffe3ae', 3.6);
sun.position.set(-38, 65, 32);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -58, right: 58, top: 58, bottom: -58, near: 1, far: 160 });
sun.shadow.normalBias = .12;
sun.shadow.bias = -.00012;
scene.add(sun);
const fill = new THREE.DirectionalLight('#c8e0de', .55);
fill.position.set(32, 24, -30);
scene.add(fill);
scene.background = new THREE.Color('#edece5');
const ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshStandardMaterial({ color: '#edece5', roughness: 1 }));
ground.rotation.x = -Math.PI / 2;
ground.position.y = -3.65;
ground.receiveShadow = true;
scene.add(ground);

// All architectural cubes share one geometry and a small set of instanced materials.
const batches = { solid: [], water: [], glow: [] };
let seed = 1977;
const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const C = { stone:'#b1b0a1', light:'#d1ceba', trim:'#e3d6b3', darkStone:'#8b9180', red:'#963d2e', redLight:'#b54b35', wood:'#583c29', gold:'#bc863b', goldLight:'#d4a753', tile:'#456b65', tileLight:'#64837a', tileDark:'#31514e', soil:'#8a8d6b', grass:'#8b9c69', moss:'#687e52', leaf:'#6b8855', leafLight:'#91a568', leafDark:'#426446', trunk:'#6c5338' };
function box(x,y,z,w,h,d,color, variation=0, type='solid', rotation=0) {
  const col = new THREE.Color(color);
  if (variation) col.multiplyScalar(1 + (random()-.5)*variation);
  batches[type].push({ x,y,z,w,h,d,color:col,rotation });
}
function builder(cx,cz,rotation=0) {
  const cs=Math.cos(rotation), sn=Math.sin(rotation);
  return (x,y,z,w,h,d,c,v=0,type='solid')=>box(cx+x*cs+z*sn,y,cz-x*sn+z*cs,w,h,d,c,v,type,rotation);
}
function ao(x,z,w,d) {
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w,d),new THREE.MeshBasicMaterial({color:'#2b3e28',transparent:true,opacity:.1,depthWrite:false}));
  mesh.rotation.x=-Math.PI/2;mesh.position.set(x,.052,z);scene.add(mesh);
}
// A lifted, layered voxel terrain block, with intentionally stepped edges.
box(0,-1.8,0,68,3.5,70,C.soil);
box(0,-.4,0,68,1,70,C.grass);
for(let x=-33;x<=33;x+=2) for(let z=-34;z<=34;z+=2) {
  box(x,.015,z,1.98,.13,1.98,random()>.83?'#929f70':C.grass,.16);
  if(Math.abs(x)>31 || Math.abs(z)>32) {
    box(x,-1.9,z,1.98,2.3+random()*.7,1.98,random()>.45?C.soil:'#969779',.18);
    if(random()>.6) box(x,-.24,z,1.8,.25,1.8,C.moss,.16);
  }
}
// Main stone courtyard and the processional path.
for(let x=-12;x<=12;x+=1.5)for(let z=-10;z<=21.5;z+=1.5)box(x,.12,z,1.46,.16,1.46,'#bcbca7',.12);
for(let z=-10;z<34;z+=1.25)for(let x=-2.5;x<=2.5;x+=1.25)box(x,.235,z,1.20,.13,1.20,'#d2ceba',.1);
for(const side of [-1,1]) {
  for(let x=7.5;x<=25;x+=1.5)for(let z=-7;z<-.5;z+=1.5)box(side*x,.13,z,1.46,.17,1.46,'#bcbca7',.12);
  for(let z=-24;z<=25;z+=1.5)box(side*28,.11,z,1.48,.17,1.46,C.stone,.15);
  for(let x=3.8;x<=26;x+=1.3)box(side*x,.12,22,1.26,.2,2.5,C.stone,.12);
}
// Drainage / edging to anchor the paving.
for(let z=-10;z<=22;z+=1)for(const side of [-1,1])box(side*13,.11,z,.25,.28,.94,C.darkStone,.12);

function roof(b,w,d,y,rise,color,hip=true) {
  const step=.6, nx=Math.round(w/step), nz=Math.round(d/step);
  const sx=w/nx, sz=d/nz;
  for(let i=0;i<nx;i++)for(let j=0;j<nz;j++) {
    const x=-w/2+sx*(i+.5), z=-d/2+sz*(j+.5);
    const edgeZ=d/2-Math.abs(z), edgeX=w/2-Math.abs(x);
    const dist=hip?Math.min(edgeX,edgeZ):edgeZ;
    const t=Math.max(0,dist/(d/2));
    const curve=rise*Math.pow(t,1.65);
    const corner=Math.pow(Math.max(0,1-edgeX/2.4),2)*Math.pow(Math.max(0,1-edgeZ/2.4),2)*1.65;
    const eave=.23*Math.pow(Math.max(0,1-dist/1.5),2);
    const yy=y+Math.round((curve+corner+eave)/.18)*.18;
    const edge=i===0||i===nx-1||j===0||j===nz-1;
    b(x,yy,z,sx*.985,.3,sz*.985,edge?(color===C.gold?C.goldLight:'#91a186'):color,.19);
    if(edge)b(x,yy-.28,z,sx,.22,sz,C.wood,.12);
    // Alternating raised tile ribs give the roofs a legible miniature scale.
    if(i%2===0 && !edge)b(x,yy+.19,z,.11,.12,sz*.9,color===C.gold?C.goldLight:C.tileLight,.15);
  }
  const ridge=Math.max(.6,w-d);
  for(let x=-ridge/2;x<=ridge/2;x+=.55)b(x,y+rise+.18,0,.56,.43,.46,color===C.gold?C.goldLight:C.tileLight,.14);
  for(const s of [-1,1]){
    b(s*(ridge/2+.2),y+rise+.45,0,.45,.8,.5,C.gold);
    b(s*(ridge/2+.38),y+rise+.85,0,.65,.28,.45,C.goldLight);
  }
  for(const x of [-1,1])for(const z of [-1,1]) {
    b(x*(w/2-.25),y+1.4,z*(d/2-.25),.45,.65,.45,C.gold);
    b(x*(w/2-.08),y+1.77,z*(d/2-.08),.35,.25,.35,C.goldLight);
  }
}
function lantern(b,x,y,z) {
  b(x,y+.6,z,.09,.6,.09,C.wood);
  b(x,y,z,.62,.8,.62,'#d36b36',.1,'glow');
  b(x,y+.43,z,.72,.13,.72,C.gold);
  b(x,y-.43,z,.65,.13,.65,C.gold);
  b(x,y-.75,z,.09,.5,.09,'#b95432');
}
function platform(b,w,d,base=1.35) {
  b(0,.33,0,w+2,.65,d+2,C.darkStone,.05);
  b(0,.79,0,w+1.5,.43,d+1.5,C.stone);
  b(0,base-.18,0,w+1.8,.36,d+1.8,C.light);
  for(let i=0;i<5;i++)b(0,.13+i*.23,d/2+3.2-i*.48,w*.40,.25,.56,C.light,.06);
  // Balustrades flank the approach, leaving the central stairs clear.
  for(const s of [-1,1]) {
    for(let x=w*.29;x<=w/2+.55;x+=1.25) {
      b(s*x,base+.63,d/2+.65,.23,1.26,.23,C.light);
      b(s*x,base+1.31,d/2+.65,.39,.19,.39,C.trim);
    }
    b(s*(w*.39),base+.93,d/2+.65,w*.25,.2,.2,C.light);
  }
}
function hall(cx,cz,w,d,{main=false,rotation=0,gate=false}={}) {
  const b=builder(cx,cz,rotation), base=1.35, h=main?6.5:4.6;
  platform(b,w,d,base);
  // Wall volumes behind an open colonnade.
  if(gate) {
    for(const s of [-1,1])b(s*w*.35,base+h/2,-d*.23,w*.23,h,d*.50,C.red,.05);
  } else b(0,base+h/2,-d*.23,w-.9,h,d*.50,C.red,.05);
  if(!gate)b(0,base+h/2,d*.03,w-1.3,h,.28,C.redLight);
  else for(const s of [-1,1])b(s*w*.35,base+h/2,d*.04,w*.23,h,.35,C.redLight);
  b(0,base+.2,0,w-.45,.35,d-.5,C.wood);
  const cols=main?7:gate?4:5;
  for(let i=0;i<cols;i++) {
    const x=-w/2+.65+i*(w-1.3)/(cols-1);
    for(const z of [-d/2+.55,d/2-.55]) {
      b(x,base+.2,z,.74,.42,.74,C.darkStone);
      b(x,base+h/2+.1,z,.43,h,.43,C.redLight,.1);
      b(x,base+h-.1,z,.68,.22,.68,C.gold);
      for(let k=0;k<3;k++) {
        b(x,base+h+.1+k*.25,z,.7+k*.36,.2,.34,C.wood);
        b(x,base+h+.15+k*.25,z,.28,.2,.72+k*.38,k===1?C.gold:C.redLight);
      }
    }
  }
  for(const z of [-d/2+.5,d/2-.5]) {
    b(0,base+h-.32,z,w,.33,.39,C.tileDark);
    b(0,base+h+.1,z,w+.5,.25,.45,C.gold);
  }
  for(let i=0;i<cols-1;i++) {
    const x=-w/2+.65+(i+.5)*(w-1.3)/(cols-1), width=(w-1.3)/(cols-1)-.36;
    if(gate && Math.abs(x)<w*.22)continue;
    b(x,base+2.15,d*.052+.18,width,3.7,.16,C.wood);
    b(x,base+2.75,d*.052+.28,width-.2,2.1,.1,'#a19162');
    for(let j=-2;j<=2;j++)b(x+j*(width-.25)/5,base+2.75,d*.052+.36,.085,2.1,.1,C.wood);
    for(let j=0;j<4;j++)b(x,base+1.78+j*.63,d*.052+.38,width-.15,.09,.13,C.wood);
    b(x,base+.62,d*.052+.28,width-.24,.72,.11,C.red);
  }
  for(const s of [-1,1])lantern(b,s*w*.34,base+h-1.1,d/2-.6);
  const eaveY=base+h+.9;
  roof(b,w+3.7,d+3.8,eaveY,main?3.6:3,main?C.gold:C.tile);
  if(main) {
    b(0,eaveY+2.9,0,w-4,2.1,d-3.7,C.red);
    for(let x=-w/2+2.5;x<=w/2-2;x+=1.5)b(x,eaveY+3.2,(d-3.7)/2+.04,.16,1.3,.17,C.gold);
    roof(b,w-.4,d+.4,eaveY+4,3.35,C.gold);
  }
  // A recessed plaque with a three-character gold mark, kept entirely voxel-built.
  b(0,base+h-.7,d/2-.26,main?3.3:2.4,.93,.22,C.tileDark);
  for(let i=-1;i<=1;i++) {
    b(i*.62,base+h-.7,d/2-.12,.09,.44,.08,C.goldLight);
    b(i*.62,base+h-.68,d/2-.12,.37,.08,.08,C.goldLight);
    b(i*.62,base+h-.86,d/2-.12,.3,.06,.08,C.goldLight);
  }
  ao(cx,cz,rotation?d+3:w+3,rotation?w+3:d+3);
}
hall(0,-18,19,10,{main:true});
hall(-21,-5,12,7.4,{rotation:Math.PI/2});
hall(21,-5,12,7.4,{rotation:-Math.PI/2});
hall(0,23,11.5,5.5,{gate:true});

function tower(cx,cz) {
  const b=builder(cx,cz);
  platform(b,6,6,1.35);
  for(let level=0;level<3;level++) {
    const w=5.5-level*.8, y=1.35+level*4.6;
    b(0,y+1.7,0,w,3.4,w,level===0?C.red:C.wood);
    for(const x of [-1,1])for(const z of [-1,1])b(x*(w/2-.12),y+1.8,z*(w/2-.12),.35,3.6,.35,C.redLight);
    for(const s of [-1,1]) {
      b(0,y+1.9,s*(w/2+.01),w*.49,1.7,.15,'#a39663');
      b(s*(w/2+.01),y+1.9,0,.15,1.7,w*.49,'#a39663');
      for(let k=-1;k<=1;k++) {
        b(k*.6,y+1.9,s*(w/2+.12),.13,1.8,.12,C.wood);
        b(s*(w/2+.12),y+1.9,k*.6,.12,1.8,.13,C.wood);
      }
      b(0,y+.5,s*(w/2+.3),w+.8,.2,.24,C.gold);
      b(s*(w/2+.3),y+.5,0,.24,.2,w+.8,C.gold);
    }
    roof(b,w+2.7,w+2.7,y+3.5,1.9,C.tile);
    if(level===2) {
      b(0,y+6,0,.42,1.1,.42,C.gold);
      b(0,y+6.65,0,.72,.33,.72,C.goldLight);
      b(0,y+7.03,0,.23,.5,.23,C.gold);
    }
  }
  ao(cx,cz,9,9);
}
tower(-23,19);tower(23,19);

// Perimeter walls, tiled caps and rhythmically spaced wall piers.
for(const s of [-1,1]) {
  for(let x=8;x<=30;x+=1) {
    box(s*x,1.35,27,.98,2.55,.7,'#d3cbb5',.08);
    box(s*x,2.74,27,1.03,.23,1.05,C.tileDark,.1);
    box(s*x,2.96,27,.99,.21,.62,C.tile,.1);
  }
  for(let z=-29;z<=27;z+=1) {
    box(s*30,1.25,z,.7,2.35,.98,'#ccc8b2',.1);
    box(s*30,2.55,z,1.1,.28,1.02,C.tileDark,.1);
    if(z%7===0)box(s*30,1.5,z,1.15,3,1.15,'#b5b39e');
  }
}
for(let x=-30;x<=30;x+=1) {
  box(x,1.2,-29,.98,2.3,.7,'#ccc8b2',.08);
  box(x,2.51,-29,1.02,.27,1.1,C.tileDark,.1);
}
// Two mirror pools with lily pads and warm stone borders.
for(const s of [-1,1]) {
  const cx=s*8,cz=11;
  box(cx,.17,cz,6,.3,7,C.darkStone);
  box(cx,.35,cz,5.6,.22,6.6,'#588983',.02,'water');
  for(const x of [-1,1])box(cx+x*3,.37,cz,.45,.5,7.5,C.light);
  for(const z of [-1,1])box(cx,.37,cz+z*3.55,6.3,.5,.45,C.light);
  for(let j=0;j<7;j++) {
    const x=cx+(random()-.5)*4,z=cz+(random()-.5)*5;
    box(x,.5,z,.55,.06,.55,'#6e8f58',.2);
    if(j%3===0)box(x,.62,z,.21,.21,.21,'#ceac87');
  }
  // Garden beds beside the front approach.
  box(s*17,.15,11,5,.23,4,C.moss);
}
function pine(x,z,height=8) {
  box(x,height*.36,z,.62,height*.72,.65,C.trunk,.18);
  box(x-.8,height*.56,z,2.1,.42,.4,C.trunk);
  box(x+.7,height*.72,z+.4,1.7,.35,.4,C.trunk);
  for(let tier=0;tier<3;tier++) {
    const width=(3-tier*.65)*(height/8),cy=height*.53+tier*height*.2;
    for(let i=-width;i<=width;i+=.72)for(let j=-width;j<=width;j+=.72) {
      if(Math.abs(i)+Math.abs(j)>width*1.65||random()<.13)continue;
      const y=cy+((1-Math.max(Math.abs(i),Math.abs(j))/width)*.6);
      box(x+i+(tier===1?-.55:.2),y,z+j,.82,.65+random()*.3,.82,[C.leaf,C.leafLight,C.leafDark][Math.floor(random()*3)],.12);
    }
  }
}
for(const s of [-1,1]) {
  pine(s*26,-23,9.5);pine(s*16,-26,7.5);pine(s*26,5,8);pine(s*17,11,7);pine(s*29,30,6);pine(s*30,-32,8);
  // Voxel rockeries and low shrubs.
  for(const [x,z] of [[17,3],[26,-15],[15,19],[25,30]]) {
    for(let i=0;i<6;i++)box(s*x+(random()-.5)*2,.4+random()*.4,z+(random()-.5)*2,.7+random()*.7,.5+random(),.7+random()*.6,i%2?C.darkStone:C.stone,.13);
  }
  for(let z=-19;z<=17;z+=6) {
    const x=s*11.7;
    box(x,.55,z,.9,1,.9,C.stone);
    box(x,1.2,z,.52,.5,.52,C.light);
    box(x,1.65,z,.5,.55,.5,'#e4b15c',0,'glow');
    box(x,2,z,1,.2,1,C.tileDark);
    box(x,2.2,z,.62,.2,.62,C.tile);
  }
}
function lion(x,z) {
  box(x,.42,z,1.5,.65,1.7,C.darkStone);
  box(x,.85,z,1.3,.22,1.5,C.light);
  box(x,1.55,z,.85,1.25,1.1,C.stone);
  box(x,2.3,z+.23,1.1,1,1,C.light);
  box(x,2.2,z+.8,.8,.5,.45,C.stone);
  for(const s of [-1,1]) {
    box(x+s*.36,2.88,z+.18,.28,.32,.3,C.stone);
    box(x+s*.32,2.48,z+.76,.13,.15,.09,C.wood);
    box(x+s*.45,1.2,z+.6,.3,.6,.65,C.light);
  }
  box(x+.3,.98,z+1,.5,.5,.5,C.stone);
}
for(const s of [-1,1]) {lion(s*5.2,28.2);lion(s*5.4,-9.4);}
// A central ceremonial bronze incense burner.
box(0,.4,1,2.4,.45,2.4,C.light);
for(const x of [-.6,.6])for(const z of [-.6,.6])box(x,.9,1+z,.22,.7,.22,C.tileDark);
box(0,1.4,1,1.65,.7,1.65,'#63775e');
box(0,1.85,1,1.95,.2,1.95,C.gold);
box(0,2.25,1,1.4,.6,1.4,C.tileDark);
box(0,2.7,1,2.2,.25,2.2,C.tile);
box(0,2.96,1,1.35,.27,1.35,C.tile);
box(0,3.24,1,.6,.3,.6,C.gold);
for(const s of [-1,1])box(s*1.02,1.85,1,.25,.9,.3,C.gold);

// Instanced rendering: one draw call per material for tens of thousands of blocks.
const geometry = new THREE.BoxGeometry(1,1,1);
const materials = {
  solid:new THREE.MeshStandardMaterial({roughness:.91,metalness:0}),
  water:new THREE.MeshStandardMaterial({roughness:.24,metalness:.25}),
  glow:new THREE.MeshStandardMaterial({roughness:.65,emissive:'#e99435',emissiveIntensity:.22})
};
const dummy = new THREE.Object3D();
let voxelCount=0;
for(const [type,items] of Object.entries(batches)) {
  const mesh=new THREE.InstancedMesh(geometry,materials[type],items.length);
  items.forEach((v,i)=>{
    dummy.position.set(v.x,v.y,v.z);dummy.rotation.set(0,v.rotation,0);dummy.scale.set(v.w,v.h,v.d);dummy.updateMatrix();
    mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,v.color);
  });
  mesh.castShadow=type==='solid';mesh.receiveShadow=type!=='glow';
  mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true;
  mesh.computeBoundingSphere();mesh.name=`${type}-voxels`;scene.add(mesh);voxelCount+=items.length;
}
renderer.shadowMap.needsUpdate=true;
document.querySelector('#voxel-count').textContent=`${voxelCount.toLocaleString()} 块体素，汇成一方天地。`;

const labelData=[['太和主殿',0,19,-18],['西配殿',-21,11,-5],['东配殿',21,11,-5],['山门',0,11,23],['钟楼',-23,19,19],['鼓楼',23,19,19]];
const labelNodes=labelData.map(([name,x,y,z])=>{
  const el=document.createElement('span');el.className='building-label';el.textContent=name;el.hidden=true;
  document.querySelector('#building-labels').appendChild(el);return {el,point:new THREE.Vector3(x,y,z)};
});
let showLabels=false, tween=null, theme='day';
const views={overview:{position:[83,75,102],target:[0,2,0],zoom:1},front:{position:[0,67,118],target:[0,2,0],zoom:1},top:{position:[0,140,1],target:[0,0,0],zoom:1.08}};
function setView(name,instant=false) {
  const v=views[name];
  controls.autoRotate=false;document.querySelector('#rotate').classList.remove('active');document.querySelector('#rotate').setAttribute('aria-pressed','false');
  document.querySelectorAll('[data-view]').forEach(b=>{b.classList.toggle('active',b.dataset.view===name);b.setAttribute('aria-pressed',String(b.dataset.view===name));});
  if(instant||reducedMotion){camera.position.fromArray(v.position);controls.target.fromArray(v.target);camera.zoom=v.zoom;camera.updateProjectionMatrix();controls.update();tween=null;}
  else tween={start:performance.now(),from:camera.position.clone(),to:new THREE.Vector3(...v.position),targetFrom:controls.target.clone(),targetTo:new THREE.Vector3(...v.target),zoomFrom:camera.zoom,zoomTo:v.zoom};
}
function resize(){
  const w=host.clientWidth,h=host.clientHeight,aspect=w/h;
  const height=Math.max(88,100/aspect);
  camera.left=-height*aspect/2;camera.right=height*aspect/2;camera.top=height/2;camera.bottom=-height/2;
  camera.setViewOffset(w,h,w>700?-w*.075:0,w<=700?-h*.075:0,w,h);
  camera.updateProjectionMatrix();renderer.setSize(w,h);
}
window.addEventListener('resize',resize);resize();setView('overview',true);
controls.addEventListener('start',()=>{tween=null;document.querySelectorAll('[data-view]').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});});
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
document.querySelector('#reset').addEventListener('click',()=>setView('overview'));
document.querySelector('#rotate').addEventListener('click',e=>{
  tween=null;controls.autoRotate=!controls.autoRotate;
  e.currentTarget.classList.toggle('active',controls.autoRotate);e.currentTarget.setAttribute('aria-pressed',String(controls.autoRotate));
});
document.querySelector('#labels').addEventListener('click',e=>{
  showLabels=!showLabels;e.currentTarget.classList.toggle('active',showLabels);e.currentTarget.setAttribute('aria-pressed',String(showLabels));
  document.querySelector('#building-labels').setAttribute('aria-hidden',String(!showLabels));labelNodes.forEach(({el})=>el.hidden=!showLabels);
});
function setLight(value){
  theme=value;const dusk=value==='dusk';document.body.classList.toggle('dusk',dusk);
  scene.background.set(dusk?'#364b49':'#edece5');ground.material.color.set(dusk?'#485955':'#edece5');
  hemi.color.set(dusk?'#a3b7d1':'#e9f0dc');hemi.groundColor.set(dusk?'#62674e':'#77765b');hemi.intensity=dusk?1.35:2.4;
  sun.color.set(dusk?'#ffb675':'#ffe3ae');sun.intensity=dusk?2.5:3.6;sun.position.set(dusk?-50:-38,dusk?25:65,dusk?-15:32);
  fill.intensity=dusk?.85:.55;materials.glow.emissiveIntensity=dusk?2:.22;
  renderer.toneMappingExposure=dusk?1.1:1.25;renderer.shadowMap.needsUpdate=true;
  document.querySelectorAll('[data-light]').forEach(b=>{b.classList.toggle('active',b.dataset.light===value);b.setAttribute('aria-pressed',String(b.dataset.light===value));});
}
document.querySelectorAll('[data-light]').forEach(b=>b.addEventListener('click',()=>setLight(b.dataset.light)));
let toastTimer;
function toast(message){const el=document.querySelector('#toast');el.textContent=message;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),2800);}
document.querySelector('#capture').addEventListener('click',()=>{
  renderer.render(scene,camera);
  renderer.domElement.toBlob(blob=>{
    if(!blob){toast('截图生成失败，请重试');return;}
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`青阙-${theme==='day'?'晨光':'暮色'}.png`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('已保存这一刻的光景');
  },'image/png');
});
const about=document.querySelector('#about');
document.querySelector('#about-open').addEventListener('click',()=>about.showModal());
for(const id of ['about-close','about-return'])document.querySelector(`#${id}`).addEventListener('click',()=>about.close());
about.addEventListener('click',e=>{if(e.target===about){const r=about.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)about.close();}});
renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();toast('图形上下文中断，请刷新页面恢复');});
let frames=0,lastTime=performance.now(),fps=0;
const sampleFrames=[];
let lastFrame=performance.now();
function animate(now){
  requestAnimationFrame(animate);
  if(document.hidden){lastFrame=now;return;}
  if(tween){
    const t=Math.min(1,(now-tween.start)/1100),ease=t*t*(3-2*t);
    camera.position.lerpVectors(tween.from,tween.to,ease);controls.target.lerpVectors(tween.targetFrom,tween.targetTo,ease);
    camera.zoom=THREE.MathUtils.lerp(tween.zoomFrom,tween.zoomTo,ease);camera.updateProjectionMatrix();if(t===1)tween=null;
  }
  controls.update();renderer.render(scene,camera);
  document.querySelector('#compass-needle').setAttribute('transform',`rotate(${-controls.getAzimuthalAngle()*180/Math.PI} 30 30)`);
  if(showLabels)for(const {el,point} of labelNodes){const p=point.clone().project(camera);el.style.left=`${(p.x*.5+.5)*host.clientWidth}px`;el.style.top=`${(-p.y*.5+.5)*host.clientHeight-16}px`;el.hidden=p.z<-1||p.z>1;}
  frames++;sampleFrames.push(now-lastFrame);lastFrame=now;if(sampleFrames.length>600)sampleFrames.shift();
  if(now-lastTime>=1000){fps=Math.round(frames*1000/(now-lastTime));document.querySelector('#fps').textContent=`${fps} FPS`;lastTime=now;frames=0;}
}
requestAnimationFrame(animate);
requestAnimationFrame(()=>{document.querySelector('#loading').classList.add('done');});
// Read-only diagnostics are exposed for reproducible browser verification.
window.__QINGQUE__={get stats(){return {voxelCount,fps,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,theme,autoRotate:controls.autoRotate,labels:showLabels,camera:camera.position.toArray(),zoom:camera.zoom,frameTimes:sampleFrames.slice(),buildings:labelData.map(([name,x,y,z])=>({name,x,y,z})),webgl:renderer.capabilities.isWebGL2?'WebGL2':'WebGL'};}};
