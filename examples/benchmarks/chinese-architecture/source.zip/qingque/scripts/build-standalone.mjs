import { build } from 'vite';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';

const result = await build({
  configFile: false,
  build: {
    write: false,
    lib: { entry: resolve('src/main.js'), name: 'Qingque', formats: ['iife'] },
    minify: 'esbuild',
    reportCompressedSize: false,
  },
});
const outputs = (Array.isArray(result) ? result : [result]).flatMap(item => item.output);
const js = outputs.filter(item => item.type === 'chunk').map(item => item.code).join('\n');
const css = outputs.filter(item => item.type === 'asset' && item.fileName.endsWith('.css')).map(item => item.source).join('\n');
const favicon = await readFile('favicon.svg', 'utf8');
const html = (await readFile('index.html', 'utf8'))
  .replace('href="./favicon.svg"', `href="data:image/svg+xml,${encodeURIComponent(favicon)}"`)
  .replace('</head>', `<style>${css}</style></head>`)
  .replace('<script type="module" src="/src/main.js"></script>', `<script>${js.replace(/<\/script/gi, '<\\/script')}</script>`);
await mkdir('standalone', { recursive: true });
await writeFile('standalone/qingque.html', html);
console.log('Standalone page: standalone/qingque.html');
