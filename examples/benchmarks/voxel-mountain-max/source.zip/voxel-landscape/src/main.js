import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createLandscape } from './landscape.js';
import './style.css';

const viewport = document.querySelector('#viewport');
const performanceLabel = document.querySelector('#performance');
const loading = document.querySelector('#loading');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const themes = {
  dawn: { background: '#e9ede6', sun: '#fff1d4', sky: '#e8f3f1', ground: '#b4ac89', water: '#54b5b0', cloud: '#fffbed', intensity: 2.7, position: [-55, 85, 45], exposure: 1.05 },
  day: { background: '#e5eef0', sun: '#fffbea', sky: '#d1eafa', ground: '#a3b58b', water: '#36acb1', cloud: '#ffffff', intensity: 3.0, position: [-25, 110, 20], exposure: 1.08 },
  dusk: { background: '#e8dee0', sun: '#ffb989', sky: '#d2d6f0', ground: '#a9909e', water: '#8496bb', cloud: '#fff0e6', intensity: 2.4, position: [-90, 46, -12], exposure: .98 },
};

function toast(message) {
  const element = document.querySelector('#toast');
  element.textContent = message;
  element.classList.add('visible');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove('visible'), 2000);
}

async function start() {
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  } catch (error) {
    loading.querySelector('p').textContent = '无法启用 3D 画面，请使用支持 WebGL 2 的浏览器并开启硬件加速。';
    loading.querySelector('.loader-cubes').style.display = 'none';
    console.error('WebGL renderer could not initialize:', error);
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(viewport.clientWidth, viewport.clientHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = themes.dawn.exposure;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.domElement.tabIndex = 0;
  renderer.domElement.setAttribute('role', 'img');
  renderer.domElement.setAttribute('aria-label', '云上山河：体素雪峰、瀑布、森林与漂浮在山腰的云层。拖动可环绕查看，滚动可缩放，按 R 恢复全景。');
  viewport.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(themes.dawn.background);
  scene.fog = new THREE.Fog(themes.dawn.background, 205, 420);
  const camera = new THREE.OrthographicCamera(-90, 90, 58, -58, .1, 600);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = .065;
  controls.enablePan = false;
  controls.rotateSpeed = .55;
  controls.zoomSpeed = .8;
  controls.minZoom = .72;
  controls.maxZoom = 2.5;
  controls.minPolarAngle = Math.PI / 6;
  controls.maxPolarAngle = Math.PI * .46;
  controls.autoRotateSpeed = .45;

  const sky = new THREE.HemisphereLight(themes.dawn.sky, themes.dawn.ground, 1.65);
  scene.add(sky);
  const sun = new THREE.DirectionalLight(themes.dawn.sun, themes.dawn.intensity);
  sun.position.set(...themes.dawn.position);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -83, right: 83, top: 83, bottom: -83, near: 1, far: 250 });
  sun.shadow.bias = -.00045;
  sun.shadow.normalBias = .045;
  sun.shadow.radius = 2;
  sun.target.position.set(0, 14, 0);
  scene.add(sun, sun.target);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshBasicMaterial({ color: themes.dawn.background }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -7.1;
  scene.add(ground);
  const shadowPlane = new THREE.Mesh(new THREE.PlaneGeometry(250, 220), new THREE.ShadowMaterial({ color: '#455f43', opacity: .16 }));
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = -7.05;
  shadowPlane.receiveShadow = true;
  scene.add(shadowPlane);

  // Yield once so the loading indicator paints before terrain construction.
  await new Promise(requestAnimationFrame);
  const generatedAt = performance.now();
  const landscape = createLandscape();
  const generationMs = performance.now() - generatedAt;
  scene.add(landscape.group);
  renderer.shadowMap.needsUpdate = true;

  let isMobile = innerWidth <= 650;
  let transition = null;
  let currentTheme = 'dawn';
  let lastTime = performance.now();
  let elapsed = 0;
  let fpsStart = lastTime;
  let frames = 0;
  let frameTimes = [];
  let lowFrameWindows = 0;
  let resizeTimer;
  let benchmarkRunning = false;
  let metrics = { fps: 0, frameMsP95: 0, ...landscape.stats, generationMs: Math.round(generationMs) };

  function frameCamera(reset = false) {
    const width = viewport.clientWidth, height = viewport.clientHeight;
    const aspect = width / height;
    const nextMobile = width <= 650;
    reset ||= nextMobile !== isMobile;
    isMobile = nextMobile;
    const viewHeight = isMobile ? Math.max(139, 116 / aspect) : 116;
    camera.left = -viewHeight * aspect / 2;
    camera.right = viewHeight * aspect / 2;
    camera.top = viewHeight / 2;
    camera.bottom = -viewHeight / 2;
    if (reset) {
      transition = null;
      controls.target.set(isMobile ? 0 : -11, isMobile ? 18 : 17, 0);
      camera.position.copy(controls.target).add(new THREE.Vector3(104, 82, 126));
      camera.zoom = 1;
    }
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
    controls.update();
  }
  frameCamera(true);

  function setOrbit(enabled) {
    controls.autoRotate = enabled;
    document.querySelector('#orbit-toggle').setAttribute('aria-pressed', String(enabled));
  }

  function resetView() {
    setOrbit(false);
    // Clear accumulated drag momentum before interpolating to the home pose.
    // Otherwise OrbitControls would keep rotating during and after the reset.
    const fromPosition = camera.position.clone();
    controls.enableDamping = false;
    controls.update(0);
    controls.enableDamping = true;
    camera.position.copy(fromPosition);
    const target = new THREE.Vector3(isMobile ? 0 : -11, isMobile ? 18 : 17, 0);
    transition = {
      start: performance.now(), fromPosition: camera.position.clone(), fromTarget: controls.target.clone(), fromZoom: camera.zoom,
      toPosition: target.clone().add(new THREE.Vector3(104, 82, 126)), toTarget: target,
    };
    if (reducedMotion) transition.start -= 900;
  }

  function setTheme(name) {
    const theme = themes[name];
    if (!theme) return;
    currentTheme = name;
    document.body.dataset.theme = name;
    document.querySelectorAll('[data-theme]').forEach((button) => {
      if (button.tagName !== 'BUTTON') return;
      const selected = button.dataset.theme === name;
      button.classList.toggle('active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
    scene.background.set(theme.background);
    scene.fog.color.set(theme.background);
    ground.material.color.set(theme.background);
    sky.color.set(theme.sky);
    sky.groundColor.set(theme.ground);
    sun.color.set(theme.sun);
    sun.intensity = theme.intensity;
    sun.position.set(...theme.position);
    landscape.water.material.uniforms.uTint.value.set(theme.water);
    landscape.clouds.material.color.set(theme.cloud);
    renderer.toneMappingExposure = theme.exposure;
    renderer.shadowMap.needsUpdate = true;
  }

  const resizeObserver = new ResizeObserver(() => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => frameCamera(false), 80);
  });
  resizeObserver.observe(viewport);
  document.querySelector('#zoom-in').addEventListener('click', () => { camera.zoom = Math.min(controls.maxZoom, camera.zoom * 1.18); camera.updateProjectionMatrix(); });
  document.querySelector('#zoom-out').addEventListener('click', () => { camera.zoom = Math.max(controls.minZoom, camera.zoom / 1.18); camera.updateProjectionMatrix(); });
  document.querySelector('#reset-view').addEventListener('click', () => { resetView(); toast('回到山河初见时'); });
  document.querySelector('#orbit-toggle').addEventListener('click', () => { setOrbit(!controls.autoRotate); });
  document.querySelectorAll('button[data-theme]').forEach((button) => button.addEventListener('click', () => setTheme(button.dataset.theme)));
  controls.addEventListener('start', () => { transition = null; setOrbit(false); });
  const dialog = document.querySelector('#about-dialog');
  document.querySelector('#about-toggle').addEventListener('click', () => dialog.showModal());
  document.querySelector('#about-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (event) => { if (event.target === dialog) { const r = dialog.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close(); } });
  window.addEventListener('keydown', (event) => {
    if (event.key.toLowerCase() === 'r' && !dialog.open && !event.metaKey && !event.ctrlKey && !event.altKey) { resetView(); toast('回到山河初见时'); }
  });
  document.addEventListener('visibilitychange', () => { lastTime = performance.now(); fpsStart = lastTime; frames = 0; frameTimes = []; });
  renderer.domElement.addEventListener('webglcontextlost', (event) => {
    event.preventDefault();
    renderer.setAnimationLoop(null);
    toast('图形上下文暂时中断，正在等待恢复');
  });
  renderer.domElement.addEventListener('webglcontextrestored', () => {
    renderer.shadowMap.needsUpdate = true;
    lastTime = performance.now();
    renderer.setAnimationLoop(animate);
    toast('山河已恢复');
  });

  function animate(now) {
    if (document.hidden) return;
    const rawDelta = now - lastTime;
    const dt = Math.min(rawDelta / 1000, .05);
    lastTime = now;
    elapsed += dt * (reducedMotion ? .25 : 1);
    landscape.update(elapsed);
    if (transition) {
      const t = Math.min((now - transition.start) / 850, 1);
      const ease = 1 - (1 - t) ** 3;
      camera.position.lerpVectors(transition.fromPosition, transition.toPosition, ease);
      controls.target.lerpVectors(transition.fromTarget, transition.toTarget, ease);
      camera.zoom = THREE.MathUtils.lerp(transition.fromZoom, 1, ease);
      camera.updateProjectionMatrix();
      if (t === 1) transition = null;
    }
    controls.update(dt);
    renderer.render(scene, camera);
    frames++;
    if (rawDelta > 0) frameTimes.push(rawDelta);
    if (now - fpsStart >= 1500) {
      const sorted = frameTimes.slice().sort((a, b) => a - b);
      const fps = Math.round(frames * 1000 / (now - fpsStart));
      metrics = {
        ...metrics, fps, frameMsP95: Math.round((sorted[Math.floor(sorted.length * .95)] || 0) * 10) / 10,
        drawCalls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
        pixelRatio: renderer.getPixelRatio(), viewport: [viewport.clientWidth, viewport.clientHeight], theme: currentTheme,
      };
      performanceLabel.textContent = `${fps} FPS  /  LIVE LANDSCAPE`;
      performanceLabel.setAttribute('aria-label', `实时帧率 ${fps} 帧每秒`);
      lowFrameWindows = fps < 34 ? lowFrameWindows + 1 : 0;
      if (!benchmarkRunning && lowFrameWindows >= 2 && renderer.getPixelRatio() > .8) {
        renderer.setPixelRatio(Math.max(.8, renderer.getPixelRatio() - .2));
        lowFrameWindows = 0;
      }
      fpsStart = now;
      frames = 0;
      frameTimes = [];
    }
  }

  // A small read-only diagnostics surface plus a repeatable orbit benchmark.
  // Measurements use real rendered rAF intervals and never clamp to a target FPS.
  window.__WILDFORM__ = {
    ready: true,
    getMetrics: () => ({ ...metrics }),
    getState: () => ({ theme: currentTheme, autoRotate: controls.autoRotate, zoom: camera.zoom, camera: camera.position.toArray(), target: controls.target.toArray(), time: elapsed }),
    async benchmark(seconds = 10) {
      if (benchmarkRunning) throw new Error('A benchmark is already running');
      if (document.hidden) throw new Error('Keep this tab visible while benchmarking');
      benchmarkRunning = true;
      const oldOrbit = controls.autoRotate, oldSpeed = controls.autoRotateSpeed;
      const oldPosition = camera.position.clone(), oldTarget = controls.target.clone();
      transition = null;
      controls.autoRotateSpeed = 5;
      setOrbit(true);
      const intervals = [];
      let previous = performance.now();
      const start = previous;
      try {
        await new Promise((resolve, reject) => {
          const sample = (time) => {
            if (document.hidden) { reject(new Error('Benchmark interrupted: tab hidden')); return; }
            const interval = time - previous;
            if (time - start > 750 && interval > 0) intervals.push(interval);
            previous = time;
            if (time - start >= Math.max(2, Math.min(seconds, 60)) * 1000) resolve();
            else requestAnimationFrame(sample);
          };
          requestAnimationFrame(sample);
        });
        intervals.sort((a, b) => a - b);
        const total = intervals.reduce((a, b) => a + b, 0);
        const result = {
          durationSeconds: seconds, samples: intervals.length,
          averageFps: Math.round(intervals.length / total * 10000) / 10,
          p95FrameMs: Math.round(intervals[Math.floor(intervals.length * .95)] * 100) / 100,
          p99FrameMs: Math.round(intervals[Math.floor(intervals.length * .99)] * 100) / 100,
          slowestFrameMs: Math.round(intervals.at(-1) * 100) / 100,
          framesAbove33ms: intervals.filter((value) => value > 33.34).length,
          ...landscape.stats, drawCalls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
          viewport: [viewport.clientWidth, viewport.clientHeight], devicePixelRatio: devicePixelRatio, renderPixelRatio: renderer.getPixelRatio(),
          userAgent: navigator.userAgent, threeRevision: THREE.REVISION,
        };
        return result;
      } finally {
        benchmarkRunning = false;
        controls.autoRotateSpeed = oldSpeed;
        setOrbit(false);
        controls.enableDamping = false;
        controls.update(0);
        controls.enableDamping = true;
        camera.position.copy(oldPosition);
        controls.target.copy(oldTarget);
        controls.update(0);
        setOrbit(oldOrbit);
      }
    },
  };
  renderer.setAnimationLoop(animate);
  requestAnimationFrame(() => {
    loading.classList.add('done');
    setTimeout(() => loading.remove(), 800);
  });
}

start().catch((error) => {
  loading.querySelector('p').textContent = '场景加载遇到问题，请刷新页面重试。';
  console.error(error);
});
