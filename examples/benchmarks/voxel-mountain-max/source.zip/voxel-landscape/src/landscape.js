import * as THREE from 'three';
import { WORLD, hash, noise, riverCenter, createTerrainData, lakeDistance } from './terrain-data.js';

class VoxelFaces {
  constructor() { this.positions = []; this.normals = []; this.colors = []; this.indices = []; }
  quad(vertices, normal, color, ao = [1, 1, 1, 1]) {
    const index = this.positions.length / 3;
    for (let i = 0; i < 4; i++) {
      this.positions.push(...vertices[i]);
      this.normals.push(...normal);
      this.colors.push(color.r * ao[i], color.g * ao[i], color.b * ao[i]);
    }
    this.indices.push(index, index + 1, index + 2, index, index + 2, index + 3);
  }
  top(x, y, z, color, ao) {
    this.quad([[x - .5, y, z + .5], [x + .5, y, z + .5], [x + .5, y, z - .5], [x - .5, y, z - .5]], [0, 1, 0], color, ao);
  }
  side(x, bottom, top, z, direction, color) {
    const l = x - .5, r = x + .5, b = z - .5, f = z + .5;
    const ao = [.87, .87, 1, 1];
    if (direction === 0) this.quad([[r, bottom, f], [r, bottom, b], [r, top, b], [r, top, f]], [1, 0, 0], color, ao);
    if (direction === 1) this.quad([[l, bottom, b], [l, bottom, f], [l, top, f], [l, top, b]], [-1, 0, 0], color, ao);
    if (direction === 2) this.quad([[l, bottom, f], [r, bottom, f], [r, top, f], [l, top, f]], [0, 0, 1], color, ao);
    if (direction === 3) this.quad([[r, bottom, b], [l, bottom, b], [l, top, b], [r, top, b]], [0, 0, -1], color, ao);
  }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.positions, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.normals, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.colors, 3));
    g.setIndex(this.indices);
    g.computeBoundingSphere();
    return g;
  }
}

const PALETTE = {
  grass: ['#7d985c', '#849e63', '#8b9e69', '#718e52', '#91a672'],
  alpine: ['#9ba789', '#91977e', '#a5ac93'],
  stone: ['#8d9490', '#a0a39a', '#94998f', '#848d84', '#aaaba1'],
  snow: ['#f2f3e8', '#e9ede3', '#e1e8e0', '#f5f4e9'],
  soil: ['#7e7962', '#878068', '#727362'],
  base: ['#666d63', '#737a69', '#6a7367', '#7c7f6c'],
};
const color = new THREE.Color();

function terrainColor(x, y, z, h, slope, top) {
  let palette = PALETTE.stone;
  const snowline = 35 + noise(x * .12, z * .12) * 5;
  if (y >= snowline && (top || y >= h - 2)) palette = PALETTE.snow;
  else if (y <= -1) palette = PALETTE.base;
  else if (y < h - 2) palette = y < 4 ? PALETTE.soil : PALETTE.stone;
  else if (h < 23 && slope < 5) palette = top || y === h - 1 ? PALETTE.grass : PALETTE.soil;
  else if (h < 30 && slope < 3) palette = PALETTE.alpine;
  const choice = Math.floor(hash(x, z, y + 92) * palette.length);
  color.set(palette[choice]);
  color.multiplyScalar(.95 + hash(x, z, y * 2) * .1);
  return color;
}

function createGround(data) {
  const faces = new VoxelFaces();
  const neighbors = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  let exposedVoxels = 0;
  for (const { x, z, height: h } of data.cells.values()) {
    const heights = neighbors.map(([dx, dz]) => data.heightAt(x + dx, z + dz));
    const slope = Math.max(...heights.map((n) => Math.abs(h - n)));
    const ao = [[-1, 1], [1, 1], [1, -1], [-1, -1]].map(([dx, dz]) => {
      const occluders = Number(data.heightAt(x + dx, z) > h) + Number(data.heightAt(x, z + dz) > h);
      return 1 - occluders * .085;
    });
    faces.top(x, h, z, terrainColor(x, h, z, h, slope, true), ao);
    exposedVoxels++;
    const bottom = WORLD.bottom + Math.floor(noise(x * .1, z * .1) * 3);
    for (let d = 0; d < 4; d++) {
      const adjacent = heights[d] === WORLD.bottom ? bottom : heights[d];
      for (let y = adjacent; y < h; y++) {
        faces.side(x, y, y + 1, z, d, terrainColor(x, y, z, h, slope, false));
        exposedVoxels++;
      }
    }
  }
  const mesh = new THREE.Mesh(faces.geometry(), new THREE.MeshLambertMaterial({ vertexColors: true }));
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.name = 'Exposed voxel terrain';
  return { mesh, exposedVoxels };
}

function instanceBlocks(blocks, material) {
  const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), material, blocks.length);
  const transform = new THREE.Object3D();
  blocks.forEach((b, i) => {
    transform.position.set(b.x, b.y, b.z);
    transform.scale.set(b.sx ?? 1, b.sy ?? 1, b.sz ?? 1);
    transform.updateMatrix();
    mesh.setMatrixAt(i, transform.matrix);
    mesh.setColorAt(i, new THREE.Color(b.color || '#ffffff'));
  });
  mesh.instanceMatrix.needsUpdate = true;
  mesh.computeBoundingSphere();
  return mesh;
}

function createVegetation(data) {
  const blocks = [];
  let trees = 0;
  const leafColors = ['#315842', '#3e6747', '#4d7450', '#5d8052', '#42664a', '#718b58'];
  for (let x = -48; x <= 48; x += 2) {
    for (let z = -32; z <= 39; z += 2) {
      const h = data.heightAt(x, z);
      if (h < 3 || h > 23 || data.waterAt(x, z) !== null || lakeDistance(x, z) < 1.3 || (z >= -10 && z <= 30 && Math.abs(x - riverCenter(z)) < 5)) continue;
      const slope = Math.max(Math.abs(h - data.heightAt(x + 1, z)), Math.abs(h - data.heightAt(x, z + 1)));
      if (slope > 2 || hash(x, z, 42) > .38) continue;
      const px = x + (hash(x, z, 2) - .5) * .8, pz = z + (hash(x, z, 3) - .5) * .8;
      const size = .75 + hash(x, z, 13) * .9;
      const foliage = leafColors[Math.floor(hash(x, z, 12) * leafColors.length)];
      blocks.push({ x: px, y: h + size * 1.9, z: pz, sx: .42 * size, sy: 3.8 * size, sz: .42 * size, color: '#665a40' });
      for (let layer = 0; layer < 4; layer++) {
        const width = (3.1 - layer * .66) * size;
        blocks.push({ x: px, y: h + (2 + layer * .88) * size, z: pz, sx: width, sy: size * 1.15, sz: width, color: foliage });
        if (layer < 2) {
          blocks.push({ x: px + .3 * size, y: h + (2.75 + layer * .88) * size, z: pz, sx: width * .64, sy: .4 * size, sz: width * .74, color: leafColors[(layer + 3) % leafColors.length] });
        }
      }
      trees++;
    }
  }
  for (let i = 0; i < 180; i++) {
    const x = Math.round((hash(i, 13) - .5) * 94), z = Math.round((hash(i, 54) - .5) * 73);
    const h = data.heightAt(x, z);
    if (h < 3 || h > 29 || data.waterAt(x, z) !== null) continue;
    const size = .4 + hash(i, 31) * .7;
    blocks.push({ x, y: h + size * .33, z, sx: size, sy: size * .66, sz: size, color: i % 4 === 0 ? '#aab1a0' : '#688454' });
  }
  // Small sunlit flowers along the meadow, sized as pixels of color.
  for (let i = 0; i < 45; i++) {
    const x = Math.round(hash(i, 9) * 78 - 39), z = Math.round(hash(i, 18) * 20 + 12);
    const h = data.heightAt(x, z);
    if (h < 3 || h > 11 || data.waterAt(x, z) !== null) continue;
    blocks.push({ x, y: h + .4, z, sx: .24, sy: .38, sz: .24, color: '#dfc37b' });
  }
  const mesh = instanceBlocks(blocks, new THREE.MeshLambertMaterial());
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.name = 'Instanced voxel forest';
  return { mesh, trees, count: blocks.length };
}

function createWater(data) {
  const faces = new VoxelFaces();
  const white = new THREE.Color('#ffffff');
  const drops = [];
  const directions = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  for (const { x, z } of data.cells.values()) {
    const level = data.waterAt(x, z);
    if (level === null) continue;
    faces.top(x, level, z, white);
    directions.forEach(([dx, dz], dir) => {
      const neighborLevel = data.waterAt(x + dx, z + dz);
      const bottom = neighborLevel ?? Math.max(data.heightAt(x + dx, z + dz), level - .3);
      if (bottom < level - .01) faces.side(x + dx * .012, bottom, level, z + dz * .012, dir, white);
    });
    const down = data.waterAt(x, z + 1);
    if (down !== null && level - down > 2) drops.push({ x, z: z + .53, top: level, bottom: down });
  }
  const material = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uTint: { value: new THREE.Color('#58bbbc') } },
    vertexShader: `
      varying vec3 vPosition;
      varying vec3 vNormal;
      void main() {
        vPosition = (modelMatrix * vec4(position, 1.0)).xyz;
        vNormal = normal;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 uTint;
      varying vec3 vPosition;
      varying vec3 vNormal;
      float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      void main() {
        bool falling = vNormal.y < 0.5;
        vec2 p = falling ? vec2(vPosition.x * 3.8 + vPosition.z * .13, vPosition.y * .7 + uTime * 4.5) : vec2(vPosition.x * 1.6, vPosition.z * 1.5 - uTime * 1.3);
        vec2 cell = floor(p);
        float n = hash(cell);
        float line = smoothstep(.84, .97, n);
        float fine = step(.97, hash(floor(p * vec2(2.0, .5))));
        vec3 tint = uTint;
        if (falling) tint = mix(tint, vec3(.61, .88, .85), .34);
        else tint *= .83 + .14 * sin(vPosition.x * .18 + vPosition.z * .2) + hash(floor(vPosition.xz * .4)) * .08;
        vec3 water = mix(tint, vec3(.89, .98, .91), line * (falling ? .8 : .38) + fine * .27);
        if (falling) water += .11 * step(.88, fract(vPosition.x * 2.0));
        gl_FragColor = vec4(water, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const mesh = new THREE.Mesh(faces.geometry(), material);
  mesh.name = 'Continuous terraced river and lake';
  return { mesh, material, drops };
}

function createSpray(drops) {
  const count = 240;
  const geometry = new THREE.BoxGeometry(1, 1, 1);
  const mesh = new THREE.InstancedMesh(geometry, new THREE.MeshBasicMaterial({ color: '#e1f3df', transparent: true, opacity: .72, depthWrite: false }), count);
  mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  // Animation stays inside the whole-world bound; avoid per-frame bound rebuilds.
  mesh.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 20, 8), 65);
  mesh.name = 'Instanced waterfall spray';
  const transform = new THREE.Object3D();
  const particles = Array.from({ length: count }, (_, i) => ({
    drop: drops[Math.floor(hash(i, 2) * drops.length)],
    offset: hash(i, 8), speed: .5 + hash(i, 11) * .6,
    x: (hash(i, 5) - .5) * 1.5, z: hash(i, 6) * 1.6,
    size: .07 + hash(i, 7) * .19,
  }));
  function update(time) {
    particles.forEach((p, i) => {
      const phase = (time * p.speed + p.offset) % 1;
      const falling = i % 3 !== 0;
      const y = falling ? THREE.MathUtils.lerp(p.drop.top, p.drop.bottom, phase * phase) : p.drop.bottom + Math.sin(phase * Math.PI) * 1.5;
      transform.position.set(p.drop.x + p.x * (falling ? .4 : phase * 2), y, p.drop.z + .12 + p.z * (falling ? .2 : phase));
      const size = p.size * (falling ? 1 : Math.sin(phase * Math.PI));
      transform.scale.set(size, size * (falling ? 2.7 : 1), size);
      transform.updateMatrix();
      mesh.setMatrixAt(i, transform.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
  }
  update(0);
  return { mesh, update };
}

function createClouds() {
  const clouds = new THREE.Group();
  clouds.name = 'Drifting volumetric voxel clouds';
  const formations = [
    [-39, 24, -12, 1.1], [-20, 28, -34, 1.4], [17, 25, -35, 1.25],
    [38, 22, -14, .95], [35, 24, 8, 1.15], [-28, 22, 16, 1.1],
    [-7, 25, 10, .7], [48, 29, 2, .65], [-43, 31, 2, .75],
  ];
  const material = new THREE.MeshLambertMaterial({ color: '#fffaf0', transparent: true, opacity: .42, depthWrite: false });
  formations.forEach(([x, y, z, scale], index) => {
    const blocks = [];
    for (let i = 0; i < 18; i++) {
      const width = 2.2 + hash(i, index, 8) * 5;
      blocks.push({
        x: (hash(i, index, 1) - .5) * 18,
        y: (hash(i, index, 2) - .5) * 2.4,
        z: (hash(i, index, 3) - .5) * 7.5,
        sx: width, sy: 1 + hash(i, index, 4) * 2.1, sz: 2.4 + hash(i, index, 5) * 3,
        color: '#ffffff',
      });
    }
    const mesh = instanceBlocks(blocks, material);
    mesh.position.set(x, y, z);
    mesh.scale.setScalar(scale);
    mesh.userData.originX = x;
    mesh.userData.originZ = z;
    mesh.userData.phase = index * 1.7;
    clouds.add(mesh);
  });
  return {
    group: clouds,
    material,
    update(time) {
      clouds.children.forEach((cloud) => {
        cloud.position.x = cloud.userData.originX + Math.sin(time * .045 + cloud.userData.phase) * 3;
        cloud.position.z = cloud.userData.originZ + Math.cos(time * .035 + cloud.userData.phase) * 1.3;
      });
    },
  };
}

function createBirds() {
  const group = new THREE.Group();
  const material = new THREE.MeshBasicMaterial({ color: '#4a5d50' });
  for (let i = 0; i < 5; i++) {
    const bird = new THREE.Group();
    for (const side of [-1, 1]) {
      const wing = new THREE.Mesh(new THREE.BoxGeometry(.9, .12, .22), material);
      wing.position.x = side * .4;
      wing.userData.side = side;
      bird.add(wing);
    }
    group.add(bird);
  }
  return { group, update(time) {
    group.children.forEach((bird, i) => {
      const angle = time * .1 + i * .18;
      bird.position.set(Math.cos(angle) * 23 + 1, 39 + Math.sin(angle * 2 + i) * 2.3 + i * .65, Math.sin(angle) * 10 - 4);
      bird.rotation.y = -angle;
      bird.children.forEach((wing) => { wing.rotation.z = Math.sin(time * 3.8 + i) * .35 * wing.userData.side; });
    });
  } };
}

export function createLandscape() {
  const group = new THREE.Group();
  const data = createTerrainData();
  const ground = createGround(data);
  const vegetation = createVegetation(data);
  const water = createWater(data);
  const spray = createSpray(water.drops);
  const clouds = createClouds();
  const birds = createBirds();
  group.add(ground.mesh, vegetation.mesh, water.mesh, spray.mesh, clouds.group, birds.group);
  return {
    group, data, water, clouds,
    stats: { terrainColumns: data.cells.size, exposedFaces: ground.exposedVoxels, vegetationBlocks: vegetation.count, trees: vegetation.trees, sprayParticles: 240, cloudBlocks: 162, majorDropColumns: water.drops.length },
    update(time) { water.material.uniforms.uTime.value = time; spray.update(time); clouds.update(time); birds.update(time); },
  };
}
