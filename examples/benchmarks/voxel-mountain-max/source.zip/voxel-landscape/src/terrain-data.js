// Deterministic terrain and hydrology, independent of the renderer.
export const WORLD = { minX: -57, maxX: 57, minZ: -47, maxZ: 47, bottom: -7, lakeLevel: 3.24 };

export function hash(x, z, seed = 0) {
  const n = Math.sin(x * 127.1 + z * 311.7 + seed * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

const smooth = (t) => t * t * (3 - 2 * t);
const mix = (a, b, t) => a + (b - a) * t;

export function noise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z);
  const sx = smooth(x - ix), sz = smooth(z - iz);
  return mix(mix(hash(ix, iz), hash(ix + 1, iz), sx), mix(hash(ix, iz + 1), hash(ix + 1, iz + 1), sx), sz);
}

export function riverCenter(z) {
  return Math.round(5 + Math.sin((z + 6) * 0.15) * 3 - z * 0.12);
}

export function riverBed(z) {
  if (z < -4) return 34;
  if (z < 1) return 33 - Math.floor((z + 4) / 2);
  if (z < 4) return 30;
  if (z < 9) return 21 - Math.floor((z - 4) * 0.4);
  if (z < 15) return 17 - Math.floor((z - 9) * 0.4);
  if (z < 19) return 10;
  if (z < 24) return 6;
  return 3;
}

export function inRiver(x, z) {
  return z >= -8 && z <= 29 && Math.abs(x - riverCenter(z)) <= 2;
}

export function lakeDistance(x, z) {
  return ((x - 3) / 17) ** 2 + ((z - 28) / 10.8) ** 2 + (noise(x * 0.17, z * 0.17) - 0.5) * 0.22;
}

const peaks = [
  [-10, -18, 56, 28, 30], [18, -26, 46, 25, 26],
  [27, -6, 38, 23, 28], [-31, -8, 36, 24, 25],
  [36, 11, 23, 16, 21], [-38, 14, 20, 18, 22],
];

export function rawHeight(x, z) {
  const radius = (x / 53) ** 2 + ((z + 1) / 43) ** 2;
  const boundary = 0.96 + (noise(x * 0.1, z * 0.1) - 0.5) * 0.19;
  if (radius > boundary) return WORLD.bottom;
  let h = 1.3 + 4.4 * Math.max(0, 1 - radius) ** 0.6;
  const wx = x + (noise(x * 0.07, z * 0.07) - 0.5) * 4;
  const wz = z + Math.sin(x * 0.14) * 1.5;
  for (const [px, pz, amplitude, rx, rz] of peaks) {
    const dx = (wx - px) / rx, dz = (wz - pz) / rz;
    const angle = Math.atan2(dz, dx);
    // Unequal ridgelines break radial symmetry while keeping broad, continuous slopes.
    const ridges = 1 + Math.sin(angle * 3 + px * .13) * .12 + Math.cos(angle * 5 - pz * .11) * .05;
    const d = Math.sqrt(dx ** 2 + dz ** 2) * ridges;
    h = Math.max(h, 3 + amplitude * Math.max(0, 1 - d) ** 1.18);
  }
  h += (noise(x * 0.24, z * 0.24) - 0.5) * 2.0 + (noise(x * 0.55, z * 0.55) - 0.5) * 0.75;

  // A rock buttress supports the stream. The bed and waterfall geometry use
  // exactly the same elevation profile, so every cascade contacts the mountain.
  if (z >= -10 && z <= 29) {
    const rz = Math.max(-8, z);
    const d = Math.abs(x - riverCenter(rz));
    if (d < 10) {
      const shoulder = riverBed(rz) + 2 - d * 0.18;
      h = mix(h, Math.max(h, shoulder), Math.max(0, 1 - (d / 10) ** 2));
    }
    if (inRiver(x, z)) h = riverBed(z);
  }

  const lake = lakeDistance(x, z);
  if (lake < 1 && z >= 19) h = Math.min(h, 1.5 + lake * 1.25);
  else if (lake < 1.36 && z > 20) h = Math.min(h, 3 + (lake - 1) * 8);
  if (inRiver(x, z)) h = riverBed(z);
  return Math.max(1, Math.floor(h));
}

export function createTerrainData() {
  const cells = new Map();
  for (let x = WORLD.minX; x <= WORLD.maxX; x++) {
    for (let z = WORLD.minZ; z <= WORLD.maxZ; z++) {
      const height = rawHeight(x, z);
      if (height > WORLD.bottom) cells.set(`${x},${z}`, { x, z, height });
    }
  }
  const heightAt = (x, z) => cells.get(`${Math.round(x)},${Math.round(z)}`)?.height ?? WORLD.bottom;
  const waterAt = (x, z) => {
    const h = heightAt(x, z);
    if (h === WORLD.bottom) return null;
    if (inRiver(x, z)) return riverBed(z) + 0.24;
    if (lakeDistance(x, z) < 1 && z >= 19 && h < WORLD.lakeLevel) return WORLD.lakeLevel;
    return null;
  };
  return { cells, heightAt, waterAt };
}
