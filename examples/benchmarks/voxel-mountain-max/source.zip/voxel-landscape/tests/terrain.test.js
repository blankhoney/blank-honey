import test from 'node:test';
import assert from 'node:assert/strict';
import { WORLD, createTerrainData, riverBed, riverCenter, inRiver } from '../src/terrain-data.js';

const data = createTerrainData();

test('the island has a tall primary summit and a bounded, non-rectangular footprint', () => {
  assert.ok(data.cells.size > 5500 && data.cells.size < 8500);
  const max = Math.max(...[...data.cells.values()].map((cell) => cell.height));
  assert.ok(max >= 50 && max < 65);
  assert.equal(data.heightAt(57, 47), WORLD.bottom);
  assert.equal(data.heightAt(-57, -47), WORLD.bottom);
});

test('the stream has no uphill segments and remains attached to its bed all the way to the lake', () => {
  let previous = Infinity;
  let majorDrops = 0;
  for (let z = -8; z <= 29; z++) {
    const x = riverCenter(z);
    const water = data.waterAt(x, z);
    assert.ok(water <= previous, `uphill flow at z=${z}`);
    assert.equal(data.heightAt(x, z), riverBed(z));
    assert.ok(Math.abs(water - data.heightAt(x, z) - .24) < 1e-8);
    if (Number.isFinite(previous) && previous - water > 2) majorDrops++;
    if (z > -8) assert.ok(Math.abs(x - riverCenter(z - 1)) <= 1, 'river cells must stay connected');
    assert.equal(inRiver(x, z), true);
    previous = water;
  }
  assert.ok(majorDrops >= 3);
  assert.equal(previous, WORLD.lakeLevel);
  assert.equal(data.waterAt(3, 32), WORLD.lakeLevel);
});

test('all water cells have terrain underneath and all terrain heights are whole voxels', () => {
  for (const { x, z, height } of data.cells.values()) {
    assert.equal(Number.isInteger(height), true);
    const water = data.waterAt(x, z);
    if (water !== null) assert.ok(water > height, `water underground at ${x},${z}`);
  }
});
