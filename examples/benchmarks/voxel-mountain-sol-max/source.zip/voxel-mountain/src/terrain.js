export const WORLD = Object.freeze({
  radiusX: 28,
  radiusZ: 22,
  baseY: -3,
  waterfallX: -6,
  waterfallStartZ: -7,
  waterfallEndZ: 19,
});

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const mix = (a, b, amount) => a + (b - a) * amount;
const smooth = (value) => value * value * (3 - 2 * value);

export function hash2(x, z) {
  const value = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123;
  return value - Math.floor(value);
}

function valueNoise(x, z) {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const tx = smooth(x - x0);
  const tz = smooth(z - z0);
  const a = mix(hash2(x0, z0), hash2(x0 + 1, z0), tx);
  const b = mix(hash2(x0, z0 + 1), hash2(x0 + 1, z0 + 1), tx);
  return mix(a, b, tz);
}

function fbm(x, z) {
  let value = 0;
  let amplitude = 0.58;
  let frequency = 0.14;

  for (let octave = 0; octave < 4; octave += 1) {
    value += valueNoise(x * frequency, z * frequency) * amplitude;
    frequency *= 2.03;
    amplitude *= 0.48;
  }

  return value;
}

function gaussian(x, z, centerX, centerZ, widthX, widthZ, height) {
  const dx = (x - centerX) / widthX;
  const dz = (z - centerZ) / widthZ;
  return Math.exp(-(dx * dx + dz * dz) * 1.45) * height;
}

export function insideIsland(x, z) {
  return (x / WORLD.radiusX) ** 2 + (z / WORLD.radiusZ) ** 2 <= 1;
}

function waterfallBed(z) {
  const progress = z - WORLD.waterfallStartZ;
  return Math.round(28 - progress * 0.62 - Math.floor(progress / 5) * 1.6);
}

export function surfaceHeight(x, z) {
  if (!insideIsland(x, z)) {
    return WORLD.baseY - 1;
  }

  const radial = Math.sqrt(
    (x / WORLD.radiusX) ** 2 + (z / WORLD.radiusZ) ** 2,
  );
  const edgeFade = 1 - smooth(clamp((radial - 0.7) / 0.3, 0, 1));
  const peaks =
    gaussian(x, z, -7, -6, 8.2, 8.8, 29) +
    gaussian(x, z, 9, -8, 7.2, 7.6, 22) +
    gaussian(x, z, -16, 4, 6.8, 8.5, 16) +
    gaussian(x, z, 11, 8, 9.2, 7.2, 14);
  const saddle = gaussian(x, z, 1, -1, 6.5, 7, 5.5);
  const brokenRidge = Math.sin(x * 0.48 + z * 0.21) * 1.1;
  const noise = (fbm(x, z) - 0.48) * 4.2;
  let height = Math.floor(
    -1 + (peaks - saddle + brokenRidge + noise) * edgeFade,
  );

  const inCascade =
    z >= WORLD.waterfallStartZ &&
    z <= WORLD.waterfallEndZ &&
    Math.abs(x - WORLD.waterfallX) <= 2;

  if (inCascade) {
    const distance = Math.abs(x - WORLD.waterfallX);
    const bed = waterfallBed(z) + distance * 1.5;
    height = distance < 0.51 ? Math.round(bed) : Math.min(height, Math.round(bed));
  }

  const poolDistance = Math.sqrt(
    ((x - WORLD.waterfallX) / 5.5) ** 2 + ((z - 18) / 4.2) ** 2,
  );
  if (poolDistance < 1) {
    height = Math.min(height, Math.floor(poolDistance * 1.4));
  }

  return Math.max(WORLD.baseY + 1, height);
}

export function waterfallPath() {
  const path = [];
  for (let z = WORLD.waterfallStartZ; z <= WORLD.waterfallEndZ; z += 1) {
    path.push({
      x: WORLD.waterfallX,
      y: surfaceHeight(WORLD.waterfallX, z),
      z,
    });
  }
  return path;
}
