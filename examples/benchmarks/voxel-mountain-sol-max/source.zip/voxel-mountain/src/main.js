import * as THREE from "three";
import "./style.css";
import {
  WORLD,
  hash2,
  insideIsland,
  surfaceHeight,
  waterfallPath,
} from "./terrain.js";

const canvas = document.querySelector("#scene");
const fallback = document.querySelector("#fallback");
const loader = document.querySelector("#loader");
const motionNote = document.querySelector("#motion-note");
const voxelCount = document.querySelector("#voxel-count");

try {
  startScene();
} catch (error) {
  console.error(error);
  loader.hidden = true;
  fallback.hidden = false;
}

function startScene() {
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const scene = new THREE.Scene();
  scene.background = makeSkyTexture();
  scene.fog = new THREE.FogExp2(0x7c91a0, 0.0095);

  const camera = new THREE.PerspectiveCamera(
    window.innerWidth < window.innerHeight ? 50 : 40,
    window.innerWidth / window.innerHeight,
    0.1,
    180,
  );
  const cameraTarget = new THREE.Vector3(0, 8.5, 0);

  const world = new THREE.Group();
  world.rotation.y = -0.08;
  scene.add(world);

  addLighting(scene);
  addWaterBase(world);
  addSun(scene);

  let totalVoxels = 0;
  totalVoxels += buildTerrain(world);
  totalVoxels += buildTrees(world);

  const waterfall = buildWaterfall(world);
  totalVoxels += waterfall.count;

  const clouds = [
    buildCloudBand(world, {
      y: 16.2,
      z: -14,
      clusters: 7,
      opacity: 0.22,
      tint: 0xcbdbe1,
      scale: 1.08,
      phase: 1.8,
    }),
    buildCloudBand(world, {
      y: 13.6,
      z: 1,
      clusters: 8,
      opacity: 0.29,
      tint: 0xe3eaeb,
      scale: 1.16,
      phase: 4.2,
    }),
    buildCloudBand(world, {
      y: 10.8,
      z: 17,
      clusters: 7,
      opacity: 0.37,
      tint: 0xffeee1,
      scale: 1.2,
      phase: 0.4,
    }),
  ];
  totalVoxels += clouds.reduce((sum, cloud) => sum + cloud.count, 0);

  voxelCount.textContent = new Intl.NumberFormat("zh-Hans").format(totalVoxels);

  const reducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  ).matches;
  if (reducedMotion) {
    motionNote.textContent = "已依系统设置减少动态效果";
  }

  let firstFrame = true;
  function render(timeMilliseconds) {
    const elapsed = timeMilliseconds * 0.001;
    const orbit = reducedMotion ? 0.72 : 0.72 + elapsed * 0.026;
    const radius = 66;

    camera.position.set(
      Math.sin(orbit) * radius,
      30.5 + (reducedMotion ? 0 : Math.sin(elapsed * 0.08) * 1.8),
      Math.cos(orbit) * radius,
    );
    camera.lookAt(cameraTarget);

    if (!reducedMotion) {
      for (const cloud of clouds) {
        cloud.group.position.x =
          Math.sin(elapsed * cloud.speed + cloud.phase) * cloud.amplitude;
      }
      waterfall.update(elapsed);
      waterfall.material.emissiveIntensity =
        0.42 + Math.sin(elapsed * 2.2) * 0.08;
    }

    renderer.render(scene, camera);

    if (firstFrame) {
      firstFrame = false;
      requestAnimationFrame(() => document.documentElement.classList.add("ready"));
    }
  }

  renderer.setAnimationLoop(render);

  window.addEventListener("resize", () => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    camera.aspect = width / height;
    camera.fov = width < height ? 50 : 40;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.65));
    renderer.setSize(width, height);
  });

  document.addEventListener("visibilitychange", () => {
    renderer.setAnimationLoop(document.hidden ? null : render);
  });
}

function addLighting(scene) {
  scene.add(new THREE.HemisphereLight(0xbcd9e8, 0x253224, 1.65));

  const sunrise = new THREE.DirectionalLight(0xffc18a, 3.15);
  sunrise.position.set(-32, 46, 34);
  sunrise.castShadow = true;
  sunrise.shadow.mapSize.set(1024, 1024);
  sunrise.shadow.camera.left = -42;
  sunrise.shadow.camera.right = 42;
  sunrise.shadow.camera.top = 46;
  sunrise.shadow.camera.bottom = -28;
  sunrise.shadow.camera.near = 8;
  sunrise.shadow.camera.far = 115;
  sunrise.shadow.bias = -0.00045;
  sunrise.target.position.set(0, 7, 0);
  scene.add(sunrise, sunrise.target);

  const skyFill = new THREE.DirectionalLight(0x8bb8d4, 0.7);
  skyFill.position.set(34, 18, -26);
  scene.add(skyFill);
}

function makeSkyTexture() {
  const sky = document.createElement("canvas");
  sky.width = 16;
  sky.height = 512;
  const context = sky.getContext("2d");
  const gradient = context.createLinearGradient(0, 0, 0, sky.height);
  gradient.addColorStop(0, "#1f3350");
  gradient.addColorStop(0.48, "#6f879b");
  gradient.addColorStop(0.76, "#d3a181");
  gradient.addColorStop(1, "#f2c4a1");
  context.fillStyle = gradient;
  context.fillRect(0, 0, sky.width, sky.height);

  const texture = new THREE.CanvasTexture(sky);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeSunTexture() {
  const sun = document.createElement("canvas");
  sun.width = 128;
  sun.height = 128;
  const context = sun.getContext("2d");
  const glow = context.createRadialGradient(64, 64, 5, 64, 64, 62);
  glow.addColorStop(0, "rgba(255, 244, 205, 1)");
  glow.addColorStop(0.28, "rgba(255, 210, 153, 0.95)");
  glow.addColorStop(0.58, "rgba(255, 175, 120, 0.28)");
  glow.addColorStop(1, "rgba(255, 175, 120, 0)");
  context.fillStyle = glow;
  context.fillRect(0, 0, 128, 128);

  const texture = new THREE.CanvasTexture(sun);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function addSun(scene) {
  const material = new THREE.SpriteMaterial({
    map: makeSunTexture(),
    transparent: true,
    depthWrite: false,
    fog: false,
  });
  const sun = new THREE.Sprite(material);
  sun.position.set(-36, 31, -46);
  sun.scale.set(17, 17, 1);
  scene.add(sun);
}

function addWaterBase(world) {
  const base = new THREE.Mesh(
    new THREE.BoxGeometry(78, 0.7, 62),
    new THREE.MeshStandardMaterial({
      color: 0x183d4d,
      roughness: 0.5,
      metalness: 0.05,
    }),
  );
  base.position.y = WORLD.baseY - 0.72;
  base.receiveShadow = true;
  world.add(base);

  const glass = new THREE.Mesh(
    new THREE.PlaneGeometry(77.5, 61.5),
    new THREE.MeshStandardMaterial({
      color: 0x4f8290,
      roughness: 0.28,
      metalness: 0.08,
      transparent: true,
      opacity: 0.46,
      depthWrite: false,
    }),
  );
  glass.rotation.x = -Math.PI / 2;
  glass.position.y = WORLD.baseY - 0.34;
  glass.receiveShadow = true;
  world.add(glass);
}

function buildTerrain(world) {
  const cells = [];
  const heights = new Map();

  for (let x = -WORLD.radiusX; x <= WORLD.radiusX; x += 1) {
    for (let z = -WORLD.radiusZ; z <= WORLD.radiusZ; z += 1) {
      if (!insideIsland(x, z)) {
        continue;
      }
      const height = surfaceHeight(x, z);
      cells.push({ x, z, height });
      heights.set(x + "," + z, height);
    }
  }

  const items = [];
  const neighbors = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ];

  for (const cell of cells) {
    for (let y = WORLD.baseY; y <= cell.height; y += 1) {
      const exposed =
        y === cell.height ||
        neighbors.some(([dx, dz]) => {
          const neighbor = heights.get(cell.x + dx + "," + (cell.z + dz));
          return neighbor === undefined || neighbor < y;
        });

      if (!exposed) {
        continue;
      }

      items.push({
        position: [cell.x, y, cell.z],
        scale: [0.98, 0.98, 0.98],
        color: terrainColor(cell.x, y, cell.z, cell.height),
      });
    }
  }

  const terrain = makeInstanced(
    items,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.94,
      metalness: 0,
      vertexColors: true,
    }),
    { castShadow: true, receiveShadow: true },
  );
  world.add(terrain);
  return items.length;
}

function terrainColor(x, y, z, surface) {
  const top = y === surface;
  const depth = surface - y;
  const snowLine = 18 + Math.sin(x * 0.27 + z * 0.16) * 1.5;
  let color;

  if (top && surface >= snowLine) {
    color = new THREE.Color(surface > 24 ? 0xf4f1e8 : 0xcbdad9);
  } else if (top && surface <= 5) {
    color = new THREE.Color(surface <= 1 ? 0x3f6958 : 0x547950);
  } else if (top) {
    color = new THREE.Color(surface > 13 ? 0x6d7477 : 0x59665d);
  } else if (depth <= 2 && surface < 9) {
    color = new THREE.Color(0x665541);
  } else {
    color = new THREE.Color(y > 12 ? 0x515c64 : 0x414d4c);
  }

  const variation = (hash2(x * 7 + y * 0.7, z * 9 - y) - 0.5) * 0.095;
  color.offsetHSL(variation * 0.12, variation * 0.18, variation);
  return color.getHex();
}

function buildTrees(world) {
  const trunks = [];
  const leaves = [];
  const canopy = [
    [0, 0, 0],
    [0.78, 0, 0],
    [-0.78, 0, 0],
    [0, 0, 0.78],
    [0, 0, -0.78],
    [0, 0.78, 0],
  ];

  for (let x = -24; x <= 24; x += 2) {
    for (let z = -18; z <= 20; z += 2) {
      if (!insideIsland(x, z) || hash2(x * 1.7, z * 2.1) < 0.78) {
        continue;
      }

      const ground = surfaceHeight(x, z);
      const slope = Math.max(
        Math.abs(surfaceHeight(x + 1, z) - ground),
        Math.abs(surfaceHeight(x, z + 1) - ground),
      );
      const nearWaterfall =
        Math.abs(x - WORLD.waterfallX) < 4 &&
        z > WORLD.waterfallStartZ - 2;

      if (ground < 0 || ground > 7 || slope > 2 || nearWaterfall) {
        continue;
      }

      const trunkHeight = 2 + Math.floor(hash2(x * 3.1, z * 4.2) * 2);
      for (let level = 1; level <= trunkHeight; level += 1) {
        trunks.push({
          position: [x, ground + level, z],
          scale: [0.42, 0.96, 0.42],
          color: 0x6a4936,
        });
      }

      for (const [dx, dy, dz] of canopy) {
        const leafShade = hash2(x + dx * 5, z + dz * 7 + dy);
        leaves.push({
          position: [
            x + dx,
            ground + trunkHeight + 0.35 + dy,
            z + dz,
          ],
          scale: [0.82, 0.82, 0.82],
          color: leafShade > 0.5 ? 0x416955 : 0x355b4d,
        });
      }
    }
  }

  world.add(
    makeInstanced(
      trunks,
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 1,
        vertexColors: true,
      }),
      { castShadow: true, receiveShadow: true },
    ),
  );
  world.add(
    makeInstanced(
      leaves,
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.9,
        vertexColors: true,
      }),
      { castShadow: true, receiveShadow: true },
    ),
  );

  return trunks.length + leaves.length;
}

function buildWaterfall(world) {
  const path = waterfallPath();
  const water = [];
  const foam = [];

  for (let index = 0; index < path.length; index += 1) {
    const point = path[index];
    const next = path[index + 1];
    water.push({
      position: [point.x, point.y + 0.57, point.z],
      scale: [1.68, 0.16, 0.94],
      color: index % 3 === 0 ? 0x80dce3 : 0x58b9cf,
    });

    if (!next) {
      continue;
    }

    const drop = Math.max(0, point.y - next.y);
    for (let level = next.y + 1; level <= point.y; level += 1) {
      water.push({
        position: [point.x, level + 0.02, point.z + 0.48],
        scale: [1.68, 0.96, 0.17],
        color: level % 2 === 0 ? 0x75d2dd : 0x49aac4,
      });
    }

    if (drop >= 2) {
      foam.push({
        position: [point.x, point.y + 0.72, point.z + 0.3],
        scale: [1.82, 0.18, 0.6],
        color: 0xe7f7f4,
      });
    }
  }

  for (let x = WORLD.waterfallX - 5; x <= WORLD.waterfallX + 5; x += 1) {
    for (let z = 14; z <= 22; z += 1) {
      const distance =
        ((x - WORLD.waterfallX) / 5.4) ** 2 + ((z - 18) / 4.1) ** 2;
      if (distance >= 0.9) {
        continue;
      }
      water.push({
        position: [x, 1.28, z],
        scale: [0.98, 0.2, 0.98],
        color: hash2(x * 4, z * 3) > 0.5 ? 0x438ca4 : 0x397b95,
      });
    }
  }

  const material = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.16,
    metalness: 0.08,
    transparent: true,
    opacity: 0.87,
    depthWrite: false,
    emissive: 0x174e66,
    emissiveIntensity: 0.42,
    vertexColors: true,
  });
  const waterMesh = makeInstanced(
    water,
    new THREE.BoxGeometry(1, 1, 1),
    material,
    { receiveShadow: true },
  );
  waterMesh.renderOrder = 4;
  world.add(waterMesh);

  const foamMesh = makeInstanced(
    foam,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.7,
      depthWrite: false,
      vertexColors: true,
    }),
  );
  foamMesh.renderOrder = 5;
  world.add(foamMesh);

  const particles = makeCascadeParticles(path);
  world.add(particles.points);

  return {
    count: water.length + foam.length,
    material,
    update: particles.update,
  };
}

function makeCascadeParticles(path) {
  const count = 80;
  const positions = new Float32Array(count * 3);
  const phases = new Float32Array(count);
  const speeds = new Float32Array(count);

  for (let index = 0; index < count; index += 1) {
    phases[index] = hash2(index * 2.7, index * 4.1);
    speeds[index] = 0.035 + hash2(index * 5.3, index * 1.9) * 0.035;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  const points = new THREE.Points(
    geometry,
    new THREE.PointsMaterial({
      color: 0xcffaff,
      size: 0.28,
      transparent: true,
      opacity: 0.82,
      depthWrite: false,
      sizeAttenuation: true,
    }),
  );
  points.renderOrder = 6;

  function update(elapsed) {
    for (let index = 0; index < count; index += 1) {
      const progress = (phases[index] + elapsed * speeds[index]) % 1;
      const pathPosition = progress * (path.length - 1);
      const pathIndex = Math.min(path.length - 2, Math.floor(pathPosition));
      const local = pathPosition - pathIndex;
      const from = path[pathIndex];
      const to = path[pathIndex + 1];
      const offset = index * 3;

      positions[offset] =
        THREE.MathUtils.lerp(from.x, to.x, local) +
        (hash2(index * 3, 2) - 0.5) * 1.2;
      positions[offset + 1] =
        THREE.MathUtils.lerp(from.y, to.y, local) +
        0.78 +
        Math.sin(index * 4.7 + elapsed * 3) * 0.08;
      positions[offset + 2] =
        THREE.MathUtils.lerp(from.z, to.z, local) + 0.18;
    }
    geometry.attributes.position.needsUpdate = true;
  }

  update(0);
  return { points, update };
}

function buildCloudBand(world, options) {
  const items = [];

  for (let cluster = 0; cluster < options.clusters; cluster += 1) {
    const centerX =
      -39 +
      cluster * (78 / Math.max(1, options.clusters - 1)) +
      (hash2(cluster * 4.1, options.phase) - 0.5) * 7;
    const centerY =
      options.y + (hash2(cluster * 8.2, options.phase + 2) - 0.5) * 3.5;
    const centerZ =
      options.z + (hash2(cluster * 2.3, options.phase + 5) - 0.5) * 12;
    const blocks = 9 + Math.floor(hash2(cluster * 6.4, options.phase) * 5);

    for (let block = 0; block < blocks; block += 1) {
      const angle = hash2(block * 7.1, cluster * 3.3 + options.phase) * Math.PI * 2;
      const radius = Math.sqrt(hash2(block * 4.7, cluster + options.phase)) * 5;
      const lift =
        (hash2(block * 8.9, cluster * 5.1 + options.phase) - 0.5) * 2.1;
      const width =
        (2.6 + hash2(block * 1.7, cluster * 9.2) * 3.8) * options.scale;

      items.push({
        position: [
          centerX + Math.cos(angle) * radius,
          centerY + lift,
          centerZ + Math.sin(angle) * radius * 0.72,
        ],
        scale: [
          width,
          (1.15 + hash2(block * 3.9, cluster * 7.7) * 1.7) * options.scale,
          (2.4 + hash2(block * 6.8, cluster * 2.6) * 3.2) * options.scale,
        ],
      });
    }
  }

  const group = new THREE.Group();
  const cloudMesh = makeInstanced(
    items,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshLambertMaterial({
      color: options.tint,
      transparent: true,
      opacity: options.opacity,
      depthWrite: false,
    }),
  );
  cloudMesh.renderOrder = 3;
  group.add(cloudMesh);
  world.add(group);

  return {
    group,
    count: items.length,
    amplitude: 3 + options.scale * 1.5,
    speed: 0.018 + options.opacity * 0.02,
    phase: options.phase,
  };
}

function makeInstanced(items, geometry, material, options = {}) {
  const mesh = new THREE.InstancedMesh(geometry, material, items.length);
  const transform = new THREE.Object3D();
  const color = new THREE.Color();
  let hasColors = false;

  items.forEach((item, index) => {
    transform.position.fromArray(item.position);
    transform.scale.fromArray(item.scale);
    transform.updateMatrix();
    mesh.setMatrixAt(index, transform.matrix);

    if (item.color !== undefined) {
      color.setHex(item.color);
      mesh.setColorAt(index, color);
      hasColors = true;
    }
  });

  mesh.instanceMatrix.needsUpdate = true;
  if (hasColors) {
    mesh.instanceColor.needsUpdate = true;
  }
  mesh.castShadow = options.castShadow ?? false;
  mesh.receiveShadow = options.receiveShadow ?? false;
  mesh.computeBoundingSphere();
  return mesh;
}
