import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const distRoot = resolve(projectRoot, "dist");
const outputPath = resolve(projectRoot, "..", "voxel-mountain-offline.html");
let html = await readFile(resolve(distRoot, "index.html"), "utf8");

const stylesheet = html.match(
  /<link[^>]+rel="stylesheet"[^>]+href="([^"]+)"[^>]*>/,
);
if (stylesheet) {
  const cssPath = resolve(distRoot, stylesheet[1].replace(/^\.?\//, ""));
  const css = await readFile(cssPath, "utf8");
  html = html.replace(stylesheet[0], "<style>" + css + "</style>");
}

const moduleScript = html.match(
  /<script[^>]+type="module"[^>]+src="([^"]+)"[^>]*><\/script>/,
);
if (!moduleScript) {
  throw new Error("Vite module entry was not found in dist/index.html");
}

const jsPath = resolve(distRoot, moduleScript[1].replace(/^\.?\//, ""));
const javascript = (await readFile(jsPath, "utf8")).replace(
  /<\/script/gi,
  "<\\/script",
);
html = html.replace(
  moduleScript[0],
  "<script type=\"module\">" + javascript + "</script>",
);

await writeFile(outputPath, html);
console.log("Offline HTML:", outputPath);
