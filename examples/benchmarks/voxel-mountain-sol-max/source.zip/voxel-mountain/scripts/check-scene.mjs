import assert from "node:assert/strict";
import {
  WORLD,
  insideIsland,
  surfaceHeight,
  waterfallPath,
} from "../src/terrain.js";

assert.equal(insideIsland(0, 0), true, "world center should exist");
assert.equal(
  insideIsland(WORLD.radiusX + 1, 0),
  false,
  "terrain must keep its bounded island footprint",
);

const mainPeak = surfaceHeight(-7, -6);
const secondaryPeak = surfaceHeight(9, -8);
assert.ok(mainPeak >= 27, "main peak must rise above the cloud deck");
assert.ok(secondaryPeak >= 18, "secondary peak must remain visually distinct");
assert.ok(
  mainPeak > surfaceHeight(-7, 12),
  "the main peak needs a meaningful downhill silhouette",
);

const path = waterfallPath();
assert.equal(
  path.length,
  WORLD.waterfallEndZ - WORLD.waterfallStartZ + 1,
  "waterfall should span the complete carved channel",
);
for (let index = 1; index < path.length; index += 1) {
  assert.ok(
    path[index].y <= path[index - 1].y,
    "waterfall channel must never climb uphill",
  );
}
assert.ok(
  path[0].y - path.at(-1).y >= 20,
  "waterfall needs enough total drop to read as a cascade",
);

console.log(
  "Scene checks passed:",
  "main peak " + mainPeak,
  "secondary peak " + secondaryPeak,
  "waterfall drop " + (path[0].y - path.at(-1).y),
);
