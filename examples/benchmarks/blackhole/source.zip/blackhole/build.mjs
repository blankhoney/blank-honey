import { build } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
const {outputFiles}=await build({entryPoints:['src/main.js'],bundle:true,write:false,format:'iife',minify:true,loader:{'.glsl':'text'},legalComments:'inline',target:['es2020']});
const readCSS=await readFile('src/style.css','utf8');
let html=await readFile('src/shell.html','utf8');
html=html.replace('/* STYLES */',()=>readCSS).replace('/* APPLICATION */',()=>outputFiles[0].text.replaceAll('</script','<\\/script'));
await writeFile('index.html',html);
console.log(`Built offline index.html (${(html.length/1024).toFixed(0)} KB)`);
