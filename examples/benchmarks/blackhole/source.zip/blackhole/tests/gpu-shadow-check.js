(() => {
 const a=window.__UMBRA__,u=a.uniforms,r=a.renderer,m=a.rayMaterial;
 const saved={shader:m.fragmentShader,position:a.camera.position.clone(),rotation:a.camera.quaternion.clone(),res:u.resolution.value.clone(),aspect:u.aspect.value,fov:u.fovScale.value,disk:u.diskOn.value,quad:a.quad.material,auto:a.controls.autoRotate};
 const n=1025,half=(n-1)/2,bcrit=3*Math.sqrt(3),r0=55,fov=.12;
 a.controls.autoRotate=false;a.camera.position.set(0,0,r0);a.camera.lookAt(0,0,0);a.camera.updateMatrixWorld();
 u.resolution.value.set(n,n);u.aspect.value=1;u.fovScale.value=fov;u.diskOn.value=false;u.jitter.value.set(0,0);
 m.fragmentShader=m.fragmentShader.replace('return diagnostic==0?sky(cos(end)*er+sin(end)*et):vec3(.008);','return vec3(1);');m.needsUpdate=true;
 r.setSize(n,n,false);a.quad.material=m;r.setRenderTarget(null);r.render(a.scene,a.quadCamera);
 const gl=r.getContext(),pixels=new Uint8Array(n*4);gl.readPixels(0,half,n,1,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
 let mismatches=0,firstEscaped=null;const errors=[];
 for(let x=0;x<n;x++) {const q=(2*(x+.5)/n-1)*fov;const b=r0*Math.abs(q)/Math.sqrt(1+q*q)/Math.sqrt(1-2/r0);const expected=b>=bcrit;const escaped=pixels[4*x]>128;if(escaped!==expected){mismatches++;errors.push({x,b,escaped});}if(x>half&&escaped&&firstEscaped===null)firstEscaped=x;}
 const sinAlpha=bcrit*Math.sqrt(1-2/r0)/r0;const predictedRadius=sinAlpha/Math.sqrt(1-sinAlpha*sinAlpha)/fov*n/2;
 m.fragmentShader=saved.shader;m.needsUpdate=true;a.camera.position.copy(saved.position);a.camera.quaternion.copy(saved.rotation);a.camera.updateMatrixWorld();u.resolution.value.copy(saved.res);u.aspect.value=saved.aspect;u.fovScale.value=saved.fov;u.diskOn.value=saved.disk;a.quad.material=saved.quad;a.controls.autoRotate=saved.auto;r.setSize(saved.res.x,saved.res.y,false);window.dispatchEvent(new Event('resize'));
 return {pixelsTested:n,mismatches,errors,predictedShadowRadiusPixels:predictedRadius,firstEscapedPixelRadius:firstEscaped-half,step:u.stepSize.value};
})();
