# UMBRA · 黑洞观测站

基于 Three.js / WebGL2 的 Schwarzschild 黑洞实时光线追踪。包含真实零测地线积分、引力透镜、吸积盘高阶像、引力红移、相对论多普勒效应和热辐射。全部依赖已经内嵌到 `index.html`，无需联网。

## 直接观看

用现代桌面浏览器打开 `index.html`，自动开始渲染并缓慢环绕。支持系统“减少动态效果”偏好。无需安装、无需 CDN、无需启动服务器。需要 WebGL2 和硬件加速。

- 鼠标左键拖拽：OrbitControls 旋转视角，开始拖拽后自动环绕停止。
- 滚轮 / 双指捏合：缩放，观测距离限制为 30–140 GM/c²。
- 右侧面板：倾角、温度、曝光、精度、频移与成像阶次诊断；吸积盘、星空、环绕开关。
- H：隐藏或显示界面；“保存画面”：导出当前画布 PNG，不含界面。
- ⓘ：查看物理模型、限制与参考文献。
- 手机窄屏采用可滚动控制面板；本次未进行真机验证。

## 安装、构建和启动

需要 Node.js 20+。以下命令在本项目目录执行：

```sh
npm ci
npm run build
npm start
```

随后打开 http://127.0.0.1:4173 。启动后直接展示模拟，不需要额外点击。内置服务器只绑定本机。修改源码后重新构建并重启服务器。

```sh
npm test
# 如果 4173 被占用：
PORT=4174 npm start
```

`npm ci` 需要网络安装开发依赖；已交付的 `index.html` 运行不需要网络。仅 `npm start` 不需要安装任何包，因为服务器只使用 Node 内置模块。

## 项目结构

```text
blackhole/
├── index.html                 # 可直接打开的独立成品
├── src/
│   ├── main.js                # Three.js、OrbitControls、光谱 LUT、累积抗锯齿、交互
│   ├── raytrace.glsl           # 实际 GPU 零测地线与辐射追踪器
│   ├── physics.mjs            # CPU 参考积分器、盘通量和 Planck/CIE 光谱
│   ├── shell.html             # 界面模板与模型说明
│   └── style.css              # 响应式样式
├── tests/
│   ├── physics.test.mjs       # 8 项解析/数值物理测试
│   └── gpu-shadow-check.js    # 在运行页面控制台执行的 GPU 阴影检查
├── build.mjs                  # esbuild 打包为离线单文件
├── serve.mjs                  # 零依赖本地服务器
├── package.json
├── package-lock.json          # 固定 Three.js 0.186.0、esbuild 0.28.2
├── PHYSICS.md                 # 方程、辐射模型、精度边界与来源
├── VALIDATION.md              # 本次实际运行证据
└── THIRD_PARTY_LICENSES.txt
```

## 物理与性能

采用 G=c=M=1，距离单位 r_g=GM/c²。事件视界 r=2、光子球 r=3、最内稳定圆轨道 r=6；临界冲量参数 b=3√3。逐像素用 RK4 积分 `u″ = −u + 3u²`。盘面在 r=6–28，采用 Page–Thorne 零内缘应力通量；温度默认峰值 6500 K；相机默认距离 55 r_g、倾角 82°。

提供 0.025 / 0.012 / 0.006 rad 的最大角步长，运动时单样本实时追踪；视角停止后累积 12 / 24 / 48 个抖动样本，减轻窄透镜像和边缘走样。渲染最长边分别限制为 1100 / 1600 / 2200 像素，保护高 DPI 设备性能。累积样本完成不代表物理积分误差为零。

这是固定 Schwarzschild 几何中的稳态薄盘辐射模拟。未包含 Kerr 自旋、GRMHD、磁场、盘厚度、散射、回返辐射、喷流或盘自引力。色谱积分、浮点精度和高阶光路长度有限。完整模型与来源见 [PHYSICS.md](PHYSICS.md)。

## 实际运行

2026-09-14 已通过本地 HTTP 与 `file://` 在 Chromium / WebGL2 运行。8/8 CPU 测试通过；GPU 阴影检测 1025 个像素的捕获/逃逸分类全部匹配解析边界。测试期间精细模式约 34–45 FPS，具体结果随设备、视口与负载变化。离线页面运行时资源请求列表为空。

应用内 Browser 的 `file://` 预览被其 URL 安全策略拒绝；未绕过该策略。此前独立 Chromium 中的文件打开和渲染验证已成功。直接在用户自己的浏览器打开 HTML，或按上述命令启动项目。详见 [VALIDATION.md](VALIDATION.md)。
