import http from 'node:http';
import { readFile } from 'node:fs/promises';
const port=Number(process.env.PORT||4173);
const html=await readFile(new URL('./index.html',import.meta.url));
http.createServer((req,res)=>{if(req.url==='/'||req.url==='/index.html'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);}else if(req.url==='/favicon.ico'){res.writeHead(204);res.end();}else{res.writeHead(404);res.end('Not found');}}).listen(port,'127.0.0.1',()=>console.log(`UMBRA → http://127.0.0.1:${port}`));
