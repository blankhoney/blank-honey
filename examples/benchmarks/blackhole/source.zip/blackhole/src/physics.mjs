// Geometrized units G = c = M = 1. CPU reference for the GPU integrator.
export const CRITICAL_B = 3 * Math.sqrt(3);
export function rk4([u,v], h) {
  const f = x => -x + 3*x*x;
  const a = [v,f(u)];
  const b = [v+h*a[1]/2,f(u+h*a[0]/2)];
  const c = [v+h*b[1]/2,f(u+h*b[0]/2)];
  const d = [v+h*c[1],f(u+h*c[0])];
  return [u+h*(a[0]+2*b[0]+2*c[0]+d[0])/6,
    v+h*(a[1]+2*b[1]+2*c[1]+d[1])/6];
}
export function trace(b, h=.01, rObserver=1000) {
  let s=[1/rObserver,Math.sqrt(1/b**2-(1-2/rObserver)/rObserver**2)];
  let phi=0, maxInvariantError=0;
  for(let i=0;i<100000;i++) {
    const prev=s; s=rk4(s,h); phi+=h;
    maxInvariantError=Math.max(maxInvariantError,Math.abs((s[1]**2+s[0]**2-2*s[0]**3)*b*b-1));
    if(s[0]>=.5) return {kind:'captured',phi,maxInvariantError};
    if(s[0]<=0) return {kind:'escaped',phi:phi-h+h*prev[0]/(prev[0]-s[0]),maxInvariantError};
  }
  return {kind:'unresolved',phi,maxInvariantError};
}
export function diskFlux(r) {
  if(r<=6) return 0;
  const x=Math.sqrt(r), x0=Math.sqrt(6), a=Math.sqrt(3);
  const integral=x-x0-a/2*Math.log(((x-a)/(x+a))/((x0-a)/(x0+a)));
  return Math.max(0,integral/(r**2.5*(r-3)));
}
export function redshift(r,rObserver,backwardLy) {
  return Math.sqrt(1-3/r)/(Math.sqrt(1-2/rObserver)*(1+backwardLy/r**1.5));
}
// Wyman, Sloan & Shirley (JCGT 2013), analytic fits to CIE 1931 matching functions.
function cie(w) {
  const g=(m,left,right)=>Math.exp(-.5*((w-m)*(w<m?left:right))**2);
  return [.362*g(442,.0624,.0374)+1.056*g(599.8,.0264,.0323)-.065*g(501.1,.049,.0382),
    .821*g(568.8,.0213,.0247)+.286*g(530.9,.0613,.0322),
    1.217*g(437,.0845,.0278)+.681*g(459,.0385,.0725)];
}
export function blackbodyRGB(T) {
  if(T<=0)return [0,0,0];
  const xyz=[0,0,0];
  for(let w=380;w<=780;w+=5) {
    const power=(550/w)**5 / Math.expm1(14387768.77/(w*T));
    const c=cie(w); for(let j=0;j<3;j++)xyz[j]+=power*c[j]*5/100;
  }
  const [x,y,z]=xyz;
  return [3.2406*x-1.5372*y-.4986*z,-.9689*x+1.8758*y+.0415*z,.0557*x-.204*y+1.057*z].map(v=>Math.max(0,v));
}
