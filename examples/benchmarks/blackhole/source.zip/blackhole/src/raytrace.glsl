precision highp float;
uniform vec2 resolution;
uniform vec2 jitter;
uniform mat4 cameraWorld;
uniform float fovScale;
uniform float aspect;
uniform float stepSize;
uniform float temperature;
uniform float fluxPeak;
uniform float diskOuter;
uniform float exposure;
uniform float skyLevel;
uniform bool diskOn;
uniform bool shiftOn;
uniform int diagnostic;
uniform sampler2D spectrum;
uniform sampler2D skyMap;
const float PI=3.141592653589793;
vec2 deriv(vec2 s) { return vec2(s.y,-s.x+3.0*s.x*s.x); }
vec2 rk4(vec2 s,float h) {
  vec2 a=deriv(s), b=deriv(s+.5*h*a), c=deriv(s+.5*h*b), d=deriv(s+h*c);
  return s+h*(a+2.0*b+2.0*c+d)/6.0;
}
float flux(float r) {
  float x=sqrt(r), a=sqrt(3.0), x0=sqrt(6.0);
  float integral=x-x0-.5*a*log(((x-a)/(x+a))/((x0-a)/(x0+a)));
  return max(0.0,integral/(pow(r,2.5)*(r-3.0)));
}
vec3 planck(float T) {
  float index=clamp(T/60000.0,0.0,1.0)*1023.0;
  return texture2D(spectrum,vec2((index+.5)/1024.0,.5)).rgb;
}
vec3 sky(vec3 direction) {
  vec2 uv=vec2(atan(direction.z,direction.x)/(2.0*PI)+.5,asin(clamp(direction.y,-1.0,1.0))/PI+.5);
  return textureLod(skyMap,uv,0.75).rgb*skyLevel;
}
vec3 traceRay(vec3 origin,vec3 ray) {
  float r0=length(origin), f0=1.0-2.0/r0;
  vec3 er=origin/r0;
  float mu=dot(ray,er);
  vec3 tangential=ray-mu*er;
  float sinAlpha=length(tangential);
  if(sinAlpha<1e-6) return mu<0.0?vec3(0):sky(ray);
  vec3 et=tangential/sinAlpha;
  // Direction measured in the static observer's orthonormal tetrad.
  float b=r0*sinAlpha/sqrt(f0);
  float Ly=b*cross(er,et).y; // Backward ray angular momentum; future photon has -Ly.
  vec2 state=vec2(1.0/r0,-mu/b);
  float phi=0.0;
  // The ray plane intersects y=0 at this angle, then every pi.
  float nextCross=mod(atan(-er.y,et.y),PI);
  if(nextCross<1e-5)nextCross+=PI;
  for(int i=0;i<2400;i++) {
    // Limit relative radial change near radial rays, without changing the orbit equation.
    float h=min(stepSize,.18*max(state.x,.002)/max(abs(state.y),.0001));
    vec2 next=rk4(state,h);
    if(diskOn && phi+h>=nextCross) {
      vec2 hit=rk4(state,nextCross-phi);
      if(hit.x>0.0) {
        float r=1.0/hit.x;
        if(r>=6.0 && r<=diskOuter) {
          float g=sqrt(1.0-3.0/r)/(sqrt(f0)*(1.0+Ly/pow(r,1.5)));
          if(diagnostic==1) return g<1.0?mix(vec3(.1,.65,.68),vec3(1,.17,.06),clamp((1.0-g)*2.2,0.0,1.0)):mix(vec3(.1,.65,.68),vec3(.25,.4,1),clamp((g-1.0)*1.6,0.0,1.0));
          if(diagnostic==2) return nextCross<PI?vec3(.9,.44,.16):nextCross<2.0*PI?vec3(.16,.72,.72):vec3(.62,.32,1);
          // Liouville: g^3 B_nu(nu/g,T) = B_nu(nu,g*T).
          float T=temperature*pow(flux(r)/fluxPeak,.25);
          return planck(T*(shiftOn?g:1.0));
        }
      }
      nextCross+=PI;
    }
    if(next.x>=.5)return vec3(0); // Event horizon r=2, never an emissive surface.
    if(next.x<=0.0) {
      // Refine the u=0 endpoint with bisection in the final RK4 step.
      float lo=0.0,hi=h;
      for(int j=0;j<8;j++) {
        float mid=.5*(lo+hi);
        if(rk4(state,mid).x>0.0)lo=mid; else hi=mid;
      }
      float end=phi+.5*(lo+hi);
      return diagnostic==0?sky(cos(end)*er+sin(end)*et):vec3(.008);
    }
    state=next; phi+=h;
  }
  // Finite angular budget: unresolved exponentially narrow critical rays are black.
  return vec3(0);
}
void main() {
  vec2 xy=(gl_FragCoord.xy+jitter)/resolution*2.0-1.0;
  vec3 local=normalize(vec3(xy.x*aspect*fovScale,xy.y*fovScale,-1.0));
  vec3 ray=normalize(mat3(cameraWorld)*local);
  vec3 color=traceRay(cameraWorld[3].xyz,ray);
  // Exposure and display transform only; no artificial emissive photon ring or bloom.
  color=vec3(1)-exp(-max(color,vec3(0))*exposure*18.0);
  color=mix(12.92*color,1.055*pow(color,vec3(1.0/2.4))-.055,step(vec3(.0031308),color));
  gl_FragColor=vec4(color,1);
}
