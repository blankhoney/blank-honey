import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import fragmentShader from './raytrace.glsl';
import { blackbodyRGB, diskFlux } from './physics.mjs';
const $=id=>document.getElementById(id);
function fail(message){$('error').hidden=false;$('error').textContent=message;}
window.addEventListener('error',e=>fail(`运行错误：${e.message}`));
try { init(); } catch(e) {fail(`无法初始化 WebGL2：${e.message}。请使用支持 WebGL2 的现代浏览器，并开启硬件加速。`);console.error(e);}
function init(){
const renderer=new THREE.WebGLRenderer({canvas:$('universe'),antialias:false,alpha:false,preserveDrawingBuffer:true,powerPreference:'high-performance'});
renderer.autoClear=false;
renderer.debug.onShaderError=(gl,p,vs,fs)=>{fail('光线追踪着色器编译失败，请查看控制台。');console.error(gl.getProgramInfoLog(p),gl.getShaderInfoLog(fs));};
const camera=new THREE.PerspectiveCamera(40,1,.1,500);
const controls=new OrbitControls(camera,renderer.domElement);
controls.enableDamping=true;controls.dampingFactor=.075;controls.enablePan=false;
controls.minDistance=30;controls.maxDistance=140;controls.minPolarAngle=.015;controls.maxPolarAngle=Math.PI-.015;
controls.autoRotateSpeed=.22;controls.zoomSpeed=.55;controls.rotateSpeed=.45;
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
controls.autoRotate=!reducedMotion; $('auto').checked=controls.autoRotate;
let dirty=true,samples=0,frameCount=0,lastStatus=performance.now(),fps=0;
let preset='high',width=0,height=0;
const settings={balanced:{step:.025,max:1100,samples:12},high:{step:.012,max:1600,samples:24},ultra:{step:.006,max:2200,samples:48}};
const spectrumData=new Float32Array(1024*4);
for(let i=0;i<1024;i++){spectrumData.set([...blackbodyRGB(i/1023*60000),1],i*4);}
const spectrum=new THREE.DataTexture(spectrumData,1024,1,THREE.RGBAFormat,THREE.FloatType);
spectrum.minFilter=THREE.LinearFilter;spectrum.magFilter=THREE.LinearFilter;spectrum.needsUpdate=true;
function makeSky(){
  const c=document.createElement('canvas');c.width=4096;c.height=2048;const ctx=c.getContext('2d');
  ctx.fillStyle='#020406';ctx.fillRect(0,0,c.width,c.height);
  let seed=1931;const rand=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
  // A seeded, static, synthetic celestial sphere; never screen-space stars.
  for(let i=0;i<24000;i++){
    const x=rand()*c.width, y=Math.acos(2*rand()-1)/Math.PI*c.height;
    const brightness=rand(),radius=.14+Math.pow(brightness,12)*.65;
    const alpha=.09+brightness*.5;
    ctx.fillStyle=`rgba(${190+rand()*65},${195+rand()*60},255,${alpha})`;
    ctx.beginPath();ctx.arc(x,y,radius,0,Math.PI*2);ctx.fill();
  }
  const tex=new THREE.CanvasTexture(c);tex.wrapS=THREE.RepeatWrapping;tex.colorSpace=THREE.SRGBColorSpace;
  tex.anisotropy=renderer.capabilities.getMaxAnisotropy();return tex;
}
let fluxPeak=0;for(let r=6;r<30;r+=.005)fluxPeak=Math.max(fluxPeak,diskFlux(r));
const uniforms={resolution:{value:new THREE.Vector2()},jitter:{value:new THREE.Vector2()},cameraWorld:{value:camera.matrixWorld},fovScale:{value:Math.tan(THREE.MathUtils.degToRad(camera.fov/2))},aspect:{value:1},stepSize:{value:.012},temperature:{value:6500},fluxPeak:{value:fluxPeak},diskOuter:{value:28},exposure:{value:1},skyLevel:{value:.045},diskOn:{value:true},shiftOn:{value:true},diagnostic:{value:0},spectrum:{value:spectrum},skyMap:{value:makeSky()}};
const vertexShader='varying vec2 vUv; void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
const scene=new THREE.Scene(),quadCamera=new THREE.Camera();
const rayMaterial=new THREE.ShaderMaterial({vertexShader,fragmentShader,uniforms,depthTest:false,depthWrite:false});
const quad=new THREE.Mesh(new THREE.PlaneGeometry(2,2),rayMaterial);scene.add(quad);
const blend=new THREE.ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,uniforms:{current:{value:null},previous:{value:null},weight:{value:1}},fragmentShader:'varying vec2 vUv; uniform sampler2D current,previous; uniform float weight; void main(){gl_FragColor=mix(texture2D(previous,vUv),texture2D(current,vUv),weight);}'});
const display=new THREE.ShaderMaterial({vertexShader,depthTest:false,depthWrite:false,uniforms:{frame:{value:null}},fragmentShader:'varying vec2 vUv; uniform sampler2D frame; void main(){gl_FragColor=texture2D(frame,vUv);}'});
const type=renderer.extensions.has('EXT_color_buffer_float')?THREE.HalfFloatType:THREE.UnsignedByteType;
const options={type,depthBuffer:false,stencilBuffer:false};
const current=new THREE.WebGLRenderTarget(1,1,options);let previous=new THREE.WebGLRenderTarget(1,1,options),accumulated=new THREE.WebGLRenderTarget(1,1,options);
function resize(){const max=settings[preset].max;const scale=Math.min(devicePixelRatio||1,max/Math.max(innerWidth,innerHeight));width=Math.round(innerWidth*scale);height=Math.round(innerHeight*scale);renderer.setSize(width,height,false);for(const t of [current,previous,accumulated])t.setSize(width,height);uniforms.resolution.value.set(width,height);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();uniforms.aspect.value=camera.aspect;dirty=true;}
function reset(){camera.position.set(0,55*Math.cos(82*Math.PI/180),55*Math.sin(82*Math.PI/180));controls.target.set(0,0,0);controls.update();dirty=true;}
function updateReadouts(){const angle=THREE.MathUtils.radToDeg(controls.getPolarAngle());$('inclination').value=angle;$('inclination-value').textContent=`${angle.toFixed(0)}°`;$('distance-value').innerHTML=`${camera.position.length().toFixed(1)} <small>r<sub>g</sub></small>`;}
controls.addEventListener('change',()=>{dirty=true;updateReadouts();});
controls.addEventListener('start',()=>{controls.autoRotate=false;$('auto').checked=false;});
$('inclination').addEventListener('input',e=>{const s=new THREE.Spherical().setFromVector3(camera.position);s.phi=Number(e.target.value)*Math.PI/180;camera.position.setFromSpherical(s);controls.update();dirty=true;});
$('temperature').addEventListener('input',e=>{uniforms.temperature.value=+e.target.value;$('temperature-value').textContent=`${(+e.target.value).toLocaleString()} K`;dirty=true;});
$('exposure').addEventListener('input',e=>{uniforms.exposure.value=+e.target.value;$('exposure-value').textContent=`${(+e.target.value).toFixed(2)} ×`;dirty=true;});
$('quality').addEventListener('change',e=>{preset=e.target.value;uniforms.stepSize.value=settings[preset].step;resize();});
$('diagnostic').addEventListener('change',e=>{uniforms.diagnostic.value=+e.target.value;$('mode-caption').textContent=['颜色来自红移后的黑体光谱','红：g < 1　青：g ≈ 1　蓝：g > 1','橙：直接像　青：次级像　紫：更高阶'][+e.target.value];dirty=true;});
for(const [id,key,on] of [['redshift','shiftOn',true],['disk','diskOn',true],['stars','skyLevel',.045]])$(id).addEventListener('change',e=>{uniforms[key].value=e.target.checked?on:(id==='stars'?0:false);dirty=true;});
$('auto').addEventListener('change',e=>{controls.autoRotate=e.target.checked;dirty=true;});
$('reset').addEventListener('click',reset);
$('capture').addEventListener('click',()=>{const a=document.createElement('a');a.download='umbra-schwarzschild.png';a.href=renderer.domElement.toDataURL('image/png');a.click();});
$('info-open').addEventListener('click',()=>$('physics').showModal());$('info-close').addEventListener('click',()=>$('physics').close());
$('physics').addEventListener('click',e=>{if(e.target===$('physics')){const r=$('physics').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('physics').close();}});
function toggleUI(){document.body.classList.toggle('ui-hidden');$('show-ui').hidden=!document.body.classList.contains('ui-hidden');}
$('show-ui').addEventListener('click',toggleUI);window.addEventListener('keydown',e=>{if(e.key.toLowerCase()==='h'&&!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName))toggleUI();});
window.addEventListener('resize',resize);
renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();fail('图形上下文丢失，请刷新页面恢复模拟。');});
let lastTime=performance.now();
function halton(i,b){let f=1,result=0;for(;i>0;i=Math.floor(i/b)){f/=b;result+=f*(i%b);}return result;}
function animate(now){requestAnimationFrame(animate);if(document.hidden)return;const dt=Math.min((now-lastTime)/1000,.1);lastTime=now;controls.update(dt);if(dirty){samples=0;dirty=false;}
  if(samples<settings[preset].samples){camera.updateMatrixWorld();uniforms.jitter.value.set(samples?halton(samples,2)-.5:0,samples?halton(samples,3)-.5:0);quad.material=rayMaterial;renderer.setRenderTarget(current);renderer.render(scene,quadCamera);blend.uniforms.current.value=current.texture;blend.uniforms.previous.value=previous.texture;blend.uniforms.weight.value=1/(samples+1);quad.material=blend;renderer.setRenderTarget(accumulated);renderer.render(scene,quadCamera);display.uniforms.frame.value=accumulated.texture;quad.material=display;renderer.setRenderTarget(null);renderer.render(scene,quadCamera);[previous,accumulated]=[accumulated,previous];samples++;frameCount++;}
  if(now-lastStatus>700){fps=frameCount*1000/(now-lastStatus);frameCount=0;lastStatus=now;$('status').textContent=`${width} × ${height}  ·  ${samples>=settings[preset].samples?`${samples} SPP · 已收敛`:`${fps.toFixed(0)} FPS · RK4`}`;}
}
// Read-only inspection plus the exact production material for reproducible GPU checks.
window.__UMBRA__={camera,controls,renderer,uniforms,rayMaterial,scene,quad,quadCamera,get state(){return {width,height,samples,preset,fluxPeak,autoRotate:controls.autoRotate,position:camera.position.toArray(),webgl:renderer.getContext().getParameter(renderer.getContext().VERSION)};}};
reset();resize();requestAnimationFrame(animate);
}
