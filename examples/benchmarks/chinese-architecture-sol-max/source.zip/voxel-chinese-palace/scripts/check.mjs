import assert from 'node:assert/strict';
import { AXIS_ROUTE, BUILDINGS } from '../src/scene-plan.js';

assert.ok(BUILDINGS.length >= 5, '建筑数量必须不少于 5 座');

const main = BUILDINGS.find((building) => building.kind === 'mainHall');
assert.ok(main && main.x === 0, '主殿必须位于中轴线上');
assert.ok(
  BUILDINGS.every((building) => building === main || main.width * main.depth > building.width * building.depth),
  '主殿必须是体量最大的建筑'
);

for (const kind of ['sideHall', 'tower']) {
  const pair = BUILDINGS.filter((building) => building.kind === kind);
  assert.equal(pair.length, 2, `${kind} 必须成对布置`);
  assert.equal(pair[0].x, -pair[1].x, `${kind} 必须关于中轴对称`);
  assert.equal(pair[0].z, pair[1].z, `${kind} 必须位于同一进深`);
}

assert.ok(BUILDINGS.some((building) => building.kind === 'gate'), '必须包含山门');
assert.ok(BUILDINGS.some((building) => building.kind === 'pagoda'), '必须包含宝塔');
assert.deepEqual(AXIS_ROUTE.map(({ x }) => x), Array(AXIS_ROUTE.length).fill(0), '御道必须沿中轴连续');
assert.ok(AXIS_ROUTE.every((point, index) => index === 0 || point.z < AXIS_ROUTE[index - 1].z), '御道应从入口依次通往主殿');

console.log(`Scene plan OK: ${BUILDINGS.length} buildings, ${AXIS_ROUTE.length} axial waypoints.`);
