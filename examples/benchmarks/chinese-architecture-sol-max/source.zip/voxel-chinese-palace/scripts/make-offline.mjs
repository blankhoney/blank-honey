import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'dist');
let html = await readFile(join(dist, 'index.html'), 'utf8');

const scriptTag = html.match(/<script type="module"[^>]*src="([^"]+)"[^>]*><\/script>/);
const styleTag = html.match(/<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/);
if (!scriptTag || !styleTag) throw new Error('Vite output did not contain the expected script and stylesheet tags.');

const assetPath = (url) => join(dist, url.replace(/^\.\//, ''));
const [javascript, css] = await Promise.all([
  readFile(assetPath(scriptTag[1]), 'utf8'),
  readFile(assetPath(styleTag[1]), 'utf8')
]);

html = html
  .replace(styleTag[0], `<style>${css}</style>`)
  .replace(scriptTag[0], `<script type="module">${javascript.replaceAll('</script', '<\\/script')}</script>`);

const target = join(root, 'voxel-chinese-palace-offline.html');
await writeFile(target, html);
console.log(`Offline HTML: ${target}`);
