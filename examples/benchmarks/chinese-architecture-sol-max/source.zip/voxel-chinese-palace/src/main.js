import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { BUILDINGS } from './scene-plan.js';
import './style.css';

const canvas = document.querySelector('#scene');
const loading = document.querySelector('#loading');
const tourToggle = document.querySelector('#tourToggle');
const prefersReducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xa9bcc2);
scene.fog = new THREE.FogExp2(0xb8c4bd, 0.0092);

const camera = new THREE.PerspectiveCamera(43, innerWidth / innerHeight, 0.1, 260);
camera.position.set(61, 43, 72);

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
} catch (error) {
  loading.innerHTML = '<p>当前浏览器无法创建 WebGL 场景，请尝试启用硬件加速。</p>';
  throw error;
}

renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 6.5, -3);
controls.enableDamping = true;
controls.dampingFactor = 0.055;
controls.autoRotate = !prefersReducedMotion;
controls.autoRotateSpeed = 0.38;
controls.minDistance = 34;
controls.maxDistance = 125;
controls.minPolarAngle = Math.PI * 0.19;
controls.maxPolarAngle = Math.PI * 0.47;
controls.enablePan = false;
controls.update();

const materialSpecs = {
  grassA: { color: 0x61774f, roughness: 1, cast: false },
  grassB: { color: 0x71845b, roughness: 1, cast: false },
  earth: { color: 0x65523c, roughness: 1, cast: false },
  paving: { color: 0xaaa89b, roughness: 0.95 },
  pavingDark: { color: 0x85887f, roughness: 0.95 },
  whiteStone: { color: 0xd6d2bf, roughness: 0.9 },
  stone: { color: 0x98958a, roughness: 1 },
  stoneDark: { color: 0x676b66, roughness: 1 },
  red: { color: 0xa83b28, roughness: 0.82 },
  redDark: { color: 0x6f271f, roughness: 0.88 },
  vermilion: { color: 0xc24d30, roughness: 0.78 },
  wood: { color: 0x6b4128, roughness: 0.9 },
  woodDark: { color: 0x342a24, roughness: 0.94 },
  window: { color: 0x192b2d, roughness: 0.62, metalness: 0.08 },
  interior: { color: 0x171b19, roughness: 1 },
  tealRoof: { color: 0x315d58, roughness: 0.72, metalness: 0.04 },
  tealEdge: { color: 0x45766e, roughness: 0.68, metalness: 0.06 },
  glaze: { color: 0xa86b28, roughness: 0.56, metalness: 0.09 },
  gold: { color: 0xd5a449, roughness: 0.48, metalness: 0.2 },
  goldDark: { color: 0x93652e, roughness: 0.64, metalness: 0.12 },
  lantern: { color: 0xe45b31, emissive: 0x8f2009, emissiveIntensity: 0.9, roughness: 0.65 },
  leaf: { color: 0x345d45, roughness: 1 },
  leafLight: { color: 0x4d7451, roughness: 1 },
  blossom: { color: 0xd9a2a2, roughness: 0.95 }
};

const materials = Object.fromEntries(
  Object.entries(materialSpecs).map(([key, { cast: _cast, ...options }]) => [
    key,
    new THREE.MeshStandardMaterial({ ...options, flatShading: true })
  ])
);
const batches = new Map(Object.keys(materials).map((key) => [key, []]));
const unitBox = new THREE.BoxGeometry(1, 1, 1);
const dummy = new THREE.Object3D();
let voxelCount = 0;

function voxel(material, x, y, z, width = 1, height = 1, depth = 1, rotation = 0) {
  batches.get(material).push({ x, y, z, width, height, depth, rotation });
  voxelCount += 1;
}

function localVoxel(material, originX, originZ, x, y, z, width, height, depth, rotation = 0) {
  const cosine = Math.cos(rotation);
  const sine = Math.sin(rotation);
  voxel(
    material,
    originX + x * cosine + z * sine,
    y,
    originZ - x * sine + z * cosine,
    width,
    height,
    depth,
    rotation
  );
}

function addPavingRect(centerX, centerZ, width, depth, tileSize = 2) {
  const columns = Math.floor(width / tileSize);
  const rows = Math.floor(depth / tileSize);
  for (let column = 0; column < columns; column += 1) {
    for (let row = 0; row < rows; row += 1) {
      const x = centerX - width / 2 + tileSize / 2 + column * tileSize;
      const z = centerZ - depth / 2 + tileSize / 2 + row * tileSize;
      voxel((column + row) % 3 ? 'paving' : 'pavingDark', x, 0.08, z, tileSize - 0.08, 0.18, tileSize - 0.08);
    }
  }
}

function addFoundation({ x, z, width, depth, rotation = 0, stairsWidth = 6, grand = false }) {
  localVoxel('stoneDark', x, z, 0, 0.28, 0, width + 2.6, 0.56, depth + 2.6, rotation);
  localVoxel('whiteStone', x, z, 0, 0.72, 0, width + 1.8, 0.34, depth + 1.8, rotation);
  localVoxel('stone', x, z, 0, 0.98, 0, width + 1.1, 0.2, depth + 1.1, rotation);

  const steps = grand ? 6 : 4;
  for (let index = 0; index < steps; index += 1) {
    const height = (index + 1) * (0.96 / steps);
    localVoxel(
      index % 2 ? 'whiteStone' : 'stone',
      x,
      z,
      0,
      height / 2,
      depth / 2 + 3.15 - index * 0.62,
      stairsWidth + (steps - index) * 0.25,
      height,
      0.72,
      rotation
    );
  }

  if (grand) addBalustrade(x, z, width + 1.2, depth + 1.2, rotation, stairsWidth + 0.8);
  return 1.08;
}

function addBalustrade(x, z, width, depth, rotation, opening) {
  const postHeight = 0.9;
  for (const side of [-1, 1]) {
    for (let offset = -width / 2; offset <= width / 2; offset += 2.35) {
      if (side === 1 && Math.abs(offset) < opening / 2) continue;
      localVoxel('whiteStone', x, z, offset, 1.5, side * depth / 2, 0.28, postHeight, 0.28, rotation);
    }
  }
  for (const side of [-1, 1]) {
    for (let offset = -depth / 2; offset <= depth / 2; offset += 2.3) {
      localVoxel('whiteStone', x, z, side * width / 2, 1.5, offset, 0.28, postHeight, 0.28, rotation);
    }
    localVoxel('whiteStone', x, z, side * width / 2, 1.58, 0, 0.26, 0.22, depth, rotation);
  }
  const railHalf = (width - opening) / 4;
  localVoxel('whiteStone', x, z, -(opening / 2 + railHalf), 1.58, depth / 2, railHalf * 2, 0.22, 0.26, rotation);
  localVoxel('whiteStone', x, z, opening / 2 + railHalf, 1.58, depth / 2, railHalf * 2, 0.22, 0.26, rotation);
  localVoxel('whiteStone', x, z, 0, 1.58, -depth / 2, width, 0.22, 0.26, rotation);
}

function addBracket(originX, originZ, x, y, z, rotation, scale = 1) {
  localVoxel('wood', originX, originZ, x, y, z, 1.8 * scale, 0.34 * scale, 0.54 * scale, rotation);
  localVoxel('goldDark', originX, originZ, x, y + 0.34 * scale, z, 0.58 * scale, 0.66 * scale, 0.72 * scale, rotation);
  localVoxel('wood', originX, originZ, x, y + 0.68 * scale, z, 2.4 * scale, 0.3 * scale, 0.52 * scale, rotation);
}

function addLatticePanel(originX, originZ, x, baseY, z, width, height, rotation, door = false) {
  localVoxel('window', originX, originZ, x, baseY + height / 2, z, width, height, 0.2, rotation);
  const frame = door ? 'goldDark' : 'redDark';
  localVoxel(frame, originX, originZ, x - width / 2, baseY + height / 2, z + 0.13, 0.18, height + 0.22, 0.18, rotation);
  localVoxel(frame, originX, originZ, x + width / 2, baseY + height / 2, z + 0.13, 0.18, height + 0.22, 0.18, rotation);
  for (let row = 1; row < 4; row += 1) {
    localVoxel(frame, originX, originZ, x, baseY + (height * row) / 4, z + 0.13, width, 0.12, 0.18, rotation);
  }
  for (let column = 1; column < 4; column += 1) {
    localVoxel(frame, originX, originZ, x - width / 2 + (width * column) / 4, baseY + height / 2, z + 0.13, 0.11, height, 0.18, rotation);
  }
  if (door) {
    localVoxel('gold', originX, originZ, x - 0.14, baseY + height * 0.48, z + 0.26, 0.13, 0.13, 0.13, rotation);
    localVoxel('gold', originX, originZ, x + 0.14, baseY + height * 0.48, z + 0.26, 0.13, 0.13, 0.13, rotation);
  }
}

function addFlyingCorners(x, z, width, depth, y, rotation, edgeKey) {
  for (const sideX of [-1, 1]) {
    for (const sideZ of [-1, 1]) {
      for (let step = 0; step < 3; step += 1) {
        localVoxel(
          edgeKey,
          x,
          z,
          sideX * (width / 2 + 1.9 + step * 0.48),
          y + step * 0.38,
          sideZ * (depth / 2 + 1.45 + step * 0.34),
          0.82 - step * 0.08,
          0.34,
          0.82 - step * 0.08,
          rotation
        );
      }
    }
  }
}

function addHipRoof({ x, z, width, depth, y, rotation = 0, roofKey = 'tealRoof', edgeKey = 'tealEdge' }) {
  const halfDepth = (depth + 4) / 2;
  const rows = Math.ceil(halfDepth / 0.95);
  for (const side of [-1, 1]) {
    for (let row = 0; row < rows; row += 1) {
      const span = width + 5 - row * 0.48;
      localVoxel(
        row % 3 === 2 ? edgeKey : roofKey,
        x,
        z,
        0,
        y + row * 0.4,
        side * (halfDepth - 0.52 - row * 0.94),
        span,
        0.44,
        1.08,
        rotation
      );
    }
  }
  const ridgeY = y + (rows - 1) * 0.4 + 0.48;
  localVoxel(edgeKey, x, z, 0, ridgeY, 0, width + 1.1, 0.48, 0.5, rotation);
  for (const side of [-1, 1]) {
    localVoxel('gold', x, z, side * (width / 2 + 0.82), ridgeY + 0.18, 0, 0.54, 0.72, 0.58, rotation);
  }
  addFlyingCorners(x, z, width, depth, y + 0.12, rotation, edgeKey);
}

function addXieshanRoof({ x, z, width, depth, y, rotation = 0 }) {
  localVoxel('tealEdge', x, z, 0, y, 0, width + 4.8, 0.42, depth + 3.8, rotation);
  localVoxel('tealRoof', x, z, 0, y + 0.32, 0, width + 3.7, 0.38, depth + 2.8, rotation);
  const halfDepth = (depth + 1.8) / 2;
  const rows = Math.ceil(halfDepth / 0.88);
  for (const side of [-1, 1]) {
    for (let row = 0; row < rows; row += 1) {
      localVoxel(
        row % 3 === 1 ? 'tealEdge' : 'tealRoof',
        x,
        z,
        0,
        y + 0.56 + row * 0.4,
        side * (halfDepth - 0.46 - row * 0.86),
        width + 2.4,
        0.42,
        0.98,
        rotation
      );
    }
  }
  const ridgeY = y + 0.56 + (rows - 1) * 0.4 + 0.48;
  localVoxel('goldDark', x, z, 0, ridgeY, 0, width + 3, 0.48, 0.5, rotation);
  for (const side of [-1, 1]) {
    for (let tier = 0; tier < 3; tier += 1) {
      localVoxel(
        'redDark',
        x,
        z,
        side * (width / 2 + 0.22),
        y + 0.72 + tier * 0.48,
        0,
        0.3,
        0.5,
        Math.max(1.2, depth - 2.2 - tier * 1.7),
        rotation
      );
    }
  }
  addFlyingCorners(x, z, width, depth, y + 0.12, rotation, 'tealEdge');
}

function addPyramidRoof(x, z, size, y, roofKey = 'tealRoof') {
  for (let layer = 0; layer < 5; layer += 1) {
    const span = size - layer * 0.9;
    voxel(layer % 2 ? 'tealEdge' : roofKey, x, y + layer * 0.31, z, span, 0.34, span);
  }
  for (const sideX of [-1, 1]) {
    for (const sideZ of [-1, 1]) {
      voxel('tealEdge', x + sideX * (size / 2 + 0.35), y + 0.22, z + sideZ * (size / 2 + 0.35), 0.62, 0.36, 0.62);
      voxel('goldDark', x + sideX * (size / 2 + 0.72), y + 0.56, z + sideZ * (size / 2 + 0.72), 0.45, 0.38, 0.45);
    }
  }
}

function addHall(building, grand = false) {
  const { x, z, width, depth, rotation = 0 } = building;
  const base = addFoundation({ x, z, width, depth, rotation, stairsWidth: grand ? 9 : 5.5, grand });
  const wallHeight = grand ? 7.4 : 5.6;
  const eaveY = base + wallHeight + 0.62;
  const bays = grand ? 7 : 5;
  const bayWidth = (width - 2.2) / bays;

  localVoxel('redDark', x, z, 0, base + wallHeight / 2, 0, width - 1.7, wallHeight, depth - 1.6, rotation);
  localVoxel('woodDark', x, z, 0, base + 0.36, depth / 2 - 0.66, width - 1.4, 0.72, 0.42, rotation);
  localVoxel('red', x, z, 0, eaveY - 0.92, depth / 2 - 0.3, width + 0.5, 0.68, 0.68, rotation);
  localVoxel('goldDark', x, z, 0, eaveY - 0.46, depth / 2 - 0.3, width + 1.3, 0.24, 0.82, rotation);
  localVoxel('red', x, z, 0, eaveY - 0.92, -depth / 2 + 0.3, width + 0.5, 0.68, 0.68, rotation);

  for (let bay = 0; bay < bays; bay += 1) {
    const centerX = -width / 2 + 1.1 + bayWidth / 2 + bay * bayWidth;
    addLatticePanel(x, z, centerX, base + 0.78, depth / 2 - 0.18, bayWidth * 0.72, wallHeight - 2.12, rotation, grand && bay > 1 && bay < 5);
  }

  const columnCount = bays + 1;
  for (let column = 0; column < columnCount; column += 1) {
    const columnX = -width / 2 + 1.05 + ((width - 2.1) * column) / (columnCount - 1);
    for (const side of [-1, 1]) {
      const columnZ = side * (depth / 2 - 0.18);
      localVoxel('goldDark', x, z, columnX, base + 0.14, columnZ, 0.92, 0.28, 0.92, rotation);
      localVoxel('vermilion', x, z, columnX, base + wallHeight / 2, columnZ, 0.66, wallHeight, 0.66, rotation);
      addBracket(x, z, columnX, eaveY - 0.63, columnZ, rotation, grand ? 1 : 0.82);
    }
  }

  for (const side of [-1, 1]) {
    localVoxel('red', x, z, side * (width / 2 - 0.4), base + wallHeight / 2, 0, 0.7, wallHeight, depth - 1.5, rotation);
    for (let panel = -1; panel <= 1; panel += 1) {
      localVoxel('window', x, z, side * (width / 2 - 0.78), base + wallHeight * 0.52, panel * 1.8, 0.18, 2.35, 1.22, rotation);
    }
  }

  localVoxel('goldDark', x, z, 0, eaveY - 1.28, depth / 2 + 0.13, grand ? 5.2 : 3.8, grand ? 1.18 : 0.92, 0.32, rotation);
  localVoxel('gold', x, z, 0, eaveY - 1.28, depth / 2 + 0.31, grand ? 3.8 : 2.7, grand ? 0.72 : 0.54, 0.11, rotation);

  if (grand) {
    addHipRoof({ x, z, width, depth, y: eaveY, rotation, roofKey: 'glaze', edgeKey: 'gold' });
  } else {
    addXieshanRoof({ x, z, width, depth, y: eaveY, rotation });
  }
}

function addGate({ x, z, width, depth }) {
  const base = addFoundation({ x, z, width, depth, stairsWidth: 15 });
  const top = 7.5;
  localVoxel('redDark', x, z, 0, base + 2.8, 0, width - 1.2, 5.5, depth - 1.3);
  const posts = [-10, -7.35, -4.35, -1.35, 1.35, 4.35, 7.35, 10];
  for (const post of posts) {
    for (const side of [-1, 1]) {
      localVoxel('vermilion', x, z, post, base + 2.9, side * (depth / 2 - 0.22), 0.62, 5.8, 0.62);
      addBracket(x, z, post, top - 0.55, side * (depth / 2 - 0.22), 0, 0.82);
    }
  }
  for (const doorX of [-5.8, 0, 5.8]) {
    localVoxel('interior', x, z, doorX, base + 2.45, depth / 2 - 0.1, 3.55, 4.85, 0.28);
    localVoxel('goldDark', x, z, doorX, base + 4.82, depth / 2 + 0.12, 3.8, 0.28, 0.3);
    for (const divider of [-1, 0, 1]) {
      localVoxel('red', x, z, doorX + divider * 1.18, base + 2.42, depth / 2 + 0.1, 0.14, 4.7, 0.22);
    }
  }
  localVoxel('red', x, z, 0, top - 0.72, depth / 2 - 0.12, width + 0.8, 0.7, 0.72);
  localVoxel('goldDark', x, z, 0, top - 1.35, depth / 2 + 0.18, 4.5, 1.1, 0.3);
  localVoxel('gold', x, z, 0, top - 1.35, depth / 2 + 0.36, 3.25, 0.6, 0.12);
  addXieshanRoof({ x, z, width, depth, y: top });
}

function addTower({ x, z }, isBell) {
  addFoundation({ x, z, width: 9, depth: 9, stairsWidth: 4.4 });
  const floorLevels = [1.08, 7.15];
  const sizes = [7.3, 5.7];
  for (let floor = 0; floor < floorLevels.length; floor += 1) {
    const base = floorLevels[floor];
    const size = sizes[floor];
    voxel('interior', x, base + 2.1, z, size - 1.2, 3.8, size - 1.2);
    for (const sideX of [-1, 1]) {
      for (const sideZ of [-1, 1]) {
        voxel('vermilion', x + sideX * (size / 2 - 0.35), base + 2.15, z + sideZ * (size / 2 - 0.35), 0.5, 4.3, 0.5);
      }
    }
    for (const side of [-1, 1]) {
      voxel('red', x, base + 3.95, z + side * (size / 2 - 0.28), size + 0.2, 0.48, 0.5);
      voxel('red', x + side * (size / 2 - 0.28), base + 3.95, z, 0.5, 0.48, size + 0.2);
    }
    addPyramidRoof(x, z, size + 3, base + 4.4);
  }
  voxel('gold', x, 13.15, z, 0.55, 1.7, 0.55);
  voxel('gold', x, 14.08, z, 0.28, 0.45, 0.28);
  voxel(isBell ? 'gold' : 'red', x, 4.0, z, isBell ? 1.45 : 2.1, isBell ? 2.2 : 1.65, isBell ? 1.45 : 0.78);
  if (!isBell) {
    voxel('gold', x, 4.0, z + 0.45, 2.35, 0.16, 0.2);
    voxel('gold', x, 4.0, z - 0.45, 2.35, 0.16, 0.2);
  }
}

function addPagoda({ x, z }) {
  addFoundation({ x, z, width: 9, depth: 9, stairsWidth: 4.2 });
  let baseY = 1.08;
  for (let floor = 0; floor < 5; floor += 1) {
    const size = 6.6 - floor * 0.72;
    const height = 2.55;
    voxel(floor % 2 ? 'redDark' : 'stone', x, baseY + height / 2, z, size, height, size);
    for (const sideX of [-1, 1]) {
      for (const sideZ of [-1, 1]) {
        voxel('vermilion', x + sideX * (size / 2 - 0.28), baseY + height / 2, z + sideZ * (size / 2 - 0.28), 0.35, height, 0.35);
      }
    }
    for (const side of [-1, 1]) {
      voxel('window', x, baseY + 1.28, z + side * (size / 2 + 0.03), Math.max(0.8, size - 2.1), 1.15, 0.18);
      voxel('window', x + side * (size / 2 + 0.03), baseY + 1.28, z, 0.18, 1.15, Math.max(0.8, size - 2.1));
    }
    addPyramidRoof(x, z, size + 3.15, baseY + height);
    baseY += 3.92;
  }
  voxel('goldDark', x, baseY + 0.8, z, 0.6, 2.5, 0.6);
  voxel('gold', x, baseY + 2.25, z, 0.34, 0.58, 0.34);
  for (let tier = 0; tier < 3; tier += 1) {
    voxel('gold', x, baseY + 0.25 + tier * 0.58, z, 1.45 - tier * 0.3, 0.16, 1.45 - tier * 0.3);
  }
}

function addLantern(x, z) {
  voxel('woodDark', x, 1.35, z, 0.24, 2.7, 0.24);
  voxel('goldDark', x, 2.75, z, 1.05, 0.16, 1.05);
  voxel('lantern', x, 3.25, z, 0.82, 0.95, 0.82);
  voxel('gold', x, 3.78, z, 0.98, 0.14, 0.98);
  voxel('goldDark', x, 2.72, z, 0.18, 0.25, 0.18);
}

function addLion(x, z, mirror) {
  voxel('stoneDark', x, 0.25, z, 2.15, 0.5, 2.15);
  voxel('whiteStone', x, 0.66, z, 1.55, 0.34, 1.55);
  voxel('whiteStone', x, 1.55, z, 1.1, 1.55, 1.25);
  voxel('whiteStone', x, 2.65, z + 0.15, 1.18, 1.08, 1.08);
  voxel('whiteStone', x, 2.66, z + 0.78, 0.68, 0.54, 0.58);
  voxel('stoneDark', x - 0.28, 2.82, z + 1.08, 0.13, 0.13, 0.13);
  voxel('stoneDark', x + 0.28, 2.82, z + 1.08, 0.13, 0.13, 0.13);
  voxel('whiteStone', x - 0.42, 3.22, z + 0.05, 0.32, 0.42, 0.32);
  voxel('whiteStone', x + 0.42, 3.22, z + 0.05, 0.32, 0.42, 0.32);
  voxel('whiteStone', x + mirror * 0.7, 1.72, z - 0.58, 0.52, 0.55, 0.52);
}

function addPine(x, z, height = 8) {
  voxel('wood', x, height * 0.35, z, 0.72, height * 0.7, 0.72);
  const tiers = [
    { y: height * 0.42, span: 5.5 },
    { y: height * 0.62, span: 4.5 },
    { y: height * 0.8, span: 3.4 },
    { y: height * 0.96, span: 2.2 }
  ];
  for (const [index, tier] of tiers.entries()) {
    voxel(index % 2 ? 'leafLight' : 'leaf', x, tier.y, z, tier.span, 1.1, 1.35);
    voxel(index % 2 ? 'leaf' : 'leafLight', x, tier.y + 0.28, z, 1.35, 0.95, tier.span);
    for (const side of [-1, 1]) {
      voxel('leaf', x + side * tier.span * 0.33, tier.y + 0.38, z, 1.2, 1.25, 1.2);
      voxel('leafLight', x, tier.y + 0.48, z + side * tier.span * 0.33, 1.1, 1.05, 1.1);
    }
  }
}

function addBlossomTree(x, z, height = 6.5) {
  voxel('wood', x, height * 0.38, z, 0.62, height * 0.76, 0.62);
  for (let branch = 0; branch < 4; branch += 1) {
    const angle = branch * Math.PI * 0.5 + 0.4;
    const bx = x + Math.cos(angle) * 1.2;
    const bz = z + Math.sin(angle) * 1.2;
    voxel('wood', (x + bx) / 2, height * 0.7, (z + bz) / 2, 0.45, 2.1, 0.45, -angle);
    voxel(branch % 2 ? 'blossom' : 'leafLight', bx, height * 0.87, bz, 2.25, 1.65, 2.25);
    voxel('blossom', bx + Math.cos(angle) * 0.8, height, bz + Math.sin(angle) * 0.8, 1.35, 1.25, 1.35);
  }
  voxel('leaf', x, height * 0.92, z, 2.7, 1.8, 2.7);
}

function addBoundaryWalls() {
  for (let z = -44; z <= 43; z += 4) {
    for (const x of [-44, 44]) {
      voxel('redDark', x, 1.55, z, 1, 2.8, 3.82);
      voxel('stone', x, 0.28, z, 1.5, 0.55, 4);
      voxel('tealRoof', x, 3.06, z, 1.65, 0.35, 4.15);
    }
  }
  for (let x = -42; x <= 42; x += 4) {
    if (Math.abs(x) < 13) continue;
    voxel('redDark', x, 1.55, 45, 3.82, 2.8, 1);
    voxel('stone', x, 0.28, 45, 4, 0.55, 1.5);
    voxel('tealRoof', x, 3.06, 45, 4.15, 0.35, 1.65);
  }
  for (let x = -42; x <= 42; x += 4) {
    if (Math.abs(x) < 8) continue;
    voxel('redDark', x, 1.55, -47, 3.82, 2.8, 1);
    voxel('stone', x, 0.28, -47, 4, 0.55, 1.5);
    voxel('tealRoof', x, 3.06, -47, 4.15, 0.35, 1.65);
  }
}

function addRockGarden(side) {
  const originX = side * 51;
  for (let layer = 0; layer < 6; layer += 1) {
    const width = 10 - layer * 1.25;
    voxel(layer % 2 ? 'stoneDark' : 'stone', originX + side * layer * 0.25, layer * 1.05 + 0.4, -36 + layer * 0.5, width, 1.9, 8 - layer * 0.75);
  }
  for (let layer = 0; layer < 4; layer += 1) {
    voxel('stoneDark', originX - side * 5, layer * 0.9 + 0.3, -43, 5 - layer * 0.85, 1.6, 5 - layer * 0.7);
  }
}

function buildGround() {
  const tileSize = 4;
  for (let x = -56; x <= 56; x += tileSize) {
    for (let z = -56; z <= 52; z += tileSize) {
      const variation = Math.abs(Math.sin(x * 12.9898 + z * 78.233));
      voxel(variation > 0.48 ? 'grassA' : 'grassB', x, -0.25 - variation * 0.03, z, 3.94, 0.5, 3.94);
    }
  }
  addPavingRect(0, 37, 7, 22, 1.75);
  addPavingRect(0, 9, 36, 35, 2.05);
  addPavingRect(0, -11.5, 9, 12, 1.8);
  addPavingRect(-24, 9, 7, 18, 1.75);
  addPavingRect(24, 9, 7, 18, 1.75);
  for (const x of [-18.6, 18.6]) voxel('whiteStone', x, 0.22, 9, 0.38, 0.3, 35.5);
  for (const z of [-8.6, 26.6]) voxel('whiteStone', 0, 0.22, z, 37.5, 0.3, 0.38);
}

function buildScene() {
  buildGround();
  addBoundaryWalls();

  for (const building of BUILDINGS) {
    if (building.kind === 'mainHall') addHall(building, true);
    if (building.kind === 'sideHall') addHall(building);
    if (building.kind === 'gate') addGate(building);
    if (building.kind === 'tower') addTower(building, building.id === 'bell');
    if (building.kind === 'pagoda') addPagoda(building);
  }

  for (const z of [25, 16, 7, -2]) {
    addLantern(-5.1, z);
    addLantern(5.1, z);
  }
  addLion(-8.4, 41, -1);
  addLion(8.4, 41, 1);

  for (const z of [-31, -18, 0, 31]) {
    addPine(-36, z, z === -31 ? 10 : 8);
    addPine(36, z, z === -31 ? 10 : 8);
  }
  addBlossomTree(-15.5, 23.5);
  addBlossomTree(15.5, 23.5);
  addBlossomTree(-35, 10, 6);
  addBlossomTree(35, 10, 6);
  addRockGarden(-1);
  addRockGarden(1);
}

function flushVoxels() {
  for (const [key, instances] of batches) {
    if (!instances.length) continue;
    const mesh = new THREE.InstancedMesh(unitBox, materials[key], instances.length);
    mesh.name = `voxels-${key}`;
    mesh.castShadow = materialSpecs[key].cast !== false;
    mesh.receiveShadow = true;
    instances.forEach(({ x, y, z, width, height, depth, rotation }, index) => {
      dummy.position.set(x, y, z);
      dummy.rotation.set(0, rotation, 0);
      dummy.scale.set(width, height, depth);
      dummy.updateMatrix();
      mesh.setMatrixAt(index, dummy.matrix);
    });
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    scene.add(mesh);
  }
}

buildScene();
flushVoxels();
document.documentElement.dataset.voxels = String(voxelCount);

const hemisphere = new THREE.HemisphereLight(0xd4e3e5, 0x493b2d, 1.85);
scene.add(hemisphere);

const sun = new THREE.DirectionalLight(0xffd7a0, 3.65);
sun.position.set(-38, 54, 34);
sun.target.position.set(0, 0, -10);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -66;
sun.shadow.camera.right = 66;
sun.shadow.camera.top = 66;
sun.shadow.camera.bottom = -66;
sun.shadow.camera.near = 8;
sun.shadow.camera.far = 135;
sun.shadow.bias = -0.00045;
sun.shadow.normalBias = 0.035;
scene.add(sun, sun.target);

const warmFill = new THREE.PointLight(0xff9a4b, 9, 38, 2);
warmFill.position.set(0, 8, 18);
scene.add(warmFill);

function animate() {
  requestAnimationFrame(animate);
  if (document.hidden) return;
  controls.update();
  renderer.render(scene, camera);
}

function resize() {
  const portrait = innerWidth < innerHeight;
  camera.aspect = innerWidth / innerHeight;
  camera.fov = portrait ? 55 : 43;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.6));
  renderer.setSize(innerWidth, innerHeight, false);
}

tourToggle.setAttribute('aria-pressed', String(controls.autoRotate));
tourToggle.querySelector('.button-label').textContent = controls.autoRotate ? '自动巡游' : '开始巡游';
tourToggle.addEventListener('click', () => {
  controls.autoRotate = !controls.autoRotate;
  tourToggle.setAttribute('aria-pressed', String(controls.autoRotate));
  tourToggle.setAttribute('aria-label', controls.autoRotate ? '暂停自动巡游' : '开始自动巡游');
  tourToggle.querySelector('.button-label').textContent = controls.autoRotate ? '自动巡游' : '开始巡游';
});

addEventListener('resize', resize, { passive: true });
addEventListener('load', () => requestAnimationFrame(() => loading.classList.add('done')), { once: true });
addEventListener('beforeunload', () => {
  controls.dispose();
  renderer.dispose();
  unitBox.dispose();
  Object.values(materials).forEach((material) => material.dispose());
});

resize();
animate();
console.info(`紫宸宫阙：${voxelCount} 个体素，${BUILDINGS.length} 座建筑，${scene.children.length} 个场景对象。`);
