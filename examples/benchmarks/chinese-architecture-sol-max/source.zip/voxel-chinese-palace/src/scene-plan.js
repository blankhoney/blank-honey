export const BUILDINGS = Object.freeze([
  { id: 'gate', name: '承天门', kind: 'gate', x: 0, z: 34, width: 22, depth: 7 },
  { id: 'drum', name: '鼓楼', kind: 'tower', x: -28, z: 20, width: 9, depth: 9 },
  { id: 'bell', name: '钟楼', kind: 'tower', x: 28, z: 20, width: 9, depth: 9 },
  { id: 'west-hall', name: '西配殿', kind: 'sideHall', x: -24, z: -5, width: 17, depth: 9, rotation: Math.PI / 2 },
  { id: 'east-hall', name: '东配殿', kind: 'sideHall', x: 24, z: -5, width: 17, depth: 9, rotation: -Math.PI / 2 },
  { id: 'main-hall', name: '紫宸殿', kind: 'mainHall', x: 0, z: -18, width: 28, depth: 15 },
  { id: 'pagoda', name: '凌霄塔', kind: 'pagoda', x: 0, z: -39, width: 9, depth: 9 }
]);

export const AXIS_ROUTE = Object.freeze([
  { x: 0, z: 43, label: '入口' },
  { x: 0, z: 34, label: '山门' },
  { x: 0, z: 12, label: '前庭' },
  { x: 0, z: -7, label: '月台' },
  { x: 0, z: -18, label: '主殿' }
]);
