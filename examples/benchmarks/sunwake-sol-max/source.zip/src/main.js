import * as THREE from 'three';
import './style.css';
import {
  TAU,
  bearingTo,
  celestialState,
  clamp,
  damp,
  formatCycleClock,
  headingLabel,
  lerpAngle,
  waveSample,
  wrapAngle,
} from './simulation.js';

const $ = (selector) => document.querySelector(selector);
const canvas = $('#game');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const mobile = matchMedia('(max-width: 760px)').matches;
const clock = new THREE.Clock();
const random = mulberry32(0x51f17e);
const temp = {
  a: new THREE.Vector3(),
  b: new THREE.Vector3(),
  c: new THREE.Vector3(),
  d: new THREE.Vector3(),
  euler: new THREE.Euler(),
  matrix: new THREE.Matrix4(),
  color: new THREE.Color(),
  color2: new THREE.Color(),
};

const ui = {
  intro: $('#intro'),
  begin: $('#begin'),
  hud: $('#hud'),
  pause: $('#pause'),
  pauseMenu: $('#pause-menu'),
  resume: $('#resume'),
  complete: $('#complete'),
  sailOn: $('#sail-on'),
  toast: $('#toast'),
  toastTitle: $('#toast b'),
  objectiveIndex: $('#objective-index'),
  objectiveName: $('#objective-name'),
  objectiveCopy: $('#objective-copy'),
  objectiveDistance: $('#objective-distance'),
  beaconCount: $('#beacon-count'),
  rangeFill: $('#range-fill'),
  heading: $('#heading'),
  compassLeft: $('#compass-left'),
  compassRight: $('#compass-right'),
  speed: $('#speed'),
  windSpeed: $('#wind-speed'),
  windArrow: $('#wind-arrow'),
  seaState: $('#sea-state'),
  cycleTime: $('#cycle-time'),
  cycleProgress: $('#cycle-progress'),
  timeIcon: $('#time-icon'),
  weather: $('#weather'),
  weatherValue: $('#weather b'),
  cameraMode: $('#camera-mode'),
  cameraValue: $('#camera-mode b'),
  lens: $('#lens'),
  fallback: $('#fallback'),
};

let renderer;
try {
  renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: !mobile,
    alpha: false,
    powerPreference: 'high-performance',
  });
} catch (error) {
  console.error(error);
  ui.intro.classList.add('is-hidden');
  ui.fallback.classList.remove('is-hidden');
  throw error;
}

renderer.setPixelRatio(Math.min(devicePixelRatio, mobile ? 1.5 : 2));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.16;
renderer.shadowMap.enabled = !mobile;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x8f7e91, 0.00205);
const camera = new THREE.PerspectiveCamera(56, innerWidth / innerHeight, 0.08, 1500);
camera.position.set(12, 10, 57);

const state = {
  started: false,
  paused: false,
  completed: false,
  elapsed: 0,
  physicsTime: 0,
  heading: 0,
  speed: 0,
  verticalSpeed: 0,
  pitchSpeed: 0,
  rollSpeed: 0,
  throttle: 0,
  rudder: 0,
  position: new THREE.Vector3(0, 0, 35),
  cameraMode: 'chase',
  waterMode: 'illustrated',
  weatherMode: 'dynamic',
  storm: 0.34,
  stormTarget: 0.34,
  objective: 0,
  lastWake: 0,
  lastSpray: 0,
  lastDroplet: 0,
  screenShake: 0,
};

const keys = new Set();
const palette = {
  skyNight: new THREE.Color(0x02091b),
  skyDay: new THREE.Color(0x6aa3c5),
  fogNight: new THREE.Color(0x07152b),
  fogDawn: new THREE.Color(0xb86d70),
  fogDay: new THREE.Color(0x7aa9bc),
  fogStorm: new THREE.Color(0x253344),
  sun: new THREE.Color(0xffbd72),
  moon: new THREE.Color(0x9fd8ff),
};

const objectives = [
  {
    name: 'Emberwatch',
    copy: 'Follow the amber beam beyond the morning swell.',
    position: new THREE.Vector3(0, 0, -125),
    radius: 17,
    accent: 0xffa75e,
  },
  {
    name: 'Glassward',
    copy: 'Cross the storm glass and wake the western light.',
    position: new THREE.Vector3(112, 0, -246),
    radius: 20,
    accent: 0x73ddff,
  },
  {
    name: 'Riven Crown',
    copy: 'Thread the black teeth where the long wind turns.',
    position: new THREE.Vector3(-76, 0, -382),
    radius: 22,
    accent: 0xa7f2df,
  },
  {
    name: 'Northstar Reach',
    copy: 'Carry the final flame beneath the aurora.',
    position: new THREE.Vector3(34, 0, -520),
    radius: 24,
    accent: 0xc7a5ff,
  },
];

function mulberry32(seed) {
  return function seededRandom() {
    let value = seed += 0x6d2b79f5;
    value = Math.imul(value ^ value >>> 15, value | 1);
    value ^= value + Math.imul(value ^ value >>> 7, value | 61);
    return ((value ^ value >>> 14) >>> 0) / 4294967296;
  };
}

function material(color, options = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.58,
    metalness: 0.03,
    flatShading: true,
    ...options,
  });
}

function mesh(geometry, mat, parent, cast = true, receive = true) {
  const result = new THREE.Mesh(geometry, mat);
  result.castShadow = cast;
  result.receiveShadow = receive;
  parent.add(result);
  return result;
}

function cylinderBetween(start, end, radius, mat, parent, sides = 8) {
  const midpoint = temp.a.copy(start).add(end).multiplyScalar(0.5).clone();
  const direction = temp.b.copy(end).sub(start);
  const result = mesh(new THREE.CylinderGeometry(radius, radius, direction.length(), sides), mat, parent);
  result.position.copy(midpoint);
  result.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  return result;
}

function createGlowTexture() {
  const size = 128;
  const glowCanvas = document.createElement('canvas');
  glowCanvas.width = size;
  glowCanvas.height = size;
  const context = glowCanvas.getContext('2d');
  const gradient = context.createRadialGradient(64, 64, 2, 64, 64, 63);
  gradient.addColorStop(0, 'rgba(255,255,244,1)');
  gradient.addColorStop(0.14, 'rgba(255,205,124,.92)');
  gradient.addColorStop(0.42, 'rgba(255,153,76,.31)');
  gradient.addColorStop(1, 'rgba(255,130,58,0)');
  context.fillStyle = gradient;
  context.fillRect(0, 0, size, size);
  const texture = new THREE.CanvasTexture(glowCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createSky() {
  const uniforms = {
    uSunDirection: { value: new THREE.Vector3(0, 0.06, -1).normalize() },
    uMoonDirection: { value: new THREE.Vector3(0, -0.06, 1).normalize() },
    uDaylight: { value: 0.55 },
    uTwilight: { value: 1 },
    uStorm: { value: 0.3 },
    uTime: { value: 0 },
  };
  const skyMaterial = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms,
    vertexShader: `
      varying vec3 vDirection;
      void main() {
        vDirection = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      precision highp float;
      varying vec3 vDirection;
      uniform vec3 uSunDirection;
      uniform vec3 uMoonDirection;
      uniform float uDaylight;
      uniform float uTwilight;
      uniform float uStorm;
      uniform float uTime;

      float hash(vec3 p) {
        p = fract(p * .1031);
        p += dot(p, p.yzx + 33.33);
        return fract((p.x + p.y) * p.z);
      }

      float noise(vec3 p) {
        vec3 i = floor(p);
        vec3 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(mix(hash(i), hash(i + vec3(1.0,0.0,0.0)), f.x), mix(hash(i + vec3(0.0,1.0,0.0)), hash(i + vec3(1.0,1.0,0.0)), f.x), f.y),
          mix(mix(hash(i + vec3(0.0,0.0,1.0)), hash(i + vec3(1.0,0.0,1.0)), f.x), mix(hash(i + vec3(0.0,1.0,1.0)), hash(i + vec3(1.0,1.0,1.0)), f.x), f.y),
          f.z
        );
      }

      void main() {
        vec3 dir = normalize(vDirection);
        float horizon = pow(clamp(1.0 - max(dir.y, 0.0), 0.0, 1.0), 2.2);
        vec3 night = mix(vec3(.008, .025, .085), vec3(.002, .006, .025), clamp(dir.y * .75 + .35, 0.0, 1.0));
        vec3 day = mix(vec3(.98, .45, .34), vec3(.19, .47, .72), clamp(dir.y * .9 + .14, 0.0, 1.0));
        day = mix(day, vec3(1.0, .64, .33), horizon * uTwilight * .65);
        vec3 color = mix(night, day, uDaylight);

        float sunDot = max(dot(dir, uSunDirection), 0.0);
        float sunDisc = smoothstep(.99915, .99972, sunDot);
        float sunGlow = pow(sunDot, 22.0) * (.55 + uTwilight * .8);
        color += vec3(1.0, .55, .2) * sunGlow * uDaylight;
        color = mix(color, vec3(1.0, .88, .59), sunDisc * uDaylight);

        float moonDot = max(dot(dir, uMoonDirection), 0.0);
        float moonDisc = smoothstep(.9996, .99986, moonDot);
        color += vec3(.38, .68, 1.0) * (pow(moonDot, 38.0) * .22 + moonDisc * (1.0 - uDaylight));

        float starCell = hash(floor(dir * 510.0));
        float star = smoothstep(.993, 1.0, starCell) * pow(clamp(dir.y + .18, 0.0, 1.0), .5) * (1.0 - uDaylight);
        star *= .55 + .45 * sin(hash(floor(dir * 97.0)) * 30.0 + uTime * 2.0);
        color += vec3(.62, .82, 1.0) * star * 2.2;

        float north = smoothstep(.1, .75, -dir.z) * smoothstep(.02, .35, dir.y) * (1.0 - smoothstep(.37, .68, dir.y));
        float ribbons = sin(dir.x * 27.0 + noise(dir * 8.0 + vec3(uTime * .025)) * 7.0 + uTime * .12);
        ribbons = pow(max(ribbons, 0.0), 3.0);
        vec3 aurora = mix(vec3(.08, .9, .62), vec3(.38, .35, 1.0), dir.x * .5 + .5);
        color += aurora * north * ribbons * (1.0 - uDaylight) * .38;

        float cloudNoise = noise(vec3(dir.x * 4.2 + uTime * .006, dir.y * 10.0, dir.z * 4.2));
        float canopy = smoothstep(.25, .78, dir.y) * smoothstep(.43, .7, cloudNoise) * uStorm;
        color = mix(color, vec3(.035, .055, .09), canopy * .77);
        color = mix(color, vec3(.11, .13, .18), uStorm * .26);
        gl_FragColor = vec4(color, 1.0);
      }
    `,
  });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(820, 36, 20), skyMaterial);
  sky.frustumCulled = false;
  scene.add(sky);
  return { sky, uniforms };
}

const sky = createSky();
const sunLight = new THREE.DirectionalLight(0xffb36d, 3.2);
sunLight.castShadow = !mobile;
sunLight.shadow.mapSize.set(1024, 1024);
sunLight.shadow.camera.left = -75;
sunLight.shadow.camera.right = 75;
sunLight.shadow.camera.top = 75;
sunLight.shadow.camera.bottom = -75;
sunLight.shadow.camera.near = 1;
sunLight.shadow.camera.far = 360;
sunLight.shadow.bias = -0.0005;
scene.add(sunLight, sunLight.target);
const hemisphere = new THREE.HemisphereLight(0x87bbd4, 0x081226, 1.85);
scene.add(hemisphere);

const glowTexture = createGlowTexture();
const sunDisc = mesh(new THREE.SphereGeometry(9, 18, 12), new THREE.MeshBasicMaterial({ color: 0xfff0b5, fog: false }), scene, false, false);
const sunGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture, color: 0xffa653, transparent: true, opacity: 0.92, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
sunGlow.scale.setScalar(90);
scene.add(sunGlow);
const moonDisc = mesh(new THREE.SphereGeometry(6.5, 14, 10), new THREE.MeshBasicMaterial({ color: 0xa9d8ff, fog: false }), scene, false, false);
const moonGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture, color: 0x6bafff, transparent: true, opacity: 0.42, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }));
moonGlow.scale.setScalar(52);
scene.add(moonGlow);

function createOcean() {
  const segments = mobile ? 42 : 58;
  let geometry = new THREE.PlaneGeometry(720, 720, segments, segments);
  geometry.rotateX(-Math.PI / 2);
  geometry = geometry.toNonIndexed();
  const positions = geometry.getAttribute('position');
  const base = new Float32Array(positions.count * 2);
  const colors = new Float32Array(positions.count * 3);
  for (let index = 0; index < positions.count; index += 1) {
    base[index * 2] = positions.getX(index);
    base[index * 2 + 1] = positions.getZ(index);
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const waterMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    vertexColors: true,
    flatShading: true,
    roughness: 0.34,
    metalness: 0.12,
    clearcoat: 0.18,
    clearcoatRoughness: 0.28,
    transparent: true,
    opacity: 0.985,
    side: THREE.DoubleSide,
  });
  const ocean = mesh(geometry, waterMaterial, scene, false, true);
  ocean.frustumCulled = false;
  return { ocean, geometry, material: waterMaterial, base, positions, colors: geometry.getAttribute('color'), frame: 0 };
}

const water = createOcean();

function updateOcean(time, storm) {
  water.frame += 1;
  if (mobile && water.frame % 2 === 1) return;
  const snap = 12;
  water.ocean.position.x = Math.round(state.position.x / snap) * snap;
  water.ocean.position.z = Math.round(state.position.z / snap) * snap;
  const illustrated = state.waterMode === 'illustrated';
  const deep = temp.color.set(illustrated ? 0x031942 : 0x061c27);
  const mid = temp.color2.set(illustrated ? 0x075783 : 0x0a4f60);
  const top = new THREE.Color(illustrated ? 0x1aa8cb : 0x4b94a0);
  const dawn = new THREE.Color(0xf28b5f);

  for (let index = 0; index < water.positions.count; index += 1) {
    const worldX = water.base[index * 2] + water.ocean.position.x;
    const worldZ = water.base[index * 2 + 1] + water.ocean.position.z;
    water.positions.setY(index, waveSample(worldX, worldZ, time, storm).height);
  }

  for (let index = 0; index < water.positions.count; index += 3) {
    const height = (water.positions.getY(index) + water.positions.getY(index + 1) + water.positions.getY(index + 2)) / 3;
    const face = index / 3;
    const jitter = ((face * 16807) % 97) / 97;
    const mixHeight = clamp((height + 4.5) / 10 + (jitter - 0.5) * 0.2, 0, 1);
    const color = deep.clone().lerp(mid, clamp(mixHeight * 1.3, 0, 1)).lerp(top, clamp((mixHeight - .48) * 1.7, 0, .58));
    const worldZ = water.base[index * 2 + 1] + water.ocean.position.z;
    const sunPath = Math.exp(-Math.abs(water.base[index * 2]) * .02) * Math.exp(-Math.abs(worldZ + 100) * .0017);
    color.lerp(dawn, sunPath * sky.uniforms.uTwilight.value * .16 * sky.uniforms.uDaylight.value);
    water.colors.setXYZ(index, color.r, color.g, color.b);
    water.colors.setXYZ(index + 1, color.r, color.g, color.b);
    water.colors.setXYZ(index + 2, color.r, color.g, color.b);
  }
  water.positions.needsUpdate = true;
  water.colors.needsUpdate = true;
  water.geometry.computeVertexNormals();
}

function applyWaterMode(mode) {
  state.waterMode = mode;
  const natural = mode === 'natural';
  water.material.roughness = natural ? 0.14 : 0.38;
  water.material.metalness = natural ? 0.08 : 0.15;
  water.material.clearcoat = natural ? 0.92 : 0.18;
  water.material.clearcoatRoughness = natural ? 0.08 : 0.31;
  water.material.opacity = natural ? 0.94 : 0.99;
  renderer.toneMappingExposure = natural ? 1.02 : 1.17;
  document.querySelectorAll('[data-water]').forEach((button) => {
    const active = button.dataset.water === mode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  boat.userData.applyMode?.(mode);
}

function createSparkles() {
  const count = mobile ? 110 : 240;
  const positions = new Float32Array(count * 3);
  const seeds = new Float32Array(count);
  for (let index = 0; index < count; index += 1) seeds[index] = random();
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 1));
  const uniforms = { uTime: { value: 0 }, uOpacity: { value: 1 } };
  const sparkleMaterial = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
    uniforms,
    vertexShader: `
      attribute float aSeed;
      varying float vSeed;
      void main() {
        vSeed = aSeed;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = (2.0 + aSeed * 5.0) * clamp(130.0 / -mv.z, .45, 2.6);
        gl_Position = projectionMatrix * mv;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform float uOpacity;
      varying float vSeed;
      void main() {
        vec2 p = gl_PointCoord - .5;
        float glow = smoothstep(.5, 0.0, length(p));
        float twinkle = .38 + .62 * sin(uTime * 5.0 + vSeed * 31.0) * sin(uTime * 2.3 + vSeed * 17.0);
        gl_FragColor = vec4(mix(vec3(.22,.82,1.0), vec3(1.0,.67,.31), vSeed), glow * max(twinkle, .08) * uOpacity);
      }
    `,
  });
  const points = new THREE.Points(geometry, sparkleMaterial);
  points.frustumCulled = false;
  scene.add(points);
  return { points, positions: geometry.getAttribute('position'), seeds, uniforms };
}

const sparkles = createSparkles();

function updateSparkles(time, daylight) {
  for (let index = 0; index < sparkles.seeds.length; index += 1) {
    const seed = sparkles.seeds[index];
    const distance = 20 + seed * seed * 285;
    const width = (randomStable(index * 3.17) - .5) * (8 + distance * .28);
    const forward = temp.a.set(Math.sin(state.heading), 0, -Math.cos(state.heading));
    const right = temp.b.set(Math.cos(state.heading), 0, Math.sin(state.heading));
    const x = state.position.x + forward.x * distance + right.x * width;
    const z = state.position.z + forward.z * distance + right.z * width;
    const y = waveSample(x, z, time, state.storm).height + .12;
    sparkles.positions.setXYZ(index, x, y, z);
  }
  sparkles.positions.needsUpdate = true;
  sparkles.uniforms.uTime.value = time;
  sparkles.uniforms.uOpacity.value = daylight * (.32 + sky.uniforms.uTwilight.value * .75);
}

function randomStable(value) {
  return (Math.sin(value * 91.713 + 17.371) * 43758.5453) % 1 + ((Math.sin(value * 91.713 + 17.371) * 43758.5453) % 1 < 0 ? 1 : 0);
}

function createIsland(config, index) {
  const group = new THREE.Group();
  group.position.copy(config.position);
  scene.add(group);
  const sides = 11 + index * 2;
  const rings = [
    { y: -6, r: config.radius * 1.25 },
    { y: -1.1, r: config.radius },
    { y: 3, r: config.radius * .72 },
    { y: 7 + index * .7, r: config.radius * .35 },
    { y: 8.3 + index * .8, r: .6 },
  ];
  const positions = [];
  const colors = [];
  const indices = [];
  const rockDark = new THREE.Color(index % 2 ? 0x152837 : 0x172b3a);
  const rockLight = new THREE.Color(index % 2 ? 0x41644f : 0x3e6658);
  for (let ringIndex = 0; ringIndex < rings.length; ringIndex += 1) {
    const ring = rings[ringIndex];
    for (let side = 0; side < sides; side += 1) {
      const angle = side / sides * TAU;
      const irregular = 0.84 + randomStable(index * 100 + ringIndex * 17 + side) * .25;
      positions.push(Math.cos(angle) * ring.r * irregular, ring.y + (randomStable(side + index * 51) - .5) * .7, Math.sin(angle) * ring.r * irregular);
      const color = rockDark.clone().lerp(rockLight, ringIndex / (rings.length - 1) * .8 + randomStable(side * 9 + ringIndex) * .15);
      colors.push(color.r, color.g, color.b);
    }
  }
  for (let ringIndex = 0; ringIndex < rings.length - 1; ringIndex += 1) {
    for (let side = 0; side < sides; side += 1) {
      const next = (side + 1) % sides;
      const a = ringIndex * sides + side;
      const b = ringIndex * sides + next;
      const c = (ringIndex + 1) * sides + side;
      const d = (ringIndex + 1) * sides + next;
      indices.push(a, c, b, b, c, d);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  mesh(geometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .9, flatShading: true }), group, true, true);

  const grass = material(index === 2 ? 0x355a57 : 0x3a5b3d, { roughness: 1 });
  for (let patch = 0; patch < 8 + index * 2; patch += 1) {
    const angle = random() * TAU;
    const radius = random() * config.radius * .52;
    const tuft = mesh(new THREE.ConeGeometry(.25 + random() * .35, 1.4 + random(), 5), grass, group);
    tuft.position.set(Math.cos(angle) * radius, 7.8 + index * .75, Math.sin(angle) * radius);
    tuft.rotation.z = (random() - .5) * .35;
  }

  const lighthouse = createLighthouse(config, index);
  lighthouse.position.y = 8.5 + index * .8;
  group.add(lighthouse);

  const marker = mesh(new THREE.OctahedronGeometry(1.2, 0), new THREE.MeshBasicMaterial({ color: config.accent, transparent: true, opacity: .82, blending: THREE.AdditiveBlending }), group, false, false);
  marker.position.y = 25;
  marker.userData.baseY = marker.position.y;
  const markerRing = mesh(new THREE.TorusGeometry(2.4, .09, 4, 24), new THREE.MeshBasicMaterial({ color: config.accent, transparent: true, opacity: .62, blending: THREE.AdditiveBlending }), group, false, false);
  markerRing.position.y = 25;
  markerRing.rotation.x = Math.PI / 2;
  return { group, lighthouse, marker, markerRing, lit: false, config };
}

function createLighthouse(config, index) {
  const group = new THREE.Group();
  const stone = material(0xe3ddca, { roughness: .88 });
  const stripe = material(index % 2 ? 0x28495a : 0xa64735, { roughness: .75 });
  const metal = material(0x263844, { roughness: .42, metalness: .45 });
  const tower = mesh(new THREE.CylinderGeometry(.86, 1.42, 9.2, 10, 4), stone, group);
  tower.position.y = 4.6;
  for (let stripeIndex = 0; stripeIndex < 2; stripeIndex += 1) {
    const band = mesh(new THREE.CylinderGeometry(1.03 - stripeIndex * .13, 1.12 - stripeIndex * .12, 1.15, 10), stripe, group);
    band.position.y = 2.3 + stripeIndex * 3.45;
  }
  const gallery = mesh(new THREE.CylinderGeometry(1.52, 1.52, .22, 12), metal, group);
  gallery.position.y = 9.15;
  const glassMaterial = new THREE.MeshPhysicalMaterial({ color: config.accent, emissive: config.accent, emissiveIntensity: 2.4, roughness: .12, metalness: .05, transparent: true, opacity: .75 });
  const lantern = mesh(new THREE.CylinderGeometry(.82, .82, 1.35, 10, 1, true), glassMaterial, group, false, false);
  lantern.position.y = 9.9;
  const roof = mesh(new THREE.ConeGeometry(1.25, 1.25, 10), metal, group);
  roof.position.y = 11.15;
  const finial = mesh(new THREE.CylinderGeometry(.07, .07, .9, 6), metal, group);
  finial.position.y = 12.15;

  const railMaterial = new THREE.LineBasicMaterial({ color: 0x70808a, transparent: true, opacity: .8 });
  const railPoints = [];
  for (let point = 0; point <= 20; point += 1) {
    const angle = point / 20 * TAU;
    railPoints.push(new THREE.Vector3(Math.cos(angle) * 1.4, 9.62, Math.sin(angle) * 1.4));
  }
  group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(railPoints), railMaterial));

  const beamPivot = new THREE.Group();
  beamPivot.position.y = 9.9;
  group.add(beamPivot);
  const beamMaterial = new THREE.MeshBasicMaterial({ color: config.accent, transparent: true, opacity: .13, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  for (const direction of [-1, 1]) {
    const beam = mesh(new THREE.ConeGeometry(8, 62, 12, 1, true), beamMaterial, beamPivot, false, false);
    beam.geometry.translate(0, -31, 0);
    beam.rotation.z = direction * Math.PI / 2;
  }
  const light = new THREE.PointLight(config.accent, 0.8, 72, 1.8);
  light.position.y = 10;
  group.add(light);
  group.userData = { beamPivot, beamMaterial, glassMaterial, light };
  return group;
}

const islands = objectives.map(createIsland);

function triangle(target, colors, a, b, c, color) {
  target.push(...a, ...b, ...c);
  const shade = new THREE.Color(color);
  colors.push(shade.r, shade.g, shade.b, shade.r, shade.g, shade.b, shade.r, shade.g, shade.b);
}

function createHullGeometry() {
  const positions = [];
  const colors = [];
  const stations = [
    { z: -6.25, w: .05, rail: .82, chine: .34, keel: -.28 },
    { z: -5.45, w: .84, rail: 1.06, chine: -.02, keel: -.74 },
    { z: -4.2, w: 1.54, rail: 1.18, chine: -.28, keel: -.97 },
    { z: -2.4, w: 1.96, rail: 1.21, chine: -.35, keel: -1.05 },
    { z: -.3, w: 2.12, rail: 1.18, chine: -.38, keel: -1.02 },
    { z: 1.75, w: 2.04, rail: 1.12, chine: -.34, keel: -.9 },
    { z: 3.65, w: 1.84, rail: 1.05, chine: -.22, keel: -.69 },
    { z: 4.65, w: 1.62, rail: .96, chine: -.12, keel: -.55 },
  ];
  const sideColors = [0x7e2e20, 0x963a24];
  const bottomColors = [0x27313a, 0x33434a];

  for (const side of [-1, 1]) {
    for (let index = 0; index < stations.length - 1; index += 1) {
      const a = stations[index];
      const b = stations[index + 1];
      const railA = [side * a.w, a.rail, a.z];
      const chineA = [side * a.w * .73, a.chine, a.z];
      const keelA = [0, a.keel, a.z];
      const railB = [side * b.w, b.rail, b.z];
      const chineB = [side * b.w * .73, b.chine, b.z];
      const keelB = [0, b.keel, b.z];
      const sideColor = sideColors[(index + (side > 0 ? 1 : 0)) % 2];
      const bottomColor = bottomColors[index % 2];
      triangle(positions, colors, railA, chineA, railB, sideColor);
      triangle(positions, colors, railB, chineA, chineB, sideColor);
      triangle(positions, colors, chineA, keelA, chineB, bottomColor);
      triangle(positions, colors, chineB, keelA, keelB, bottomColor);
    }
  }

  const stern = stations.at(-1);
  triangle(positions, colors, [-stern.w, stern.rail, stern.z], [-stern.w * .73, stern.chine, stern.z], [stern.w, stern.rail, stern.z], 0x63251e);
  triangle(positions, colors, [stern.w, stern.rail, stern.z], [-stern.w * .73, stern.chine, stern.z], [stern.w * .73, stern.chine, stern.z], 0x63251e);
  triangle(positions, colors, [-stern.w * .73, stern.chine, stern.z], [0, stern.keel, stern.z], [stern.w * .73, stern.chine, stern.z], 0x273038);

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  return { geometry, stations };
}

function createSailGeometry(height = 7.1, foot = 4.65, segments = 8, offsetZ = 0) {
  const positions = [];
  const uvs = [];
  const indices = [];
  const rowStart = [];
  for (let row = 0; row <= segments; row += 1) {
    rowStart[row] = positions.length / 3;
    const down = row / segments;
    for (let column = 0; column <= row; column += 1) {
      const across = row === 0 ? 0 : column / row;
      const billow = Math.sin(across * Math.PI) * Math.sin(down * Math.PI) * .34;
      positions.push(billow, 10.55 - down * height + Math.sin(across * Math.PI) * .05, offsetZ + across * foot * down);
      uvs.push(across, 1 - down);
    }
  }
  for (let row = 0; row < segments; row += 1) {
    for (let column = 0; column <= row; column += 1) {
      const a = rowStart[row] + column;
      const b = rowStart[row + 1] + column;
      const c = rowStart[row + 1] + column + 1;
      indices.push(a, b, c);
      if (column < row) {
        const d = rowStart[row] + column + 1;
        indices.push(a, c, d);
      }
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  geometry.userData.rest = geometry.attributes.position.array.slice();
  return geometry;
}

function rope(points, parent, color = 0x4a3525, opacity = .95) {
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const line = new THREE.Line(geometry, new THREE.LineBasicMaterial({ color, transparent: opacity < 1, opacity }));
  parent.add(line);
  return line;
}

function addBox(parent, size, position, mat, rotation = null) {
  const item = mesh(new THREE.BoxGeometry(size[0], size[1], size[2]), mat, parent);
  item.position.set(...position);
  if (rotation) item.rotation.set(...rotation);
  return item;
}

function createBoat() {
  const group = new THREE.Group();
  group.rotation.order = 'YXZ';
  scene.add(group);

  const mats = {
    hull: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .54, metalness: .04, flatShading: true, side: THREE.DoubleSide }),
    wood: material(0x9d4c2e, { roughness: .68 }),
    darkWood: material(0x48261e, { roughness: .75 }),
    deck: material(0xc37a45, { roughness: .72 }),
    rope: material(0xa8875c, { roughness: 1 }),
    brass: material(0xd29847, { roughness: .28, metalness: .62 }),
    metal: material(0x34444b, { roughness: .35, metalness: .55 }),
    sail: new THREE.MeshStandardMaterial({ color: 0xf1d9ad, roughness: .82, flatShading: true, side: THREE.DoubleSide, transparent: true, opacity: .92 }),
    lantern: new THREE.MeshPhysicalMaterial({ color: 0xffa552, emissive: 0xff6a24, emissiveIntensity: 2, roughness: .15, transparent: true, opacity: .82 }),
  };

  const { geometry: hullGeometry, stations } = createHullGeometry();
  const hull = mesh(hullGeometry, mats.hull, group);
  hull.name = 'Procedural cutter hull';

  for (const side of [-1, 1]) {
    const points = stations.map((station) => new THREE.Vector3(side * station.w, station.rail + .06, station.z));
    const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal');
    mesh(new THREE.TubeGeometry(curve, 32, .11, 6, false), mats.deck, group);
  }

  const floor = addBox(group, [2.55, .18, 6.6], [0, .18, .05], mats.darkWood);
  floor.geometry.translate(0, 0, .25);
  for (let plank = -2; plank <= 2; plank += 1) {
    addBox(group, [.42, .07, 6.15], [plank * .5, .32, .05], plank % 2 ? mats.wood : mats.deck);
  }

  const ribZ = [-3.55, -2.05, -.4, 1.25, 2.75, 3.85];
  for (let index = 0; index < ribZ.length; index += 1) {
    const width = 3.0 + Math.sin((index + 1) / (ribZ.length + 1) * Math.PI) * .7;
    addBox(group, [width, .13, .18], [0, .55, ribZ[index]], mats.darkWood);
  }
  for (const z of [-2.7, .2, 2.65]) {
    addBox(group, [3.35, .22, .68], [0, .96, z], mats.deck);
    addBox(group, [3.2, .14, .08], [0, 1.1, z - .32], mats.brass);
  }

  addBox(group, [3.15, 1.25, .25], [0, .5, 4.45], mats.wood);
  addBox(group, [.2, 1.95, 3.5], [0, -.67, 1.05], mats.metal);
  const rudder = addBox(group, [.18, 1.65, 1.25], [0, -.55, 5.05], mats.wood, [-.08, 0, 0]);
  const tiller = addBox(group, [.14, .14, 2.15], [0, .45, 3.95], mats.darkWood, [-.06, 0, 0]);

  const bowDeck = addBox(group, [2.2, .19, 1.5], [0, .88, -4.72], mats.deck, [0, 0, 0]);
  bowDeck.scale.x = .72;
  const bowspritStart = new THREE.Vector3(0, 1.3, -4.7);
  const bowspritEnd = new THREE.Vector3(0, 1.62, -8.1);
  cylinderBetween(bowspritStart, bowspritEnd, .09, mats.darkWood, group, 8);

  for (const side of [-1, 1]) {
    for (const z of [-3.9, -1.5, 1.3, 3.5]) {
      const cleat = mesh(new THREE.TorusGeometry(.2, .045, 5, 9, Math.PI), mats.brass, group);
      cleat.position.set(side * 1.62, 1.34, z);
      cleat.rotation.set(Math.PI / 2, 0, side * Math.PI / 2);
    }
  }

  const mast = cylinderBetween(new THREE.Vector3(0, .4, -.05), new THREE.Vector3(0, 11.45, -.05), .14, mats.darkWood, group, 10);
  mast.name = 'Main mast';
  const mastBands = [2.9, 6.8, 10.35].map((y) => {
    const band = mesh(new THREE.TorusGeometry(.155, .025, 5, 10), mats.brass, group);
    band.position.set(0, y, -.05);
    band.rotation.x = Math.PI / 2;
    return band;
  });

  const sailRig = new THREE.Group();
  sailRig.position.z = -.05;
  group.add(sailRig);
  const boom = cylinderBetween(new THREE.Vector3(0, 3.4, 0), new THREE.Vector3(0, 3.52, 4.95), .105, mats.darkWood, sailRig, 9);
  const sailGeometry = createSailGeometry();
  const sail = mesh(sailGeometry, mats.sail, sailRig, true, false);
  const sailSeamMaterial = new THREE.LineBasicMaterial({ color: 0xb48b62, transparent: true, opacity: .72 });
  for (const row of [.25, .5, .74]) {
    const seamPoints = [];
    for (let point = 0; point <= 9; point += 1) {
      const across = point / 9;
      seamPoints.push(new THREE.Vector3(Math.sin(across * Math.PI) * .34 * Math.sin(row * Math.PI) + .015, 10.55 - row * 7.1, across * 4.65 * row));
    }
    sailRig.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(seamPoints), sailSeamMaterial));
  }
  rope([new THREE.Vector3(.02, 10.55, 0), new THREE.Vector3(.02, 3.4, 0), new THREE.Vector3(.02, 3.52, 4.95)], sailRig, 0x5f432a);

  const jibRig = new THREE.Group();
  group.add(jibRig);
  const jibGeometry = new THREE.BufferGeometry();
  jibGeometry.setAttribute('position', new THREE.Float32BufferAttribute([
    0, 10.25, -.08, 0, 2.12, -5.95, .27, 3.0, -.18,
    0, 10.25, -.08, .27, 3.0, -.18, -.17, 5.65, -.12,
  ], 3));
  jibGeometry.computeVertexNormals();
  const jib = mesh(jibGeometry, mats.sail, jibRig, true, false);
  jib.userData.rest = jibGeometry.attributes.position.array.slice();

  const riggingMaterial = new THREE.LineBasicMaterial({ color: 0x806344, transparent: true, opacity: .88 });
  const stays = [
    [new THREE.Vector3(0, 11.2, -.05), new THREE.Vector3(0, 1.4, -7.85)],
    [new THREE.Vector3(0, 11.2, -.05), new THREE.Vector3(0, 1.25, 4.4)],
    [new THREE.Vector3(0, 10.9, -.05), new THREE.Vector3(-1.82, 1.25, 2.85)],
    [new THREE.Vector3(0, 10.9, -.05), new THREE.Vector3(1.82, 1.25, 2.85)],
  ];
  for (const points of stays) group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), riggingMaterial));

  const wheel = mesh(new THREE.TorusGeometry(.53, .055, 7, 18), mats.darkWood, group);
  wheel.position.set(0, 1.7, 3.12);
  wheel.rotation.y = Math.PI / 2;
  for (let spoke = 0; spoke < 6; spoke += 1) {
    const angle = spoke / 6 * TAU;
    const spokeStart = new THREE.Vector3(0, 1.7, 3.12);
    const spokeEnd = new THREE.Vector3(0, 1.7 + Math.sin(angle) * .46, 3.12 + Math.cos(angle) * .46);
    cylinderBetween(spokeStart, spokeEnd, .025, mats.brass, group, 5);
  }
  addBox(group, [.22, 1.2, .22], [0, 1.02, 3.12], mats.metal);

  const lanternFrame = mesh(new THREE.CylinderGeometry(.2, .27, .7, 8), mats.metal, group);
  lanternFrame.position.set(-1.3, 1.72, 3.6);
  const lanternGlass = mesh(new THREE.CylinderGeometry(.14, .18, .43, 8), mats.lantern, group, false, false);
  lanternGlass.position.copy(lanternFrame.position);
  const lanternLight = new THREE.PointLight(0xff8738, 1.4, 16, 1.8);
  lanternLight.position.copy(lanternFrame.position);
  group.add(lanternLight);

  const bowFoamMaterial = new THREE.MeshBasicMaterial({ color: 0x6ee7ff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const bowFoamGeometry = new THREE.BufferGeometry();
  bowFoamGeometry.setAttribute('position', new THREE.Float32BufferAttribute([0,0,0, -3.2,.05,3.9, -.55,.22,2.5, 0,0,0, .55,.22,2.5, 3.2,.05,3.9], 3));
  const bowFoam = mesh(bowFoamGeometry, bowFoamMaterial, group, false, false);
  bowFoam.position.set(0, -.02, -5.55);

  group.userData = {
    mats,
    hull,
    rudder,
    tiller,
    wheel,
    mast,
    mastBands,
    boom,
    sailRig,
    sail,
    sailGeometry,
    jib,
    jibRig,
    lanternLight,
    bowFoam,
    bowFoamMaterial,
    applyMode(mode) {
      const natural = mode === 'natural';
      mats.wood.color.set(natural ? 0x70412f : 0x9d4c2e);
      mats.deck.color.set(natural ? 0x9a6647 : 0xc37a45);
      mats.sail.color.set(natural ? 0xd7d4c8 : 0xf1d9ad);
      mats.sail.opacity = natural ? .86 : .94;
      mats.hull.roughness = natural ? .38 : .56;
      mats.hull.metalness = natural ? .09 : .03;
    },
  };
  return group;
}

const boat = createBoat();
boat.position.copy(state.position);

function createClouds() {
  const root = new THREE.Group();
  scene.add(root);
  const dawnMaterial = material(0xe39a91, { roughness: 1, transparent: true, opacity: .72, depthWrite: false });
  const stormMaterial = material(0x1f2836, { roughness: 1, transparent: true, opacity: .82, depthWrite: false });
  const groups = [];
  for (let index = 0; index < (mobile ? 16 : 25); index += 1) {
    const storm = index % 3 === 0;
    const cloud = new THREE.Group();
    const angle = random() * TAU;
    const distance = 145 + random() * 260;
    cloud.position.set(Math.cos(angle) * distance, storm ? 55 + random() * 40 : 40 + random() * 30, Math.sin(angle) * distance);
    cloud.userData = { angle, distance, speed: .001 + random() * .0024, storm, baseY: cloud.position.y };
    const pieces = storm ? 5 + Math.floor(random() * 5) : 3 + Math.floor(random() * 4);
    for (let piece = 0; piece < pieces; piece += 1) {
      const puff = mesh(new THREE.IcosahedronGeometry(1, 1), storm ? stormMaterial : dawnMaterial, cloud, false, false);
      const size = (storm ? 12 : 8) + random() * (storm ? 20 : 14);
      puff.position.set((random() - .5) * size * 2.7, (random() - .5) * size * .48, (random() - .5) * size * .65);
      puff.scale.set(size * (1.4 + random()), size * (.45 + random() * .32), size * (.62 + random() * .45));
      puff.rotation.set(random() * .7, random() * TAU, random() * .3);
    }
    root.add(cloud);
    groups.push(cloud);
  }
  return { root, groups, dawnMaterial, stormMaterial };
}

const clouds = createClouds();

function updateClouds(time, daylight, twilight) {
  clouds.root.position.set(state.position.x, 0, state.position.z);
  for (const cloud of clouds.groups) {
    const info = cloud.userData;
    const angle = info.angle + time * info.speed;
    cloud.position.x = Math.cos(angle) * info.distance;
    cloud.position.z = Math.sin(angle) * info.distance;
    cloud.position.y = info.baseY + Math.sin(time * .08 + info.angle * 3) * 2;
    cloud.rotation.y = -angle * .2;
  }
  clouds.dawnMaterial.color.set(0xffffff).lerp(new THREE.Color(0xf18c7d), twilight * .72).lerp(new THREE.Color(0x8eafba), daylight * .28);
  clouds.dawnMaterial.opacity = .28 + daylight * .5;
  clouds.stormMaterial.color.set(0x2a3140).lerp(new THREE.Color(0x111722), state.storm * .58).lerp(new THREE.Color(0x5d6470), daylight * .16);
  clouds.stormMaterial.opacity = .18 + state.storm * .8;
}

function createRain() {
  const count = mobile ? 160 : 340;
  const positions = new Float32Array(count * 6);
  const drops = [];
  for (let index = 0; index < count; index += 1) {
    drops.push({
      x: (random() - .5) * 95,
      y: random() * 58,
      z: (random() - .5) * 110,
      speed: 25 + random() * 28,
    });
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const rainMaterial = new THREE.LineBasicMaterial({ color: 0xb8e8ff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending });
  const lines = new THREE.LineSegments(geometry, rainMaterial);
  lines.frustumCulled = false;
  scene.add(lines);
  return { lines, geometry, positions: geometry.attributes.position, drops, material: rainMaterial };
}

const rain = createRain();

function updateRain(delta) {
  const wind = new THREE.Vector3(-.55, 0, -.25);
  for (let index = 0; index < rain.drops.length; index += 1) {
    const drop = rain.drops[index];
    drop.y -= drop.speed * delta;
    drop.x += wind.x * drop.speed * delta * .22;
    drop.z += wind.z * drop.speed * delta * .22;
    if (drop.y < -3) {
      drop.y = 48 + random() * 20;
      drop.x = (random() - .5) * 95;
      drop.z = (random() - .5) * 110;
    }
    const x = state.position.x + drop.x;
    const y = state.position.y + drop.y;
    const z = state.position.z + drop.z;
    rain.positions.setXYZ(index * 2, x, y, z);
    rain.positions.setXYZ(index * 2 + 1, x - 1.1, y + 3.6, z - .45);
  }
  rain.positions.needsUpdate = true;
  rain.material.opacity = clamp((state.storm - .34) * .95, 0, .58);
  rain.lines.visible = rain.material.opacity > .01;
}

function createWakeSystem() {
  const count = mobile ? 70 : 130;
  const geometry = new THREE.RingGeometry(.7, 1, 10, 1);
  geometry.rotateX(-Math.PI / 2);
  const wakeMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .62, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
  const instances = new THREE.InstancedMesh(geometry, wakeMaterial, count);
  instances.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  instances.frustumCulled = false;
  scene.add(instances);
  const particles = Array.from({ length: count }, () => ({ life: 0, maxLife: 1, x: 0, z: 0, scale: 0, stretch: 1, rotation: 0 }));
  const hidden = new THREE.Matrix4().makeScale(0, 0, 0);
  for (let index = 0; index < count; index += 1) instances.setMatrixAt(index, hidden);
  return { instances, particles, cursor: 0 };
}

const wakes = createWakeSystem();

function spawnWake(x, z, size = 1.1, life = 2.7, stretch = 1) {
  const particle = wakes.particles[wakes.cursor];
  wakes.cursor = (wakes.cursor + 1) % wakes.particles.length;
  particle.life = life;
  particle.maxLife = life;
  particle.x = x;
  particle.z = z;
  particle.scale = size;
  particle.stretch = stretch;
  particle.rotation = state.heading + (random() - .5) * .25;
}

function updateWakes(delta, time) {
  for (let index = 0; index < wakes.particles.length; index += 1) {
    const particle = wakes.particles[index];
    particle.life -= delta;
    if (particle.life <= 0) {
      temp.matrix.makeScale(0, 0, 0);
      wakes.instances.setMatrixAt(index, temp.matrix);
      continue;
    }
    const age = 1 - particle.life / particle.maxLife;
    const height = waveSample(particle.x, particle.z, time, state.storm).height + .1;
    const scale = particle.scale * (.5 + age * 2.35);
    temp.a.set(particle.x, height, particle.z);
    temp.euler.set(0, particle.rotation, 0);
    temp.b.set(scale * particle.stretch, 1, scale);
    temp.matrix.compose(temp.a, new THREE.Quaternion().setFromEuler(temp.euler), temp.b);
    wakes.instances.setMatrixAt(index, temp.matrix);
    const brightness = Math.max(0, 1 - age);
    temp.color.setRGB(.16 * brightness, (.62 + .2 * brightness) * brightness, brightness);
    wakes.instances.setColorAt(index, temp.color);
  }
  wakes.instances.instanceMatrix.needsUpdate = true;
  if (wakes.instances.instanceColor) wakes.instances.instanceColor.needsUpdate = true;
}

function createSpraySystem() {
  const count = mobile ? 110 : 220;
  const geometry = new THREE.TetrahedronGeometry(.11, 0);
  const sprayMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .93, depthWrite: false, blending: THREE.AdditiveBlending });
  const instances = new THREE.InstancedMesh(geometry, sprayMaterial, count);
  instances.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  instances.frustumCulled = false;
  scene.add(instances);
  const particles = Array.from({ length: count }, () => ({ life: 0, maxLife: 1, position: new THREE.Vector3(), velocity: new THREE.Vector3(), size: 1 }));
  const hidden = new THREE.Matrix4().makeScale(0, 0, 0);
  for (let index = 0; index < count; index += 1) instances.setMatrixAt(index, hidden);
  return { instances, particles, cursor: 0 };
}

const spray = createSpraySystem();

function spawnSpray(count, force = 1) {
  const forward = temp.a.set(Math.sin(state.heading), 0, -Math.cos(state.heading)).clone();
  const right = temp.b.set(Math.cos(state.heading), 0, Math.sin(state.heading)).clone();
  for (let amount = 0; amount < count; amount += 1) {
    const particle = spray.particles[spray.cursor];
    spray.cursor = (spray.cursor + 1) % spray.particles.length;
    const side = random() < .5 ? -1 : 1;
    const bowX = state.position.x + forward.x * (4.8 + random() * 1.1) + right.x * side * (1 + random() * .75);
    const bowZ = state.position.z + forward.z * (4.8 + random() * 1.1) + right.z * side * (1 + random() * .75);
    particle.position.set(bowX, waveSample(bowX, bowZ, state.physicsTime, state.storm).height + random() * .5, bowZ);
    particle.velocity.copy(right).multiplyScalar(side * (2.8 + random() * 5) * force);
    particle.velocity.addScaledVector(forward, -1.2 + random() * 2.8);
    particle.velocity.y = (3.2 + random() * 6.5) * force;
    particle.life = .55 + random() * .8;
    particle.maxLife = particle.life;
    particle.size = .65 + random() * 2.4;
  }
}

function updateSpray(delta) {
  for (let index = 0; index < spray.particles.length; index += 1) {
    const particle = spray.particles[index];
    particle.life -= delta;
    if (particle.life <= 0) {
      temp.matrix.makeScale(0, 0, 0);
      spray.instances.setMatrixAt(index, temp.matrix);
      continue;
    }
    particle.velocity.y -= 11.5 * delta;
    particle.velocity.multiplyScalar(Math.exp(-.42 * delta));
    particle.position.addScaledVector(particle.velocity, delta);
    const age = 1 - particle.life / particle.maxLife;
    const size = particle.size * (.72 + age * .55);
    temp.euler.set(particle.velocity.z * .03, age * 3 + index, particle.velocity.x * .03);
    temp.matrix.compose(particle.position, new THREE.Quaternion().setFromEuler(temp.euler), temp.a.set(size, size * 1.35, size));
    spray.instances.setMatrixAt(index, temp.matrix);
    const brightness = Math.max(0, 1 - age * .86);
    temp.color.setRGB(.22 * brightness, (.74 + index % 3 * .09) * brightness, brightness);
    spray.instances.setColorAt(index, temp.color);
  }
  spray.instances.instanceMatrix.needsUpdate = true;
  if (spray.instances.instanceColor) spray.instances.instanceColor.needsUpdate = true;
}

const droplets = Array.from({ length: mobile ? 10 : 18 }, (_, index) => {
  const element = document.createElement('i');
  element.className = 'droplet';
  element.style.left = `${5 + random() * 90}%`;
  element.style.top = `${2 + random() * 72}%`;
  element.style.setProperty('--size', `${10 + random() * (index % 4 === 0 ? 38 : 23)}px`);
  element.style.setProperty('--rotation', `${-25 + random() * 50}deg`);
  element.style.setProperty('--dx', `${(random() - .5) * 20}px`);
  element.style.setProperty('--dy', `${25 + random() * 110}px`);
  element.style.setProperty('--life', `${3.2 + random() * 4}s`);
  element.style.setProperty('--opacity', `${.25 + random() * .48}`);
  ui.lens.append(element);
  return element;
});
let dropletCursor = 0;

function splashLens(force = 1) {
  if (reducedMotion || !state.started) return;
  const count = Math.max(1, Math.round(2 * force));
  for (let index = 0; index < count; index += 1) {
    const droplet = droplets[dropletCursor];
    dropletCursor = (dropletCursor + 1) % droplets.length;
    droplet.classList.remove('live');
    void droplet.offsetWidth;
    droplet.classList.add('live');
  }
}

function waveAtOffset(lateral, longitudinal) {
  const forwardX = Math.sin(state.heading);
  const forwardZ = -Math.cos(state.heading);
  const rightX = Math.cos(state.heading);
  const rightZ = Math.sin(state.heading);
  const x = state.position.x + rightX * lateral + forwardX * longitudinal;
  const z = state.position.z + rightZ * lateral + forwardZ * longitudinal;
  return waveSample(x, z, state.physicsTime, state.storm).height;
}

function controlAxis(positiveKeys, negativeKeys) {
  const positive = positiveKeys.some((key) => keys.has(key));
  const negative = negativeKeys.some((key) => keys.has(key));
  return Number(positive) - Number(negative);
}

function updateBoat(delta) {
  const helmEnabled = state.started && !state.completed;
  const driveInput = helmEnabled ? controlAxis(['KeyW', 'ArrowUp', 'touch-forward'], ['KeyS', 'ArrowDown']) : 0;
  const steerInput = helmEnabled ? controlAxis(['KeyD', 'ArrowRight', 'touch-right'], ['KeyA', 'ArrowLeft', 'touch-left']) : 0;
  state.throttle = damp(state.throttle, driveInput, driveInput ? 2.8 : 1.3, delta);
  state.rudder = damp(state.rudder, steerInput, steerInput ? 5.8 : 7.5, delta);

  const windDirection = -.62 + Math.sin(state.elapsed * .026) * .12;
  const relativeWind = wrapAngle(windDirection - state.heading);
  const sailEfficiency = clamp(.22 + Math.abs(Math.sin(relativeWind)) * .88, .18, 1);
  const stormPush = .9 + state.storm * .19;
  const targetSpeed = state.throttle >= 0
    ? state.throttle * (11.8 + sailEfficiency * 10.7) * stormPush
    : state.throttle * 5.3;
  state.speed = damp(state.speed, targetSpeed, state.throttle ? .84 : .42, delta);
  state.speed *= Math.exp(-Math.abs(state.rudder) * .038 * delta);
  const steerAuthority = clamp(Math.abs(state.speed) / 10, .12, 1.15);
  state.heading = wrapAngle(state.heading + state.rudder * steerAuthority * delta * .67 * Math.sign(state.speed || 1));

  const forward = temp.a.set(Math.sin(state.heading), 0, -Math.cos(state.heading));
  state.position.addScaledVector(forward, state.speed * delta);

  for (const island of islands) {
    temp.b.set(state.position.x - island.config.position.x, 0, state.position.z - island.config.position.z);
    const distance = temp.b.length();
    const shore = island.config.radius * .76;
    if (distance < shore) {
      temp.b.normalize();
      state.position.x = island.config.position.x + temp.b.x * shore;
      state.position.z = island.config.position.z + temp.b.z * shore;
      state.speed *= -.18;
      state.screenShake = Math.max(state.screenShake, .4);
    }
  }

  const center = waveAtOffset(0, 0);
  const bow = waveAtOffset(0, 4.75);
  const stern = waveAtOffset(0, -4.2);
  const port = waveAtOffset(-1.55, .1);
  const starboard = waveAtOffset(1.55, .1);
  const dynamicLift = clamp(state.speed * state.speed * .00125, 0, .48);
  const targetY = (center * 2 + bow + stern + port + starboard) / 6 + .08 + dynamicLift;
  const heaveAcceleration = (targetY - state.position.y) * 18.5 - state.verticalSpeed * 7.3;
  state.verticalSpeed += heaveAcceleration * delta;
  state.position.y += state.verticalSpeed * delta;

  const pitchTarget = clamp(Math.atan2(bow - stern, 8.95) + clamp(state.speed, 0, 22) * .0042, -.34, .34);
  const rollTarget = clamp(Math.atan2(starboard - port, 3.1) - state.rudder * state.speed * .0065, -.38, .38);
  state.pitchSpeed += ((pitchTarget - boat.rotation.x) * 16 - state.pitchSpeed * 6.4) * delta;
  state.rollSpeed += ((rollTarget - boat.rotation.z) * 14 - state.rollSpeed * 6.1) * delta;
  boat.rotation.x += state.pitchSpeed * delta;
  boat.rotation.z += state.rollSpeed * delta;
  boat.rotation.y = lerpAngle(boat.rotation.y, state.heading, 12, delta);
  boat.position.copy(state.position);

  const desiredSail = clamp(relativeWind * .68, -1.12, 1.12);
  boat.userData.sailRig.rotation.y = lerpAngle(boat.userData.sailRig.rotation.y, desiredSail, 2.3, delta);
  boat.userData.jibRig.rotation.y = lerpAngle(boat.userData.jibRig.rotation.y, desiredSail * .66, 3.1, delta);
  boat.userData.rudder.rotation.y = -state.rudder * .48;
  boat.userData.tiller.rotation.y = state.rudder * .24;
  boat.userData.wheel.rotation.x -= state.rudder * delta * 1.8;

  const sailPosition = boat.userData.sailGeometry.attributes.position;
  const sailRest = boat.userData.sailGeometry.userData.rest;
  const flutter = (.015 + state.storm * .055) * Math.abs(Math.sin(relativeWind));
  for (let index = 0; index < sailPosition.count; index += 1) {
    const restX = sailRest[index * 3];
    const restY = sailRest[index * 3 + 1];
    const restZ = sailRest[index * 3 + 2];
    const edge = clamp(restZ / 4.65, 0, 1);
    sailPosition.setX(index, restX + Math.sin(state.elapsed * 5.1 + restY * 1.7 + restZ) * flutter * edge);
  }
  sailPosition.needsUpdate = true;
  if (Math.floor(state.elapsed * 15) % 3 === 0) boat.userData.sailGeometry.computeVertexNormals();

  const wakeStrength = clamp((Math.abs(state.speed) - 1.5) / 12, 0, 1);
  boat.userData.bowFoamMaterial.opacity = damp(boat.userData.bowFoamMaterial.opacity, wakeStrength * .62, 5, delta);
  boat.userData.bowFoam.scale.x = .75 + wakeStrength * .6;
  boat.userData.bowFoam.scale.z = .8 + wakeStrength * 1.15;

  if (wakeStrength > .05 && state.elapsed - state.lastWake > .085) {
    const right = temp.b.set(Math.cos(state.heading), 0, Math.sin(state.heading));
    const sternX = state.position.x - forward.x * 4.2;
    const sternZ = state.position.z - forward.z * 4.2;
    spawnWake(sternX + right.x * 1.1, sternZ + right.z * 1.1, .72 + wakeStrength * .52, 2.7, 1.6);
    spawnWake(sternX - right.x * 1.1, sternZ - right.z * 1.1, .72 + wakeStrength * .52, 2.7, 1.6);
    if (Math.floor(state.elapsed * 10) % 3 === 0) spawnWake(sternX, sternZ, .5 + wakeStrength * .5, 2.2, 1.2);
    state.lastWake = state.elapsed;
  }

  const impact = Math.abs(state.verticalSpeed) * .18 + Math.max(0, pitchTarget - boat.rotation.x) * 2.2 + wakeStrength;
  if (wakeStrength > .12 && state.elapsed - state.lastSpray > .055) {
    spawnSpray(Math.ceil(1 + impact * (mobile ? 1.3 : 2.6)), .55 + impact * .28);
    state.lastSpray = state.elapsed;
  }
  if (impact > 1.2) {
    state.screenShake = Math.max(state.screenShake, clamp(impact * .15, .05, .38));
    if (state.elapsed - state.lastDroplet > 1.1 / impact) {
      splashLens(clamp(impact * .7, 1, 3));
      state.lastDroplet = state.elapsed;
    }
  }
}

const cameraLook = new THREE.Vector3(0, 2, 0);
const cameraDesired = new THREE.Vector3();
const lookDesired = new THREE.Vector3();

function updateCamera(delta) {
  boat.updateMatrixWorld();
  if (!state.started) {
    const orbit = state.elapsed * .035;
    cameraDesired.set(state.position.x + 13 + Math.sin(orbit) * 2, state.position.y + 9.2, state.position.z + 23 + Math.cos(orbit) * 2);
    lookDesired.set(state.position.x, state.position.y + 2.1, state.position.z - 8);
  } else if (state.cameraMode === 'bow') {
    cameraDesired.copy(boat.localToWorld(new THREE.Vector3(0, 2.2, -4.65)));
    lookDesired.copy(boat.localToWorld(new THREE.Vector3(0, 1.65, -42)));
  } else {
    const forward = temp.a.set(Math.sin(state.heading), 0, -Math.cos(state.heading));
    const right = temp.b.set(Math.cos(state.heading), 0, Math.sin(state.heading));
    cameraDesired.copy(state.position).addScaledVector(forward, -18.5 - Math.abs(state.speed) * .12).addScaledVector(right, 1.9);
    cameraDesired.y += 8.2 + Math.abs(state.speed) * .055;
    lookDesired.copy(state.position).addScaledVector(forward, 5.2);
    lookDesired.y += 1.65;
  }
  const cameraDamping = state.cameraMode === 'bow' ? 8.5 : 3.25;
  camera.position.lerp(cameraDesired, 1 - Math.exp(-cameraDamping * delta));
  cameraLook.lerp(lookDesired, 1 - Math.exp(-(state.cameraMode === 'bow' ? 9 : 4.6) * delta));
  if (!reducedMotion && state.screenShake > .002) {
    camera.position.x += (random() - .5) * state.screenShake;
    camera.position.y += (random() - .5) * state.screenShake * .65;
    state.screenShake *= Math.exp(-5.5 * delta);
  }
  camera.lookAt(cameraLook);
  camera.fov = damp(camera.fov, state.cameraMode === 'bow' ? 65 + clamp(state.speed * .28, 0, 5) : 56 + clamp(state.speed * .12, 0, 3), 3, delta);
  camera.updateProjectionMatrix();
}

function weatherTarget() {
  if (state.weatherMode === 'clear') return .11;
  if (state.weatherMode === 'storm') return .94;
  const routeWeather = [.29, .84, .58, .36, .24][Math.min(state.objective, 4)];
  const breathing = Math.sin(state.elapsed * .035) * .08 + Math.sin(state.elapsed * .013 + 1.7) * .05;
  return clamp(routeWeather + breathing, .14, .92);
}

function updateSkyAndLight(celestial, delta) {
  state.stormTarget = weatherTarget();
  state.storm = damp(state.storm, state.stormTarget, .22, delta);
  const sunDirection = temp.c.set(Math.cos(celestial.angle) * .18, celestial.altitude, -Math.cos(celestial.angle)).normalize();
  const moonDirection = temp.d.copy(sunDirection).multiplyScalar(-1);
  sky.uniforms.uSunDirection.value.copy(sunDirection);
  sky.uniforms.uMoonDirection.value.copy(moonDirection);
  sky.uniforms.uDaylight.value = celestial.daylight;
  sky.uniforms.uTwilight.value = celestial.twilight;
  sky.uniforms.uStorm.value = state.storm;
  sky.uniforms.uTime.value = state.elapsed;
  sky.sky.position.set(state.position.x, 0, state.position.z);

  sunDisc.position.copy(state.position).addScaledVector(sunDirection, 660);
  sunGlow.position.copy(sunDisc.position);
  sunDisc.visible = celestial.altitude > -.09;
  sunGlow.visible = sunDisc.visible;
  sunGlow.material.opacity = celestial.daylight * (.55 + celestial.twilight * .45);
  moonDisc.position.copy(state.position).addScaledVector(moonDirection, 660);
  moonGlow.position.copy(moonDisc.position);
  moonDisc.visible = celestial.altitude < .2;
  moonGlow.visible = moonDisc.visible;
  moonGlow.material.opacity = (1 - celestial.daylight) * .46;

  sunLight.position.copy(state.position).addScaledVector(sunDirection, 170);
  sunLight.position.y = Math.max(sunLight.position.y, state.position.y + 30);
  sunLight.target.position.copy(state.position);
  sunLight.intensity = celestial.daylight * (3.6 - state.storm * 1.85) + celestial.twilight * .42;
  sunLight.color.copy(palette.sun).lerp(new THREE.Color(0xfff1d1), clamp(celestial.altitude, 0, 1));
  hemisphere.intensity = .24 + celestial.daylight * (1.72 - state.storm * .68);
  hemisphere.color.set(0x557fa6).lerp(new THREE.Color(0x9bcbe0), celestial.daylight);
  hemisphere.groundColor.set(0x071226).lerp(new THREE.Color(0x24434f), celestial.daylight * .55);

  const fogColor = palette.fogNight.clone().lerp(palette.fogDay, celestial.daylight);
  fogColor.lerp(palette.fogDawn, celestial.twilight * .45);
  fogColor.lerp(palette.fogStorm, state.storm * .62);
  scene.fog.color.copy(fogColor);
  scene.fog.density = .00165 + state.storm * .00122;
  renderer.setClearColor(fogColor);
  renderer.toneMappingExposure = (state.waterMode === 'natural' ? .96 : 1.1) + celestial.daylight * .12 - state.storm * .08;
  boat.userData.lanternLight.intensity = .45 + (1 - celestial.daylight) * 2.2;
}

function showToast(kicker, title) {
  ui.toast.querySelector('span').textContent = kicker;
  ui.toastTitle.textContent = title;
  ui.toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => ui.toast.classList.remove('show'), 2800);
}

function lightBeacon(index) {
  const island = islands[index];
  if (!island || island.lit) return;
  island.lit = true;
  island.lighthouse.userData.glassMaterial.emissiveIntensity = 5.2;
  island.lighthouse.userData.light.intensity = 3.2;
  island.lighthouse.userData.beamMaterial.opacity = .23;
  island.marker.material.color.set(0xffe4a8);
  showToast('BEACON LIT', `${island.config.name} answers the sea`);
  state.objective += 1;
  state.screenShake = Math.max(state.screenShake, .16);

  if (state.objective >= objectives.length) {
    state.completed = true;
    setTimeout(() => {
      ui.complete.classList.remove('is-hidden');
      ui.hud.classList.add('is-hidden');
    }, 1900);
  }
}

function updateObjectives(delta) {
  for (let index = 0; index < islands.length; index += 1) {
    const island = islands[index];
    const current = index === state.objective;
    island.lighthouse.userData.beamPivot.rotation.y += delta * (.32 + index * .045);
    island.marker.rotation.y += delta * .75;
    island.marker.position.y = island.marker.userData.baseY + Math.sin(state.elapsed * 1.6 + index) * .7;
    island.markerRing.position.y = island.marker.position.y;
    island.markerRing.rotation.z += delta * .24;
    island.marker.visible = current;
    island.markerRing.visible = current;
    island.lighthouse.userData.beamMaterial.opacity = island.lit ? .16 : current ? .13 : .035;
    island.lighthouse.userData.light.intensity = island.lit ? 2.1 : current ? 1.05 : .3;
  }

  const target = objectives[state.objective];
  if (!target || !state.started || state.paused) return;
  const distance = Math.hypot(state.position.x - target.position.x, state.position.z - target.position.z);
  if (distance < target.radius + 19) lightBeacon(state.objective);
}

function updateHud(celestial) {
  const labels = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const headingIndex = Math.round(((state.heading % TAU) + TAU) % TAU / (TAU / 8)) % 8;
  ui.heading.textContent = headingLabel(state.heading);
  ui.compassLeft.textContent = labels[(headingIndex + 7) % 8];
  ui.compassRight.textContent = labels[(headingIndex + 1) % 8];
  ui.speed.textContent = (Math.abs(state.speed) * .54).toFixed(1);
  ui.windSpeed.textContent = String(Math.round(11 + state.storm * 13 + Math.sin(state.elapsed * .2) * 2));
  ui.windArrow.style.transform = `rotate(${(-.62 - state.heading) * 180 / Math.PI}deg)`;
  ui.seaState.textContent = state.storm > .76 ? 'HIGH SEAS' : state.storm > .48 ? 'BUILDING' : 'LONG SWELL';
  ui.cycleTime.textContent = formatCycleClock(celestial.progress);
  ui.cycleProgress.style.width = `${celestial.progress * 100}%`;
  ui.timeIcon.textContent = celestial.daylight > .52 ? '☼' : celestial.twilight > .45 ? '◐' : '✦';

  const target = objectives[state.objective];
  if (target) {
    const distance = Math.hypot(state.position.x - target.position.x, state.position.z - target.position.z);
    ui.objectiveIndex.textContent = String(state.objective + 1).padStart(2, '0');
    ui.objectiveName.textContent = target.name;
    ui.objectiveCopy.textContent = target.copy;
    const bearing = bearingTo(state.position.x, state.position.z, target.position.x, target.position.z);
    ui.objectiveDistance.textContent = `${(distance / 18).toFixed(1)} nm · ${headingLabel(bearing)}`;
    ui.rangeFill.style.width = `${clamp((1 - distance / 190) * 100, 0, 100)}%`;
  } else {
    ui.objectiveIndex.textContent = '∞';
    ui.objectiveName.textContent = 'Open Sea';
    ui.objectiveCopy.textContent = 'All lights answer. Follow any horizon you choose.';
    ui.objectiveDistance.textContent = 'free sail';
    ui.rangeFill.style.width = '100%';
  }
  ui.beaconCount.textContent = `${Math.min(state.objective, 4)} / 4 lit`;
}

function cycleCamera() {
  state.cameraMode = state.cameraMode === 'chase' ? 'bow' : 'chase';
  ui.cameraValue.textContent = state.cameraMode.toUpperCase();
  showToast('VIEW CHANGED', state.cameraMode === 'bow' ? 'At the bow, behind the glass' : 'Following the wake');
}

function cycleWeather() {
  const modes = ['dynamic', 'clear', 'storm'];
  state.weatherMode = modes[(modes.indexOf(state.weatherMode) + 1) % modes.length];
  ui.weatherValue.textContent = state.weatherMode.toUpperCase();
  showToast('WEATHER', state.weatherMode === 'storm' ? 'Glass Between Storms' : state.weatherMode === 'clear' ? 'First Light Voyage' : 'The voyage will change the sea');
}

function setPaused(paused) {
  if (!state.started || state.completed) return;
  state.paused = paused;
  ui.pauseMenu.classList.toggle('is-hidden', !paused);
  ui.hud.classList.toggle('is-hidden', paused);
  ui.pause.textContent = paused ? '▶' : 'Ⅱ';
  if (!paused) clock.getDelta();
}

function beginVoyage() {
  if (state.started) return;
  state.started = true;
  ui.intro.classList.add('is-hidden');
  ui.hud.classList.remove('is-hidden');
  state.throttle = .12;
  showToast('PASSAGE I', 'Make for Emberwatch');
}

ui.begin.addEventListener('click', beginVoyage);
ui.pause.addEventListener('click', () => setPaused(!state.paused));
ui.resume.addEventListener('click', () => setPaused(false));
ui.sailOn.addEventListener('click', () => {
  state.completed = false;
  ui.complete.classList.add('is-hidden');
  ui.hud.classList.remove('is-hidden');
});
ui.cameraMode.addEventListener('click', cycleCamera);
ui.weather.addEventListener('click', cycleWeather);
document.querySelectorAll('[data-water]').forEach((button) => button.addEventListener('click', () => applyWaterMode(button.dataset.water)));

window.addEventListener('keydown', (event) => {
  if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) event.preventDefault();
  if (event.repeat && ['KeyV', 'KeyR', 'KeyP', 'Escape'].includes(event.code)) return;
  keys.add(event.code);
  if (event.code === 'KeyV' && state.started && !state.paused) cycleCamera();
  if (event.code === 'KeyR' && state.started && !state.paused) cycleWeather();
  if ((event.code === 'KeyP' || event.code === 'Escape') && state.started) setPaused(!state.paused);
  if ((event.code === 'Enter' || event.code === 'Space') && !state.started) beginVoyage();
});

window.addEventListener('keyup', (event) => keys.delete(event.code));
window.addEventListener('blur', () => {
  keys.clear();
  if (state.started && !state.completed) setPaused(true);
});

document.querySelectorAll('[data-control]').forEach((button) => {
  const key = `touch-${button.dataset.control}`;
  const press = (event) => {
    event.preventDefault();
    keys.add(key);
    button.setPointerCapture?.(event.pointerId);
  };
  const release = (event) => {
    event.preventDefault();
    keys.delete(key);
  };
  button.addEventListener('pointerdown', press);
  button.addEventListener('pointerup', release);
  button.addEventListener('pointercancel', release);
  button.addEventListener('pointerleave', release);
});

window.addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio, innerWidth < 760 ? 1.5 : 2));
  renderer.setSize(innerWidth, innerHeight);
});

canvas.addEventListener('webglcontextlost', (event) => {
  event.preventDefault();
  ui.hud.classList.add('is-hidden');
  ui.intro.classList.add('is-hidden');
  ui.fallback.classList.remove('is-hidden');
});

applyWaterMode('illustrated');
updateOcean(0, state.storm);
updateHud(celestialState(0));

function animate() {
  const rawDelta = Math.min(clock.getDelta(), .05);
  const delta = state.paused ? 0 : rawDelta;
  if (delta > 0) {
    state.elapsed += delta;
    state.physicsTime += delta;
    updateBoat(delta);
  }
  const celestial = celestialState(state.elapsed);
  updateSkyAndLight(celestial, delta || .0001);
  if (delta > 0) {
    updateOcean(state.physicsTime, state.storm);
    updateSparkles(state.physicsTime, celestial.daylight);
    updateClouds(state.elapsed, celestial.daylight, celestial.twilight);
    updateRain(delta);
    updateWakes(delta, state.physicsTime);
    updateSpray(delta);
    updateObjectives(delta);
    if (state.storm > .72 && state.started && state.elapsed - state.lastDroplet > 2.5 + random() * 2) {
      splashLens(1);
      state.lastDroplet = state.elapsed;
    }
  }
  updateCamera(rawDelta);
  updateHud(celestial);
  renderer.render(scene, camera);
}

renderer.setAnimationLoop(animate);
