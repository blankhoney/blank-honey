export const TAU = Math.PI * 2;

const WAVES = [
  { x: 0.82, z: -0.57, amplitude: 2.65, length: 44, speed: 1.06, steepness: 0.42 },
  { x: -0.35, z: -0.94, amplitude: 1.55, length: 27, speed: 1.31, steepness: 0.34 },
  { x: 0.96, z: 0.28, amplitude: 0.82, length: 15, speed: 1.72, steepness: 0.24 },
  { x: -0.76, z: 0.65, amplitude: 0.42, length: 8, speed: 2.18, steepness: 0.16 },
];

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function damp(current, target, smoothing, delta) {
  return current + (target - current) * (1 - Math.exp(-smoothing * delta));
}

export function wrapAngle(angle) {
  return Math.atan2(Math.sin(angle), Math.cos(angle));
}

export function lerpAngle(current, target, smoothing, delta) {
  return current + wrapAngle(target - current) * (1 - Math.exp(-smoothing * delta));
}

export function waveSample(x, z, time, storm = 0.45) {
  let height = 0;
  let dx = 0;
  let dz = 0;
  const energy = 0.62 + storm * 0.62;

  for (const wave of WAVES) {
    const k = TAU / wave.length;
    const phase = k * (wave.x * x + wave.z * z) + time * wave.speed;
    const amplitude = wave.amplitude * energy;
    height += Math.sin(phase) * amplitude;
    const slope = Math.cos(phase) * amplitude * k;
    dx += slope * wave.x;
    dz += slope * wave.z;
  }

  const cross = Math.sin(x * 0.105 - z * 0.073 + time * 1.55) *
    Math.sin(z * 0.088 + time * 0.82) * (0.22 + storm * 0.42);
  height += cross;
  dx += Math.cos(x * 0.105 - z * 0.073 + time * 1.55) * 0.105 *
    Math.sin(z * 0.088 + time * 0.82) * (0.22 + storm * 0.42);
  dz += -Math.cos(x * 0.105 - z * 0.073 + time * 1.55) * 0.073 *
    Math.sin(z * 0.088 + time * 0.82) * (0.22 + storm * 0.42) +
    Math.sin(x * 0.105 - z * 0.073 + time * 1.55) *
    Math.cos(z * 0.088 + time * 0.82) * 0.088 * (0.22 + storm * 0.42);

  const inv = 1 / Math.hypot(dx, 1, dz);
  return { height, normal: { x: -dx * inv, y: inv, z: -dz * inv } };
}

export function headingLabel(radians) {
  const labels = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return labels[Math.round(((radians % TAU) + TAU) % TAU / (TAU / 8)) % 8];
}

export function bearingTo(fromX, fromZ, toX, toZ) {
  return Math.atan2(toX - fromX, -(toZ - fromZ));
}

export function celestialState(elapsedSeconds) {
  const progress = ((elapsedSeconds % 300) + 300) % 300 / 300;
  const angle = progress * TAU + 0.055;
  const altitude = Math.sin(angle);
  const daylight = clamp(altitude * 1.65 + 0.38, 0, 1);
  const twilight = Math.pow(clamp(1 - Math.abs(altitude) * 3.2, 0, 1), 1.4);
  return { progress, angle, altitude, daylight, twilight };
}

export function formatCycleClock(progress) {
  const totalMinutes = (5.6 + progress * 24) % 24;
  const hours = Math.floor(totalMinutes);
  const minutes = Math.floor((totalMinutes - hours) * 60);
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}
