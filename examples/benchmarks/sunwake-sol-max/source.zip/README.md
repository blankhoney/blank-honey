# Sunwake — First Light Voyage

A static, procedural WebGL sailing slice inspired by the supplied *First Light Voyage* and *Glass Between Storms* concept images. The ocean, vessel, islands, clouds, weather, particles, stars, and aurora are generated from code; the build loads no remote art, sprites, or models.

## Run

```sh
npm ci
npm run build
npm run check
```

For local play, run `npm run dev`. The production build is in `dist/` and uses relative asset paths, so it can be mounted below any static-host subdirectory.

## Helm

- `W` / `↑`: trim sail and accelerate
- `S` / `↓`: spill wind, brake, then reverse slowly
- `A D` / `← →`: rudder
- `V`: switch between chase and bow cameras
- `R`: cycle Dynamic, Clear, and Storm weather
- `P` / `Esc`: pause
- On touch devices, use the three lower controls.

Light all four lighthouse beacons in order. Illustrated water is the default; Natural changes lighting and material response while retaining the same triangular mesh and wave field. The full sun, stars, moonlight, and aurora cycle lasts five minutes.

## Vessel source

The game builds the cutter at runtime in `src/main.js`, so the static build needs no model request. `tools/build_vessel.py` is a Blender Python reconstruction of the same hull, deck, spars, sail, and rigging, intended for future authored GLB export with:

```sh
blender --background --python tools/build_vessel.py
```

Blender was not present in the build environment, so the optional `.blend`/`.glb` output was not generated or visually checked here.

## Verification boundary

`npm run check` covers JavaScript syntax, deterministic wave normals, heading and five-minute-cycle invariants, production-build existence, relative asset URLs, and absence of remote runtime dependencies. Browser/WebGL visual and interaction acceptance was intentionally not performed in this task.
