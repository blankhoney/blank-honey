import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { celestialState, headingLabel, waveSample } from '../src/simulation.js';

for (const point of [[0, 0], [41.2, -88.7], [-190, 212]]) {
  const sample = waveSample(point[0], point[1], 13.5, 0.7);
  const length = Math.hypot(sample.normal.x, sample.normal.y, sample.normal.z);
  assert(Number.isFinite(sample.height), 'wave height must be finite');
  assert(Math.abs(length - 1) < 1e-9, 'wave normal must stay normalized');
}

assert.equal(headingLabel(0), 'N');
assert.equal(headingLabel(Math.PI / 2), 'E');
assert.equal(celestialState(0).progress, 0);
assert(Math.abs(celestialState(300).progress) < 1e-12, 'celestial cycle must be five minutes');

await stat(new URL('../dist/index.html', import.meta.url));
const builtHtml = await readFile(new URL('../dist/index.html', import.meta.url), 'utf8');
assert.match(builtHtml, /(?:src|href)="\.\/assets\//, 'build assets must use relative paths');
assert(!builtHtml.includes('src="/assets/'), 'build must not contain root-relative assets');
assert(!/https?:\/\//.test(builtHtml), 'build must not depend on remote assets');

console.log('self-check: wave physics, five-minute sky cycle, and portable build verified');
