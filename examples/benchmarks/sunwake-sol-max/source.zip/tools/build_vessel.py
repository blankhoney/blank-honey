"""Build the Sunwake cutter from primitives in Blender and export a GLB.

Run from the project root with:
    blender --background --python tools/build_vessel.py

The browser game intentionally recreates the same construction at runtime so it
does not need to fetch a model. This source is the editable Blender counterpart.
"""

from math import pi, sin
from pathlib import Path

import bpy
from mathutils import Vector


ROOT = Path(__file__).resolve().parents[1]


def mat(name, color, metallic=0.0, roughness=0.6):
    material = bpy.data.materials.new(name)
    material.diffuse_color = (*color, 1.0)
    material.use_nodes = True
    principled = material.node_tree.nodes.get("Principled BSDF")
    principled.inputs["Base Color"].default_value = (*color, 1.0)
    principled.inputs["Metallic"].default_value = metallic
    principled.inputs["Roughness"].default_value = roughness
    return material


def cube(name, scale, location, material):
    bpy.ops.mesh.primitive_cube_add(location=location)
    obj = bpy.context.object
    obj.name = name
    obj.scale = Vector(scale) * 0.5
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(material)
    bevel = obj.modifiers.new("Soft construction edges", "BEVEL")
    bevel.width = 0.035
    bevel.segments = 2
    return obj


def cylinder_between(name, start, end, radius, material, vertices=10):
    start, end = Vector(start), Vector(end)
    direction = end - start
    midpoint = (start + end) * 0.5
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=direction.length, location=midpoint)
    obj = bpy.context.object
    obj.name = name
    obj.rotation_mode = "QUATERNION"
    obj.rotation_quaternion = Vector((0, 0, 1)).rotation_difference(direction.normalized())
    obj.data.materials.append(material)
    return obj


def curve_rope(name, points, radius, material):
    curve = bpy.data.curves.new(name, "CURVE")
    curve.dimensions = "3D"
    curve.bevel_depth = radius
    curve.bevel_resolution = 1
    spline = curve.splines.new("POLY")
    spline.points.add(len(points) - 1)
    for point, co in zip(spline.points, points):
        point.co = (*co, 1.0)
    obj = bpy.data.objects.new(name, curve)
    bpy.context.collection.objects.link(obj)
    obj.data.materials.append(material)
    return obj


def build_hull(material_outer, material_bottom):
    stations = [
        (-6.25, 0.05, 0.82, 0.34, -0.28),
        (-5.45, 0.84, 1.06, -0.02, -0.74),
        (-4.20, 1.54, 1.18, -0.28, -0.97),
        (-2.40, 1.96, 1.21, -0.35, -1.05),
        (-0.30, 2.12, 1.18, -0.38, -1.02),
        (1.75, 2.04, 1.12, -0.34, -0.90),
        (3.65, 1.84, 1.05, -0.22, -0.69),
        (4.65, 1.62, 0.96, -0.12, -0.55),
    ]
    vertices = []
    faces = []
    outer_faces = []
    bottom_faces = []

    for z, width, rail, chine, keel in stations:
        vertices.extend([
            (-width, rail, z),
            (-width * 0.73, chine, z),
            (0, keel, z),
            (width * 0.73, chine, z),
            (width, rail, z),
        ])

    for index in range(len(stations) - 1):
        a = index * 5
        b = (index + 1) * 5
        for face in [(a, b, a + 1), (b, b + 1, a + 1), (a + 3, b + 3, a + 4), (b + 3, b + 4, a + 4)]:
            outer_faces.append(len(faces))
            faces.append(face)
        for face in [(a + 1, b + 1, a + 2), (b + 1, b + 2, a + 2), (a + 2, b + 2, a + 3), (b + 2, b + 3, a + 3)]:
            bottom_faces.append(len(faces))
            faces.append(face)

    stern = (len(stations) - 1) * 5
    faces.extend([(stern, stern + 1, stern + 4), (stern + 4, stern + 1, stern + 3), (stern + 1, stern + 2, stern + 3)])
    mesh_data = bpy.data.meshes.new("Sunwake hull mesh")
    mesh_data.from_pydata(vertices, [], faces)
    mesh_data.materials.append(material_outer)
    mesh_data.materials.append(material_bottom)
    for face_index in bottom_faces:
        mesh_data.polygons[face_index].material_index = 1
    mesh_data.update()
    hull = bpy.data.objects.new("Sunwake cutter hull", mesh_data)
    bpy.context.collection.objects.link(hull)
    bevel = hull.modifiers.new("Hull edge restraint", "BEVEL")
    bevel.width = 0.045
    bevel.segments = 2
    weighted = hull.modifiers.new("Weighted hull normals", "WEIGHTED_NORMAL")
    weighted.keep_sharp = True
    return hull, stations


def build_sail(name, height, foot, material):
    segments = 10
    vertices = []
    faces = []
    starts = []
    for row in range(segments + 1):
        starts.append(len(vertices))
        down = row / segments
        for column in range(row + 1):
            across = 0 if row == 0 else column / row
            billow = sin(across * pi) * sin(down * pi) * 0.34
            vertices.append((billow, 10.55 - down * height, across * foot * down))
    for row in range(segments):
        for column in range(row + 1):
            a = starts[row] + column
            b = starts[row + 1] + column
            c = starts[row + 1] + column + 1
            faces.append((a, b, c))
            if column < row:
                faces.append((a, c, starts[row] + column + 1))
    mesh_data = bpy.data.meshes.new(f"{name} cloth")
    mesh_data.from_pydata(vertices, [], faces)
    mesh_data.materials.append(material)
    mesh_data.update()
    sail = bpy.data.objects.new(name, mesh_data)
    bpy.context.collection.objects.link(sail)
    solidify = sail.modifiers.new("Cloth thickness", "SOLIDIFY")
    solidify.thickness = 0.018
    return sail


def main():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

    hull_red = mat("Illustrated vermilion hull", (0.42, 0.08, 0.035), roughness=0.48)
    hull_bottom = mat("Slate keel", (0.055, 0.085, 0.105), metallic=0.08, roughness=0.55)
    warm_wood = mat("Sun-warmed cedar", (0.50, 0.19, 0.07), roughness=0.58)
    dark_wood = mat("Oiled spars", (0.12, 0.055, 0.03), roughness=0.62)
    brass = mat("Aged brass", (0.54, 0.29, 0.07), metallic=0.72, roughness=0.24)
    sailcloth = mat("Warm sailcloth", (0.79, 0.67, 0.48), roughness=0.83)
    rope_material = mat("Hemp rigging", (0.29, 0.20, 0.11), roughness=0.95)

    hull, stations = build_hull(hull_red, hull_bottom)
    for side in (-1, 1):
        rail = [(side * width, rail_y + 0.06, z) for z, width, rail_y, _, _ in stations]
        curve_rope(f"{'Port' if side < 0 else 'Starboard'} gunwale", rail, 0.105, warm_wood)

    cube("Cockpit floor", (2.55, 0.18, 6.6), (0, 0.18, 0.3), dark_wood)
    for index, x in enumerate((-1.0, -0.5, 0, 0.5, 1.0)):
        cube(f"Deck plank {index + 1}", (0.42, 0.07, 6.15), (x, 0.32, 0.05), warm_wood)
    for index, z in enumerate((-3.55, -2.05, -0.4, 1.25, 2.75, 3.85)):
        width = 3.0 + sin((index + 1) / 7 * pi) * 0.7
        cube(f"Frame {index + 1}", (width, 0.13, 0.18), (0, 0.55, z), dark_wood)
    for index, z in enumerate((-2.7, 0.2, 2.65)):
        cube(f"Thwart {index + 1}", (3.35, 0.22, 0.68), (0, 0.96, z), warm_wood)

    cube("Transom", (3.15, 1.25, 0.25), (0, 0.5, 4.45), warm_wood)
    cube("Keel", (0.2, 1.95, 3.5), (0, -0.67, 1.05), hull_bottom)
    cube("Rudder", (0.18, 1.65, 1.25), (0, -0.55, 5.05), warm_wood)
    cube("Tiller", (0.14, 0.14, 2.15), (0, 0.45, 3.95), dark_wood)

    cylinder_between("Main mast", (0, 0.4, -0.05), (0, 11.45, -0.05), 0.14, dark_wood)
    cylinder_between("Boom", (0, 3.4, -0.05), (0, 3.52, 4.9), 0.105, dark_wood)
    cylinder_between("Bowsprit", (0, 1.3, -4.7), (0, 1.62, -8.1), 0.09, dark_wood)
    for index, y in enumerate((2.9, 6.8, 10.35)):
        bpy.ops.mesh.primitive_torus_add(major_radius=0.155, minor_radius=0.025, major_segments=10, minor_segments=5, location=(0, y, -0.05), rotation=(pi / 2, 0, 0))
        bpy.context.object.name = f"Mast band {index + 1}"
        bpy.context.object.data.materials.append(brass)

    build_sail("Billowed mainsail", 7.1, 4.65, sailcloth)
    stays = [
        ((0, 11.2, -0.05), (0, 1.4, -7.85)),
        ((0, 11.2, -0.05), (0, 1.25, 4.4)),
        ((0, 10.9, -0.05), (-1.82, 1.25, 2.85)),
        ((0, 10.9, -0.05), (1.82, 1.25, 2.85)),
    ]
    for index, points in enumerate(stays):
        curve_rope(f"Standing rigging {index + 1}", points, 0.018, rope_material)

    bpy.ops.mesh.primitive_torus_add(major_radius=0.53, minor_radius=0.055, major_segments=18, minor_segments=7, location=(0, 1.7, 3.12), rotation=(0, pi / 2, 0))
    wheel = bpy.context.object
    wheel.name = "Helm wheel"
    wheel.data.materials.append(dark_wood)
    for spoke in range(6):
        angle = spoke / 6 * pi * 2
        cylinder_between(f"Wheel spoke {spoke + 1}", (0, 1.7, 3.12), (0, 1.7 + sin(angle) * 0.46, 3.12 + __import__('math').cos(angle) * 0.46), 0.025, brass, 6)

    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.shade_flat()
    blend_path = ROOT / "sunwake-cutter.blend"
    glb_path = ROOT / "sunwake-cutter.glb"
    bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    bpy.ops.export_scene.gltf(filepath=str(glb_path), export_format="GLB", use_selection=False, export_apply=True)
    print(f"Saved {blend_path} and {glb_path}")


if __name__ == "__main__":
    main()
