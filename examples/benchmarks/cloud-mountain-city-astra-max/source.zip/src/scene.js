import * as THREE from 'three';
import {
  FALL, PALACE, SUMMIT, TERRAIN_STEP, VOXEL, WORLD_BOUNDS, clamp, isWater,
  mix, nearestRoad, randomGenerator, rawHeight, riverWidth, riverX, roads,
  snap, terrainHeight, waterHeight,
} from './world.js';

const colors = {
  stone: '#aaa993', limestone: '#d8c9aa', paving: '#c7baa0', plaster: '#e0d4b4',
  timber: '#644734', red: '#a25340', dark: '#283c37', roof: '#3b6259',
  roofEdge: '#648675', royal: '#a49156', royalEdge: '#d1b779',
  pine: '#426953', pineLight: '#6a8560', gingko: '#c5aa61', bark: '#706443',
  water: '#4c9894', foam: '#c5e2cd', cloth: '#b57751', white: '#eee4c7',
};

function materials() {
  const result = {};
  for (const [name, color] of Object.entries(colors)) {
    result[name] = new THREE.MeshStandardMaterial({
      color, roughness: name === 'water' ? 0.32 : 1,
      metalness: name === 'water' ? 0.1 : 0,
      flatShading: true,
    });
  }
  result.lamp = new THREE.MeshStandardMaterial({
    color: '#c78b41', emissive: '#ffb652', emissiveIntensity: 0.05, roughness: 0.8,
  });
  result.water.emissive = new THREE.Color('#163c3b');
  result.water.emissiveIntensity = 0.23;
  result.foam.emissive = new THREE.Color('#42605c');
  result.foam.emissiveIntensity = 0.15;
  return result;
}

// One shared cube and one InstancedMesh per material keep the many individual
// voxel elements cheap to submit. Source geometry remains in metres.
function voxelBatches(palette) {
  const batches = new Map();
  const geometry = new THREE.BoxGeometry(1, 1, 1);
  const transform = new THREE.Object3D();
  let count = 0;
  function box(material, x, y, z, width, height, depth, angle = 0) {
    if (![x, y, z, width, height, depth, angle].every(Number.isFinite)) throw new Error('Non-finite voxel');
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push([
      snap(x), snap(y), snap(z), Math.max(VOXEL, snap(width)),
      Math.max(VOXEL, snap(height)), Math.max(VOXEL, snap(depth)), angle,
    ]);
    count++;
  }
  function flush(group) {
    const meshes = {};
    for (const [name, instances] of batches) {
      const mesh = new THREE.InstancedMesh(geometry, palette[name], instances.length);
      for (let index = 0; index < instances.length; index++) {
        const [x, y, z, width, height, depth, angle] = instances[index];
        transform.position.set(x, y, z);
        transform.scale.set(width, height, depth);
        transform.rotation.set(0, angle, 0);
        transform.updateMatrix();
        mesh.setMatrixAt(index, transform.matrix);
      }
      mesh.castShadow = !['lamp', 'water', 'foam', 'paving'].includes(name);
      mesh.receiveShadow = name !== 'lamp';
      mesh.name = `Voxels: ${name}`;
      mesh.computeBoundingSphere();
      group.add(mesh);
      meshes[name] = mesh;
    }
    batches.clear();
    return meshes;
  }
  return { box, flush, get count() { return count; } };
}

function makeTerrain(step, bounds, distant = false, cityHeight = terrainHeight) {
  const nx = Math.round((bounds.maxX - bounds.minX) / step);
  const nz = Math.round((bounds.maxZ - bounds.minZ) / step);
  const heights = new Float32Array(nx * nz);
  const heightAt = distant ? rawHeight : cityHeight;
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      heights[iz * nx + ix] = heightAt(bounds.minX + (ix + 0.5) * step, bounds.minZ + (iz + 0.5) * step);
    }
  }

  const positions = [];
  const vertexColors = [];
  const indices = [];
  const grass = new THREE.Color('#8a9a73');
  const highGrass = new THREE.Color('#a3ab87');
  const rock = new THREE.Color('#929887');
  const paleRock = new THREE.Color('#b3ad94');
  const tint = new THREE.Color();
  function quad(a, b, c, d, color) {
    const first = positions.length / 3;
    positions.push(...a, ...b, ...c, ...d);
    for (let i = 0; i < 4; i++) vertexColors.push(color.r, color.g, color.b);
    indices.push(first, first + 1, first + 2, first, first + 2, first + 3);
  }
  function face(x0, x1, z0, z1, bottom, top, side) {
    // Geological bands break up sheer voxel cliffs without textures.
    for (let low = bottom; low < top - 0.01;) {
      const high = Math.min(top, (Math.floor(low / 14.4) + 1) * 14.4);
      if (high <= low) break;
      tint.copy(rock).lerp(paleRock, (Math.floor(high / 14.4) % 4) / 6);
      if (distant) tint.multiplyScalar(0.85);
      if (side === 0) quad([x1, low, z1], [x1, low, z0], [x1, high, z0], [x1, high, z1], tint);
      if (side === 1) quad([x0, low, z0], [x0, low, z1], [x0, high, z1], [x0, high, z0], tint);
      if (side === 2) quad([x0, low, z1], [x1, low, z1], [x1, high, z1], [x0, high, z1], tint);
      if (side === 3) quad([x1, low, z0], [x0, low, z0], [x0, high, z0], [x1, high, z0], tint);
      low = high;
    }
  }

  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const x0 = bounds.minX + ix * step;
      const z0 = bounds.minZ + iz * step;
      const x1 = x0 + step;
      const z1 = z0 + step;
      if (distant && x0 > WORLD_BOUNDS.minX - step && x1 < WORLD_BOUNDS.maxX + step
        && z0 > WORLD_BOUNDS.minZ - step && z1 < WORLD_BOUNDS.maxZ + step) continue;
      const height = heights[iz * nx + ix];
      const variation = Math.sin(ix * 13.7 + iz * 21.2) * 0.05;
      tint.copy(grass).lerp(highGrass, clamp((height - 180) / 350 + variation, 0, 1));
      if (height > 370) tint.lerp(paleRock, clamp((height - 370) / 380, 0, 0.65));
      if (isWater((x0 + x1) / 2, (z0 + z1) / 2, 5)) tint.set('#9caa8a');
      if (distant) tint.multiplyScalar(0.9);
      quad([x0, height, z1], [x1, height, z1], [x1, height, z0], [x0, height, z0], tint);
      const neighbours = [
        ix < nx - 1 ? heights[iz * nx + ix + 1] : -6,
        ix > 0 ? heights[iz * nx + ix - 1] : -6,
        iz < nz - 1 ? heights[(iz + 1) * nx + ix] : -6,
        iz > 0 ? heights[(iz - 1) * nx + ix] : -6,
      ];
      neighbours.forEach((neighbour, side) => {
        if (height > neighbour) face(x0, x1, z0, z1, neighbour, height, side);
      });
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(vertexColors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  geometry.computeBoundingSphere();
  const mesh = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, flatShading: true }));
  mesh.name = distant ? 'Distant physical mountains' : 'Carved voxel terrain';
  mesh.receiveShadow = !distant;
  mesh.castShadow = !distant;
  return mesh;
}

function localPoint(site, x, y, z) {
  const cosine = Math.cos(site.angle || 0);
  const sine = Math.sin(site.angle || 0);
  return [site.x + x * cosine + z * sine, site.y + y, site.z - x * sine + z * cosine];
}

function childSite(site, x, y, z, angle = 0) {
  const point = localPoint(site, x, y, z);
  return { x: point[0], y: point[1], z: point[2], angle: (site.angle || 0) + angle };
}

export function buildWorld() {
  const group = new THREE.Group();
  group.name = '云山巨城';
  const palette = materials();
  const voxels = voxelBatches(palette);
  const box = voxels.box;
  const random = randomGenerator(20260921);
  const stats = { compounds: 0, halls: 0, roofs: 0, trees: 0, roadMetres: roads.reduce((sum, road) => sum + road.length, 0), districts: {} };
  const sites = [];
  const doors = [];

  function block(site, material, x, y, z, width, height, depth) {
    const [wx, wy, wz] = localPoint(site, x, y, z);
    box(material, wx, wy, wz, width, height, depth, site.angle || 0);
  }

  function roof(site, x, y, z, width, depth, royal = false, overhang = 2) {
    stats.roofs++;
    const material = royal ? 'royal' : 'roof';
    const edge = royal ? 'royalEdge' : 'roofEdge';
    const height = snap(clamp(depth * 0.32, 2.8, 8.4));
    const layers = Math.ceil(height / 0.6);
    const ridge = Math.max(2.4, width * 0.62);
    for (let layer = 0; layer < layers; layer++) {
      const ratio = layer / Math.max(1, layers - 1);
      block(site, layer === 0 ? edge : material, x, y + layer * 0.6, z,
        mix(width + overhang * 2, ridge, ratio), 0.6,
        mix(depth + overhang * 2, 0.8, ratio));
    }
    for (const sx of [-1, 1]) {
      for (const sz of [-1, 1]) {
        for (let step = 0; step < 4; step++) {
          block(site, edge, x + sx * (width / 2 + overhang - 1.6 + step * 0.4),
            y + 0.2 + step * 0.4, z + sz * (depth / 2 + overhang - 1.6 + step * 0.4), 1.4, 0.6, 1.4);
        }
      }
      block(site, edge, x + sx * (ridge / 2 - 0.2), y + layers * 0.6 + 0.4, z, 0.8, 1.4, 0.8);
    }
    block(site, edge, x, y + layers * 0.6, z, ridge, 0.6, 0.8);
  }

  function lantern(site, x, y, z, large = false) {
    const size = large ? 1 : 0.6;
    block(site, 'timber', x, y + size * 0.7, z, size * 1.4, 0.2, size * 1.4);
    block(site, 'lamp', x, y, z, size, size * 1.3, size);
    block(site, 'red', x, y - size * 0.8, z, 0.2, 0.6, 0.2);
  }

  function balustrade(site, x, y, z, length, alongX = true) {
    block(site, 'limestone', x, y + 1, z, alongX ? length : 0.4, 0.4, alongX ? 0.4 : length);
    for (let position = -length / 2; position <= length / 2; position += 2.4) {
      block(site, 'limestone', x + (alongX ? position : 0), y + 0.5,
        z + (alongX ? 0 : position), 0.6, 1.2, 0.6);
    }
  }

  function hall(site, x, z, width, depth, floors = 1, options = {}) {
    stats.halls++;
    const height = options.height ?? 5.2;
    const foot = options.foot ?? 0.8;
    const body = options.red ? 'red' : 'plaster';
    const bays = Math.max(2, Math.round(width / 4));
    block(site, 'limestone', x, foot / 2, z, width + 1.6, foot, depth + 1.6);
    for (let floor = 0; floor < floors; floor++) {
      const base = foot + floor * height;
      block(site, body, x, base + height / 2, z, width - 0.6, height - 0.5, depth - 0.6);
      block(site, 'timber', x, base + height - 0.4, z, width + 0.4, 0.6, depth + 0.4);
      for (let bay = 0; bay <= bays; bay++) {
        const px = x - width / 2 + bay * width / bays;
        for (const side of [-1, 1]) {
          block(site, options.red ? 'red' : 'timber', px, base + height / 2, z + side * depth / 2,
            0.6, height, 0.6);
        }
      }
      for (let bay = 0; bay < bays; bay++) {
        const wx = x - width / 2 + (bay + 0.5) * width / bays;
        for (const side of [-1, 1]) {
          block(site, 'timber', wx, base + 2.6, z + side * (depth / 2 + 0.1), 2.2, 2.4, 0.4);
          block(site, 'lamp', wx, base + 2.6, z + side * (depth / 2 + 0.4), 1.6, 1.8, 0.2);
          block(site, 'timber', wx, base + 2.6, z + side * (depth / 2 + 0.6), 0.2, 2, 0.2);
          block(site, 'timber', wx, base + 2.6, z + side * (depth / 2 + 0.6), 1.8, 0.2, 0.2);
        }
      }
      for (const side of [-1, 1]) {
        block(site, 'timber', x + side * width / 2, base + 2.8, z, 0.4, 2.6, depth * 0.5);
        block(site, 'lamp', x + side * (width / 2 + 0.2), base + 2.8, z, 0.2, 1.8, depth * 0.42);
      }
      if (floor > 0) {
        block(site, 'timber', x, base, z + depth / 2 + 0.8, width + 1.2, 0.4, 2.4);
        block(site, 'red', x, base + 1.2, z + depth / 2 + 1.8, width + 1.2, 0.4, 0.4);
        for (let bay = 0; bay <= bays; bay++) {
          block(site, 'timber', x - width / 2 + bay * width / bays, base + 0.6,
            z + depth / 2 + 1.8, 0.4, 1.2, 0.4);
        }
      }
      if (options.tiered || floor === floors - 1) {
        roof(site, x, base + height, z, width - floor * (options.tiered ? 1.2 : 0), depth, options.royal, options.overhang ?? 2);
      }
    }
    block(site, 'dark', x, foot + 1.7, z + depth / 2 + 0.6, 2.4, 3.4, 0.4);
    block(site, 'royalEdge', x, foot + 3.6, z + depth / 2 + 0.8, 3.2, 0.4, 0.4);
    lantern(site, x - 2.4, foot + 3.4, z + depth / 2 + 1.2);
    lantern(site, x + 2.4, foot + 3.4, z + depth / 2 + 1.2);
  }

  function pavilion(site, width = 16, depth = 14, height = 8, royal = false) {
    stats.halls++;
    block(site, 'limestone', 0, 0.2, 0, width + 3.2, 0.8, depth + 3.2);
    for (const x of [-width / 2 + 1, 0, width / 2 - 1]) {
      for (const z of [-depth / 2 + 1, depth / 2 - 1]) {
        block(site, 'red', x, height / 2, z, 0.8, height, 0.8);
        block(site, 'limestone', x, 0.8, z, 1.4, 1.2, 1.4);
      }
    }
    block(site, 'timber', 0, height - 0.8, 0, width, 0.8, depth);
    roof(site, 0, height, 0, width, depth, royal, 2.8);
    roof(site, 0, height + 5.2, 0, width * 0.56, depth * 0.5, royal, 1.8);
    for (const x of [-width / 2 + 1, width / 2 - 1]) lantern(site, x, height - 2.2, depth / 2 - 1, true);
    balustrade(site, 0, 0.4, -depth / 2, width);
    balustrade(site, -width / 2, 0.4, 0, depth, false);
    balustrade(site, width / 2, 0.4, 0, depth, false);
  }

  function tree(x, y, z, size, golden = false) {
    stats.trees++;
    box('bark', x, y + size * 0.35, z, size * 0.12, size * 0.7, size * 0.12);
    if (golden) {
      box('gingko', x, y + size * 0.85, z, size * 0.95, size * 0.4, size * 0.75);
      box('gingko', x - size * 0.22, y + size * 1.04, z + size * 0.04, size * 0.55, size * 0.3, size * 0.65);
      box('pineLight', x + size * 0.3, y + size * 0.67, z, size * 0.35, size * 0.3, size * 0.45);
    } else {
      for (let level = 0; level < 4; level++) {
        const breadth = size * (0.9 - level * 0.19);
        box(level % 2 ? 'pineLight' : 'pine', x, y + size * (0.5 + level * 0.2), z,
          breadth, size * 0.24, breadth);
      }
    }
  }

  function stairLink(start, end, width, material = 'paving', support = false) {
    const dx = end.x - start.x;
    const dz = end.z - start.z;
    const distance = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(distance / 1.4), Math.ceil(Math.abs(end.y - start.y) / 0.2));
    const angle = Math.atan2(dx, dz);
    for (let i = 0; i < steps; i++) {
      const t = (i + 0.5) / steps;
      const top = snap(mix(start.y, end.y, t));
      const x = mix(start.x, end.x, t);
      const z = mix(start.z, end.z, t);
      box(material, x, top - 0.4, z, width, 0.8,
        distance / steps + 0.3, angle);
      if (support) {
        const height = top - terrainHeight(x, z);
        if (height > 1.2) box('stone', x, top - height / 2 - 0.4, z, width + 0.4,
          height + 0.8, distance / steps + 0.08, angle);
      }
    }
  }

  function buildRoads() {
    for (const road of roads) {
      let previousLamp = -100;
      let previousPier = -100;
      for (let index = 1; index < road.samples.length; index++) {
        const current = road.samples[index];
        const previous = road.samples[index - 1];
        stairLink(previous, current, road.width, 'paving', !current.bridge && !previous.bridge);
        const angle = Math.atan2(current.tangent.x, current.tangent.z);
        if (current.bridge) {
          const span = Math.hypot(current.x - previous.x, current.z - previous.z);
          box('limestone', current.x, current.y - 1.5, current.z, road.width + 1.2, 2, span + 0.6, angle);
          if (current.distance - previousPier > 17) {
            const bottom = Math.min(rawHeight(current.x, current.z), waterHeight(current.z) - 3);
            const height = Math.max(3, current.y - bottom - 1.4);
            box('stone', current.x, bottom + height / 2, current.z, road.width - 1.6, height, 3.4, angle);
            for (let tier = 0; tier < 4; tier++) {
              box('limestone', current.x, current.y - 2.8 - tier * 1.2, current.z,
                road.width, 1.2, 15 - tier * 3, angle);
            }
            previousPier = current.distance;
          }
        }
        if (index % 2 === 0 && (current.bridge || current.y > 105)) {
          const normalX = current.tangent.z;
          const normalZ = -current.tangent.x;
          for (const side of [-1, 1]) {
            const x = current.x + normalX * side * (road.width / 2 - 0.4);
            const z = current.z + normalZ * side * (road.width / 2 - 0.4);
            box('limestone', x, current.y + 0.5, z, 0.6, 1.2, 0.6);
            box('limestone', x, current.y + 1.1, z, 0.4, 0.4, 6.1, angle);
          }
        }
        if (current.distance - previousLamp > 22) {
          const side = index % 4 < 2 ? 1 : -1;
          const x = current.x + current.tangent.z * side * (road.width / 2 + 0.7);
          const z = current.z - current.tangent.x * side * (road.width / 2 + 0.7);
          box('timber', x, current.y + 1.8, z, 0.4, 3.6, 0.4);
          lantern({ x, y: current.y, z, angle: 0 }, 0, 3.6, 0, true);
          previousLamp = current.distance;
        }
      }
    }
  }

  function foundation(site, width, depth) {
    let bottom = site.y;
    for (const x of [-width / 2, width / 2]) {
      for (const z of [-depth / 2, depth / 2]) {
        const point = localPoint(site, x, 0, z);
        bottom = Math.min(bottom, terrainHeight(point[0], point[2]) - 0.4);
      }
    }
    const height = Math.max(1.2, site.y - bottom);
    block(site, 'stone', 0, -height / 2, 0, width, height, depth);
    block(site, 'limestone', 0, -0.4, 0, width + 0.8, 0.8, depth + 0.8);
  }

  function courtyard(site, width, depth, royal = false) {
    hall(site, 0, -depth * 0.27, width - 5.2, 8.4, royal ? 2 : 1, { royal, red: royal });
    hall(childSite(site, -width * 0.34, 0, depth * 0.08, Math.PI / 2), 0, 0, depth * 0.52, 6.4);
    hall(childSite(site, width * 0.34, 0, depth * 0.08, -Math.PI / 2), 0, 0, depth * 0.52, 6.4);
    for (const side of [-1, 1]) block(site, 'plaster', side * width * 0.3, 1.3, depth / 2 - 1, width * 0.34, 2.6, 0.8);
    roof(site, 0, 3.6, depth / 2 - 1, 4.8, 2.4, royal, 1);
    block(site, 'paving', 0, 0.1, 0, 3.2, 0.2, depth);
    const garden = localPoint(site, -3.8, 0, 1.8);
    tree(garden[0], garden[1], garden[2], 5.6, royal);
    block(site, 'stone', 3.8, 0.6, 1, 2.4, 1.2, 1.4);
  }

  function storefront(site, width, depth, floors, quay) {
    hall(site, 0, -1, width, depth - 2, floors, { overhang: 2.6 });
    block(site, 'cloth', 0, 3.2, depth / 2 + 1.2, width + 0.8, 0.4, 3.2);
    for (const x of [-width / 2 + 0.6, width / 2 - 0.6]) {
      block(site, 'timber', x, 1.6, depth / 2 + 2.5, 0.4, 3.2, 0.4);
    }
    block(site, 'timber', width * 0.28, 1, depth / 2 + 1.5, width * 0.32, 1.6, 1.2);
    block(site, quay ? 'white' : 'gingko', width * 0.28, 2, depth / 2 + 1.5, width * 0.28, 0.4, 1);
    block(site, 'red', -width / 2 - 0.8, 4.3, depth / 2, 1, 3.6, 0.4);
    for (let mark = 0; mark < 3; mark++) block(site, 'royalEdge', -width / 2 - 0.8, 3.3 + mark, depth / 2 + 0.3, 0.6, 0.4, 0.2);
    if (quay) {
      block(site, 'timber', -width * 0.24, 0.6, depth / 2 + 1.4, 1.8, 1.2, 1.8);
      block(site, 'cloth', -width * 0.24, 1.4, depth / 2 + 1.4, 1.4, 0.4, 1.4);
    }
  }

  const siteBuckets = new Map();
  function occupied(x, z, radius) {
    const bx = Math.floor(x / 48);
    const bz = Math.floor(z / 48);
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        for (const site of siteBuckets.get(`${bx + dx},${bz + dz}`) ?? []) {
          if (Math.hypot(x - site.x, z - site.z) < radius + site.radius) return true;
        }
      }
    }
    return false;
  }

  function recordSite(site) {
    sites.push(site);
    const key = `${Math.floor(site.x / 48)},${Math.floor(site.z / 48)}`;
    if (!siteBuckets.has(key)) siteBuckets.set(key, []);
    siteBuckets.get(key).push(site);
  }

  function buildNeighbourhoods() {
    for (const road of roads) {
      let nextBuilding = 8;
      let parcel = 0;
      for (const point of road.samples) {
        if (point.distance < nextBuilding) continue;
        parcel++;
        const broadParcels = ['scholar', 'temple', 'west'].includes(road.district)
          || (['market', 'quay'].includes(road.district) && [0, 4].includes(parcel % 5));
        nextBuilding = point.distance + (broadParcels ? 43 : 23) + random() * 9;
        if (point.bridge) continue;
        for (const side of [-1, 1]) {
          const scholarly = ['scholar', 'temple'].includes(road.district);
          const compound = (scholarly && parcel % 2 === 0) || (road.district === 'west' && parcel % 3 === 0)
            || (['market', 'quay'].includes(road.district) && parcel % 5 === 0);
          const width = snap(compound ? 20 + random() * 4 : 11 + random() * 9);
          const depth = snap(compound ? 24 + random() * 4 : 11 + random() * 8);
          const offset = road.width / 2 + depth / 2 + 5 + random() * 2;
          const x = point.x + point.tangent.z * side * offset;
          const z = point.z - point.tangent.x * side * offset;
          if (Math.abs(x - PALACE.x) < 107 && Math.abs(z - PALACE.z) < 108) continue;
          if (Math.hypot(x - SUMMIT.x, z - SUMMIT.z) < 47 || Math.hypot(x + 376, z + 208) < 30) continue;
          if (isWater(x, z, Math.max(width, depth) / 2 + 3)) continue;
          const radius = Math.hypot(width, depth) / 2 + 0.6;
          if (occupied(x, z, radius)) continue;
          const near = nearestRoad(x, z, radius + 7);
          if (near && near.distance < Math.min(width, depth) / 2 + road.width / 2 + 1) continue;
          const angle = Math.atan2(point.x - x, point.z - z);
          const site = { x, z, y: terrainHeight(x, z), angle, radius, width, depth, district: road.district };
          const cosine = Math.cos(angle);
          const sine = Math.sin(angle);
          const clearance = radius + 12;
          const overlapsStreet = roads.some(street => street.samples.some(sample => {
            const dx = sample.x - x;
            const dz = sample.z - z;
            if (Math.abs(dx) > clearance || Math.abs(dz) > clearance) return false;
            const lx = dx * cosine - dz * sine;
            const lz = dx * sine + dz * cosine;
            return Math.abs(lx) < width / 2 + 3 + sample.width / 2
              && Math.abs(lz) < depth / 2 + 3.6 + sample.width / 2;
          }));
          if (overlapsStreet) continue;
          const cornerHeights = [];
          for (const lx of [-width / 2, width / 2]) {
            for (const lz of [-depth / 2, depth / 2]) {
              const corner = localPoint(site, lx, 0, lz);
              cornerHeights.push(terrainHeight(corner[0], corner[2]));
            }
          }
          if (Math.max(...cornerHeights) - Math.min(...cornerHeights) > (scholarly ? 49 : 41)) continue;
          // Cut-and-fill platforms put doors near street level. The matching
          // excavation is applied to the terrain below, not hidden inside it.
          site.y = snap(point.y + clamp((site.y - point.y) * 0.4, -4, 8) + 0.8);
          foundation(site, width + 3.2, depth + 4);
          if (compound) courtyard(site, width, depth, road.district === 'temple');
          else if (['market', 'quay', 'river'].includes(road.district)) {
            storefront(site, width, depth, road.district === 'market' || parcel % 3 === 0 ? 2 : 1, road.district === 'quay');
          } else {
            hall(site, 0, -0.8, width, depth, scholarly ? 2 + (parcel % 6 === 0 ? 1 : 0) : 1 + (parcel % 3 === 0 ? 1 : 0),
              { royal: road.district === 'temple', tiered: scholarly, red: scholarly });
          }
          const entrance = localPoint(site, 0, 0.4, depth / 2 + 1.6);
          const streetEdge = {
            x: point.x + (x - point.x) / offset * (road.width / 2),
            y: point.y,
            z: point.z + (z - point.z) / offset * (road.width / 2),
          };
          stairLink(streetEdge, { x: entrance[0], y: entrance[1], z: entrance[2] }, 2.8);
          doors.push({ from: [streetEdge.x, streetEdge.y, streetEdge.z], to: entrance });
          stats.compounds++;
          stats.districts[road.district] = (stats.districts[road.district] ?? 0) + 1;
          recordSite(site);
        }
      }
    }
  }

  function buildPalace() {
    const site = { ...PALACE, angle: 0 };
    foundation(site, 132, 116);
    // The route enters the south gate, crosses this open court, then exits east.
    block(site, 'paving', 5, 0.1, 28, 115, 0.2, 42);
    for (const side of [-1, 1]) {
      const x = side * 54;
      hall(site, x, -5, 16, 54, 2, { red: true, royal: true, tiered: true, height: 7.2 });
      balustrade(site, x, 0.4, 54, 22);
    }
    const central = childSite(site, -6, 5.6, -12);
    foundation(central, 64, 37);
    hall(central, 0, 0, 58, 28, 3, { red: true, royal: true, tiered: true, height: 11.2, overhang: 4 });
    hall(site, 8, -46, 82, 19, 2, { red: true, royal: true, height: 7.2, tiered: true });

    // A seven-eave tower rises on the waterfall-facing cliff terrace.
    const tower = childSite(site, -73, 6.4, -27);
    foundation(tower, 27, 27);
    for (let floor = 0; floor < 7; floor++) {
      const width = 25 - floor * 1.8;
      const tier = childSite(tower, 0, floor * 11.2, 0);
      hall(tier, 0, 0, width, width * 0.85, 1, { red: true, royal: true, height: 8.4, overhang: 3 });
    }
    block(tower, 'royalEdge', 0, 84, 0, 1.2, 10, 1.2);
    block(tower, 'royalEdge', 0, 88, 0, 3.2, 0.8, 3.2);

    // An open gate is modelled as two piers and a spanning hall, not a solid wall.
    const gate = childSite(site, 4, 0, 52);
    for (const side of [-1, 1]) {
      block(gate, 'red', side * 11, 5.6, 0, 10, 11.2, 10);
      lantern(gate, side * 5.6, 8.2, 5.6, true);
    }
    block(gate, 'timber', 0, 11, 0, 37, 1.2, 13);
    hall(childSite(gate, 0, 11.4, 0), 0, 0, 32, 11, 1, { red: true, royal: true, height: 7.2 });
    roof(gate, 0, 10.4, 0, 39, 13, true, 3.2);
    for (const side of [-1, 1]) {
      balustrade(site, side * 60, 0.4, 26, 54, false);
      for (let index = 0; index < 4; index++) {
        const x = side * (24 + index * 8);
        block(site, 'stone', x, 1.2, 36, 2.8, 2.4, 2.8);
        lantern(site, x, 3.4, 36, true);
      }
    }
    stairLink({ x: -26, y: PALACE.y + 0.2, z: -90 }, { x: -99, y: 151.6, z: -109 }, 7.2);
    const overlook = { x: -99, z: -109, y: 151.6, angle: -0.4 };
    foundation(overlook, 23, 19);
    pavilion(overlook, 17, 13, 7.8);
    stats.compounds++;
  }

  function buildSummits() {
    const summit = { ...SUMMIT, angle: 0 };
    foundation(summit, 35, 33);
    pavilion(summit, 27, 25, 11.6, true);
    const west = { x: -376, z: -208, y: rawHeight(-376, -208) + 0.6, angle: 0.2 };
    foundation(west, 23, 21);
    pavilion(west, 17, 15, 8);
    stats.compounds += 2;
  }

  function buildWater() {
    for (let z = -585; z < 594; z += 6) {
      const center = riverX(z);
      const halfWidth = riverWidth(z);
      for (let x = Math.floor((center - halfWidth) / 6) * 6; x < center + halfWidth; x += 6) {
        if (!isWater(x + 3, z + 3)) continue;
        const y = waterHeight(z + 3);
        box('water', x + 3, y - 1.1, z + 3, 6.2, 2.4, 6.2);
        if (random() < 0.12) box('foam', x + 3, y + 0.2, z + 3, 2.2 + random() * 3, 0.2, 0.4);
      }
    }
    const fallHeight = FALL.top - FALL.bottom;
    for (let column = -8; column <= 8; column++) {
      const z = FALL.z + Math.cos(column * 2.2) * 1.4;
      const height = fallHeight - Math.abs(column) * 0.7;
      box(column % 3 === 0 ? 'foam' : 'water', FALL.x + column * 1.8, FALL.top - height / 2,
        z, 2, height, 3.8 + random() * 1.2);
    }
    // Falling water protrudes from the cliff and meets a broad, gridded plunge pool.
    box('foam', FALL.x, FALL.top + 0.2, FALL.z - 2, 29.6, 0.8, 8);
    for (let index = 0; index < 45; index++) {
      const angle = random() * Math.PI * 2;
      const radius = random() * 23;
      box('foam', FALL.x + Math.cos(angle) * radius, FALL.bottom + random() * 2.6,
        FALL.z + 9 + Math.sin(angle) * radius * 0.45, 1.8 + random() * 4, 0.6, 1.4 + random() * 2);
    }
  }

  function boat(x, z, length, angle) {
    const site = { x, y: waterHeight(z) + 0.4, z, angle };
    block(site, 'timber', 0, 0, 0, 4.8, 1.2, length);
    block(site, 'red', 0, 1, 0, 5.6, 0.8, length - 2);
    block(site, 'timber', 0, 1.5, -length / 2 + 1, 3.8, 1.4, 3.2);
    block(site, 'timber', 0, 1.5, length / 2 - 1, 3.8, 1.4, 3.2);
    roof(site, 0, 3.8, -length * 0.2, 4.4, length * 0.3, false, 0.8);
    block(site, 'timber', 0, 7.2, length * 0.18, 0.4, 14.4, 0.4);
    for (let level = 0; level < 6; level++) {
      block(site, level % 2 ? 'cloth' : 'white', -1.8, 5 + level * 1.6,
        length * 0.18, 4.8 - level * 0.45, 1.6, 0.2);
    }
    lantern(site, 0, 3.4, length / 2 - 1, true);
  }

  buildWater();
  buildRoads();
  buildNeighbourhoods();
  buildPalace();
  buildSummits();

  function cityTerrainHeight(x, z) {
    let height = terrainHeight(x, z);
    const bx = Math.floor(x / 48);
    const bz = Math.floor(z / 48);
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        for (const site of siteBuckets.get(`${bx + dx},${bz + dz}`) ?? []) {
          const cosine = Math.cos(site.angle);
          const sine = Math.sin(site.angle);
          const lx = (x - site.x) * cosine - (z - site.z) * sine;
          const lz = (x - site.x) * sine + (z - site.z) * cosine;
          if (Math.abs(lx) < site.width / 2 + 4 && Math.abs(lz) < site.depth / 2 + 4.5) {
            height = Math.min(height, site.y - 0.8);
          }
        }
      }
    }
    return Math.floor(height / 2.4) * 2.4;
  }
  const nearTerrain = makeTerrain(TERRAIN_STEP, WORLD_BOUNDS, false, cityTerrainHeight);
  group.add(nearTerrain);
  group.add(makeTerrain(24, { minX: -1812, maxX: 1812, minZ: -1506, maxZ: 1218 }, true));
  for (let index = 0; index < 9; index++) {
    const z = 78 + index * 47;
    boat(riverX(z) + (index % 2 ? -9 : 7), z, 13 + index % 3 * 3, 0.12 + Math.sin(index) * 0.3);
  }

  for (let x = -630; x < 645; x += 12) {
    for (let z = -550; z < 545; z += 12) {
      if (random() > 0.31) continue;
      const tx = x + random() * 8;
      const tz = z + random() * 8;
      const y = terrainHeight(tx, tz);
      if (isWater(tx, tz, 8) || y < 19 || occupied(tx, tz, 4.4)) continue;
      if (Math.abs(tx - PALACE.x) < 103 && Math.abs(tz - PALACE.z) < 92) continue;
      if (Math.hypot(tx - SUMMIT.x, tz - SUMMIT.z) < 33) continue;
      if (nearestRoad(tx, tz, 9)) continue;
      const nearHeight = terrainHeight(tx + 4, tz + 4);
      if (Math.abs(y - nearHeight) > 12) continue;
      const groundX = WORLD_BOUNDS.minX + (Math.floor((tx - WORLD_BOUNDS.minX) / TERRAIN_STEP) + 0.5) * TERRAIN_STEP;
      const groundZ = WORLD_BOUNDS.minZ + (Math.floor((tz - WORLD_BOUNDS.minZ) / TERRAIN_STEP) + 0.5) * TERRAIN_STEP;
      tree(tx, cityTerrainHeight(groundX, groundZ), tz, 7 + random() * 9, random() < 0.17);
    }
  }

  const meshes = voxels.flush(group);
  stats.voxelBlocks = voxels.count;
  stats.terrainTriangles = nearTerrain.geometry.index.count / 3;
  stats.siteBounds = sites.length ? {
    minX: Math.min(...sites.map(site => site.x)), maxX: Math.max(...sites.map(site => site.x)),
    minZ: Math.min(...sites.map(site => site.z)), maxZ: Math.max(...sites.map(site => site.z)),
    minY: Math.min(...sites.map(site => site.y)), maxY: Math.max(...sites.map(site => site.y)),
  } : null;
  return { group, palette, stats, sites, doors, meshes, heightAt: cityTerrainHeight };
}

export function createAtmosphere() {
  const group = new THREE.Group();
  const random = randomGenerator(7284);
  const transform = new THREE.Object3D();
  const cloudRecords = [];
  // The middle of the initial composition and the palace stay open; thin mist
  // occupies the valleys and the far mountain shoulders.
  const cloudCenters = [
    [-580, 160, -120], [-330, 120, 255], [580, 145, 233], [70, 220, -352],
    [-610, 265, -438], [560, 325, -422], [-85, 405, -602], [220, 190, 252],
    [-775, 315, -645], [810, 215, -120], [-910, 205, 170], [370, 400, -644],
  ];
  cloudCenters.forEach(([cx, cy, cz], cloud) => {
    for (let index = 0; index < 12; index++) {
      cloudRecords.push({
        x: cx + (random() - 0.5) * 110, y: cy + random() * 13, z: cz + (random() - 0.5) * 42,
        width: 23 + random() * 34, height: 7 + random() * 11, depth: 17 + random() * 21,
        phase: cloud * 1.7,
      });
    }
  });
  const cloudMaterial = new THREE.MeshLambertMaterial({ color: '#e0e6d6', transparent: true, opacity: 0.16, depthWrite: false });
  const clouds = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), cloudMaterial, cloudRecords.length);
  clouds.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  clouds.frustumCulled = false;
  group.add(clouds);

  const sprayRecords = Array.from({ length: 225 }, () => ({
    x: FALL.x + (random() - 0.5) * 31, phase: random(), speed: 0.09 + random() * 0.06,
    z: FALL.z + 2 + random() * 4, size: 0.5 + random() * 1.2,
  }));
  const sprayMaterial = new THREE.MeshBasicMaterial({ color: '#c4ead5', transparent: true, opacity: 0.68 });
  const spray = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), sprayMaterial, sprayRecords.length);
  spray.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  spray.frustumCulled = false;
  group.add(spray);

  function update(elapsed, daylight) {
    cloudRecords.forEach((record, index) => {
      transform.position.set(record.x + Math.sin(elapsed * 0.008 + record.phase) * 32, record.y, record.z + Math.cos(elapsed * 0.005 + record.phase) * 10);
      transform.scale.set(record.width, record.height, record.depth);
      transform.updateMatrix();
      clouds.setMatrixAt(index, transform.matrix);
    });
    clouds.instanceMatrix.needsUpdate = true;
    cloudMaterial.opacity = mix(0.065, 0.16, daylight);
    sprayRecords.forEach((record, index) => {
      const progress = (record.phase + elapsed * record.speed) % 1;
      transform.position.set(record.x + Math.sin(progress * 16 + index) * 0.8,
        mix(FALL.top, FALL.bottom + 1, progress), record.z + progress * 2);
      transform.scale.set(record.size, record.size * (2 + progress * 3), record.size);
      transform.updateMatrix();
      spray.setMatrixAt(index, transform.matrix);
    });
    spray.instanceMatrix.needsUpdate = true;
    sprayMaterial.opacity = mix(0.2, 0.7, daylight);
  }
  update(0, 1);
  return { group, update, cloudMaterial };
}
