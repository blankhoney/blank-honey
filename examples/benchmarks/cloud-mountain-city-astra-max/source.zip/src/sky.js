import * as THREE from 'three';
import { mix, randomGenerator, timeState } from './world.js';

export function createSky(scene) {
  const uniforms = {
    zenith: { value: new THREE.Color() },
    horizon: { value: new THREE.Color() },
    ground: { value: new THREE.Color() },
    sunDirection: { value: new THREE.Vector3() },
    sunset: { value: 0 },
  };
  const sky = new THREE.Mesh(new THREE.SphereGeometry(3600, 20, 14), new THREE.ShaderMaterial({
    uniforms,
    side: THREE.BackSide,
    depthWrite: false,
    vertexShader: `
      varying vec3 direction;
      void main() {
        direction = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      varying vec3 direction;
      uniform vec3 zenith;
      uniform vec3 horizon;
      uniform vec3 ground;
      uniform vec3 sunDirection;
      uniform float sunset;
      void main() {
        vec3 ray = normalize(direction);
        vec3 color = mix(horizon, zenith, smoothstep(-0.03, 0.77, ray.y));
        color = mix(color, ground, 1.0 - smoothstep(-0.5, 0.01, ray.y));
        float glow = pow(max(dot(ray, sunDirection), 0.0), 7.0) * sunset;
        color += vec3(0.28, 0.075, 0.015) * glow;
        gl_FragColor = vec4(color, 1.0);
      }
    `,
  }));
  sky.renderOrder = -10;
  scene.add(sky);

  const random = randomGenerator(9234);
  const positions = [];
  for (let index = 0; index < 1150; index++) {
    const azimuth = random() * Math.PI * 2;
    const altitude = Math.asin(random() * 0.97 + 0.025);
    positions.push(Math.cos(azimuth) * Math.cos(altitude) * 2800,
      Math.sin(altitude) * 2800, Math.sin(azimuth) * Math.cos(altitude) * 2800);
  }
  const starGeometry = new THREE.BufferGeometry();
  starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  const starMaterial = new THREE.PointsMaterial({ color: '#d7e7dc', size: 1.35, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false, fog: false });
  const stars = new THREE.Points(starGeometry, starMaterial);
  stars.renderOrder = -9;
  scene.add(stars);

  function celestialBody(crescent) {
    const group = new THREE.Group();
    const material = new THREE.MeshBasicMaterial({ color: crescent ? '#c5dfdd' : '#ffe2a0', fog: false });
    const geometry = new THREE.BoxGeometry(13, 13, 4);
    const pixels = [];
    for (let x = -5; x <= 5; x++) {
      for (let y = -5; y <= 5; y++) {
        if (x * x + y * y > 28) continue;
        if (crescent && (x + 2.5) ** 2 + (y - 1.1) ** 2 < 24) continue;
        pixels.push([x * 13, y * 13]);
      }
    }
    const mesh = new THREE.InstancedMesh(geometry, material, pixels.length);
    const matrix = new THREE.Matrix4();
    pixels.forEach(([x, y], index) => mesh.setMatrixAt(index, matrix.makeTranslation(x, y, 0)));
    mesh.computeBoundingSphere();
    group.add(mesh);
    group.renderOrder = -8;
    scene.add(group);
    return { group, material };
  }
  const sun = celestialBody(false);
  const moon = celestialBody(true);
  const sunlight = new THREE.DirectionalLight('#fff0c7', 2);
  sunlight.castShadow = true;
  sunlight.shadow.mapSize.set(2048, 2048);
  sunlight.shadow.camera.left = -790;
  sunlight.shadow.camera.right = 790;
  sunlight.shadow.camera.top = 690;
  sunlight.shadow.camera.bottom = -690;
  sunlight.shadow.camera.near = 50;
  sunlight.shadow.camera.far = 2400;
  sunlight.shadow.bias = -0.00012;
  sunlight.shadow.normalBias = 0.7;
  sunlight.target.position.set(0, 165, -60);
  scene.add(sunlight, sunlight.target);
  const moonlight = new THREE.DirectionalLight('#7faace', 0.25);
  moonlight.target.position.copy(sunlight.target.position);
  scene.add(moonlight, moonlight.target);
  const hemisphere = new THREE.HemisphereLight('#dce8dd', '#777860', 1.2);
  scene.add(hemisphere, new THREE.AmbientLight('#96b3bd', 0.15));
  scene.fog = new THREE.FogExp2('#cbd0b9', 0.00055);

  const topNight = new THREE.Color('#0b1a2d');
  const topDay = new THREE.Color('#83aeaf');
  const topDusk = new THREE.Color('#637f91');
  const horizonNight = new THREE.Color('#263c4a');
  const horizonDay = new THREE.Color('#e8dfbd');
  const horizonDusk = new THREE.Color('#eab48d');
  const sunDirection = new THREE.Vector3();
  const moonDirection = new THREE.Vector3();

  function update(hours, camera) {
    const state = timeState(hours);
    sunDirection.set(Math.cos(state.angle) * 0.91, Math.sin(state.angle), -Math.cos(state.angle) * 0.28).normalize();
    moonDirection.copy(sunDirection).multiplyScalar(-1);
    uniforms.zenith.value.copy(topNight).lerp(topDay, state.day).lerp(topDusk, state.twilight * 0.48);
    uniforms.horizon.value.copy(horizonNight).lerp(horizonDay, state.day).lerp(horizonDusk, state.twilight * 0.72);
    uniforms.ground.value.copy(uniforms.horizon.value).multiplyScalar(0.86);
    uniforms.sunDirection.value.copy(sunDirection);
    uniforms.sunset.value = state.twilight;
    sky.position.copy(camera.position);
    stars.position.copy(camera.position);
    starMaterial.opacity = (1 - state.day) * 0.8;
    sun.group.position.copy(camera.position).addScaledVector(sunDirection, 2600);
    sun.group.quaternion.copy(camera.quaternion);
    sun.group.visible = state.altitude > -0.09;
    sun.material.color.set('#ffe2a0').lerp(new THREE.Color('#ed986b'), state.twilight).multiplyScalar(2.2);
    moon.group.position.copy(camera.position).addScaledVector(moonDirection, 2580);
    moon.group.quaternion.copy(camera.quaternion);
    moon.group.visible = state.altitude < 0.08;
    moon.material.color.set('#b8d2d4').multiplyScalar(1.4);
    sunlight.position.copy(sunlight.target.position).addScaledVector(sunDirection, 1050);
    sunlight.intensity = Math.max(0, state.altitude) * 2.65 + state.day * 0.3;
    sunlight.color.set('#fff1c8').lerp(new THREE.Color('#ffa16d'), state.twilight * 0.56);
    moonlight.position.copy(moonlight.target.position).addScaledVector(moonDirection, 900);
    moonlight.intensity = state.moon * 0.75;
    hemisphere.intensity = mix(0.59, 1.4, state.day);
    hemisphere.color.set('#809bac').lerp(new THREE.Color('#d9e4da'), state.day);
    hemisphere.groundColor.set('#374653').lerp(new THREE.Color('#848069'), state.day);
    scene.fog.color.copy(uniforms.horizon.value).lerp(uniforms.zenith.value, 0.3);
    scene.fog.density = mix(0.00052, 0.00043, state.day);
    return state;
  }
  return { update, sunlight };
}
