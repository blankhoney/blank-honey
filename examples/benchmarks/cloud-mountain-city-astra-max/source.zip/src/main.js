import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { buildWorld, createAtmosphere } from './scene.js';
import { createSky } from './sky.js';
import { clamp, mix, mountains, riverX, roadPosition, roads, stations, terrainHeight, tourRoad } from './world.js';
import './style.css';

const $ = (id) => document.getElementById(id);
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const overview = { position: new THREE.Vector3(840, 650, 910), target: new THREE.Vector3(-8, 150, -75) };
const state = {
  hours: 16.33,
  timeRunning: !reducedMotion,
  daySeconds: 240,
  mode: 'overview',
  distance: 0,
  walking: false,
  speed: 8,
  yaw: 0,
  pitch: 0,
  quality: window.innerWidth < 700 ? 'fast' : 'balanced',
  hidden: false,
};

function toast(message) {
  $('toast').textContent = message;
  $('toast').classList.add('visible');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('toast').classList.remove('visible'), 3400);
}

function formatTime(hours) {
  const minutes = Math.floor((((hours % 24) + 24) % 24) * 60);
  return `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
}

function period(hours) {
  const names = ['子时 · 夜阑', '丑时 · 星河', '寅时 · 将晓', '卯时 · 晨光', '辰时 · 山青', '巳时 · 日升',
    '午时 · 晴昼', '未时 · 云舒', '申时 · 斜阳', '酉时 · 向晚', '戌时 · 灯起', '亥时 · 月明'];
  return names[Math.floor(((hours + 1) % 24) / 2)];
}

function updateTimeUI() {
  const time = formatTime(state.hours);
  $('clock').textContent = time;
  $('period').textContent = period(state.hours);
  $('time-slider').value = String(state.hours);
  $('time-slider').setAttribute('aria-valuetext', time);
  $('time-play').textContent = state.timeRunning ? 'Ⅱ' : '▶';
  $('time-play').setAttribute('aria-label', state.timeRunning ? '暂停昼夜循环' : '继续昼夜循环');
  $('time-play').setAttribute('aria-pressed', String(state.timeRunning));
  $('time-speed').textContent = `一日 / ${state.daySeconds / 60}分`;
}

function setTime(hours, running = false) {
  state.hours = ((hours % 24) + 24) % 24;
  state.timeRunning = running;
  updateTimeUI();
}

function buildMap() {
  const mapX = (x) => (x + 610) / 1220 * 240;
  const mapZ = (z) => (z + 545) / 1090 * 192;
  let markup = '';
  for (const [x, z, , rx, rz] of mountains.slice(0, 10)) {
    for (let ring = 1; ring <= 3; ring++) {
      markup += `<ellipse cx="${mapX(x)}" cy="${mapZ(z)}" rx="${rx / 1220 * 240 * ring / 3}" ry="${rz / 1090 * 192 * ring / 3}" fill="none" stroke="#879777" stroke-width="0.6" opacity="0.28"/>`;
    }
  }
  const river = [];
  for (let z = -530; z < 535; z += 15) river.push(`${mapX(riverX(z))},${mapZ(z)}`);
  markup += `<polyline points="${river.join(' ')}" fill="none" stroke="#77a7a0" stroke-width="5" opacity="0.6"/>`;
  for (const road of roads) {
    const points = road.samples.filter((_, index) => index % 5 === 0).map(point => `${mapX(point.x)},${mapZ(point.z)}`);
    markup += `<polyline points="${points.join(' ')}" fill="none" stroke="${road.id === 'pilgrim' ? '#9d723f' : '#7f8970'}" stroke-width="${road.id === 'pilgrim' ? 1.65 : 0.65}" opacity="${road.id === 'pilgrim' ? 1 : 0.48}"/>`;
  }
  stations.forEach((station, index) => {
    const x = mapX(station.x);
    const z = mapZ(station.z);
    markup += `<circle cx="${x}" cy="${z}" r="3.6" fill="#f1e6c6" stroke="#967447" stroke-width="0.8"/><text x="${x}" y="${z + 1.6}" text-anchor="middle" font-size="5.3" fill="#705638">${index + 1}</text>`;
  });
  markup += '<circle id="map-marker-halo" cx="0" cy="0" r="6" fill="#a4763b" opacity="0.2"/><circle id="map-marker" cx="0" cy="0" r="2.7" fill="#9c6536" stroke="#f5edce" stroke-width="1"/>';
  $('map').innerHTML = markup;
  return (x, z) => {
    for (const id of ['map-marker', 'map-marker-halo']) {
      $(id).setAttribute('cx', String(mapX(x)));
      $(id).setAttribute('cy', String(mapZ(z)));
    }
  };
}

async function boot() {
  // Give the browser a paint opportunity before synchronous, deterministic mesh generation.
  await new Promise(resolve => requestAnimationFrame(resolve));
  const canvas = $('scene');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.06;
  renderer.shadowMap.enabled = state.quality !== 'fast';
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.shadowMap.autoUpdate = false;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(43, innerWidth / innerHeight, 0.35, 6500);
  camera.position.copy(overview.position);
  const controls = new OrbitControls(camera, canvas);
  controls.target.copy(overview.target);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.minDistance = 8;
  controls.maxDistance = 2350;
  controls.minPolarAngle = 0.075;
  controls.maxPolarAngle = Math.PI / 2 - 0.035;
  controls.screenSpacePanning = true;
  controls.panSpeed = 0.7;
  controls.zoomSpeed = 0.75;
  controls.update();

  const world = buildWorld();
  scene.add(world.group);
  const atmosphere = createAtmosphere();
  scene.add(atmosphere.group);
  const sky = createSky(scene);
  const composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  const bloom = new UnrealBloomPass(new THREE.Vector2(640, 360), 0.28, 0.38, 1.1);
  composer.addPass(bloom);
  composer.addPass(new OutputPass());
  const moveMapMarker = buildMap();
  moveMapMarker(stations[0].x, stations[0].z);

  const keys = new Set();
  const windowDay = new THREE.Color('#967c4d');
  const windowNight = new THREE.Color('#dd9d50');
  let transition = null;
  let rememberedView = { position: overview.position.clone(), target: overview.target.clone() };
  let renderEnabled = true;
  let shadowTime = -999;
  let previousTime = performance.now();
  let elapsed = 0;
  let lastUI = 0;
  let lastStation = -1;

  function resize() {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    const cap = { fast: 1, balanced: 1.25, detailed: 1.75 }[state.quality];
    renderer.setPixelRatio(Math.min(devicePixelRatio, cap));
    renderer.setSize(innerWidth, innerHeight);
    composer.setPixelRatio(renderer.getPixelRatio());
    composer.setSize(innerWidth, innerHeight);
  }

  function applyQuality() {
    const names = { fast: '流畅画质', balanced: '均衡画质', detailed: '细致画质' };
    $('quality').textContent = names[state.quality];
    renderer.shadowMap.enabled = state.quality !== 'fast';
    const size = state.quality === 'detailed' ? 2048 : 1024;
    if (sky.sunlight.shadow.mapSize.x !== size) {
      sky.sunlight.shadow.mapSize.set(size, size);
      sky.sunlight.shadow.map?.dispose();
      sky.sunlight.shadow.map = null;
    }
    renderer.shadowMap.needsUpdate = true;
    bloom.strength = state.quality === 'detailed' ? 0.3 : 0.24;
    resize();
  }

  function highlightStation(index) {
    document.querySelectorAll('.station-button').forEach((button, item) => {
      button.classList.toggle('active', item === index);
      button.setAttribute('aria-pressed', String(item === index));
    });
    lastStation = index;
  }

  function updateWalkUI() {
    $('walk-play').textContent = state.walking ? 'Ⅱ' : '▶';
    $('walk-play').setAttribute('aria-label', state.walking ? '暂停行走' : '开始行走');
    $('walk-speed').textContent = `${state.speed} m/s`;
    $('journey-progress').value = String(state.distance);
    $('journey-distance').textContent = `${Math.round(state.distance).toLocaleString()} / ${Math.round(tourRoad.length).toLocaleString()} m`;
    let index = 0;
    stations.forEach((station, candidate) => {
      if (station.distance <= state.distance + 8) index = candidate;
    });
    $('journey-location').textContent = stations[index].name;
    if (state.mode === 'walk' && lastStation !== index) {
      highlightStation(index);
      $('view-kicker').textContent = stations[index].subtitle;
      $('view-title').textContent = index === 4 ? '亭前万山，城中万家。' : `正在行经 · ${stations[index].name}`;
    }
  }

  function setMode(mode) {
    if (mode === state.mode) return;
    state.mode = mode;
    transition = null;
    const walking = mode === 'walk';
    document.body.classList.toggle('walking', walking);
    $('journey-strip').hidden = !walking;
    $('overview-mode').classList.toggle('active', !walking);
    $('walk-mode').classList.toggle('active', walking);
    $('overview-mode').setAttribute('aria-pressed', String(!walking));
    $('walk-mode').setAttribute('aria-pressed', String(walking));
    controls.enabled = !walking;
    camera.fov = walking ? 65 : 43;
    camera.updateProjectionMatrix();
    if (walking) {
      rememberedView = { position: camera.position.clone(), target: controls.target.clone() };
      state.walking = !reducedMotion;
      state.yaw = 0;
      state.pitch = 0;
      if (state.distance >= tourRoad.length - 1) state.distance = 0;
      $('control-hint').textContent = '拖动环顾 · W / S 或滚轮前后移动 · 空格暂停';
      lastStation = -1;
      toast('沿登云道出发。拖动可环顾，进度条可前往沿途任意位置。');
    } else {
      state.walking = false;
      camera.position.copy(rememberedView.position);
      controls.target.copy(rememberedView.target);
      controls.update();
      $('control-hint').textContent = '拖动环顾 · 滚轮靠近 · 右键平移';
    }
    updateWalkUI();
  }

  function focusView(position, target) {
    transition = {
      elapsed: 0, duration: reducedMotion ? 0.01 : 1.6,
      from: camera.position.clone(), fromTarget: controls.target.clone(),
      to: new THREE.Vector3(...position), target: new THREE.Vector3(...target),
    };
  }

  function selectStation(index) {
    const station = stations[index];
    if (state.mode === 'walk') {
      state.distance = station.distance;
      state.walking = false;
      state.yaw = 0;
      state.pitch = 0;
      updateWalkUI();
    } else {
      focusView(station.camera, station.target);
      highlightStation(index);
      moveMapMarker(station.x, station.z);
      $('view-kicker').textContent = station.subtitle;
      $('view-title').textContent = station.name;
    }
  }

  function home() {
    if (state.mode === 'walk') setMode('overview');
    focusView(overview.position.toArray(), overview.target.toArray());
    highlightStation(-1);
    $('view-kicker').textContent = '山水之间 · 层城万叠';
    $('view-title').textContent = '群峰之上，城如长卷。';
  }

  function toggleHidden() {
    state.hidden = !state.hidden;
    $('interface').classList.toggle('hidden', state.hidden);
    $('show-ui').hidden = !state.hidden;
  }

  stations.forEach((station, index) => {
    const button = document.createElement('button');
    button.className = 'station-button';
    button.innerHTML = `<span class="station-number">0${index + 1}</span><span>${station.name}</span><span class="station-arrow">↗</span>`;
    button.setAttribute('aria-pressed', 'false');
    button.setAttribute('title', `${station.subtitle}（${index + 1}）`);
    button.addEventListener('click', () => selectStation(index));
    $('station-buttons').append(button);
  });
  $('journey-progress').max = String(tourRoad.length);
  $('journey-progress').addEventListener('input', event => {
    state.distance = Number(event.target.value);
    state.walking = false;
    state.yaw = 0;
    updateWalkUI();
  });
  $('time-slider').addEventListener('input', event => setTime(Number(event.target.value)));
  $('time-play').addEventListener('click', () => {
    state.timeRunning = !state.timeRunning;
    updateTimeUI();
  });
  $('time-speed').addEventListener('click', () => {
    const durations = [240, 120, 720];
    state.daySeconds = durations[(durations.indexOf(state.daySeconds) + 1) % durations.length];
    updateTimeUI();
    toast(`一个昼夜现在持续 ${state.daySeconds / 60} 分钟`);
  });
  document.querySelectorAll('[data-time]').forEach(button => {
    button.addEventListener('click', () => setTime(Number(button.dataset.time)));
  });
  $('walk-play').addEventListener('click', () => {
    if (state.distance >= tourRoad.length - 1) state.distance = 0;
    state.walking = !state.walking;
    updateWalkUI();
  });
  $('walk-speed').addEventListener('click', () => {
    const speeds = [8, 18, 3];
    state.speed = speeds[(speeds.indexOf(state.speed) + 1) % speeds.length];
    updateWalkUI();
  });
  $('overview-mode').addEventListener('click', () => setMode('overview'));
  $('walk-mode').addEventListener('click', () => setMode('walk'));
  $('home').addEventListener('click', home);
  $('hide-ui').addEventListener('click', toggleHidden);
  $('show-ui').addEventListener('click', toggleHidden);
  $('help-open').addEventListener('click', () => $('help-dialog').showModal());
  $('help-close').addEventListener('click', () => $('help-dialog').close());
  $('help-dialog').addEventListener('click', event => {
    if (event.target === $('help-dialog')) {
      const rectangle = $('help-dialog').getBoundingClientRect();
      if (event.clientX < rectangle.left || event.clientX > rectangle.right || event.clientY < rectangle.top || event.clientY > rectangle.bottom) $('help-dialog').close();
    }
  });
  $('map-toggle').addEventListener('click', () => {
    const collapsed = $('map-card').classList.toggle('collapsed');
    $('map-toggle').setAttribute('aria-expanded', String(!collapsed));
    document.querySelector('.map-note i').textContent = collapsed ? '+' : '−';
  });
  $('quality').addEventListener('click', () => {
    const options = ['balanced', 'detailed', 'fast'];
    state.quality = options[(options.indexOf(state.quality) + 1) % options.length];
    applyQuality();
    toast($('quality').textContent);
  });

  let pointer = null;
  canvas.addEventListener('pointerdown', event => {
    if (state.mode !== 'walk') return;
    pointer = { id: event.pointerId, x: event.clientX, y: event.clientY };
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointermove', event => {
    if (state.mode !== 'walk' || !pointer || pointer.id !== event.pointerId) return;
    state.yaw -= (event.clientX - pointer.x) * 0.004;
    state.pitch = clamp(state.pitch - (event.clientY - pointer.y) * 0.003, -0.9, 0.9);
    pointer.x = event.clientX;
    pointer.y = event.clientY;
  });
  const releasePointer = (event) => {
    if (pointer?.id === event.pointerId) pointer = null;
  };
  canvas.addEventListener('pointerup', releasePointer);
  canvas.addEventListener('pointercancel', releasePointer);
  canvas.addEventListener('wheel', event => {
    if (state.mode !== 'walk') return;
    event.preventDefault();
    state.distance = clamp(state.distance - event.deltaY * 0.045, 0, tourRoad.length);
    state.walking = false;
    updateWalkUI();
  }, { passive: false });
  controls.addEventListener('start', () => { transition = null; });
  window.addEventListener('keydown', event => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || $('help-dialog').open) return;
    if (document.activeElement?.tagName === 'BUTTON' && ['Space', 'Enter'].includes(event.code)) return;
    keys.add(event.code);
    if (event.repeat) return;
    if (['Space', 'ArrowUp', 'ArrowDown'].includes(event.code)) event.preventDefault();
    if (event.code === 'Space') {
      if (state.mode === 'walk') {
        state.walking = !state.walking;
        updateWalkUI();
      } else {
        state.timeRunning = !state.timeRunning;
        updateTimeUI();
      }
    }
    if (event.code === 'KeyT') {
      state.timeRunning = !state.timeRunning;
      updateTimeUI();
    }
    if (event.code === 'KeyH') toggleHidden();
    if (event.code === 'Escape') setMode('overview');
    if (event.code === 'Home') home();
    if (/^Digit[1-5]$/.test(event.code)) selectStation(Number(event.code.slice(-1)) - 1);
  });
  window.addEventListener('keyup', event => keys.delete(event.code));
  window.addEventListener('blur', () => keys.clear());
  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', () => { previousTime = performance.now(); });
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    renderEnabled = false;
    toast('图形上下文暂时丢失，恢复后会重新载入场景。');
  });
  canvas.addEventListener('webglcontextrestored', () => location.reload());

  function tick(now) {
    requestAnimationFrame(tick);
    if (!renderEnabled || document.hidden) return;
    const wallDelta = Math.max(0, (now - previousTime) / 1000);
    const delta = Math.min(0.05, wallDelta);
    previousTime = now;
    elapsed += delta;
    if (state.timeRunning) state.hours = (state.hours + wallDelta * 24 / state.daySeconds) % 24;

    if (state.mode === 'walk') {
      // ponytail: an authored ground route supplies the requested walking tour;
      // unrestricted character movement would need a navigable surface/collider.
      let movement = state.walking ? state.speed : 0;
      if (keys.has('KeyW') || keys.has('ArrowUp')) movement = keys.has('ShiftLeft') ? 20 : 8;
      if (keys.has('KeyS') || keys.has('ArrowDown')) movement = keys.has('ShiftLeft') ? -20 : -8;
      state.distance = clamp(state.distance + movement * delta, 0, tourRoad.length);
      if (state.distance >= tourRoad.length && state.walking) {
        state.walking = false;
        toast('已抵达望岳亭。拖动环顾群山，或切回全景继续探索。');
      }
      const point = roadPosition(state.distance);
      const ahead = roadPosition(Math.min(state.distance + 6, tourRoad.length));
      const behind = roadPosition(Math.max(0, state.distance - 2));
      const direction = ahead.sub(behind).normalize();
      camera.position.set(point.x, point.y + 1.9, point.z);
      camera.rotation.set(Math.asin(clamp(direction.y, -1, 1)) * 0.33 + state.pitch,
        Math.atan2(-direction.x, -direction.z) + state.yaw, 0, 'YXZ');
      moveMapMarker(point.x, point.z);
    } else if (transition) {
      transition.elapsed += delta;
      const t = clamp(transition.elapsed / transition.duration, 0, 1);
      const eased = t * t * (3 - 2 * t);
      camera.position.lerpVectors(transition.from, transition.to, eased);
      controls.target.lerpVectors(transition.fromTarget, transition.target, eased);
      controls.update();
      if (t === 1) transition = null;
    } else {
      controls.update();
      const minimum = terrainHeight(camera.position.x, camera.position.z) + 2.5;
      if (camera.position.y < minimum) camera.position.y = minimum;
    }

    const daylight = sky.update(state.hours, camera);
    world.palette.lamp.emissiveIntensity = mix(0.02, 3.9, daylight.lamps);
    world.palette.lamp.color.copy(windowDay).lerp(windowNight, daylight.lamps);
    atmosphere.update(reducedMotion ? 0 : elapsed, daylight.day);
    renderer.toneMappingExposure = mix(1.15, 1.06, daylight.day);
    document.body.classList.toggle('night', daylight.day < 0.45);
    if (Math.abs(state.hours - shadowTime) > 0.055) {
      renderer.shadowMap.needsUpdate = true;
      shadowTime = state.hours;
    }
    if (state.quality === 'fast') renderer.render(scene, camera);
    else composer.render();

    if (now - lastUI > 120) {
      updateTimeUI();
      if (state.mode === 'walk') updateWalkUI();
      lastUI = now;
    }
  }

  applyQuality();
  updateTimeUI();
  updateWalkUI();
  sky.update(state.hours, camera);
  renderer.shadowMap.needsUpdate = true;
  // This diagnostic is local only and makes the generated model inspectable.
  window.cloudCity = { stats: world.stats, getState: () => ({ ...state }), setTime };
  requestAnimationFrame(tick);
  $('loading').classList.add('done');
  setTimeout(() => { $('loading').hidden = true; }, 850);
}

boot().catch(error => {
  console.error(error);
  $('interface').classList.add('hidden');
  $('loading-note').textContent = '无法建立三维场景。请使用支持 WebGL 2 的现代浏览器，并启用硬件加速。';
  $('loading-note').style.maxWidth = '320px';
  $('loading-note').style.lineHeight = '1.8';
  $('loading-note').style.textAlign = 'center';
  document.querySelector('.loading-line').hidden = true;
});
