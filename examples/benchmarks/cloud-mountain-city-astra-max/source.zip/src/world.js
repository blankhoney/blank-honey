import { CatmullRomCurve3, Vector3 } from 'three';

// All distances are metres. One modelling voxel is 0.2 m; larger blocks are
// integer multiples of that unit, including the 30-voxel terrain columns.
export const VOXEL = 0.2;
export const TERRAIN_STEP = 6;
export const WORLD_BOUNDS = { minX: -714, maxX: 714, minZ: -594, maxZ: 594 };
export const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
export const mix = (a, b, amount) => a + (b - a) * amount;
export const snap = (value, step = VOXEL) => Math.round(value / step) * step;
export const smooth = (low, high, value) => {
  const t = clamp((value - low) / (high - low), 0, 1);
  return t * t * (3 - 2 * t);
};

export function randomGenerator(seed) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let value = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    value ^= value + Math.imul(value ^ (value >>> 7), 61 | value);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

function terrainNoise(x, z) {
  return Math.sin(x * 0.024 + Math.cos(z * 0.017)) * 4.5
    + Math.cos(z * 0.035 - x * 0.013) * 3
    + Math.sin((x + z) * 0.082) * 1.4;
}

export const mountains = [
  [-390, 135, 244, 216, 176],
  [395, 155, 233, 211, 215],
  [-382, -214, 369, 202, 232],
  [340, -268, 431, 214, 228],
  [-72, -449, 455, 233, 188],
  [-258, -429, 332, 175, 174],
  [464, -510, 402, 203, 200],
  [15, -132, 186, 177, 226],
  [-492, 415, 161, 211, 169],
  [560, 414, 160, 242, 183],
  [-698, -317, 389, 268, 284],
  [737, -230, 402, 240, 267],
  [-460, -803, 588, 288, 275],
  [54, -849, 655, 290, 241],
  [614, -846, 583, 300, 305],
  [-1110, -485, 495, 343, 321],
  [1160, -463, 570, 330, 340],
  [-1050, 170, 301, 307, 365],
  [1030, 233, 338, 356, 294],
];

export function riverX(z) {
  return -103 + Math.sin((z + 60) / 190) * 62 + Math.sin((z + 20) / 85) * 24;
}

export function riverWidth(z) {
  if (z < -162) return 14 + 3 * Math.cos(z / 80);
  return 21 + 26 * Math.exp(-(((z + 107) / 49) ** 2))
    + 7 * Math.exp(-(((z - 338) / 130) ** 2));
}

export function waterHeight(z) {
  return z < -162 ? snap(190 + (-162 - z) * 0.12) : 14;
}

export function isWater(x, z, margin = 0) {
  return Math.abs(x - riverX(z)) < riverWidth(z) + margin;
}

export function rawHeight(x, z) {
  let height = 4;
  for (const [mx, mz, amplitude, rx, rz] of mountains) {
    const distance = ((x - mx) / rx) ** 2 + ((z - mz) / rz) ** 2;
    height = Math.max(height, amplitude * Math.exp(-1.55 * distance));
  }
  height = Math.max(18, height + terrainNoise(x, z) + 7);

  // The elevated river shelf has an actual 176 m cliff at its southern lip.
  const riverDistance = Math.abs(x - riverX(z));
  if (z < -162) {
    const shelf = (waterHeight(z) + 6) * Math.exp(-((riverDistance / 115) ** 4));
    height = Math.max(height, shelf);
  }
  if (riverDistance < riverWidth(z) + 85) {
    const gorge = waterHeight(z) - 3 + Math.max(0, riverDistance - riverWidth(z)) * 2.6;
    height = Math.min(height, gorge);
  }
  return Math.max(0, snap(height, 2.4));
}

export const PALACE = { x: 26, z: -125, y: 178.4, name: '听瀑天阙' };
export const SUMMIT = { x: 341, z: -274, y: snap(rawHeight(341, -274)) + 1.2, name: '望岳亭' };
export const FALL = { x: riverX(-162), z: -161.4, top: 190, bottom: 14 };

// Every branch touches an existing road anchor. Deliberate elevated anchors
// carry the stone bridges across the ravine instead of dipping into the river.
const roadDefinitions = [
  {
    id: 'pilgrim', name: '登云道', district: 'river', width: 7.2,
    points: [[80, 365], [20, 295], [8, 225], [8, 150], [25, 85], [12, 26],
      [-22, -20], [10, -52, 164], [24, -64, PALACE.y], [30, -73, PALACE.y], [30, -98, PALACE.y],
      [98, -93, PALACE.y], [110, -148, 183], [130, -195, 190], [207, -197, 196],
      [247, -144], [327, -139], [386, -182], [399, -226], [375, -261],
      [362, -267, SUMMIT.y], [SUMMIT.x, SUMMIT.z, SUMMIT.y]],
  },
  {
    id: 'west-bridge', name: '九孔长桥', district: 'west', width: 8.4,
    points: [[12, 26], [-65, 42, 87], [-143, 38, 89], [-227, 33], [-305, 52],
      [-385, 118], [-445, 120]],
  },
  {
    id: 'west-ridge', name: '栖霞长街', district: 'west', width: 6.4,
    points: [[-445, 120], [-479, 44], [-446, -39], [-381, -89], [-325, -143],
      [-345, -185], [-361, -202, rawHeight(-376, -208) + 0.6], [-376, -208]],
  },
  {
    id: 'west-market', name: '杏花里', district: 'market', width: 5.6,
    points: [[-305, 52], [-286, 116], [-322, 175], [-402, 200], [-472, 181], [-445, 120]],
  },
  {
    id: 'west-upper', name: '松风书院', district: 'scholar', width: 5.6,
    points: [[-446, -39], [-479, -125], [-459, -218], [-401, -278], [-327, -266], [-325, -143]],
  },
  {
    id: 'west-gardens', name: '青麓坊', district: 'west', width: 5.2,
    points: [[-381, -89], [-274, -94], [-256, -30], [-305, 52]],
  },
  {
    id: 'east-low', name: '东市', district: 'market', width: 7.2,
    points: [[25, 85], [117, 130], [212, 163], [310, 204], [407, 185], [470, 136]],
  },
  {
    id: 'east-arc', name: '朝云坊', district: 'east', width: 6.4,
    points: [[327, -139], [406, -104], [483, -47], [494, 32], [470, 136]],
  },
  {
    id: 'east-gardens', name: '锦绣长坡', district: 'east', width: 5.6,
    points: [[117, 130], [153, 47], [232, 3], [320, 20], [398, 81], [407, 185]],
  },
  {
    id: 'east-upper', name: '凌霄台', district: 'scholar', width: 5.6,
    points: [[247, -144], [220, -70], [298, -58], [398, 81]],
  },
  {
    id: 'east-river', name: '石渡', district: 'river', width: 5.6,
    points: [[80, 365], [155, 337], [226, 270], [310, 204]],
  },
  {
    id: 'lower-quay', name: '水云埠', district: 'quay', width: 6.4,
    points: [[80, 365], [49, 426], [-12, 450], [-10, 393], [-15, 319], [3, 253], [8, 225]],
  },
  {
    id: 'water-crossing', name: '烟波桥', district: 'quay', width: 7.2,
    points: [[-15, 319], [-121, 305, 23], [-175, 299, 23], [-220, 307], [-309, 350],
      [-404, 315], [-402, 200]],
  },
  {
    id: 'west-water', name: '澄溪道', district: 'quay', width: 5.6,
    points: [[-220, 307], [-230, 232], [-202, 154], [-227, 33]],
  },
  {
    id: 'north-pass', name: '上清津', district: 'temple', width: 7.2,
    points: [[110, -148, 183], [47, -220, 198], [-19, -254, 215], [-111, -280, 224],
      [-231, -282], [-327, -266]],
  },
  {
    id: 'north-west', name: '北阙', district: 'temple', width: 6.4,
    points: [[-231, -282], [-253, -352], [-190, -398], [-80, -434]],
  },
  {
    id: 'north-crown', name: '天衢', district: 'temple', width: 7.2,
    points: [[-80, -434], [33, -391], [123, -367], [223, -325], [319, -282, SUMMIT.y], [SUMMIT.x, SUMMIT.z, SUMMIT.y]],
  },
  {
    id: 'north-terrace', name: '云上街', district: 'scholar', width: 5.6,
    points: [[123, -367], [178, -440], [284, -449], [388, -434], [441, -355], [399, -226]],
  },
  {
    id: 'west-inner', name: '梧桐巷', district: 'west', width: 4.8,
    points: [[-305, 52], [-353, 72], [-411, 54], [-479, 44]],
  },
  {
    id: 'west-court', name: '栖霞内坊', district: 'west', width: 4.8,
    points: [[-385, 118], [-374, 156], [-402, 200]],
  },
  {
    id: 'west-academy', name: '文庙街', district: 'scholar', width: 4.8,
    points: [[-479, -125], [-423, -136], [-371, -131], [-345, -185]],
  },
  {
    id: 'west-valley', name: '溪南里', district: 'market', width: 4.8,
    points: [[-230, 232], [-300, 240], [-359, 271], [-404, 315]],
  },
  {
    id: 'east-inner', name: '百工巷', district: 'market', width: 4.8,
    points: [[212, 163], [258, 106], [320, 113], [398, 81]],
  },
  {
    id: 'east-south', name: '南华坊', district: 'east', width: 5.2,
    points: [[407, 185], [392, 261], [310, 288], [226, 270]],
  },
  {
    id: 'east-court', name: '织锦里', district: 'east', width: 4.8,
    points: [[406, -104], [369, -55], [376, 12], [320, 20]],
  },
  {
    id: 'harbour-east', name: '万家埠', district: 'quay', width: 4.8,
    points: [[20, 295], [84, 266], [158, 258], [226, 270]],
  },
  {
    id: 'harbour-south', name: '归帆街', district: 'quay', width: 5.6,
    points: [[49, 426], [133, 431], [212, 380], [155, 337]],
  },
  {
    id: 'summit-west', name: '青云书院', district: 'scholar', width: 5.2,
    points: [[207, -197], [271, -243], [296, -298], [223, -325]],
  },
  {
    id: 'north-monastery', name: '万松院', district: 'temple', width: 5.6,
    points: [[-253, -352], [-334, -355], [-392, -341], [-401, -278]],
  },
];

const junctionHeights = new Map();
const junctionCounts = new Map();
for (const road of roadDefinitions) {
  for (const [x, z, y] of road.points) {
    const key = `${x},${z}`;
    junctionCounts.set(key, (junctionCounts.get(key) ?? 0) + 1);
    if (y !== undefined) junctionHeights.set(`${x},${z}`, y);
  }
}
const junctionLandings = [...junctionCounts].filter(([, count]) => count > 1).map(([key]) => {
  const [x, z] = key.split(',').map(Number);
  return { x, z, y: junctionHeights.get(key) ?? rawHeight(x, z) + 0.6 };
});

export function createRoad(definition) {
  const controls = definition.points.map(([x, z, y]) => new Vector3(x, (y ?? junctionHeights.get(`${x},${z}`) ?? rawHeight(x, z) + 0.6), z));
  const curve = new CatmullRomCurve3(controls, false, 'centripetal');
  const count = Math.ceil(curve.getLength() / 2.8);
  const points = curve.getSpacedPoints(count);
  let distance = 0;
  const samples = points.map((point, index) => {
    // Shared level landings prevent an ascending side street's paving from
    // projecting into the main street at a junction.
    for (const junction of junctionLandings) {
      const separation = Math.hypot(point.x - junction.x, point.z - junction.z);
      if (separation < 20) point.y = mix(junction.y, point.y, smooth(8, 20, separation));
    }
    point.y = snap(point.y);
    const next = points[Math.min(index + 1, points.length - 1)];
    const previous = points[Math.max(index - 1, 0)];
    const tangent = next.clone().sub(previous).setY(0).normalize();
    if (index > 0) distance += point.distanceTo(points[index - 1]);
    return {
      x: point.x, y: point.y, z: point.z,
      tangent, distance, width: definition.width,
      bridge: point.y - rawHeight(point.x, point.z) > 19 || isWater(point.x, point.z, 2),
    };
  });
  return { ...definition, curve, samples, length: distance };
}

export const roads = roadDefinitions.map(createRoad);
export const tourRoad = roads[0];

const roadBuckets = new Map();
const BUCKET = 24;
for (const road of roads) {
  for (const sample of road.samples) {
    const key = `${Math.floor(sample.x / BUCKET)},${Math.floor(sample.z / BUCKET)}`;
    if (!roadBuckets.has(key)) roadBuckets.set(key, []);
    roadBuckets.get(key).push(sample);
  }
}

export function nearestRoad(x, z, radius = 34) {
  let best = null;
  let distance = radius;
  const range = Math.ceil(radius / BUCKET);
  const bx = Math.floor(x / BUCKET);
  const bz = Math.floor(z / BUCKET);
  for (let dx = -range; dx <= range; dx++) {
    for (let dz = -range; dz <= range; dz++) {
      for (const point of roadBuckets.get(`${bx + dx},${bz + dz}`) ?? []) {
        const candidate = Math.hypot(x - point.x, z - point.z);
        if (candidate < distance) {
          best = point;
          distance = candidate;
        }
      }
    }
  }
  return best ? { point: best, distance } : null;
}

export function terrainHeight(x, z) {
  let height = rawHeight(x, z);
  // Palace and summit are inhabited stone terraces, cut into the land itself.
  const palaceEdge = Math.max(Math.abs(x - 25) - 65, Math.abs(z + 125) - 58);
  if (palaceEdge < 8) height = mix(PALACE.y - 0.8, height, smooth(0, 8, palaceEdge));
  const summitEdge = Math.hypot(x - SUMMIT.x, z - SUMMIT.z);
  if (summitEdge < 25) height = mix(SUMMIT.y - 0.8, height, smooth(18, 25, summitEdge));

  const nearby = nearestRoad(x, z, 18);
  if (nearby && !nearby.point.bridge) {
    const road = nearby.point;
    const weight = 1 - smooth(road.width / 2 + 2, road.width / 2 + 9, nearby.distance);
    height = mix(height, road.y - 0.8, weight);
  }
  // Carve the entire coarse terrain cell to the lowest intersecting road step.
  // Sampling only its centre leaves rock across a steep street's downhill half.
  const bx = Math.floor(x / BUCKET);
  const bz = Math.floor(z / BUCKET);
  for (let dx = -1; dx <= 1; dx++) {
    for (let dz = -1; dz <= 1; dz++) {
      for (const road of roadBuckets.get(`${bx + dx},${bz + dz}`) ?? []) {
        if (!road.bridge && Math.hypot(road.x - x, road.z - z) < road.width / 2 + TERRAIN_STEP * 0.72) {
          height = Math.min(height, road.y - 0.8);
        }
      }
    }
  }
  return Math.floor(height / 2.4) * 2.4;
}

export function roadPosition(distance, road = tourRoad) {
  distance = clamp(distance, 0, road.length);
  let low = 0;
  let high = road.samples.length - 1;
  while (low < high) {
    const middle = Math.floor((low + high) / 2);
    if (road.samples[middle].distance < distance) low = middle + 1;
    else high = middle;
  }
  const to = road.samples[low];
  const from = road.samples[Math.max(0, low - 1)];
  const ratio = (distance - from.distance) / (to.distance - from.distance || 1);
  return new Vector3(mix(from.x, to.x, ratio), mix(from.y, to.y, ratio), mix(from.z, to.z, ratio));
}

function distanceAt(x, z) {
  let distance = 0;
  let closest = Infinity;
  for (const point of tourRoad.samples) {
    const delta = Math.hypot(point.x - x, point.z - z);
    if (delta < closest) {
      closest = delta;
      distance = point.distance;
    }
  }
  return distance;
}

export const stations = [
  { name: '水云埠', subtitle: '一江灯火 · 百舸归帆', x: 80, z: 365, distance: 0, camera: [305, 135, 542], target: [-29, 36, 314] },
  { name: '澄溪长桥', subtitle: '山河入城 · 九孔连云', x: 12, z: 26, distance: distanceAt(12, 26), camera: [230, 211, 290], target: [-134, 112, 32] },
  { name: '听瀑天阙', subtitle: '百丈飞泉 · 万重飞檐', x: 30, z: -98, distance: distanceAt(30, -98), camera: [276, 345, 225], target: [-43, 172, -136] },
  { name: '凌霄台', subtitle: '层台沿岭 · 城在云中', x: 247, z: -144, distance: distanceAt(247, -144), camera: [581, 455, 126], target: [290, 264, -170] },
  { name: '望岳亭', subtitle: '登临绝顶 · 一览千峰', x: SUMMIT.x, z: SUMMIT.z, distance: tourRoad.length, camera: [531, 551, -88], target: [311, SUMMIT.y - 8, -255] },
];

// A complete periodic time model is also used by the CPU verification script.
export function timeState(hours) {
  hours = ((hours % 24) + 24) % 24;
  const angle = ((hours - 6) / 24) * Math.PI * 2;
  const altitude = Math.sin(angle);
  const day = smooth(-0.16, 0.2, altitude);
  const twilight = (1 - smooth(0.04, 0.42, Math.abs(altitude))) * smooth(-0.25, 0.02, altitude);
  return {
    hours, angle, altitude, day, twilight,
    lamps: 1 - smooth(-0.09, 0.2, altitude),
    moon: smooth(-0.04, 0.24, -altitude),
    skyTop: day,
  };
}
