import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import * as THREE from 'three';
import { buildWorld, createAtmosphere } from './src/scene.js';
import { createSky } from './src/sky.js';
import {
  FALL, SUMMIT, TERRAIN_STEP, VOXEL, WORLD_BOUNDS, isWater, roadPosition,
  roads, stations, timeState, tourRoad, waterHeight,
} from './src/world.js';

const checks = [];
function check(name, action) {
  action();
  checks.push(name);
  console.log(`PASS ${name}`);
}

const world = buildWorld();

check('Deterministic world has seven occupied districts across separate mountain elevations', () => {
  assert.equal(Object.keys(world.stats.districts).length, 7);
  assert.ok(world.stats.compounds >= 200);
  assert.ok(world.stats.siteBounds.maxX - world.stats.siteBounds.minX > 980);
  assert.ok(world.stats.siteBounds.maxZ - world.stats.siteBounds.minZ > 900);
  assert.ok(world.stats.siteBounds.maxY - world.stats.siteBounds.minY > 330);
  assert.ok(world.stats.roofs > world.stats.halls);
  assert.ok(world.stats.trees > 1500);
});

check('Road graph joins every branch to the low-town-to-summit route', () => {
  const reached = new Set([roads[0].id]);
  for (let pass = 0; pass < roads.length; pass++) {
    const vertices = new Set(roads.filter(road => reached.has(road.id)).flatMap(road => road.points.map(([x, z]) => `${x},${z}`)));
    for (const road of roads) {
      if (road.points.some(([x, z]) => vertices.has(`${x},${z}`))) reached.add(road.id);
    }
  }
  assert.equal(reached.size, roads.length);
  assert.ok(tourRoad.length > 1200);
  assert.ok(roadPosition(0).y < 30);
  assert.ok(Math.abs(roadPosition(tourRoad.length).y - SUMMIT.y) < 0.21);
  assert.equal(stations[2].name, '听瀑天阙');
  for (let index = 1; index < stations.length; index++) assert.ok(stations[index].distance > stations[index - 1].distance);
});

check('Tour stays above water and its sampled stone terrain', () => {
  const intrusions = [];
  for (let distance = 0; distance <= tourRoad.length; distance += 1.25) {
    const point = roadPosition(distance);
    assert.ok([point.x, point.y, point.z].every(Number.isFinite));
    if (isWater(point.x, point.z)) assert.ok(point.y > waterHeight(point.z) + 0.8);
    const cx = WORLD_BOUNDS.minX + (Math.floor((point.x - WORLD_BOUNDS.minX) / TERRAIN_STEP) + 0.5) * TERRAIN_STEP;
    const cz = WORLD_BOUNDS.minZ + (Math.floor((point.z - WORLD_BOUNDS.minZ) / TERRAIN_STEP) + 0.5) * TERRAIN_STEP;
    const ground = world.heightAt(cx, cz);
    if (ground > point.y + 1.5) intrusions.push({ distance: Math.round(distance), road: point.y, ground, x: point.x, z: point.z });
  }
  assert.deepEqual(intrusions.slice(0, 8), [], 'Terrain overlaps the eye-level tour corridor');
});

check('Every generated building entrance has an actual stair connection', () => {
  assert.equal(world.doors.length, world.sites.length);
  for (const door of world.doors) {
    assert.ok([...door.from, ...door.to].every(Number.isFinite));
    assert.ok(Math.hypot(door.from[0] - door.to[0], door.from[2] - door.to[2]) < 16);
    assert.ok(Math.abs(door.from[1] - door.to[1]) < 10);
  }
});

check('Eye-level tour corridor does not pass through solid architectural voxels', () => {
  const buckets = new Map();
  const cell = 16;
  for (const [material, mesh] of Object.entries(world.meshes)) {
    if (['water', 'foam', 'lamp'].includes(material)) continue;
    const values = mesh.instanceMatrix.array;
    for (let offset = 0; offset < values.length; offset += 16) {
      const x = values[offset + 12];
      const z = values[offset + 14];
      const halfX = (Math.abs(values[offset]) + Math.abs(values[offset + 8])) / 2;
      const halfZ = (Math.abs(values[offset + 2]) + Math.abs(values[offset + 10])) / 2;
      const record = { values, offset, material };
      for (let bx = Math.floor((x - halfX) / cell); bx <= Math.floor((x + halfX) / cell); bx++) {
        for (let bz = Math.floor((z - halfZ) / cell); bz <= Math.floor((z + halfZ) / cell); bz++) {
          const key = `${bx},${bz}`;
          if (!buckets.has(key)) buckets.set(key, []);
          buckets.get(key).push(record);
        }
      }
    }
  }
  const intrusions = [];
  for (let distance = 0; distance <= tourRoad.length; distance += 1.25) {
    const point = roadPosition(distance);
    point.y += 1.9;
    for (const { values: m, offset: o, material } of buckets.get(`${Math.floor(point.x / cell)},${Math.floor(point.z / cell)}`) ?? []) {
      const dy = point.y - m[o + 13];
      if (Math.abs(dy / m[o + 5]) >= 0.48) continue;
      const dx = point.x - m[o + 12];
      const dz = point.z - m[o + 14];
      const localX = (dx * m[o] + dz * m[o + 2]) / (m[o] ** 2 + m[o + 2] ** 2);
      const localZ = (dx * m[o + 8] + dz * m[o + 10]) / (m[o + 8] ** 2 + m[o + 10] ** 2);
      if (Math.abs(localX) < 0.48 && Math.abs(localZ) < 0.48) {
        intrusions.push({ distance: Math.round(distance), material, x: Math.round(point.x), y: point.y, z: Math.round(point.z) });
        break;
      }
    }
  }
  assert.deepEqual(intrusions.slice(0, 12), [], 'Architecture crosses the camera route');
});

check('All instanced voxels have finite transforms and dimensions in 0.2 m units', () => {
  for (const mesh of Object.values(world.meshes)) {
    const values = mesh.instanceMatrix.array;
    assert.equal(values.length, mesh.count * 16);
    for (let offset = 0; offset < values.length; offset += 16) {
      for (let component = 0; component < 16; component++) assert.ok(Number.isFinite(values[offset + component]));
      for (const start of [0, 4, 8]) {
        const size = Math.hypot(values[offset + start], values[offset + start + 1], values[offset + start + 2]);
        assert.ok(size > 0);
        assert.ok(Math.abs(size / VOXEL - Math.round(size / VOXEL)) < 0.002);
      }
    }
  }
  for (const mesh of world.group.children.filter(child => !child.isInstancedMesh)) {
    assert.ok(mesh.geometry.index.count > 0);
    for (const value of mesh.geometry.attributes.position.array) assert.ok(Number.isFinite(value));
  }
});

check('Daylight is periodic, continuous and drives distinct midday and midnight states', () => {
  assert.deepEqual(timeState(0), timeState(24));
  assert.deepEqual(timeState(-1), timeState(23));
  assert.equal(timeState(12).day, 1);
  assert.equal(timeState(0).day, 0);
  assert.equal(timeState(12).lamps, 0);
  assert.equal(timeState(0).lamps, 1);
  for (let hour = 0; hour <= 24; hour += 0.01) {
    const current = timeState(hour);
    const next = timeState(hour + 0.001);
    for (const key of ['day', 'twilight', 'lamps', 'moon']) {
      assert.ok(current[key] >= 0 && current[key] <= 1);
      assert.ok(Math.abs(current[key] - next[key]) < 0.01);
    }
  }
});

check('Sky, sun, moon, clouds and 176 m waterfall update without a renderer', () => {
  assert.equal(FALL.top - FALL.bottom, 176);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera();
  camera.position.set(100, 200, 400);
  const sky = createSky(scene);
  const atmosphere = createAtmosphere();
  for (const hour of [0, 4, 6, 9, 12, 16, 18, 21, 24]) {
    const lighting = sky.update(hour, camera);
    atmosphere.update(hour * 7, lighting.day);
    assert.ok(Number.isFinite(sky.sunlight.intensity));
    assert.ok(scene.fog.density > 0);
    for (const child of atmosphere.group.children) {
      for (const value of child.instanceMatrix.array) assert.ok(Number.isFinite(value));
    }
  }
});

check('Built HTML uses relative local assets suitable for arbitrary deployment prefixes', () => {
  const html = readFileSync('dist/index.html', 'utf8');
  const references = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(match => match[1]);
  for (const reference of references) {
    if (reference.startsWith('data:')) continue;
    assert.ok(reference.startsWith('./'), `Non-relative build asset: ${reference}`);
    assert.ok(readFileSync(`dist/${reference.slice(2)}`).length > 0);
    assert.ok(new URL(reference, 'https://example.invalid/exhibitions/cloud-city/index.html').pathname.startsWith('/exhibitions/cloud-city/'));
  }
  assert.ok(readdirSync('dist/assets').some(file => file.endsWith('.js')));
  assert.ok(readFileSync('dist/licenses/three.txt', 'utf8').includes('Permission is hereby granted'));
  assert.ok(readFileSync('dist/licenses/vite.txt', 'utf8').includes('MIT License'));
});

const report = {
  checkedAt: new Date().toISOString(),
  environment: `Node ${process.version}; ${process.platform} ${process.arch}`,
  checks,
  stats: world.stats,
  limitations: ['No browser opened', 'No WebGL shader compilation or GPU rendering tested', 'No measured frame rate', 'No browser interaction or mobile-device test'],
};
writeFileSync('test-report.json', `${JSON.stringify(report, null, 2)}\n`);
console.log(`\n${checks.length} checks passed. This is CPU/static verification, not a browser test.`);
