import * as THREE from 'three';

// All modeled dimensions are multiples of one 0.2 metre voxel. The terrain
// uses larger merged columns (12 × 12 voxels) to keep the mountain tractable.
export const VOXEL = 0.2;
const STEP = 2.4;
const snap = (n) => Math.round(n / VOXEL) * VOXEL;
const gaussian = (x, z, cx, cz, sx, sz) => Math.exp(-(((x - cx) / sx) ** 2 + ((z - cz) / sz) ** 2));
const riverX = (z) => 2 + 5.5 * Math.sin((z + 53) / 32);
const hash = (a, b) => {
  const n = Math.sin(a * 127.1 + b * 311.7) * 43758.5453;
  return n - Math.floor(n);
};

export function terrainHeight(x, z) {
  const ridges =
    33 * gaussian(x, z, -69, -31, 53, 49) +
    37 * gaussian(x, z, 72, -48, 56, 48) +
    27 * gaussian(x, z, -94, -105, 48, 43) +
    29 * gaussian(x, z, 70, -102, 47, 43) +
    21 * gaussian(x, z, -11, -121, 66, 36);
  const smallRidges = 4.2 * Math.sin(x * 0.075 + z * 0.029) * Math.cos(z * 0.063);
  let height = 5.2 + ridges + smallRidges;
  const channel = Math.exp(-(((x - riverX(z)) / 12) ** 4));
  // The upper river ends at a steep lip; the lower river continues from its plunge pool.
  const upper = z < -31;
  const lower = z > -18;
  const riverbed = upper ? 22.5 : lower ? 3.3 : THREE.MathUtils.lerp(22.5, 3.3, (z + 31) / 13);
  height = THREE.MathUtils.lerp(height, riverbed, channel * 0.97);
  const terraceX = THREE.MathUtils.clamp((24 - Math.abs(x - 43)) / 12, 0, 1);
  const terraceZ = THREE.MathUtils.clamp((24 - Math.abs(z + 31)) / 12, 0, 1);
  height = THREE.MathUtils.lerp(height, 32, terraceX * terraceZ * 0.86);
  return snap(Math.max(2.2, height));
}

export const routeNodes = [
  { x: -43, z: 71, name: '烟汀市集' },
  { x: -38, z: 56 }, { x: -34, z: 41 }, { x: -28, z: 25 },
  { x: -20, z: 15, y: 11.3 }, { x: -14, z: 9, y: 13.2, bridge: true },
  { x: 15, z: 9, bridge: true }, { x: 23, z: 5, y: 13.4, bridge: true },
  { x: 27, z: -8 }, { x: 31, z: -18 },
  { x: 27, z: -30, y: 28.9, name: '听瀑天阙' },
  { x: 23, z: -40 }, { x: 36, z: -49 }, { x: 49, z: -51 },
  { x: 64, z: -57 }, { x: 83, z: -61 },
  { x: 94, z: -73 }, { x: 85, z: -82 },
  { x: 62, z: -76 }, { x: 54, z: -85 },
  { x: 70, z: -95, name: '揽云亭' },
];

function seededRandom(seed = 84391) {
  let value = seed >>> 0;
  return () => {
    value = (1664525 * value + 1013904223) >>> 0;
    return value / 4294967296;
  };
}

export function buildWorld() {
  const random = seededRandom();
  const scene = new THREE.Scene();
  const palettes = {
    rock: 0x65756e, rockDark: 0x4c625e, rockWarm: 0x8c8571,
    grass: 0x67806d, grassLight: 0x82977a, peak: 0xc2bba1,
    plinth: 0x667879, stone: 0xa7a395, paving: 0xaaa394,
    plaster: 0xe0d1b1, timber: 0x784436, timberDark: 0x50362e,
    red: 0x9e4c3e, gold: 0xd5ac69, roof: 0x244a51,
    roofLight: 0x3c6870, roofDark: 0x173840, leaf: 0x426d5e,
    leafLight: 0x5b8872, pine: 0x2e5d54,
    water: 0x448e9c, waterLight: 0x77bdc2, waterFoam: 0xcbe2d6,
    snow: 0xd8d3bd, lantern: 0xf7cc7a, window: 0xe0a957,
  };
  const materials = Object.fromEntries(Object.entries(palettes).map(([key, color]) => [
    key,
    key === 'lantern' || key === 'window' || key === 'waterFoam'
      ? new THREE.MeshBasicMaterial({ color, transparent: key !== 'waterFoam' })
      : new THREE.MeshLambertMaterial({ color, flatShading: true }),
  ]));
  const boxes = new Map();
  const unitBox = new THREE.BoxGeometry(1, 1, 1);

  function box(kind, x, y, z, width, height, depth, rotation = 0) {
    if (!boxes.has(kind)) boxes.set(kind, []);
    boxes.get(kind).push([
      snap(x), snap(y), snap(z),
      Math.max(VOXEL, snap(width)), Math.max(VOXEL, snap(height)), Math.max(VOXEL, snap(depth)),
      rotation,
    ]);
  }

  function localBox(kind, cx, cz, lx, y, lz, width, height, depth, yaw = 0) {
    const c = Math.cos(yaw);
    const s = Math.sin(yaw);
    box(kind, cx + lx * c - lz * s, y, cz + lx * s + lz * c, width, height, depth, yaw);
  }

  function plinth(x, z, width, depth, top, yaw = 0) {
    const c = Math.cos(yaw);
    const s = Math.sin(yaw);
    const corners = [[-width / 2, -depth / 2], [width / 2, -depth / 2], [-width / 2, depth / 2], [width / 2, depth / 2]];
    const foot = Math.min(top - 0.8, Math.min(...corners.map(([u, v]) => terrainHeight(x + u * c - v * s, z + u * s + v * c))) - 1.2);
    box('plinth', x, (foot + top) / 2, z, width, top - foot, depth, yaw);
    box('stone', x, top + 0.1, z, width + 0.4, 0.2, depth + 0.4, yaw);
  }

  function roof(cx, cz, y, width, depth, yaw = 0, kind = 'roof') {
    // Three wide pixel courses and raised eave tips give every roof a clear silhouette.
    localBox('roofDark', cx, cz, 0, y + 0.1, 0, width + 2.2, 0.4, depth + 2.2, yaw);
    localBox(kind, cx, cz, 0, y + 0.5, 0, width + 1.7, 0.4, depth + 1.7, yaw);
    localBox(kind, cx, cz, 0, y + 0.9, 0, width + 0.7, 0.4, depth + 0.8, yaw);
    localBox('roofLight', cx, cz, 0, y + 1.3, 0, width * 0.35, 0.4, depth + 0.6, yaw);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      localBox('roofDark', cx, cz, sx * (width / 2 + 1), y + 0.6, sz * (depth / 2 + 1), 1.2, 0.8, 1.2, yaw);
      localBox('gold', cx, cz, sx * (width / 2 + 1), y + 1.1, sz * (depth / 2 + 1), 0.4, 0.2, 0.4, yaw);
    }
    for (let i = -Math.floor(depth / 2); i <= Math.floor(depth / 2); i += 1.6) {
      localBox('roofDark', cx, cz, -width / 2 - 1.05, y + 0.35, i, 0.2, 0.2, 0.9, yaw);
      localBox('roofDark', cx, cz, width / 2 + 1.05, y + 0.35, i, 0.2, 0.2, 0.9, yaw);
    }
  }

  function hall(x, z, width, depth, options = {}) {
    const yaw = options.yaw ?? 0;
    const stories = options.stories ?? 1;
    const base = options.base ?? terrainHeight(x, z) + 0.3;
    const wallKind = options.red ? 'red' : 'plaster';
    plinth(x, z, width + 1.4, depth + 1.4, base, yaw);
    for (let floor = 0; floor < stories; floor++) {
      const shrink = floor * 1.4;
      const w = width - shrink;
      const d = depth - shrink;
      const bottom = base + 0.4 + floor * 5.4;
      localBox(wallKind, x, z, 0, bottom + 1.8, 0, w, 3.6, d, yaw);
      localBox('timberDark', x, z, 0, bottom + 0.2, 0, w + 0.2, 0.4, d + 0.2, yaw);
      for (const side of [-1, 1]) {
        for (let column = -w / 2 + 0.5; column <= w / 2 - 0.4; column += Math.max(2.2, w / 3)) {
          localBox('timber', x, z, column, bottom + 1.9, side * (d / 2 + 0.1), 0.4, 3.8, 0.4, yaw);
          if (Math.abs(column) > 0.9) {
            localBox('timberDark', x, z, column, bottom + 2.1, side * (d / 2 + 0.35), 1.2, 1.2, 0.2, yaw);
            localBox('window', x, z, column, bottom + 2.1, side * (d / 2 + 0.47), 0.7, 0.8, 0.2, yaw);
            localBox('timber', x, z, column, bottom + 2.1, side * (d / 2 + 0.6), 0.2, 1.2, 0.2, yaw);
          }
        }
      }
      localBox('timberDark', x, z, 0, bottom + 1.1, d / 2 + 0.5, 1.7, 2.2, 0.2, yaw);
      localBox('gold', x, z, 0, bottom + 3.3, d / 2 + 0.6, 1.8, 0.25, 0.2, yaw);
      roof(x, z, bottom + 3.9, w, d, yaw, options.roof ?? 'roof');
    }
    return base;
  }

  function lantern(x, z, y = terrainHeight(x, z) + 2.6) {
    box('timberDark', x, y - 1.2, z, 0.2, 2.4, 0.2);
    box('gold', x, y + 0.45, z, 0.9, 0.2, 0.9);
    box('lantern', x, y, z, 0.7, 0.8, 0.7);
    box('timberDark', x, y - 0.45, z, 0.9, 0.2, 0.9);
  }

  function tree(x, z, size = 1) {
    const y = terrainHeight(x, z);
    const h = snap((2.4 + 1.2 * size));
    box('timberDark', x, y + h / 2, z, 0.6, h, 0.6);
    const kind = hash(x, z) > 0.52 ? 'leaf' : 'pine';
    box(kind, x, y + h + 0.8, z, 2.6 * size, 1.8 * size, 2.6 * size);
    box('leafLight', x, y + h + 1.8 * size, z, 2.0 * size, 1.2 * size, 2.0 * size);
    box(kind, x, y + h + 2.6 * size, z, 1.2 * size, 1.0 * size, 1.2 * size);
  }

  function courtyard(x, z, yaw = 0, scale = 1) {
    const width = snap(13 * scale);
    const depth = snap(15 * scale);
    const base = terrainHeight(x, z) + 0.4;
    plinth(x, z, width, depth, base, yaw);
    localBox('paving', x, z, 0, base + 0.3, 0, width - 1, 0.2, depth - 1, yaw);
    const at = (u, v) => ({ x: x + u * Math.cos(yaw) - v * Math.sin(yaw), z: z + u * Math.sin(yaw) + v * Math.cos(yaw) });
    const rear = at(0, -3.0 * scale);
    hall(rear.x, rear.z, 8.4 * scale, 5.4 * scale, { base: base + 0.4, yaw });
    for (const side of [-1, 1]) {
      const wing = at(side * 4.2 * scale, 3.1 * scale);
      hall(wing.x, wing.z, 3.4 * scale, 4.8 * scale, { base: base + 0.4, yaw, roof: 'roofLight' });
      localBox('plaster', x, z, side * (width / 2 - 0.2), base + 1.5, 0, 0.4, 2.3, depth, yaw);
    }
    localBox('plaster', x, z, 0, base + 1.5, -depth / 2 + 0.2, width, 2.3, 0.4, yaw);
    for (const side of [-1, 1]) {
      localBox('plaster', x, z, side * (width / 4 + 0.9), base + 1.5, depth / 2 - 0.2, width / 2 - 1.3, 2.3, 0.4, yaw);
    }
    localBox('red', x, z, 0, base + 1.6, depth / 2, 2.4, 2.8, 0.4, yaw);
    localBox('roofDark', x, z, 0, base + 3.1, depth / 2, 3.6, 0.4, 1.2, yaw);
    const lamp = at(width / 2 + 1.1, depth / 2);
    lantern(lamp.x, lamp.z);
  }

  function watchtower(x, z, stories = 3, yaw = 0) {
    const base = terrainHeight(x, z) + 0.4;
    const width = 7.8;
    plinth(x, z, 10.2, 10.2, base, yaw);
    for (let level = 0; level < stories; level++) {
      const w = width - level * 0.9;
      const bottom = base + 0.4 + level * 4.9;
      box('red', x, bottom + 1.65, z, w, 3.3, w, yaw);
      for (const side of [-1, 1]) {
        localBox('timberDark', x, z, side * (w / 2 + 0.1), bottom + 1.8, 0, 0.4, 3.5, w, yaw);
        localBox('window', x, z, 0, bottom + 2.0, side * (w / 2 + 0.2), 2.1, 1.1, 0.2, yaw);
      }
      roof(x, z, bottom + 3.5, w, w, yaw);
    }
    box('gold', x, base + 0.4 + stories * 4.9 + 0.2, z, 0.8, 1.1, 0.8);
  }

  function gate(x, z, yaw = 0) {
    const base = terrainHeight(x, z) + 0.3;
    for (const side of [-1, 1]) {
      localBox('stone', x, z, side * 3.5, base + 2.1, 0, 2.2, 4.2, 2.6, yaw);
      localBox('red', x, z, side * 3.5, base + 4.0, 0, 2.2, 1.1, 2.6, yaw);
    }
    localBox('red', x, z, 0, base + 4.4, 0, 5.0, 0.8, 2.8, yaw);
    roof(x, z, base + 4.8, 9.2, 3.2, yaw);
    localBox('gold', x, z, 0, base + 4.5, 1.7, 2.4, 0.5, 0.2, yaw);
  }

  function ridgeWall(points) {
    for (let segment = 0; segment < points.length - 1; segment++) {
      const [ax, az] = points[segment];
      const [bx, bz] = points[segment + 1];
      const length = Math.hypot(bx - ax, bz - az);
      const angle = Math.atan2(bx - ax, bz - az);
      const count = Math.ceil(length / 1.8);
      for (let i = 0; i < count; i++) {
        const t = (i + 0.5) / count;
        const x = ax + (bx - ax) * t;
        const z = az + (bz - az) * t;
        const ground = terrainHeight(x, z);
        box('plinth', x, ground + 1.6, z, 1.6, 3.2, 1.9, angle);
        box('stone', x, ground + 3.25, z, 1.9, 0.3, 2.0, angle);
        if (i % 2 === 0) box('stone', x, ground + 3.75, z, 1.9, 0.8, 0.8, angle);
      }
    }
  }

  function stoneRoad(nodes, width = 3.2, makeBridge = false, collect = false) {
    const samples = [];
    for (let k = 0; k < nodes.length - 1; k++) {
      const a = nodes[k];
      const b = nodes[k + 1];
      const length = Math.hypot(b.x - a.x, b.z - a.z);
      const aHeight = a.y ?? terrainHeight(a.x, a.z) + 0.35;
      const bHeight = b.y ?? terrainHeight(b.x, b.z) + 0.35;
      const count = Math.max(1, Math.ceil(length / (collect ? 0.45 : 0.9)), Math.ceil(Math.abs(bHeight - aHeight) / 0.25));
      const slabDepth = Math.max(0.4, length / count + 0.15);
      const angle = Math.atan2(b.x - a.x, b.z - a.z);
      for (let j = 0; j < count; j++) {
        const t = j / count;
        const x = a.x + (b.x - a.x) * t;
        const z = a.z + (b.z - a.z) * t;
        const ground = terrainHeight(x, z);
        const bridge = makeBridge || (a.bridge && b.bridge);
        const y = bridge
          ? Math.max(z < -31 ? 26.2 : 13.2, ground + 0.4)
          : Math.max(ground + 0.35, THREE.MathUtils.lerp(aHeight, bHeight, t));
        box('paving', x, y, z, width, 0.35, slabDepth, angle);
        if (!bridge && y - ground > 1.2 && j % 3 === 0) box('plinth', x, (y + ground) / 2, z, width - 0.6, y - ground, 0.8, angle);
        if (bridge && j % 5 === 0) {
          const dx = Math.cos(angle) * (width / 2 + 0.25);
          const dz = -Math.sin(angle) * (width / 2 + 0.25);
          for (const side of [-1, 1]) {
            box('stone', x + dx * side, y + 0.9, z + dz * side, 0.5, 1.5, 0.5);
            box('gold', x + dx * side, y + 1.8, z + dz * side, 0.7, 0.2, 0.7);
          }
          if (y - ground > 2) box('plinth', x, (y + ground) / 2, z, width - 0.4, y - ground, 1.0, angle);
        }
        if (collect) samples.push({ x, y, z });
      }
    }
    if (collect) {
      const last = nodes.at(-1);
      samples.push({ x: last.x, y: last.y ?? terrainHeight(last.x, last.z) + 0.35, z: last.z });
    }
    return samples;
  }

  // The large terrain is carved first; all later foundations use its exact height function.
  for (let x = -132; x <= 132; x += STEP) for (let z = -138; z <= 126; z += STEP) {
    const h = terrainHeight(x, z);
    const grit = hash(x, z);
    const rockKind = h > 53 ? 'rockWarm' : grit > 0.79 ? 'rockDark' : grit > 0.55 ? 'rockWarm' : 'rock';
    box(rockKind, x, (h - 4) / 2, z, STEP, h + 4, STEP);
    const top = h > 57 ? 'snow' : h > 38 ? (grit > 0.45 ? 'peak' : 'grass') : grit > 0.7 ? 'grassLight' : 'grass';
    box(top, x, h + 0.1, z, STEP, 0.2, STEP);
  }

  // The two reaches, a terraced plunge pool, and a broad, luminous fall.
  for (let z = -134; z < -33; z += 2.4) {
    const x = riverX(z);
    box('water', x, 23.4, z, 9.8, 0.4, 2.6);
    for (let i = -1; i <= 1; i++) if (hash(i + 3, z) > 0.42) box('waterLight', x + i * 2.6, 23.7, z + 0.4, 1.3, 0.2, 0.35);
  }
  for (let z = -16; z < 123; z += 2.4) {
    const x = riverX(z);
    box('water', x, 4.3, z, z < -2 ? 13.2 : 9.8, 0.4, 2.6);
    for (let i = -1; i <= 1; i++) if (hash(i + 7, z) > 0.48) box('waterLight', x + i * 2.3, 4.6, z + 0.5, 1.4, 0.2, 0.35);
  }
  for (let strip = -9; strip <= 9; strip++) {
    for (let level = 0; level < 24; level++) {
      const t = level / 23;
      const x = riverX(-31) + strip * 0.65 + (hash(strip, level) - 0.5) * 0.32;
      const z = -33 + t * 17;
      const y = 23.1 - t * 18.1;
      box(level % 5 === 0 ? 'waterFoam' : level % 3 === 0 ? 'waterLight' : 'water', x, y, z, 0.6, 1.15, 1.0);
    }
  }
  for (let i = 0; i < 95; i++) {
    const x = riverX(-16) + (random() - 0.5) * 16;
    const z = -14 + random() * 11;
    box('waterFoam', x, 4.9 + random() * 0.9, z, 0.4 + random() * 0.8, 0.2, 0.4 + random() * 0.8);
  }

  // Main pedestrian journey, with a stone bridge across the lower gorge.
  const palaceBase = terrainHeight(43, -31) + 1.0;
  const route = stoneRoad(routeNodes, 3.2, false, true);
  const districtSpines = [
    [[-50, 72], [-43, 55], [-37, 38], [-29, 17]],
    [[29, 52], [34, 31], [41, 13], [44, -9], [43, -35]],
    [[-58, 10], [-67, -15], [-76, -39], [-88, -69]],
    [[34, -52], [44, -70], [54, -103]],
    [[-38, -76], [-44, -98], [-38, -128]],
    [[-83, 62], [-84, 38], [-79, 16], [-65, -5]],
    [[59, 51], [70, 28], [83, 3], [88, -25]],
    [[-86, -47], [-102, -63], [-108, -90], [-97, -114]],
    [[17, -97], [26, -113], [34, -130]],
  ];
  const toNodes = (points) => points.map(([x, z]) => ({ x, z }));
  for (const spine of districtSpines) stoneRoad(toNodes(spine), 2.4);
  // The mountain districts make a loop around both sides of the river.
  stoneRoad(toNodes([[-43, 55], [-57, 18], [-58, 10]]), 2.2);
  stoneRoad(toNodes([[-88, -69], [-77, -83], [-54, -89], [-38, -76]]), 2.2);
  stoneRoad([{ x: -38, z: -76 }, { x: -26, z: -80 }, { x: -18, z: -81, y: 26.2 }], 2.2);
  stoneRoad(toNodes([[-18, -81], [18, -81]]), 3.0, true);
  stoneRoad([{ x: 18, z: -81, y: 26.2 }, { x: 34, z: -52 }, { x: 39, z: -41 }], 2.2);
  stoneRoad(toNodes([[29, 52], [23, 27], [16, 9]]), 2.2);
  stoneRoad([{ x: 43, z: -35, y: palaceBase + 0.4 }, { x: 32, z: -34, y: palaceBase + 0.4 }, { x: 27, z: -30, y: 28.9 }], 2.2);
  stoneRoad(toNodes([[-50, 72], [-68, 68], [-83, 62]]), 2.2);
  stoneRoad(toNodes([[-65, -5], [-58, 10]]), 2.2);
  stoneRoad(toNodes([[29, 52], [43, 54], [59, 51]]), 2.2);
  stoneRoad(toNodes([[88, -25], [66, -32], [43, -35]]), 2.2);
  stoneRoad(toNodes([[-86, -47], [-76, -39]]), 2.2);
  stoneRoad(toNodes([[-97, -114], [-70, -111], [-44, -98]]), 2.2);
  stoneRoad(toNodes([[17, -97], [18, -81]]), 2.2);
  stoneRoad(toNodes([[34, -130], [47, -117], [54, -103]]), 2.2);
  gate(-58, 10, 0.28);
  gate(33, 33, 0.18);
  gate(-38, -77, -0.2);
  gate(49, -61, 0.4);
  ridgeWall([[99, 52], [112, 25], [117, -11], [112, -44], [105, -72], [88, -111]]);
  ridgeWall([[-100, 62], [-116, 33], [-121, -7], [-116, -48], [-119, -86]]);
  for (const [x, z] of [[112, 25], [112, -44], [88, -111], [-116, 33], [-116, -48]]) watchtower(x, z, 3);

  // The central palace sits on a cliffside stone court next to the fall.
  const palaceX = 43;
  const palaceZ = -31;
  plinth(palaceX, palaceZ, 24, 27, palaceBase);
  box('paving', palaceX, palaceBase + 0.32, palaceZ, 23.0, 0.2, 25.8);
  hall(46, -34, 17, 10, { base: palaceBase + 0.5, stories: 2, red: true });
  hall(43, -20, 12, 5.6, { base: palaceBase + 0.5, red: true });
  for (const z of [-42, -20]) watchtower(31, z, 3);
  for (let x = 32; x <= 54; x += 2) {
    box('stone', x, palaceBase + 1.4, -44, 0.6, 1.6, 0.6);
    box('gold', x, palaceBase + 2.2, -44, 0.9, 0.2, 0.9);
  }
  for (let i = 0; i < 8; i++) {
    const x = 32 - i * 0.9;
    const y = palaceBase - i * 0.55;
    box('paving', x, y, -30, 4.8, 0.4, 1.2);
  }
  lantern(31, -26, palaceBase + 2.9);
  lantern(31, -36, palaceBase + 2.9);

  // Summit pavilion: open red columns make the destination readable from afar.
  const summitY = terrainHeight(70, -95) + 1.0;
  plinth(70, -95, 14, 14, summitY);
  box('paving', 70, summitY + 0.3, -95, 12.8, 0.2, 12.8);
  for (const dx of [-4.2, 4.2]) for (const dz of [-4.2, 4.2]) {
    box('red', 70 + dx, summitY + 3.0, -95 + dz, 0.6, 5.4, 0.6);
    box('gold', 70 + dx, summitY + 5.7, -95 + dz, 0.8, 0.3, 0.8);
  }
  roof(70, -95, summitY + 5.8, 11.2, 11.2);
  box('gold', 70, summitY + 8.1, -95, 0.8, 1.3, 0.8);
  for (let dx = -6; dx <= 6; dx += 2) for (const dz of [-6, 6]) box('stone', 70 + dx, summitY + 1.3, -95 + dz, 0.5, 1.6, 0.5);
  for (let dz = -4; dz <= 4; dz += 2) for (const dx of [-6, 6]) box('stone', 70 + dx, summitY + 1.3, -95 + dz, 0.5, 1.6, 0.5);

  // Each ward has a curving avenue, walled homes, trades, gates, and lookout towers.
  // Parcels attach to the avenue, with broad empty breaks for trees and views.
  const buildingSites = [[43, -31, 22], [70, -95, 12], [-43, 71, 17]];
  for (const spine of districtSpines) {
    for (let segment = 0; segment < spine.length - 1; segment++) {
      const [ax, az] = spine[segment];
      const [bx, bz] = spine[segment + 1];
      const length = Math.hypot(bx - ax, bz - az);
      const nx = -(bz - az) / length;
      const nz = (bx - ax) / length;
      for (let distance = 5; distance < length - 2; distance += 11) {
        const x = ax + (bx - ax) * distance / length + nx * 2.7;
        const z = az + (bz - az) * distance / length + nz * 2.7;
        lantern(x, z);
      }
    }
  }
  for (let wardIndex = 0; wardIndex < districtSpines.length; wardIndex++) {
    const spine = districtSpines[wardIndex];
    for (let segment = 0; segment < spine.length - 1; segment++) {
      const [ax, az] = spine[segment];
      const [bx, bz] = spine[segment + 1];
      const len = Math.hypot(bx - ax, bz - az);
      const nx = -(bz - az) / len;
      const nz = (bx - ax) / len;
      const number = Math.max(3, Math.floor(len / 7));
      for (let n = 0; n < number; n++) {
        if ((n + segment + wardIndex) % 7 === 5) continue;
        const t = (n + 0.45) / number;
        const mx = ax + (bx - ax) * t;
        const mz = az + (bz - az) * t;
        const side = (n + segment) % 2 ? 1 : -1;
        const offset = side * (8.2 + (n % 3) * 1.4);
        const x = mx + nx * offset;
        const z = mz + nz * offset;
        if (Math.abs(x - riverX(z)) < 14 || x < -125 || x > 125 || z > 119 || z < -133) continue;
        const variant = (n * 3 + segment + wardIndex * 4) % 9;
        const yaw = Math.atan2(bx - ax, bz - az) * 0.35;
        buildingSites.push([x, z, variant <= 3 ? 9 : 6]);
        if (variant === 0 && n % 2 === 0) watchtower(x, z, 2 + (wardIndex % 2), yaw);
        else if (variant <= 3) courtyard(x, z, yaw, variant === 3 ? 0.9 : 1);
        else if (variant === 4) {
          hall(x, z, 10.5, 6.8, { yaw, stories: 2, red: true });
          lantern(x + 4.5, z + 4.2);
        } else {
          hall(x, z, 5.6 + (variant % 2) * 1.2, 5.6, { yaw });
          box('red', x, terrainHeight(x, z) + 2.2, z + 3.5, 0.7, 2.2, 0.2, yaw);
        }
        stoneRoad([{ x: mx, z: mz }, { x, z }], 1.4);
      }
    }
  }

  // Quay, warehouse halls, and a tiered market give the low end its own scale.
  for (let k = 0; k < 5; k++) hall(-58 + k * 8.0, 81 + (k % 2) * 4, 7.5, 5.8, { red: k === 2 });
  hall(-47, 66, 16, 8, { stories: 2, red: true });
  for (let k = 0; k < 7; k++) {
    const z = 72 - k * 8;
    box('paving', riverX(z) - 11, terrainHeight(riverX(z) - 11, z) + 0.35, z, 5.2, 0.35, 3.0);
    lantern(riverX(z) - 12.5, z);
  }

  // Woods and isolated cliff shrines give the buildings room to breathe.
  for (let i = 0; i < 790; i++) {
    const x = -127 + random() * 254;
    const z = -134 + random() * 252;
    const h = terrainHeight(x, z);
    if (Math.abs(x - riverX(z)) < 15 || h > 57 || h < 6 || buildingSites.some(([rx, rz, radius]) => Math.hypot(x - rx, z - rz) < radius)) continue;
    const nearRoad = districtSpines.some((spine) => spine.some(([ax, az], index) => {
      if (index === spine.length - 1) return false;
      const [bx, bz] = spine[index + 1];
      const t = THREE.MathUtils.clamp(((x - ax) * (bx - ax) + (z - az) * (bz - az)) / ((bx - ax) ** 2 + (bz - az) ** 2), 0, 1);
      return Math.hypot(x - (ax + (bx - ax) * t), z - (az + (bz - az) * t)) < 4;
    }));
    if (nearRoad || hash(x, z) < 0.15) continue;
    tree(x, z, 0.75 + random() * 0.7);
  }
  for (const [x, z] of [[-105, -48], [-113, -112], [111, -103], [97, 3], [-12, -121]]) {
    hall(x, z, 5.5, 5.5, { red: true });
    tree(x + 5, z + 2, 1.2);
  }

  // A sparse atmosphere adds depth without obscuring the main buildings.
  const clouds = [];
  const cloudMaterial = new THREE.MeshBasicMaterial({ color: 0xe9e8db, transparent: true, opacity: 0.27, depthWrite: false });
  for (let i = 0; i < 15; i++) {
    const group = new THREE.Group();
    const x = -135 + random() * 270;
    const z = -128 + random() * 250;
    const y = 34 + random() * 30;
    group.position.set(x, y, z);
    const width = 9 + random() * 13;
    for (let layer = 0; layer < 5; layer++) {
      const puff = new THREE.Mesh(new THREE.BoxGeometry(width - layer * 1.5, 1.0 + (layer % 2) * 0.6, 3.2 + layer * 0.5), cloudMaterial);
      puff.position.set(layer * 2.5 - 4.5, Math.sin(layer * 2.1) * 0.9, layer * 1.2 - 2);
      group.add(puff);
    }
    scene.add(group);
    clouds.push({ group, x, speed: 0.3 + random() * 0.5 });
  }

  const mistMaterial = new THREE.MeshBasicMaterial({ color: 0xe3ebe4, transparent: true, opacity: 0.18, depthWrite: false });
  for (let i = 0; i < 12; i++) {
    const x = riverX(-14) + (random() - 0.5) * 22;
    const z = -20 + random() * 27;
    const y = 6 + random() * 7;
    const mist = new THREE.Mesh(new THREE.BoxGeometry(8 + random() * 8, 0.8, 2 + random() * 3), mistMaterial);
    mist.position.set(x, y, z);
    scene.add(mist);
  }

  const dummy = new THREE.Object3D();
  const instanceCounts = {};
  for (const [kind, items] of boxes) {
    const mesh = new THREE.InstancedMesh(unitBox, materials[kind], items.length);
    mesh.name = kind;
    mesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);
    for (let i = 0; i < items.length; i++) {
      const [x, y, z, w, h, d, yaw] = items[i];
      dummy.position.set(x, y, z);
      dummy.rotation.set(0, yaw, 0);
      dummy.scale.set(w, h, d);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.computeBoundingSphere();
    scene.add(mesh);
    instanceCounts[kind] = items.length;
  }

  const ambient = new THREE.HemisphereLight(0xdde8e7, 0x344f4d, 1.2);
  const sunLight = new THREE.DirectionalLight(0xffdfad, 2.0);
  sunLight.position.set(-80, 120, 30);
  const moonLight = new THREE.DirectionalLight(0xb5c9e4, 0.2);
  moonLight.position.set(70, 110, -40);
  scene.add(ambient, sunLight, moonLight);
  const sun = new THREE.Mesh(new THREE.SphereGeometry(4.2, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffe1a4, fog: false }));
  const moon = new THREE.Mesh(new THREE.SphereGeometry(2.8, 12, 8), new THREE.MeshBasicMaterial({ color: 0xf0eee0, fog: false }));
  scene.add(sun, moon);

  // Tiny square stars reinforce the pixel-art language at night.
  const stars = new THREE.InstancedMesh(new THREE.BoxGeometry(0.55, 0.55, 0.55), new THREE.MeshBasicMaterial({ color: 0xe5e6d4, transparent: true, opacity: 0, depthWrite: false, fog: false }), 150);
  for (let i = 0; i < 150; i++) {
    const theta = random() * Math.PI * 2;
    const elevation = 0.25 + random() * 1.05;
    const radius = 220;
    dummy.position.set(Math.cos(theta) * Math.cos(elevation) * radius, Math.sin(elevation) * radius, Math.sin(theta) * Math.cos(elevation) * radius);
    dummy.rotation.set(0, 0, 0);
    dummy.scale.setScalar(i % 9 === 0 ? 1.5 : 0.7);
    dummy.updateMatrix();
    stars.setMatrixAt(i, dummy.matrix);
  }
  stars.instanceMatrix.needsUpdate = true;
  scene.add(stars);

  scene.fog = new THREE.FogExp2(0x9dadae, 0.0025);
  return { scene, route, routeNodes, ambient, sunLight, moonLight, sun, moon, stars, materials, clouds, instanceCounts };
}
