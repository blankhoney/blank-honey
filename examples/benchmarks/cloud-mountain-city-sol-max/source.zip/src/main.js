import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { buildWorld } from './world.js';
import './style.css';

const canvas = document.querySelector('#world');
const error = document.querySelector('#error');
const timeRange = document.querySelector('#time-range');
const tourRange = document.querySelector('#tour-range');
const clockText = document.querySelector('#clock');
const periodText = document.querySelector('#period');
const timePlay = document.querySelector('#time-play');
const tourPlay = document.querySelector('#tour-play');
const overviewButton = document.querySelector('#overview');
const journeyButton = document.querySelector('#journey');
const tourControls = document.querySelector('#tour-controls');
const tourPercent = document.querySelector('#tour-percent');

const SKY = [
  [0, 0x101c2e], [4.5, 0x1c2e49], [5.8, 0x758299],
  [6.8, 0xdba783], [8.5, 0xc4d4d4], [12, 0xbdd9df],
  [15.5, 0xd5ded5], [17.7, 0xe1b28a], [19.1, 0x53677c],
  [20.5, 0x192d47], [24, 0x101c2e],
].map(([hour, color]) => [hour, new THREE.Color(color)]);
const FOG = [
  [0, 0x243548], [5.8, 0x747d87], [8.5, 0x9fb8b8],
  [12, 0xaac9cc], [15.5, 0xb9c7bd], [17.7, 0xc5a992],
  [19.1, 0x536675], [24, 0x243548],
].map(([hour, color]) => [hour, new THREE.Color(color)]);

function colorAt(hour, stops) {
  for (let i = 1; i < stops.length; i++) {
    if (hour <= stops[i][0]) {
      const [leftHour, leftColor] = stops[i - 1];
      const [rightHour, rightColor] = stops[i];
      return leftColor.clone().lerp(rightColor, (hour - leftHour) / (rightHour - leftHour));
    }
  }
  return stops.at(-1)[1].clone();
}

function period(hour) {
  if (hour < 4.5) return '深夜';
  if (hour < 7.5) return '清晨';
  if (hour < 11) return '早间';
  if (hour < 14) return '日中';
  if (hour < 17.2) return '午后';
  if (hour < 19.4) return '薄暮';
  return '夜色';
}

function fillRange(element) {
  const value = (Number(element.value) - Number(element.min)) / (Number(element.max) - Number(element.min));
  element.style.setProperty('--fill', `${value * 100}%`);
}

try {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.14;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));

  const world = buildWorld();
  const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 650);
  const overviewPosition = new THREE.Vector3(90, 79, 132);
  const overviewTarget = new THREE.Vector3(0, 28, -42);
  camera.position.copy(overviewPosition);
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.minDistance = 4;
  controls.maxDistance = 380;
  controls.maxPolarAngle = Math.PI * 0.49;
  controls.target.copy(overviewTarget);
  controls.update();

  const route = world.route;
  const cumulative = [0];
  for (let i = 1; i < route.length; i++) {
    const a = route[i - 1];
    const b = route[i];
    cumulative.push(cumulative.at(-1) + Math.hypot(b.x - a.x, b.y - a.y, b.z - a.z));
  }
  const routeLength = cumulative.at(-1);
  const namedStops = world.routeNodes.filter((node) => node.name);
  const stopDistances = namedStops.map((node) => {
    let best = 0;
    let separation = Infinity;
    route.forEach((point, index) => {
      const distance = Math.hypot(point.x - node.x, point.z - node.z);
      if (distance < separation) { best = index; separation = distance; }
    });
    return cumulative[best];
  });

  function routeAt(distance) {
    const limited = THREE.MathUtils.clamp(distance, 0, routeLength);
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo < hi) {
      const mid = Math.floor((lo + hi) / 2);
      if (cumulative[mid] < limited) lo = mid + 1;
      else hi = mid;
    }
    const index = Math.max(1, lo);
    const a = route[index - 1];
    const b = route[index];
    const fraction = (limited - cumulative[index - 1]) / Math.max(0.001, cumulative[index] - cumulative[index - 1]);
    return new THREE.Vector3(
      THREE.MathUtils.lerp(a.x, b.x, fraction),
      THREE.MathUtils.lerp(a.y, b.y, fraction),
      THREE.MathUtils.lerp(a.z, b.z, fraction),
    );
  }

  let minute = 930;
  let timePlaying = true;
  let touring = false;
  let tourPlaying = false;
  let tourDistance = 0;
  let selectedStop = -1;
  let elapsed = 0;
  let lastFrame = performance.now();

  function setTime(value) {
    minute = (value + 1440) % 1440;
    const wholeMinute = Math.floor(minute);
    const hour = wholeMinute / 60;
    clockText.textContent = `${String(Math.floor(wholeMinute / 60)).padStart(2, '0')}:${String(wholeMinute % 60).padStart(2, '0')}`;
    periodText.textContent = period(hour);
    timeRange.value = wholeMinute;
    fillRange(timeRange);

    const sunAltitude = Math.sin((hour - 6) / 24 * Math.PI * 2);
    const moonAltitude = -sunAltitude;
    const daylight = THREE.MathUtils.smoothstep(sunAltitude, -0.11, 0.28);
    const twilight = Math.max(0, 1 - Math.abs(sunAltitude) / 0.55);
    const night = 1 - daylight;
    world.scene.background = colorAt(hour, SKY);
    world.scene.fog.color.copy(colorAt(hour, FOG));
    world.scene.fog.density = THREE.MathUtils.lerp(0.0029, 0.00235, daylight);
    world.ambient.intensity = 0.48 + daylight * 0.87;
    world.ambient.color.set(0xc6d5e0).lerp(new THREE.Color(0xe8ece7), daylight);
    world.sunLight.intensity = Math.max(0, sunAltitude) ** 0.6 * 2.1 + twilight * 0.08;
    world.sunLight.color.set(0xffd1a1).lerp(new THREE.Color(0xfff1d9), Math.max(0, sunAltitude));
    world.moonLight.intensity = Math.max(0, moonAltitude) * 0.32;

    const phase = (hour - 6) / 24 * Math.PI * 2;
    world.sun.position.set(-Math.cos(phase) * 185, Math.sin(phase) * 185, -90);
    world.moon.position.set(Math.cos(phase) * 185, -Math.sin(phase) * 185, -90);
    world.sun.visible = sunAltitude > -0.035;
    world.moon.visible = moonAltitude > 0.015;
    world.sunLight.position.copy(world.sun.position);
    world.moonLight.position.copy(world.moon.position);
    world.stars.material.opacity = THREE.MathUtils.smoothstep(night, 0.55, 0.93) * 0.9;
    world.materials.window.opacity = 0.28 + night * 0.72;
    world.materials.lantern.opacity = 0.25 + night * 0.75;
    document.body.classList.toggle('night', night > 0.67);
  }

  function setTourDistance(value) {
    tourDistance = THREE.MathUtils.clamp(value, 0, routeLength);
    tourRange.value = Math.round(tourDistance / routeLength * 1000);
    fillRange(tourRange);
    tourPercent.textContent = `${String(Math.round(tourDistance / routeLength * 100)).padStart(2, '0')}%`;
    if (!touring) return;
    const location = routeAt(tourDistance);
    camera.position.copy(location).add(new THREE.Vector3(0, 1.9, 0));
    let look;
    if (!tourPlaying && selectedStop === 1) look = new THREE.Vector3(45, 39, -31);
    else if (!tourPlaying && selectedStop === 2) look = new THREE.Vector3(2, 22, -24);
    else if (!tourPlaying && selectedStop === 0) look = new THREE.Vector3(-24, 14, 25);
    else look = routeAt(Math.min(routeLength, tourDistance + 7)).add(new THREE.Vector3(0, 1.45, 0));
    if (look.distanceTo(camera.position) < 0.01) look = new THREE.Vector3(2, 22, -24);
    camera.lookAt(look);
  }

  function updateMode() {
    controls.enabled = !touring;
    overviewButton.classList.toggle('active', !touring);
    journeyButton.classList.toggle('active', touring);
    overviewButton.setAttribute('aria-pressed', String(!touring));
    journeyButton.setAttribute('aria-pressed', String(touring));
    tourControls.hidden = !touring;
    tourPlay.textContent = tourPlaying ? 'Ⅱ' : '▶';
    tourPlay.setAttribute('aria-label', tourPlaying ? '暂停游览' : '继续游览');
    document.querySelectorAll('.stop').forEach((button, index) => button.classList.toggle('current', index === selectedStop && touring));
  }

  overviewButton.addEventListener('click', () => {
    touring = false;
    tourPlaying = false;
    selectedStop = -1;
    camera.position.copy(overviewPosition);
    controls.target.copy(overviewTarget);
    controls.update();
    updateMode();
  });
  journeyButton.addEventListener('click', () => {
    touring = true;
    tourPlaying = true;
    selectedStop = -1;
    setTourDistance(0);
    updateMode();
  });
  tourPlay.addEventListener('click', () => {
    tourPlaying = !tourPlaying;
    selectedStop = -1;
    if (tourDistance >= routeLength) setTourDistance(0);
    updateMode();
  });
  tourRange.addEventListener('input', () => {
    touring = true;
    tourPlaying = false;
    selectedStop = -1;
    setTourDistance(Number(tourRange.value) / 1000 * routeLength);
    updateMode();
  });
  document.querySelectorAll('.stop').forEach((button, index) => {
    button.addEventListener('click', () => {
      touring = true;
      tourPlaying = false;
      selectedStop = index;
      setTourDistance(stopDistances[index]);
      updateMode();
    });
  });
  timePlay.addEventListener('click', () => {
    timePlaying = !timePlaying;
    timePlay.textContent = timePlaying ? 'Ⅱ' : '▶';
    timePlay.setAttribute('aria-label', timePlaying ? '暂停时间' : '继续时间');
  });
  timeRange.addEventListener('input', () => setTime(Number(timeRange.value)));
  const helpToggle = document.querySelector('#help-toggle');
  const helpPanel = document.querySelector('#help-panel');
  helpToggle.addEventListener('click', () => {
    helpPanel.hidden = !helpPanel.hidden;
    helpToggle.setAttribute('aria-expanded', String(!helpPanel.hidden));
  });
  window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !helpPanel.hidden) {
      helpPanel.hidden = true;
      helpToggle.setAttribute('aria-expanded', 'false');
    }
  });

  function resize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    renderer.setSize(width, height, false);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();
  setTime(minute);
  fillRange(tourRange);
  updateMode();

  function frame(now) {
    const dt = Math.min((now - lastFrame) / 1000, 0.05);
    lastFrame = now;
    elapsed += dt;
    if (timePlaying) setTime(minute + dt * 3.2);
    if (touring && tourPlaying) {
      setTourDistance(tourDistance + dt * 4.3);
      if (tourDistance >= routeLength) {
        tourPlaying = false;
        selectedStop = 2;
        updateMode();
        setTourDistance(routeLength);
      }
    }
    for (const cloud of world.clouds) cloud.group.position.x = cloud.x + Math.sin(elapsed * cloud.speed * 0.13) * 7;
    if (!touring) controls.update();
    renderer.render(world.scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
} catch (problem) {
  console.error(problem);
  error.hidden = false;
}
