import test from 'node:test';
import assert from 'node:assert/strict';
import { buildWorld, routeNodes, terrainHeight, VOXEL } from './world.js';

test('mountain city has a stepped river and a continuous ground-level visit', () => {
  assert.equal(VOXEL, 0.2);
  assert.ok(terrainHeight(3, -40) > terrainHeight(5, 0) + 12, 'upper river must stand above the lower reach');
  assert.ok(terrainHeight(6, -25) < 14.7, 'waterfall chute stays exposed above the rock');
  assert.ok(terrainHeight(70, -95) > terrainHeight(-43, 71) + 35, 'summit must rise above the quay');

  const world = buildWorld();
  assert.ok(world.route.length > 150);
  for (const node of routeNodes.filter((point) => point.name)) {
    assert.ok(world.route.some((point) => Math.hypot(point.x - node.x, point.z - node.z) < 1.6), `${node.name} belongs to the route`);
  }
  for (const point of world.route) {
    assert.ok(point.y > terrainHeight(point.x, point.z), 'walking deck stays above ground');
  }
  const highestStep = Math.max(...world.route.slice(1).map((point, index) => Math.abs(point.y - world.route[index].y)));
  assert.ok(highestStep < 0.41, 'the guided road does not jump between decks');
  assert.ok(world.route.some((point) => Math.abs(point.x) < 1 && Math.abs(point.z - 9) < 1 && point.y > 12), 'lower bridge clears the river');
  assert.ok(world.instanceCounts.roofDark > 1000, 'built city contains roof detail');
  assert.ok(world.instanceCounts.water > 100, 'both river reaches and waterfall are modeled');
});
