import { readFile, writeFile } from 'node:fs/promises';
// Embed Vite's complete bundle so file:// also works without a server or CDN.
let html = await readFile('dist/index.html', 'utf8');
const script = html.match(/<script type="module" crossorigin src="([^"]+)"><\/script>/);
const stylesheet = html.match(/<link rel="stylesheet" crossorigin href="([^"]+)">/);
if (!script || !stylesheet) throw new Error('Unexpected build output: missing bundle or stylesheet.');
const js = await readFile(`dist${script[1]}`, 'utf8');
const css = await readFile(`dist${stylesheet[1]}`, 'utf8');
html = html.replace(script[0], "");
html = html.replace("</body>", () => `<script>${js.replaceAll('</script', '<\\/script')}</script></body>`);
html = html.replace(stylesheet[0], () => `<style>${css}</style>`);
await writeFile('dist/standalone.html', html);
console.log('Created dist/standalone.html — open directly in your browser.');
