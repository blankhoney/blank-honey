// Deterministic terrain: the same seed produces the same little world.
export const SIZE = 36;
export const key = (x, z) => `${x},${z}`;
export function hash(x, z, salt = 0) {
  const n = Math.sin(x * 127.1 + z * 311.7 + salt * 74.7) * 43758.5453;
  return n - Math.floor(n);
}
const smooth = t => t * t * (3 - 2 * t);
function noise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z), a = smooth(x - ix), b = smooth(z - iz);
  return (hash(ix, iz) * (1-a) + hash(ix+1, iz)*a)*(1-b) + (hash(ix, iz+1)*(1-a)+hash(ix+1,iz+1)*a)*b;
}
export function createTerrain() {
  const heights = new Map();
  const peaks = [[-5,-9,39,1.32],[-21,-4,25,1.24],[14,-12,31,1.38],[21,5,19,1.25],[-15,13,14,1.02]];
  for(let x=-SIZE;x<=SIZE;x++) for(let z=-SIZE;z<=SIZE;z++) {
    const radius = Math.hypot(x/35,z/29);
    if(radius > 1 + (noise(x*.19,z*.19)-.5)*.11) continue;
    const detail = (noise(x*.22,z*.22)-.5)*3 + (noise(x*.55,z*.55)-.5)*1.2;
    let h = 2 + noise(x*.12,z*.12)*2;
    for(const [px,pz,peak,slope] of peaks) {
      const dx=x-px,dz=z-pz;
      const d = Math.sqrt(dx*dx + dz*dz*1.12);
      h = Math.max(h, peak - d*slope + detail);
    }
    // Low foreground basin, with a stepped shoreline cut into the terrain.
    const lake = Math.hypot((x-5)/11,(z-20)/8);
    if(lake<1) h=1;
    else if(lake<1.23) h=Math.min(h,3+Math.floor((lake-1)*12));
    heights.set(key(x,z),Math.max(1,Math.floor(h)));
  }
  const river=[];
  let previous=Infinity;
  for(let z=-6;z<=23;z++) {
    const x=2;
    const h=Math.min(previous,heights.get(key(x,z)) ?? 1);
    for(let dx=-1;dx<=1;dx++) heights.set(key(x+dx,z),h);
    river.push({x,z,h});
    previous=h;
  }
  return {heights,river};
}
