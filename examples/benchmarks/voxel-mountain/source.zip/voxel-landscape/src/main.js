import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createTerrain, hash, key } from './terrain.js';
import './style.css';

const container = document.querySelector('#scene');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const state = { paused: reducedMotion, clouds: true, dusk: false, time: 0, fps: 0 };
const scene = new THREE.Scene();
scene.fog = new THREE.Fog('#dce8e2', 155, 300);
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
} catch (error) {
  document.querySelector('#loading').hidden = true;
  const message = document.querySelector('#error');
  message.hidden = false;
  message.textContent = '当前浏览器无法创建 WebGL 2 场景。请开启浏览器硬件加速，并使用支持 WebGL 2 的浏览器重新打开。';
  throw error;
}
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = false;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;
container.appendChild(renderer.domElement);
const camera = new THREE.PerspectiveCamera(36, innerWidth/innerHeight, .1, 400);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = .055;
controls.enablePan = false;
controls.minDistance = 65;
controls.maxDistance = 190;
controls.minPolarAngle = .3;
controls.maxPolarAngle = Math.PI/2.08;
controls.autoRotateSpeed = .45;
function resetView() {
  const mobile = innerWidth < 760;
  controls.target.set(0, mobile ? 15 : 13, 0);
  camera.position.set(83,68,112).sub(new THREE.Vector3(0,13,0)).multiplyScalar(mobile?1.36:1).add(controls.target);
  camera.zoom = mobile ? .68 : 1.08;
  // An off-center lens keeps the entire diorama beside the opening text.
  camera.setViewOffset(innerWidth,innerHeight, mobile?0:-innerWidth*.095, mobile?-innerHeight*.075:0,innerWidth,innerHeight);
  camera.updateProjectionMatrix();
  controls.update();
}
resetView();
const hemi = new THREE.HemisphereLight('#eef7ff','#718568',2.1);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#fff2d3',3.3);
sun.position.set(-35,70,40);
sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-58,right:58,top:65,bottom:-50,near:1,far:160});
sun.shadow.normalBias=.09;
sun.shadow.bias=-.0002;
scene.add(sun);
const rim = new THREE.DirectionalLight('#bbdbe6',.8);
rim.position.set(30,30,-50);
scene.add(rim);
const world = new THREE.Group();
scene.add(world);
const cube = new THREE.BoxGeometry(1,1,1);
const dummy = new THREE.Object3D();
const color = new THREE.Color();
let instanceCount=0;
function instances(items, material, parent=world, shadow=true) {
  const mesh=new THREE.InstancedMesh(cube,material,items.length);
  items.forEach((v,i)=>{
    dummy.position.set(v.x,v.y,v.z);
    dummy.scale.set(v.sx??1,v.sy??1,v.sz??1);
    dummy.rotation.set(0,v.rotation??0,0);
    dummy.updateMatrix();
    mesh.setMatrixAt(i,dummy.matrix);
    if(v.color) mesh.setColorAt(i,color.set(v.color));
  });
  mesh.castShadow=shadow;
  mesh.receiveShadow=shadow;
  mesh.instanceMatrix.needsUpdate=true;
  mesh.computeBoundingSphere();
  parent.add(mesh);
  instanceCount+=items.length;
  return mesh;
}
const terrainMaterial=new THREE.MeshLambertMaterial();
const {heights,river}=createTerrain();
const blocks=[];
const palette={grass:['#71935b','#809e62','#8da76b','#668654'],stone:['#87918b','#7d8984','#929b91','#a0a599'],earth:['#767361','#696c5c','#80806b'],snow:['#e1e9de','#d5dfd6','#edf0e5']};
for(const [coordinate,h] of heights) {
  const [x,z]=coordinate.split(',').map(Number);
  const adjacent=[[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dz])=>heights.get(key(x+dx,z+dz))??-8);
  // Only the top and exposed cliff shell are submitted to the GPU.
  const bottom=Math.max(-8,Math.min(h-1,...adjacent));
  for(let y=bottom;y<h;y++) {
    const variation=hash(x+y*.17,z,3);
    let shades=y===h-1&&h<25?palette.grass:palette.stone;
    if(y<0) shades=palette.earth;
    if(h>32+hash(x,z,11)*3 && y>h-3) shades=palette.snow;
    const c=new THREE.Color(shades[Math.floor(variation*shades.length)]);
    if(y<h-1) c.multiplyScalar(.92+variation*.08);
    blocks.push({x,y:y+.5,z,color:c});
  }
}
instances(blocks,terrainMaterial);
// A closed, recessed underside makes the exposed island edge feel geological.
const underside=[];
for(const [coordinate] of heights) {
  const [x,z]=coordinate.split(',').map(Number);
  underside.push({x,y:-8,z,sy:.5,color:'#676c5c'});
}
instances(underside,terrainMaterial,world,false);

const vegetation=[];
function tree(x,z,h,seed) {
  const tall=3.4+seed*3.4;
  vegetation.push({x,y:h+tall*.35,z,sx:.45,sy:tall*.7,sz:.45,color:'#625c46'});
  for(let tier=0;tier<4;tier++) {
    const width=(3.4-tier*.72)*(0.8+seed*.3);
    vegetation.push({x,y:h+1.5+tier*tall*.21,z,sx:width,sy:tall*.28,sz:width,color:['#345d48','#3d6b4b','#497953','#60895b'][tier]});
    if(tier<2) vegetation.push({x:x+.17,y:h+1.75+tier*tall*.21,z:z+.15,sx:width*.72,sy:tall*.25,sz:width*1.16,color:'#497552'});
  }
}
for(const [coordinate,h] of heights) {
  const [x,z]=coordinate.split(',').map(Number);
  if(h<4||h>22||Math.abs(x-2)<3||hash(x,z,80)>.078)continue;
  const near=[[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dz])=>heights.get(key(x+dx,z+dz))??0);
  if(Math.max(...near)-Math.min(...near)>3)continue;
  tree(x,z,h,hash(x,z,26));
}
instances(vegetation,terrainMaterial);
const details=[];
for(let i=0;i<180;i++) {
  const x=Math.floor(hash(i,7)*65)-32,z=Math.floor(hash(i,12)*50)-24;
  const h=heights.get(key(x,z));
  if(!h||h>19||h<3||Math.abs(x-2)<3)continue;
  details.push({x:x+.2,y:h+.2,z,sx:.35,sy:.4,sz:.35,color: i%6===0?'#d6bd78':'#89a263'});
}
instances(details,terrainMaterial);

const waterUniforms={time:{value:0},tint:{value:new THREE.Color('#5cbfc4')}};
const waterMaterial=new THREE.MeshLambertMaterial({color:'#7ad6d4',emissive:'#256873',emissiveIntensity:.14});
waterMaterial.onBeforeCompile=shader=>{
  shader.uniforms.uTime=waterUniforms.time;
  shader.uniforms.uTint=waterUniforms.tint;
  shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vWorld;');
  shader.vertexShader=shader.vertexShader.replace('#include <worldpos_vertex>',`#include <worldpos_vertex>
    vec4 localPosition = vec4(transformed, 1.0);
    #ifdef USE_INSTANCING
      localPosition = instanceMatrix * localPosition;
    #endif
    vWorld = (modelMatrix * localPosition).xyz;`);
  shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nuniform float uTime; uniform vec3 uTint; varying vec3 vWorld;');
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
    float flow = sin(vWorld.y * 5.0 + vWorld.z * 3.4 + uTime * 7.0);
    float streak = step(0.84, sin(vWorld.x * 12.0 + sin(vWorld.z * 2.0)));
    diffuseColor.rgb = mix(uTint, vec3(0.89,0.98,0.94), (flow * 0.5 + 0.5) * 0.18 + streak * 0.30);`);
};
const water=[];
for(const [coordinate,h] of heights) {
  const [x,z]=coordinate.split(',').map(Number);
  if(h===1&&Math.hypot((x-5)/11,(z-20)/8)<1.02)water.push({x,y:1.55,z,sy:.9});
}
const route=[];
for(let i=0;i<river.length;i++) {
  const {x,z,h}=river[i];
  water.push({x,y:h+.14,z,sx:2.94,sy:.25,sz:1.05});
  route.push(new THREE.Vector3(x,h+.34,z-.5));
  route.push(new THREE.Vector3(x,h+.34,z+.5));
  const next=river[i+1];
  if(next&&h>next.h) {
    water.push({x,y:(h+next.h)/2+.13,z:z+.51,sx:2.94,sy:h-next.h+.25,sz:.24});
    route.push(new THREE.Vector3(x,next.h+.34,z+.51));
  }
}
instances(water,waterMaterial,world,false);
// A small spring pool feeds the first lip of the cascade.
const spring=river[0];
instances([{x:2,y:spring.h+.1,z:-6.25,sx:3,sy:.3,sz:1.5}],waterMaterial,world,false);
const lengths=[0];
for(let i=1;i<route.length;i++)lengths.push(lengths[i-1]+route[i].distanceTo(route[i-1]));
const routeLength=lengths.at(-1);
const flowItems=Array.from({length:200},()=>({x:0,y:0,z:0,sx:.15,sy:.15,sz:.4}));
const flow=instances(flowItems,new THREE.MeshBasicMaterial({color:'#d4f4e9'}),world,false);
flow.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
flow.frustumCulled=false;
const splashSources=river.filter((p,i)=>i>0&&river[i-1].h-p.h>=2).map(p=>new THREE.Vector3(p.x,p.h+.5,p.z-.35));
splashSources.push(new THREE.Vector3(2,2,18));
const spray=instances(Array.from({length:100},()=>({x:0,y:0,z:0})),new THREE.MeshLambertMaterial({color:'#dbf3e7',transparent:true,opacity:.72,depthWrite:false}),world,false);
spray.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
spray.frustumCulled=false;
function animateWater(t) {
  waterUniforms.time.value=t;
  for(let i=0;i<flow.count;i++) {
    const distance=(hash(i,19)*routeLength+t*(4+hash(i,34)*2))%routeLength;
    let segment=1;
    while(lengths[segment]<distance)segment++;
    const a=route[segment-1],b=route[segment];
    const fraction=(distance-lengths[segment-1])/(lengths[segment]-lengths[segment-1]);
    dummy.position.lerpVectors(a,b,fraction);
    dummy.position.x+=(hash(i,5)-.5)*2.65;
    const vertical=Math.abs(a.y-b.y)>.1;
    dummy.scale.set(.09+hash(i,9)*.1,vertical?.6:.08,vertical?.1:.4);
    dummy.rotation.set(0,0,0);
    dummy.updateMatrix();flow.setMatrixAt(i,dummy.matrix);
  }
  flow.instanceMatrix.needsUpdate=true;
  for(let i=0;i<spray.count;i++) {
    const origin=splashSources[i%splashSources.length];
    const age=(t*.8+hash(i,7))%1;
    dummy.position.set(origin.x+(hash(i,1)-.5)*(2+age*3),origin.y+Math.sin(age*Math.PI)*1.7,origin.z+age*1.9+(hash(i,3)-.5));
    dummy.scale.setScalar((1-age)*(.12+hash(i,8)*.2));
    dummy.updateMatrix();spray.setMatrixAt(i,dummy.matrix);
  }
  spray.instanceMatrix.needsUpdate=true;
}

const clouds=new THREE.Group();scene.add(clouds);
const cloudGroups=[];
const cloudMaterial=new THREE.MeshLambertMaterial({color:'#f0f0e6',transparent:true,opacity:.79,depthWrite:false});
const cloudLayout=[[-27,20,-9,1],[-16,23,-20,1.1],[5,21,-20,1.15],[24,19,-11,1.15],[29,18,4,.85],[-26,17,11,.85],[-12,19,9,.85],[15,20,7,.7]];
cloudLayout.forEach(([x,y,z,s],index)=>{
  const group=new THREE.Group();group.position.set(x,y,z);clouds.add(group);
  const puffs=[];
  for(let i=0;i<12;i++)puffs.push({x:(hash(index,i,1)-.5)*14*s,y:(hash(index,i,2)-.5)*2.2,z:(hash(index,i,3)-.5)*5.5*s,sx:(3+hash(index,i,4)*5)*s,sy:1.1+hash(index,i,5)*2,sz:(2.2+hash(index,i,6)*3.1)*s});
  instances(puffs,cloudMaterial,group,false);
  cloudGroups.push({group,x,y,z,phase:index*1.6});
});
// Soft contact shadow, generated locally; the scene needs no image assets.
const shadowCanvas=document.createElement('canvas');shadowCanvas.width=128;shadowCanvas.height=128;
const ctx=shadowCanvas.getContext('2d');const gradient=ctx.createRadialGradient(64,64,8,64,64,64);gradient.addColorStop(0,'rgba(34,68,56,0.27)');gradient.addColorStop(.5,'rgba(34,68,56,0.12)');gradient.addColorStop(1,'rgba(34,68,56,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,128);
const shadow=new THREE.Mesh(new THREE.PlaneGeometry(107,85),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(shadowCanvas),transparent:true,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=-10;scene.add(shadow);
renderer.shadowMap.needsUpdate=true;

const rotateButton=document.querySelector('#rotate');
function setPressed(button,value){button.classList.toggle('active',value);button.setAttribute('aria-pressed',String(value));}
rotateButton.addEventListener('click',()=>{controls.autoRotate=!controls.autoRotate;setPressed(rotateButton,controls.autoRotate);rotateButton.setAttribute('aria-label',controls.autoRotate?'停止自动环绕':'开启自动环绕');});
document.querySelector('#clouds').addEventListener('click',event=>{state.clouds=!state.clouds;clouds.visible=state.clouds;setPressed(event.currentTarget,state.clouds);});
document.querySelector('#theme').addEventListener('click',event=>{
  state.dusk=!state.dusk;setPressed(event.currentTarget,state.dusk);document.body.classList.toggle('dusk',state.dusk);
  event.currentTarget.setAttribute('aria-label',state.dusk?'切换到晨光':'切换到暮色');
  sun.color.set(state.dusk?'#ffb886':'#fff2d3');sun.intensity=state.dusk?2.4:3.3;
  hemi.color.set(state.dusk?'#acb8d7':'#eef7ff');hemi.intensity=state.dusk?1.6:2.1;
  scene.fog.color.set(state.dusk?'#929cac':'#dce8e2');
  waterUniforms.tint.value.set(state.dusk?'#64a7b9':'#5cbfc4');
});
document.querySelector('#reset').addEventListener('click',()=>{controls.autoRotate=false;setPressed(rotateButton,false);rotateButton.setAttribute('aria-label','开启自动环绕');resetView();});
const pauseButton=document.querySelector('#pause');
function updatePause(){setPressed(pauseButton,state.paused);pauseButton.setAttribute('aria-label',state.paused?'播放场景动画':'暂停场景动画');pauseButton.innerHTML=state.paused?'<svg viewBox="0 0 24 24"><path d="m9 5 10 7-10 7Z"/></svg>':'<svg viewBox="0 0 24 24"><path d="M9 5v14M15 5v14"/></svg>';}
pauseButton.addEventListener('click',()=>{state.paused=!state.paused;updatePause();});updatePause();
let resizeTimer;
addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;resetView();},100);});
renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();const box=document.querySelector('#error');box.hidden=false;box.textContent='图形上下文已中断，请刷新页面重新进入山野。';});
const stats={instances:instanceCount,terrainBlocks:blocks.length,trees:vegetation.length/7,drawCalls:0,triangles:0,fps:0,pixelRatio:renderer.getPixelRatio(),frames:[]};
// Read-only diagnostic interface for repeatable browser verification.
window.__VOXEL__={stats,getState:()=>({paused:state.paused,clouds:clouds.visible,dusk:state.dusk,autoRotate:controls.autoRotate,camera:camera.position.toArray(),time:state.time}),river:river.map(p=>({...p}))};
let last=performance.now(),sampleStart=last,frameCount=0;
function frame(now){
  const dt=Math.min((now-last)/1000,.05);last=now;
  if(!state.paused){state.time+=dt;animateWater(state.time);cloudGroups.forEach(({group,x,y,z,phase})=>{group.position.set(x+Math.sin(state.time*.055+phase)*1.9,y+Math.sin(state.time*.12+phase)*.22,z+Math.cos(state.time*.045+phase)*.6);});}
  const auto=controls.autoRotate;controls.autoRotate=auto&&!state.paused;controls.update(dt);controls.autoRotate=auto;
  renderer.render(scene,camera);frameCount++;
  if(now-sampleStart>750){stats.fps=Math.round(frameCount*1000/(now-sampleStart));stats.drawCalls=renderer.info.render.calls;stats.triangles=renderer.info.render.triangles;stats.frames.push(stats.fps);if(stats.frames.length>60)stats.frames.shift();document.querySelector('#fps').textContent=stats.fps;sampleStart=now;frameCount=0;}
}
animateWater(0);
renderer.setAnimationLoop(frame);
document.querySelector('#loading').remove();
